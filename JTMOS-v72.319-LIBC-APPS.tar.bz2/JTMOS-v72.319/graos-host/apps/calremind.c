/* Lightweight GraOS reminder agent. No write access to calendar store.
 * Launched once by GraOS after its IPC server is initialized. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <jtmos/graos.h>
#include <jtmos/graosprotocol.h>
#include <jtmos/console.h>
#include <jtmos/syscall.h>
#include <jtmos/syscallcodes.h>
#include "calendar4_store.h"
#include "calendar4_remind.h"
SYSMEMREQ(APPRAM_256K)
#define ALERT_BUTTON 8897
static CAL4_STORE events;
static unsigned long last_id[CAL4_MAX],last_occ[CAL4_MAX];
typedef struct {int second,minute,hour,day,month,year;int res[10];} SYS_DATE;
static int norm(int y){return y>=1900?y:y>=70?1900+y:2000+y;}
static int get_date(SYS_DATE *d)
{
    return jtmos_syscall7(SYS_getdate,(uintptr_t)d,0,0,0,0,0)>=0 &&
           d->hour>=0 && d->hour<24 && d->minute>=0 && d->minute<60 &&
           cal4_day_number(norm(d->year),d->month,d->day)>0;
}
static void notify(const CAL4_EVENT *e)
{
    int wid,sw=GRAOS_SCREEN_WIDTH,sh=GRAOS_SCREEN_HEIGHT,bpp=32,panel=30,i;
    char message[148];GUICMD ev;
    (void)JtmosGraOSGetScreenInfo(&sw,&sh,&bpp,&panel);
    wid=createWindow(sw>430?(sw-430)/2:0,sh>156?(sh-156)/2:0,430,156,
        "Calendar reminder",GRAOS_WINDOW_HAS_BORDER|GRAOS_WINDOW_AUTOCLEAR);
    if(wid<0)return;
    snprintf(message,sizeof(message),"%02d:%02d  %s",e->hour,e->minute,e->title);
    createLabel(wid,12,15,402,54,8801,0,GRAOS_LABEL_TRANSPARENT,GRAOS_LABEL_ALIGN_LEFT,message);
    createButtonStyled(wid,316,95,410,127,ALERT_BUTTON,GRAOS_BUTTON_STANDARD,"OK");
    refreshWindow(wid);
    /* Bounded wait: reminders must not block the agent forever. */
    for(i=0;i<1800;i++){
        int n=JtmosGraOSPollEvent(wid,&ev);
        if(n<0 || (n>0 && (ev.id==GRAOS_GSID_EXIT ||
           (ev.id==GRAOS_GSID_BUTTON && ev.v[0]==ALERT_BUTTON))))break;
        Sleep(100);SwitchToThread();
    }
    closeWindow(wid);
}
int main(void)
{
    SYS_DATE d;long long last_minute=-1;
    if(connectGraos()!=0)return 1;
    for(;;){
        if(get_date(&d)){
            long long key=(long long)cal4_day_number(norm(d.year),d.month,d.day)*1440+d.hour*60+d.minute;
            if(key!=last_minute){
                int i,rv;
                last_minute=key;
                rv=cal4_load(&events);
                if(rv==CAL4_OK){
                    for(i=0;i<events.count;i++){
                        CAL4_EVENT *e=&events.items[i];
                        int occ=cal4_reminder_due(e,norm(d.year),d.month,d.day,d.hour,d.minute);
                        if(occ>0 && (last_id[i]!=e->id || last_occ[i]!=(unsigned long)occ)){
                            last_id[i]=e->id;last_occ[i]=(unsigned long)occ;
                            notify(e);
                        }
                    }
                }
            }
        }
        Sleep(5000);SwitchToThread();
    }
    return 0;
}
