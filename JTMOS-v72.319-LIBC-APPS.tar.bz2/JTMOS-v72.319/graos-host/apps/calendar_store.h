#ifndef JTMOS_CALENDAR_STORE_H
#define JTMOS_CALENDAR_STORE_H
/* GraOS calendar: versioned, checksummed, two-slot persistence.
 * One event per date is retained for the current UI. An immutable event ID
 * is assigned at creation to support a future multi-event editor. */
#define CALENDAR_EVENT_MAX 128
#define CALENDAR_TITLE_MAX 95

typedef struct {
    unsigned long id;  /* nonzero, stable across edits */
    int year, month, day;
    char title[CALENDAR_TITLE_MAX+1];
} CAL_EVENT;

typedef struct {
    CAL_EVENT items[CALENDAR_EVENT_MAX];
    int count;
    unsigned long generation;
    unsigned long next_id;
    int active_slot; /* -1 = legacy or empty; 0 = A, 1 = B */
    int read_only;   /* set when both slot files are present but corrupt */
} CALENDAR_STORE;

enum {
    CALENDAR_OK=0,
    CALENDAR_ERR_IO=-1,
    CALENDAR_ERR_FULL=-2,
    CALENDAR_ERR_CORRUPT=-3,
    CALENDAR_ERR_BAD_DATE=-4,
    CALENDAR_ERR_BAD_TITLE=-5,
    CALENDAR_ERR_ID_EXHAUSTED=-6
};

int calendar_valid_date(int year,int month,int day);
int calendar_store_load(CALENDAR_STORE *store);
int calendar_store_put(CALENDAR_STORE *store,int year,int month,int day,const char *title);
#endif
