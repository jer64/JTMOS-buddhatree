# JTMOS v72.89 – native GraOS calendar with recurrence, reminders, ICS
APPNAME=calendar
APP_OBJS=calendar.o calendar4_store.o calendar4_ics.o calendar4_remind.o calendar3_store.o calendar_store.o
include app-common.mk
