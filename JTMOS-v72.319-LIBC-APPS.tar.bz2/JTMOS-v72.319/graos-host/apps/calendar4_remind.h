#ifndef JTMOS_CAL4_REMIND_H
#define JTMOS_CAL4_REMIND_H
#include "calendar4_store.h"
/* Return occurrence serial day (positive) if event reminder is due during
 * the supplied local clock minute, else 0. Call at least once a minute. */
int cal4_reminder_due(const CAL4_EVENT *e,int y,int m,int d,int h,int minute);
#endif
