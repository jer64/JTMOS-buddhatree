//----------------------------------------------------------
// taskbar.c - Windows 98 inspired external GraOS taskbar
//----------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <jtmos/graos.h>
#include <jtmos/graosprotocol.h>
#include <jtmos/console.h>
#include <jtmos/process.h>
#include <jtmos/syscall.h>
#include <jtmos/syscallcodes.h>
#include "gui/guiLaunchCompat.h"
#include "calendar_store.h"

SYSMEMREQ(APPRAM_256K)

#define TASKBAR_H 30
#define START_ID 7000
#define MENU_W 228
#define MENU_ROW_H 32
#define MENU_ITEMS 14
#define MENU_H (MENU_ITEMS*MENU_ROW_H+8)
#define MENU_PROGRAMS 7101
#define MENU_FILER 7102
#define MENU_EDITOR 7103
#define MENU_TOP 7104
#define MENU_SETTINGS 7105
#define MENU_RUN 7106
#define MENU_CLOSE 7107
#define MENU_NAVIGATOR 7108
#define MENU_TERMINAL 7109
#define MENU_SMSH 7114
#define MENU_IRC 7110
#define MENU_GAMES 7111
#define MENU_BITCHX 7112
#define MENU_ANGBAND 7113
#define POWER_W 210
#define POWER_H 48
#define POWER_TASKMGR 7201

#define CLOCK_BUTTON_ID 7400
#define CLOCK_LABEL_ID 7401
#define CLOCK_W 84
#define CLOCK_POLL_MS 500UL

#define CAL_W 240
#define CAL_H 172
#define CAL_PREV 7410
#define CAL_NEXT 7411
#define CAL_TITLE 7420
#define CAL_WEEKDAYS 7421
#define CAL_WEEK0 7430
#define CAL_FOOTER 7440
#define CAL_DAY0 7500
#define EDIT_W 340
#define EDIT_H 162
#define EDIT_TITLE 7600
#define EDIT_TEXT 7601
#define EDIT_SAVE 7602
#define EDIT_DELETE 7603
#define EDIT_CANCEL 7604
#define EDIT_STATUS 7605
/* Calendar stage 1: versioned, checksummed dual-slot storage. */
static CALENDAR_STORE cal_store;
static int cal_load_status=0;
#define cal_events cal_store.items
#define cal_event_count cal_store.count

static int find_event(int y,int m,int d)
{
    int i;
    for(i=0;i<cal_event_count;i++)
        if(cal_events[i].year==y && cal_events[i].month==m && cal_events[i].day==d)
            return i;
    return -1;
}

static void load_events(void)
{
    cal_load_status=calendar_store_load(&cal_store);
}

static int store_event(int y,int m,int d,const char *title)
{
    return calendar_store_put(&cal_store,y,m,d,title);
}

static int make_editor(int sw,int sh,int y,int m,int d)
{
    int wid,idx=find_event(y,m,d),x=sw-EDIT_W-4,top=sh-TASKBAR_H-CAL_H-EDIT_H-8;
    char caption[64];
    if(x<0) x=0;
    if(top<0) top=0;
    wid=createWindow(x,top,EDIT_W,EDIT_H,"Calendar event",
                     GRAOS_WINDOW_HAS_BORDER|GRAOS_WINDOW_AUTOCLEAR);
    if(wid<0)return wid;
    snprintf(caption,sizeof(caption),"Tapahtuma %02d.%02d.%04d",d,m,y);
    createLabel(wid,8,10,EDIT_W-16,18,EDIT_TITLE,0,GRAOS_LABEL_TRANSPARENT,
                GRAOS_LABEL_ALIGN_LEFT,caption);
    createTextBox(wid,8,38,EDIT_W-16,26,EDIT_TEXT,95,idx>=0?cal_events[idx].title:"");
    createLabel(wid,8,69,EDIT_W-16,20,EDIT_STATUS,0,GRAOS_LABEL_TRANSPARENT,
                GRAOS_LABEL_ALIGN_LEFT,"Yksi tapahtuma / paiva, enintaan 95 merkkia");
    createButtonStyled(wid,8,104,92,136,EDIT_SAVE,GRAOS_BUTTON_STANDARD,"Tallenna");
    createButtonStyled(wid,104,104,200,136,EDIT_DELETE,GRAOS_BUTTON_STANDARD,"Poista");
    createButtonStyled(wid,212,104,EDIT_W-8,136,EDIT_CANCEL,GRAOS_BUTTON_STANDARD,"Sulje");
    if(cal_load_status==CALENDAR_ERR_CORRUPT)
        setLabelText(wid,EDIT_STATUS,"Kalenteritiedot vioittuneet: vain luku");
    refreshWindow(wid); return wid;
}


static GRAOS_PIXEL *menu_brand_buf=NULL;

static void free_menu_brand(void)
{
    if(menu_brand_buf) { free(menu_brand_buf); menu_brand_buf=NULL; }
}

typedef struct {
    int second,minute,hour,day,month,year;
    int res[10];
} TASKBAR_DATE;

static int normalize_year(int year)
{
    if(year>=1900) return year;
    if(year>=70) return 1900+year;
    if(year>=0) return 2000+year;
    return 2000;
}

static int leap_year(int year)
{
    return ((year%4)==0 && (((year%100)!=0) || ((year%400)==0)));
}

static int month_days(int year,int month)
{
    static const int mdays[12]={31,28,31,30,31,30,31,31,30,31,30,31};
    if(month<1 || month>12) return 30;
    if(month==2 && leap_year(year)) return 29;
    return mdays[month-1];
}

/* Monday=0 ... Sunday=6. */
static int weekday_monday(int year,int month,int day)
{
    static const int t[12]={0,3,2,5,0,3,5,1,4,6,2,4};
    int y=year,dow;
    if(month<1 || month>12 || day<1 || day>31) return 0;
    if(month<3) y--;
    dow=(y+y/4-y/100+y/400+t[month-1]+day)%7; /* Sunday=0 */
    return (dow+6)%7;
}

static int read_wallclock(TASKBAR_DATE *d)
{
    if(!d) return -1;
    if(jtmos_syscall7(SYS_getdate,(uintptr_t)d,0,0,0,0,0)<0) return -1;
    if(d->hour<0 || d->hour>23 || d->minute<0 || d->minute>59 ||
       d->second<0 || d->second>59 || d->month<1 || d->month>12 ||
       d->day<1 || d->year<0 ||
       d->day>month_days(normalize_year(d->year),d->month)) return -1;
    return 0;
}

static void format_clock(char *dst,int cap,const TASKBAR_DATE *d)
{
    if(!dst || cap<=0) return;
    if(!d) { snprintf(dst,(size_t)cap,"--:--"); return; }
    snprintf(dst,(size_t)cap,"%02d:%02d",d->hour,d->minute);
}

static int make_menu(int screen_height)
{
    int wid,y,i;
    GRAOS_PIXEL blue;
    wid=createWindow(3,screen_height-TASKBAR_H-MENU_H,MENU_W,MENU_H,"",
                     GRAOS_WINDOW_HAS_BORDER|GRAOS_WINDOW_AUTOCLEAR|GRAOS_WINDOW_POPUP_MENU);
    if(wid<0) return wid;

    free_menu_brand();
    menu_brand_buf=(GRAOS_PIXEL*)malloc((size_t)27*MENU_H*sizeof(GRAOS_PIXEL));
    if(menu_brand_buf) {
        blue=JtmosMCGAColorToRGBA(BLUE);
        for(i=0;i<27*MENU_H;i++) menu_brand_buf[i]=blue;
        if(addFrameBuffer(wid,menu_brand_buf,0,0,27,MENU_H,GRAOS_BPP,
                          GRAOS_SURFACE_BITMAP,0)<0) free_menu_brand();
    }
    createLabel(wid,5,12,18,12,7301,15,GRAOS_LABEL_TRANSPARENT,GRAOS_LABEL_ALIGN_CENTER,"J");
    createLabel(wid,5,38,18,12,7302,15,GRAOS_LABEL_TRANSPARENT,GRAOS_LABEL_ALIGN_CENTER,"T");
    createLabel(wid,5,64,18,12,7303,15,GRAOS_LABEL_TRANSPARENT,GRAOS_LABEL_ALIGN_CENTER,"M");
    createLabel(wid,5,90,18,12,7304,15,GRAOS_LABEL_TRANSPARENT,GRAOS_LABEL_ALIGN_CENTER,"O");
    createLabel(wid,5,116,18,12,7305,15,GRAOS_LABEL_TRANSPARENT,GRAOS_LABEL_ALIGN_CENTER,"S");
    createLabel(wid,5,148,18,12,7306,15,GRAOS_LABEL_TRANSPARENT,GRAOS_LABEL_ALIGN_CENTER,"9");
    createLabel(wid,5,174,18,12,7307,15,GRAOS_LABEL_TRANSPARENT,GRAOS_LABEL_ALIGN_CENTER,"8");

    y=4;
    createButtonStyled(wid,29,y,MENU_W-5,y+MENU_ROW_H-1,MENU_PROGRAMS,
        GRAOS_BUTTON_MENU|GRAOS_BUTTON_MENU_ARROW|GRAOS_BUTTON_ICON(GRAOS_ICON_PROGRAMS),"Programs");
    y+=MENU_ROW_H;
    createButtonStyled(wid,29,y,MENU_W-5,y+MENU_ROW_H-1,MENU_NAVIGATOR,
        GRAOS_BUTTON_MENU|GRAOS_BUTTON_ICON(GRAOS_ICON_PROGRAMS),"Navigator Browser");
    y+=MENU_ROW_H;
    createButtonStyled(wid,29,y,MENU_W-5,y+MENU_ROW_H-1,MENU_TERMINAL,
        GRAOS_BUTTON_MENU|GRAOS_BUTTON_ICON(GRAOS_ICON_TERMINAL),"Command Prompt");
    y+=MENU_ROW_H;
    createButtonStyled(wid,29,y,MENU_W-5,y+MENU_ROW_H-1,MENU_SMSH,
        GRAOS_BUTTON_MENU|GRAOS_BUTTON_ICON(GRAOS_ICON_TERMINAL),"SMSH Root Console");
    y+=MENU_ROW_H;
    createButtonStyled(wid,29,y,MENU_W-5,y+MENU_ROW_H-1,MENU_FILER,
        GRAOS_BUTTON_MENU|GRAOS_BUTTON_ICON(GRAOS_ICON_FOLDER),"File Manager");
    y+=MENU_ROW_H;
    createButtonStyled(wid,29,y,MENU_W-5,y+MENU_ROW_H-1,MENU_EDITOR,
        GRAOS_BUTTON_MENU|GRAOS_BUTTON_ICON(GRAOS_ICON_EDITOR),"Text Editor");
    y+=MENU_ROW_H;
    createButtonStyled(wid,29,y,MENU_W-5,y+MENU_ROW_H-1,MENU_TOP,
        GRAOS_BUTTON_MENU|GRAOS_BUTTON_ICON(GRAOS_ICON_TASKS),"Task Manager");
    y+=MENU_ROW_H;
    createButtonStyled(wid,29,y,MENU_W-5,y+MENU_ROW_H-1,MENU_SETTINGS,
        GRAOS_BUTTON_MENU|GRAOS_BUTTON_MENU_ARROW|GRAOS_BUTTON_ICON(GRAOS_ICON_SETTINGS),"Settings");
    y+=MENU_ROW_H;
    createButtonStyled(wid,29,y,MENU_W-5,y+MENU_ROW_H-1,MENU_RUN,
        GRAOS_BUTTON_MENU|GRAOS_BUTTON_ICON(GRAOS_ICON_TERMINAL),"Run...");
    y+=MENU_ROW_H;
    createButtonStyled(wid,29,y,MENU_W-5,y+MENU_ROW_H-1,MENU_IRC,
        GRAOS_BUTTON_MENU|GRAOS_BUTTON_ICON(GRAOS_ICON_TERMINAL),"IRC");
    y+=MENU_ROW_H;
    createButtonStyled(wid,29,y,MENU_W-5,y+MENU_ROW_H-1,MENU_GAMES,
        GRAOS_BUTTON_MENU|GRAOS_BUTTON_ICON(GRAOS_ICON_PROGRAMS),"Games (Stunt Car)");
    y+=MENU_ROW_H;
    createButtonStyled(wid,29,y,MENU_W-5,y+MENU_ROW_H-1,MENU_BITCHX,
        GRAOS_BUTTON_MENU|GRAOS_BUTTON_ICON(GRAOS_ICON_TERMINAL),"BitchX IRC");
    y+=MENU_ROW_H;
    createButtonStyled(wid,29,y,MENU_W-5,y+MENU_ROW_H-1,MENU_ANGBAND,
        GRAOS_BUTTON_MENU|GRAOS_BUTTON_ICON(GRAOS_ICON_PROGRAMS),"Angband RPG");
    y+=MENU_ROW_H;
    createButtonStyled(wid,29,y,MENU_W-5,y+MENU_ROW_H-1,MENU_CLOSE,
        GRAOS_BUTTON_MENU|GRAOS_BUTTON_ICON(GRAOS_ICON_POWER),"Close Menu");
    refreshWindow(wid);
    return wid;
}

static int make_power_menu(int screen_width,int screen_height)
{
    int x=6,y=screen_height-TASKBAR_H-POWER_H;
    int wid;
    if(x+POWER_W>screen_width) x=0;
    wid=createWindow(x,y,POWER_W,POWER_H,"",
                     GRAOS_WINDOW_HAS_BORDER|GRAOS_WINDOW_AUTOCLEAR|
                     GRAOS_WINDOW_POPUP_MENU);
    if(wid<0) return wid;
    createButtonStyled(wid,4,4,POWER_W-5,POWER_H-5,POWER_TASKMGR,
        GRAOS_BUTTON_MENU|GRAOS_BUTTON_ICON(GRAOS_ICON_TASKS),"Task Manager");
    refreshWindow(wid);
    return wid;
}

static void render_calendar(int wid,int year,int month,const TASKBAR_DATE *today)
{
    static const char *months[12]={
        "Tammikuu","Helmikuu","Maaliskuu","Huhtikuu","Toukokuu","Kesakuu",
        "Heinakuu","Elokuu","Syyskuu","Lokakuu","Marraskuu","Joulukuu"
    };
    char text[64]; int i,day,first=weekday_monday(year,month,1);
    int ty=0,tm=0,td=0,idx;
    if(today){ ty=normalize_year(today->year);tm=today->month;td=today->day; }
    snprintf(text,sizeof(text),"%s %d",months[month-1],year);
    setLabelText(wid,CAL_TITLE,text);
    for(i=0;i<42;i++) {
        day=i-first+1;
        if(day<1 || day>month_days(year,month)) text[0]=0;
        else {
            idx=find_event(year,month,day);
            if(idx>=0) snprintf(text,sizeof(text),"%d*",day);
            else if(year==ty && month==tm && day==td) snprintf(text,sizeof(text),"[%d]",day);
            else snprintf(text,sizeof(text),"%d",day);
        }
        /* Day buttons are refreshed by rebuilding the popup. */
    }
    if(today) snprintf(text,sizeof(text),"Tanaan %d.%d.%d  (* tapahtuma)",td,tm,ty);
    else snprintf(text,sizeof(text),"* tapahtuma");
    setLabelText(wid,CAL_FOOTER,text);
    refreshWindow(wid);
}

static int make_calendar(int screen_width,int screen_height,int *year,int *month,const TASKBAR_DATE *today)
{
    int x=screen_width-CAL_W-4,y=screen_height-TASKBAR_H-CAL_H-2,wid,i,day,first,idx;
    char label[12];
    if(x<0) x=0;
    if(y<0) y=0;
    wid=createWindow(x,y,CAL_W,CAL_H,"",
        GRAOS_WINDOW_HAS_BORDER|GRAOS_WINDOW_AUTOCLEAR|GRAOS_WINDOW_POPUP_MENU);
    if(wid<0)return wid;
    createButtonStyled(wid,4,4,28,25,CAL_PREV,GRAOS_BUTTON_STANDARD,"<");
    createButtonStyled(wid,CAL_W-29,4,CAL_W-5,25,CAL_NEXT,GRAOS_BUTTON_STANDARD,">");
    createLabel(wid,32,8,CAL_W-64,12,CAL_TITLE,0,GRAOS_LABEL_TRANSPARENT,
        GRAOS_LABEL_ALIGN_CENTER,"");
    createLabel(wid,8,29,CAL_W-16,12,CAL_WEEKDAYS,0,GRAOS_LABEL_TRANSPARENT,
        GRAOS_LABEL_ALIGN_CENTER,"Ma    Ti    Ke    To    Pe    La    Su");
    first=weekday_monday(*year,*month,1);
    for(i=0;i<42;i++) {
        day=i-first+1;
        label[0]=0;
        if(day>=1 && day<=month_days(*year,*month)) {
            idx=find_event(*year,*month,day);
            if(idx>=0) snprintf(label,sizeof(label),"%d*",day);
            else if(today && *year==normalize_year(today->year) && *month==today->month && day==today->day)
                snprintf(label,sizeof(label),"[%d]",day);
            else snprintf(label,sizeof(label),"%d",day);
        }
        createButtonStyled(wid,5+(i%7)*33,43+(i/7)*17,36+(i%7)*33,
                           60+(i/7)*17,CAL_DAY0+i,GRAOS_BUTTON_STANDARD,label);
    }
    createLabel(wid,5,149,CAL_W-10,12,CAL_FOOTER,0,GRAOS_LABEL_TRANSPARENT,
        GRAOS_LABEL_ALIGN_CENTER,"");
    render_calendar(wid,*year,*month,today);
    return wid;
}

static void shift_calendar_month(int delta,int *year,int *month)
{
    if(!year || !month) return;
    if(delta<0 && *year<=1900 && *month==1) return;
    if(delta>0 && *year>=9999 && *month==12) return;
    *month+=delta;
    if(*month<1) { *month=12; (*year)--; }
    else if(*month>12) { *month=1; (*year)++; }
}

static void menu_action(int id)
{
    switch(id) {
    case MENU_BITCHX: graos_bgexec_command("/bin/bitchxfull.bin","/"); break;
    case MENU_ANGBAND: graos_bgexec_command("/bin/angband.bin","/"); break;
    case MENU_IRC: graos_bgexec_command("/bin/irc.bin","/"); break;
    case MENU_GAMES: graos_bgexec_command("/bin/stunt.bin","/"); break;
    case MENU_NAVIGATOR: graos_bgexec_command("/bin/navigator.bin","/"); break;
    case MENU_TERMINAL: graos_bgexec_command("/bin/terminal.bin","/"); break;
    case MENU_SMSH: graos_bgexec_command("/bin/smshgui.bin","/"); break;
    case MENU_PROGRAMS: graos_bgexec_command("/bin/launcher.bin","/"); break;
    case MENU_FILER: graos_bgexec_command("/bin/filer.bin","/"); break;
    case MENU_EDITOR: graos_bgexec_command("/bin/terminal.bin /bin/edit.bin","/"); break;
    case MENU_TOP: graos_bgexec_command("/bin/terminal.bin /bin/top.bin","/"); break;
    case MENU_SETTINGS: graos_bgexec_command("/bin/controlpanel.bin","/"); break;
    case MENU_RUN: graos_bgexec_command("/bin/terminal.bin","/"); break;
    default: break;
    }
}

static void toggle_menu(int *menu_wid,int screen_height)
{
    if(!menu_wid) return;
    if(*menu_wid>=0) {
        closeWindow(*menu_wid);
        *menu_wid=-1;
        free_menu_brand();
    } else *menu_wid=make_menu(screen_height);
}

static void close_popup(int *wid)
{
    if(wid && *wid>=0) { closeWindow(*wid); *wid=-1; }
}

static int mainLoop(int wid,int screen_width,int screen_height)
{
    GUICMD ev;
    TASKBAR_DATE now_date,last_date;
    int er,mer,menu_wid=-1,power_wid=-1,cal_wid=-1,edit_wid=-1;
    int edit_year=0,edit_month=0,edit_day=0;
    char event_title[96];
    int version_x,clock_x,cal_year=2000,cal_month=1,have_date=0,last_minute=-1;
    unsigned long last_clock_tick=0,now_tick;
    char clock_text[16];

    load_events();
    if(createButtonStyled(wid,3,4,66,TASKBAR_H-4,START_ID,
                          GRAOS_BUTTON_START,"Start")<0) return -1;

    clock_x=screen_width-CLOCK_W-4;
    if(clock_x<72) clock_x=72;
    createButtonStyled(wid,clock_x,4,screen_width-4,TASKBAR_H-4,CLOCK_BUTTON_ID,
                       GRAOS_BUTTON_SUNKEN,"");
    createLabel(wid,clock_x+2,8,CLOCK_W-4,14,CLOCK_LABEL_ID,0,GRAOS_LABEL_TRANSPARENT,
                GRAOS_LABEL_ALIGN_CENTER,"--:--");

    version_x=clock_x-124;
    if(version_x>=72)
        createLabel(wid,version_x,8,120,14,7200,0,GRAOS_LABEL_TRANSPARENT,
                    GRAOS_LABEL_ALIGN_CENTER,"JTMOS / GraOS V58");

    if(read_wallclock(&now_date)==0) {
        have_date=1;
        last_date=now_date;
        last_minute=now_date.minute;
        cal_year=normalize_year(now_date.year);
        cal_month=now_date.month;
        format_clock(clock_text,sizeof(clock_text),&now_date);
        setLabelText(wid,CLOCK_LABEL_ID,clock_text);
    }
    refreshWindow(wid);

    for(;;) {
        while((er=JtmosGraOSPollEvent(wid,&ev))>0) {
            if(ev.id==GRAOS_GSID_EXIT) {
                close_popup(&edit_wid); close_popup(&cal_wid); close_popup(&power_wid);
                close_popup(&menu_wid); free_menu_brand();
                return 1;
            }
            if(ev.id==GRAOS_GSID_STARTMENU) {
                close_popup(&edit_wid); close_popup(&power_wid); close_popup(&cal_wid);
                toggle_menu(&menu_wid,screen_height);
                continue;
            }
            if(ev.id==GRAOS_GSID_POWERMENU) {
                if(menu_wid>=0) { closeWindow(menu_wid); menu_wid=-1; free_menu_brand(); }
                close_popup(&cal_wid);
                if(power_wid>=0) close_popup(&power_wid);
                else power_wid=make_power_menu(screen_width,screen_height);
                continue;
            }
            if(ev.id==GRAOS_GSID_CLOSEMENUS) {
                if(menu_wid>=0) { closeWindow(menu_wid); menu_wid=-1; free_menu_brand(); }
                close_popup(&edit_wid); close_popup(&power_wid); close_popup(&cal_wid);
                continue;
            }
            if(ev.id==GRAOS_GSID_BUTTON && ev.v[0]==START_ID) {
                close_popup(&edit_wid); close_popup(&power_wid); close_popup(&cal_wid);
                toggle_menu(&menu_wid,screen_height);
                continue;
            }
            if(ev.id==GRAOS_GSID_BUTTON &&
               (ev.v[0]==CLOCK_BUTTON_ID || ev.v[0]==CLOCK_LABEL_ID)) {
                if(menu_wid>=0) { closeWindow(menu_wid); menu_wid=-1; free_menu_brand(); }
                close_popup(&power_wid);
                if(cal_wid>=0) close_popup(&cal_wid);
                else {
                    if(read_wallclock(&now_date)==0) {
                        have_date=1; last_date=now_date;
                        cal_year=normalize_year(now_date.year); cal_month=now_date.month;
                    }
                    cal_wid=make_calendar(screen_width,screen_height,&cal_year,&cal_month,
                                          have_date?&last_date:NULL);
                }
                continue;
            }
        }
        if(er<0) return -2;

        if(menu_wid>=0) {
            while((mer=JtmosGraOSPollEvent(menu_wid,&ev))>0) {
                if(ev.id==GRAOS_GSID_EXIT) { menu_wid=-1; free_menu_brand(); break; }
                if(ev.id==GRAOS_GSID_KEYPRESSED && ev.v[0]==JKEY_ESC) {
                    closeWindow(menu_wid); menu_wid=-1; free_menu_brand(); break;
                }
                if(ev.id==GRAOS_GSID_BUTTON) {
                    int id=ev.v[0];
                    closeWindow(menu_wid); menu_wid=-1; free_menu_brand();
                    if(id!=MENU_CLOSE) menu_action(id);
                    break;
                }
            }
            if(mer<0) { menu_wid=-1; free_menu_brand(); }
        }
        if(power_wid>=0) {
            while((mer=JtmosGraOSPollEvent(power_wid,&ev))>0) {
                if(ev.id==GRAOS_GSID_EXIT) { power_wid=-1; break; }
                if(ev.id==GRAOS_GSID_KEYPRESSED && ev.v[0]==JKEY_ESC) {
                    closeWindow(power_wid); power_wid=-1; break;
                }
                if(ev.id==GRAOS_GSID_BUTTON) {
                    int id=ev.v[0];
                    closeWindow(power_wid); power_wid=-1;
                    if(id==POWER_TASKMGR)
                        graos_bgexec_command("/bin/terminal.bin /bin/top.bin","/");
                    break;
                }
            }
            if(mer<0) power_wid=-1;
        }
        if(cal_wid>=0) {
            while((mer=JtmosGraOSPollEvent(cal_wid,&ev))>0) {
                if(ev.id==GRAOS_GSID_EXIT) { cal_wid=-1; break; }
                if(ev.id==GRAOS_GSID_KEYPRESSED && ev.v[0]==JKEY_ESC) {
                    closeWindow(cal_wid); cal_wid=-1; break;
                }
                if(ev.id==GRAOS_GSID_BUTTON) {
                    if(ev.v[0]==CAL_PREV || ev.v[0]==CAL_NEXT) {
                        shift_calendar_month(ev.v[0]==CAL_PREV?-1:1,&cal_year,&cal_month);
                        close_popup(&edit_wid); close_popup(&cal_wid);
                        cal_wid=make_calendar(screen_width,screen_height,&cal_year,&cal_month,
                                              have_date?&last_date:NULL);
                    } else if(ev.v[0]>=CAL_DAY0 && ev.v[0]<CAL_DAY0+42) {
                        int day=ev.v[0]-CAL_DAY0-weekday_monday(cal_year,cal_month,1)+1;
                        if(day>=1 && day<=month_days(cal_year,cal_month)) {
                            close_popup(&edit_wid);
                            edit_year=cal_year;edit_month=cal_month;edit_day=day;
                            edit_wid=make_editor(screen_width,screen_height,edit_year,edit_month,edit_day);
                        }
                    }
                }
            }
            if(mer<0) cal_wid=-1;
        }

        if(edit_wid>=0) {
            while((mer=JtmosGraOSPollEvent(edit_wid,&ev))>0) {
                int action=-1,rv;
                if(ev.id==GRAOS_GSID_EXIT) { edit_wid=-1; break; }
                if(ev.id==GRAOS_GSID_KEYPRESSED && ev.v[0]==JKEY_ESC) action=EDIT_CANCEL;
                if(ev.id==GRAOS_GSID_BUTTON) action=ev.v[0];
                if(ev.id==GRAOS_GSID_TEXTBOX_ENTER && ev.v[0]==EDIT_TEXT) action=EDIT_SAVE;
                if(action==EDIT_CANCEL) { close_popup(&edit_wid); break; }
                if(action!=EDIT_SAVE && action!=EDIT_DELETE) continue;
                event_title[0]=0;
                if(action==EDIT_SAVE) {
                    if(getTextBoxText(edit_wid,EDIT_TEXT,event_title,sizeof(event_title))<0) {
                        setLabelText(edit_wid,EDIT_STATUS,"Tekstin lukeminen epaonnistui"); continue;
                    }
                    /* Keep disk format one event per line. */
                    if(strchr(event_title,'\n') || strchr(event_title,'\r')) {
                        setLabelText(edit_wid,EDIT_STATUS,"Rivinvaihto ei ole sallittu"); continue;
                    }
                }
                rv=store_event(edit_year,edit_month,edit_day,event_title);
                if(rv!=0) {
                    setLabelText(edit_wid,EDIT_STATUS,rv==CALENDAR_ERR_FULL?"Kalenteri on taynna":
                            rv==CALENDAR_ERR_BAD_DATE?"Virheellinen paivamaara":
                            rv==CALENDAR_ERR_BAD_TITLE?"Virheellinen otsikko":
                            rv==CALENDAR_ERR_CORRUPT?"Tietokanta vioittunut / vain luku":
                            "Tallennus epaonnistui");
                    continue;
                }
                close_popup(&edit_wid);
                if(cal_wid>=0) {
                    close_popup(&cal_wid);
                    cal_wid=make_calendar(screen_width,screen_height,&cal_year,&cal_month,
                                          have_date?&last_date:NULL);
                }
                break;
            }
            if(mer<0) edit_wid=-1;
        }

        now_tick=GetTickCount();
        if(last_clock_tick==0 || (unsigned long)(now_tick-last_clock_tick)>=CLOCK_POLL_MS) {
            last_clock_tick=now_tick;
            if(read_wallclock(&now_date)==0) {
                if(!have_date) {
                    have_date=1;
                    cal_year=normalize_year(now_date.year);
                    cal_month=now_date.month;
                    format_clock(clock_text,sizeof(clock_text),&now_date);
                    setLabelText(wid,CLOCK_LABEL_ID,clock_text);
                    last_minute=now_date.minute;
                    last_date=now_date;
                    if(cal_wid>=0)
                        render_calendar(cal_wid,cal_year,cal_month,&now_date);
                } else {
                    if(now_date.minute!=last_minute || now_date.hour!=last_date.hour) {
                        format_clock(clock_text,sizeof(clock_text),&now_date);
                        setLabelText(wid,CLOCK_LABEL_ID,clock_text);
                        last_minute=now_date.minute;
                    }
                    if(now_date.day!=last_date.day || now_date.month!=last_date.month ||
                       now_date.year!=last_date.year) {
                        if(cal_wid>=0)
                            render_calendar(cal_wid,cal_year,cal_month,&now_date);
                    }
                    last_date=now_date;
                }
            }
        }

        Sleep(40);
        SwitchToThread();
    }
}

int main(int argc,char **argv)
{
    int wid,screen_width,screen_height,bpp,panel_height,rv;
    (void)argc; (void)argv;

    rv=connectGraos();
    if(rv!=0) return 1;
    screen_width=GRAOS_SCREEN_WIDTH;
    screen_height=GRAOS_SCREEN_HEIGHT;
    bpp=GRAOS_SCREEN_BPP;
    panel_height=GRAOS_SCREEN_PANEL_HEIGHT;
    rv=JtmosGraOSGetScreenInfo(&screen_width,&screen_height,&bpp,&panel_height);
    if(rv<0) {
        screen_width=GRAOS_SCREEN_WIDTH;
        screen_height=GRAOS_SCREEN_HEIGHT;
    }
    if(screen_width<160 || screen_height<TASKBAR_H+CAL_H+4) return 2;

    wid=createWindow(0,screen_height-TASKBAR_H,screen_width,TASKBAR_H,"",
                     GRAOS_WINDOW_TASKBAR|GRAOS_WINDOW_AUTOCLEAR);
    if(wid<0) return 3;

    rv=mainLoop(wid,screen_width,screen_height);
    if(rv==0 || rv==-1) closeWindow(wid);
    return rv<0?4:0;
}
