#ifndef JTMOS_CALENDAR4_ICS_H
#define JTMOS_CALENDAR4_ICS_H
#include "calendar4_store.h"
/* Floating/local iCalendar only. No TZID/UTC, no COUNT/UNTIL/EXDATE; reject
 * unsupported recurrence instead of importing wrong appointments. */
#define CAL4_ICS_IMPORT "/calendar-import.ics"
#define CAL4_ICS_EXPORT "/calendar-export.ics"
int cal4_ics_import(CAL4_STORE *store,const char *path,int *number);
int cal4_ics_export(const CAL4_STORE *store,const char *path);
#endif
