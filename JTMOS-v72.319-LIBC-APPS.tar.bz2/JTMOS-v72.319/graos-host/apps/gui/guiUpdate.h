#ifndef __INCLUDED_GUIUPDATE_H__
#define __INCLUDED_GUIUPDATE_H__
#include "graos.h"
int guiUpdate(VMODE *v);
/* Optional, EXCLUSIVE damage hint. Only use when all other pixels are
 * guaranteed unchanged; otherwise call graos_damage_reset(). */
void graos_damage_region(int x,int y,int w,int h);
void graos_damage_reset(void);
void graos_delta_stats(unsigned long *full,unsigned long *partial,
                       unsigned long *noop,unsigned long *rects,
                       unsigned long *pixels);
void graos_cursor_moved(int x,int y);
unsigned long graos_cursor_move_count(void);
int graos_present_cursor_erase(VMODE *v,int oldx,int oldy);
int graos_present_cursor_finish(VMODE *v,int x,int y);
#endif
