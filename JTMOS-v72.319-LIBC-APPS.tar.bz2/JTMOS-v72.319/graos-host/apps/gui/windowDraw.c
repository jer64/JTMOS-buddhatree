#include "windowDraw.h"
#include "wdb.h"
#include "guiRect.h"
#include "guifont.h"
#include "guiLabel.h"
#include "guiBitmap.h"
#include "guiBlit.h"
#include "guiTextBox.h"
#include "egafont_data.h"
#include "guiChrome.h"
#include "guiWelcome.h"
#define GRAOS_TERM_COLS 80
#define GRAOS_TERM_ROWS 25
#define GRAOS_TERM_BYTES (GRAOS_TERM_COLS*GRAOS_TERM_ROWS*2)
static BYTE terminal_snapshot[GRAOS_TERM_BYTES];
/* Detect terminal content changes without repainting every 50 ms.
 * A separate snapshot per window avoids cross-terminal false positives.
 * Polling is bounded: 32 windows * 4000 bytes, once per 50 ms. */
void graos_window_cache_invalidate(WINDOW *w);
typedef struct {
    int window_id,terminal_id,cursor,valid;
    BYTE bytes[GRAOS_TERM_BYTES];
} TERMINAL_POLL_CACHE;
static TERMINAL_POLL_CACHE terminal_poll[N_MAX_WINDOWS];
static unsigned long terminal_poll_checks,terminal_poll_changes,terminal_dirty_cells;
int graos_terminal_poll_changed(void)
{
    int i,changed=0;
    BYTE scratch[GRAOS_TERM_BYTES];
    for(i=0;i<N_MAX_WINDOWS;i++) {
        WINDOW *w=&wdb.w[i];
        TERMINAL_POLL_CACHE *c=&terminal_poll[i];
        int cursor;
        if(w->isfree || w->minimized || !w->root.visible ||
           w->fb_type!=GRAOS_SURFACE_TERMINAL || w->terminal_id<0) {
            c->valid=0;
            continue;
        }
        if(CopyThreadTerminal(w->terminal_id,scratch)!=0) continue;
        cursor=GetCursorLocation(w->terminal_id);
        terminal_poll_checks++;
        if(!c->valid || c->window_id!=w->id ||
           c->terminal_id!=w->terminal_id || c->cursor!=cursor ||
           memcmp(c->bytes,scratch,GRAOS_TERM_BYTES)!=0) {
            {
                int cell;
                if(!c->valid || c->terminal_id!=w->terminal_id) {
                    terminal_dirty_cells+=GRAOS_TERM_COLS*GRAOS_TERM_ROWS;
                } else {
                    for(cell=0;cell<GRAOS_TERM_COLS*GRAOS_TERM_ROWS;cell++) {
                        int off=cell*2;
                        if(c->bytes[off]!=scratch[off] ||
                           c->bytes[off+1]!=scratch[off+1])terminal_dirty_cells++;
                    }
                    if(c->cursor!=cursor)terminal_dirty_cells+=2;
                }
            }
            memcpy(c->bytes,scratch,GRAOS_TERM_BYTES);
            c->window_id=w->id;
            c->terminal_id=w->terminal_id;
            c->cursor=cursor;
            c->valid=1;
            graos_window_cache_invalidate(w);
            terminal_poll_changes++;
            changed=1;
        }
    }
    return changed;
}
void graos_terminal_poll_stats(unsigned long *checks,unsigned long *changes)
{
    if(checks)*checks=terminal_poll_checks;
    if(changes)*changes=terminal_poll_changes;
}

void graos_terminal_dirty_cell_stats(unsigned long *cells)
{
    if(cells)*cells=terminal_dirty_cells;
}

static void draw_ega_glyph(VMODE*v,int x,int y,BYTE ch,BYTE attr)
{int yy,xx;BYTE bits,fg=(BYTE)(attr&15),bg=(BYTE)((attr>>4)&7);const BYTE*glyph=&graos_ega_font[((unsigned int)ch)*EGA_FONT_HEIGHT];GRAOS_PIXEL fgp=graosIndexToPixel(fg),bgp=graosIndexToPixel(bg);if(!v||!v->buf)return;for(yy=0;yy<EGA_FONT_HEIGHT;yy++){bits=glyph[yy];for(xx=0;xx<EGA_FONT_WIDTH;xx++){int dx=x+xx,dy=y+yy;if(dx>=0&&dx<v->width&&dy>=0&&dy<v->height)v->buf[dy*v->width+dx]=(bits&(0x80>>xx))?fgp:bgp;}}}
static void draw_terminal(VMODE*v,WINDOW*w)
{int row,col,cols,rows,base_x,base_y,cur,cx,cy,client_w,client_h,max_cols,max_rows;if(!v||!w||w->terminal_id<0)return;if(CopyThreadTerminal(w->terminal_id,terminal_snapshot)!=0)return;base_x=w->x+w->fb_x;base_y=w->y+w->captionHeight+w->fb_y;client_w=w->width-w->fb_x;client_h=w->height-w->captionHeight-w->fb_y;if(client_w<=0||client_h<=0)return;fillRect(v,base_x,base_y,base_x+client_w-1,base_y+client_h-1,0);cols=w->fb_width;rows=w->fb_height;if(cols>80)cols=80;if(rows>25)rows=25;max_cols=client_w/EGA_FONT_WIDTH;max_rows=client_h/EGA_FONT_HEIGHT;if(cols>max_cols)cols=max_cols;if(rows>max_rows)rows=max_rows;if(cols<=0||rows<=0)return;for(row=0;row<rows;row++)for(col=0;col<cols;col++){int off=(row*80+col)*2;BYTE ch=terminal_snapshot[off],attr=terminal_snapshot[off+1];if(attr==0)attr=7;draw_ega_glyph(v,base_x+col*EGA_FONT_WIDTH,base_y+row*EGA_FONT_HEIGHT,ch,attr);}cur=GetCursorLocation(w->terminal_id);cx=cur&255;cy=(cur>>8)&255;if(cx>=0&&cx<cols&&cy>=0&&cy<rows){int px=base_x+cx*EGA_FONT_WIDTH,py=base_y+cy*EGA_FONT_HEIGHT+EGA_FONT_HEIGHT-2;fillRect(v,px,py,px+EGA_FONT_WIDTH-1,py+1,15);}}
static void draw_framebuffer(VMODE*v,WINDOW*w)
{
 int cw,ch,dx,dy,client_y,dw,dh;
 if(!v||!w||!w->framebuffer||w->fb_bpp!=32)return;
 client_y=w->captionHeight;cw=w->fb_width;ch=w->fb_height;
 dx=w->x+w->fb_x;dy=w->y+client_y+w->fb_y;
 /* Fit the native client framebuffer to the current client rectangle. A
  * resize must not change the producer's allocation or its stride. */
 dw=w->width-w->fb_x-3;dh=w->height-client_y-w->fb_y-4;
 if(cw<=0||ch<=0||w->fb_stride<cw||dw<=0||dh<=0)return;
 if(cw==dw&&ch==dh)
     guiBlit(v,dx,dy,cw,ch,w->framebuffer,w->fb_stride,GRAOS_BLIT_OPAQUE);
 else guiBlitBilinear(v,dx,dy,dw,dh,w->framebuffer,cw,ch,w->fb_stride,GRAOS_BLIT_OPAQUE);
}
static void buttonDraw(VMODE*v,WINDOW*w,BUTTON*b){if(!v||!w||!b||!b->widget.visible)return;guiChromeDrawButton(v,w,b);}

/* A GraOS window is opaque: guiChromeDrawWindow() fills its complete rectangle
 * before the client surface and child controls are painted.  This lets the
 * compositor reject a lower window when higher visible windows cover every
 * pixel of its on-screen rectangle. */
static int window_drawable(VMODE *v,const WINDOW *w)
{
    int x2,y2;
    if(!v||!w||w->isfree||w->minimized||!w->root.visible)return 0;
    if(w->width<=0||w->height<=0)return 0;
    x2=w->x+w->width;
    y2=w->y+w->height;
    if(x2<=0||y2<=0||w->x>=v->width||w->y>=v->height)return 0;
    return 1;
}

static int clipped_window_rect(VMODE *v,const WINDOW *w,int *x1,int *y1,int *x2,int *y2)
{
    int ax,ay,bx,by;
    if(!window_drawable(v,w))return 0;
    ax=w->x;ay=w->y;bx=w->x+w->width;by=w->y+w->height;
    if(ax<0)ax=0;if(ay<0)ay=0;if(bx>v->width)bx=v->width;if(by>v->height)by=v->height;
    if(ax>=bx||ay>=by)return 0;
    if(x1)*x1=ax;if(y1)*y1=ay;if(x2)*x2=bx;if(y2)*y2=by;
    return 1;
}

/* Exact rectangle-union test without heap allocation.  Y edges split the
 * target into horizontal bands; within each band the X intervals of every
 * higher opaque window are merged.  Only a completely covered window is
 * culled.  Partially visible windows are still painted normally. */
static int window_fully_occluded(VMODE *v,const WINDOW *target)
{
    int tx1,ty1,tx2,ty2;
    int yedge[2+N_MAX_WINDOWS*2],ny=0;
    int i,j,k;
    if(!clipped_window_rect(v,target,&tx1,&ty1,&tx2,&ty2))return 1;
    yedge[ny++]=ty1;yedge[ny++]=ty2;
    for(i=0;i<wdb.n_windows;i++){
        WINDOW *c=&wdb.w[i];int cx1,cy1,cx2,cy2;
        if(c==target||c->z<=target->z||!clipped_window_rect(v,c,&cx1,&cy1,&cx2,&cy2))continue;
        if(cx2<=tx1||cx1>=tx2||cy2<=ty1||cy1>=ty2)continue;
        if(cy1<ty1)cy1=ty1;if(cy2>ty2)cy2=ty2;
        yedge[ny++]=cy1;yedge[ny++]=cy2;
    }
    for(i=1;i<ny;i++){int t=yedge[i];j=i-1;while(j>=0&&yedge[j]>t){yedge[j+1]=yedge[j];j--;}yedge[j+1]=t;}
    for(i=0;i<ny-1;i++){
        int y0=yedge[i],y1=yedge[i+1],cursor=tx1;
        int ix1[N_MAX_WINDOWS],ix2[N_MAX_WINDOWS],n=0;
        if(y1<=y0)continue;
        for(j=0;j<wdb.n_windows;j++){
            WINDOW *c=&wdb.w[j];int cx1,cy1,cx2,cy2;
            if(c==target||c->z<=target->z||!clipped_window_rect(v,c,&cx1,&cy1,&cx2,&cy2))continue;
            if(cy1>y0||cy2<y1||cx2<=tx1||cx1>=tx2)continue;
            if(cx1<tx1)cx1=tx1;if(cx2>tx2)cx2=tx2;
            if(n<N_MAX_WINDOWS){ix1[n]=cx1;ix2[n]=cx2;n++;}
        }
        for(j=1;j<n;j++){
            int a=ix1[j],b=ix2[j];k=j-1;
            while(k>=0&&ix1[k]>a){ix1[k+1]=ix1[k];ix2[k+1]=ix2[k];k--;}
            ix1[k+1]=a;ix2[k+1]=b;
        }
        for(j=0;j<n&&cursor<tx2;j++){
            if(ix1[j]>cursor)break;
            if(ix2[j]>cursor)cursor=ix2[j];
        }
        if(cursor<tx2)return 0;
    }
    return 1;
}

void windowDraw(VMODE*v,WINDOW*w)
{
    int i;
    if(!window_drawable(v,w))return;
    guiChromeDrawWindow(v,w);
    if(w->type&GRAOS_WINDOW_WELCOME_STYLE)guiDrawWelcomeDecor(v,w);
    if(w->fb_type==GRAOS_SURFACE_TERMINAL)draw_terminal(v,w);else draw_framebuffer(v,w);
    if(w->qmsg[0])DrawText(v,w->qmsg,w->x+8,w->y+w->captionHeight+12,0,-1);
    for(i=0;i<w->n_bitmaps;i++)if(w->bitmap[i].widget.visible)guiDrawBitmap(v,w,&w->bitmap[i]);
    for(i=0;i<w->n_labels;i++)if(w->label[i].widget.visible)guiDrawLabel(v,w,&w->label[i]);
    for(i=0;i<w->n_textboxes;i++)if(w->textbox[i].widget.visible)guiDrawTextBox(v,w,&w->textbox[i]);
    for(i=0;i<w->n_buttons;i++)if(w->button[i].widget.visible)buttonDraw(v,w,&w->button[i]);
    w->root.flags&=~GRAOS_WIDGET_DIRTY;
}


/* v72.131: Each window owns a persistent, local-coordinate bitmap.
 * Moving or restacking a window blits its cached pixels; only content,
 * dimensions, theme or active state invalidate the window surface. */
typedef struct {
    GRAOS_PIXEL *pixels;
    int id,width,height,active,theme;
    unsigned long signature;
    int valid;
} WINDOW_BITMAP_CACHE;
static WINDOW_BITMAP_CACHE window_cache[N_MAX_WINDOWS];
static unsigned long window_cache_renders,window_cache_blits;
/* Explicit invalidation for client/widget updates; geometry and z-order are
 * intentionally not part of the cache key. */
void graos_window_cache_invalidate(WINDOW *w)
{
    int i;
    if(!w)return;
    for(i=0;i<N_MAX_WINDOWS;i++)
        if(window_cache[i].pixels && window_cache[i].id==w->id)
            window_cache[i].valid=0;
}
void graos_window_cache_release(WINDOW *w)
{
    int i;
    if(!w)return;
    for(i=0;i<N_MAX_WINDOWS;i++)
        if(window_cache[i].pixels && window_cache[i].id==w->id){
            free(window_cache[i].pixels);
            memset(&window_cache[i],0,sizeof(window_cache[i]));
        }
}


static unsigned long hash_bytes(unsigned long h,const void *data,unsigned long n)
{
    const unsigned char *p=(const unsigned char*)data;
    while(n--)h=(h^(unsigned long)*p++)*16777619UL;
    return h;
}
static unsigned long content_signature(const WINDOW *w)
{
    unsigned long h=2166136261UL;
    int i;
    /* Deliberately exclude x/y/z: these change only composition. */
    h=hash_bytes(h,&w->type,sizeof(w->type));
    h=hash_bytes(h,&w->width,sizeof(w->width));
    h=hash_bytes(h,&w->height,sizeof(w->height));
    h=hash_bytes(h,&w->captionHeight,sizeof(w->captionHeight));
    h=hash_bytes(h,w->caption,sizeof(w->caption));
    h=hash_bytes(h,w->qmsg,sizeof(w->qmsg));
    h=hash_bytes(h,&w->fb_type,sizeof(w->fb_type));
    h=hash_bytes(h,&w->fb_x,sizeof(w->fb_x));
    h=hash_bytes(h,&w->fb_y,sizeof(w->fb_y));
    h=hash_bytes(h,&w->fb_width,sizeof(w->fb_width));
    h=hash_bytes(h,&w->fb_height,sizeof(w->fb_height));
    h=hash_bytes(h,&w->fb_stride,sizeof(w->fb_stride));
    h=hash_bytes(h,&w->n_buttons,sizeof(w->n_buttons));
    h=hash_bytes(h,&w->n_labels,sizeof(w->n_labels));
    h=hash_bytes(h,&w->n_textboxes,sizeof(w->n_textboxes));
    h=hash_bytes(h,&w->n_bitmaps,sizeof(w->n_bitmaps));
    for(i=0;i<w->n_buttons;i++)h=hash_bytes(h,&w->button[i],sizeof(BUTTON));
    for(i=0;i<w->n_labels;i++)h=hash_bytes(h,&w->label[i],sizeof(LABEL));
    for(i=0;i<w->n_textboxes;i++)h=hash_bytes(h,&w->textbox[i],sizeof(TEXTBOX));
    for(i=0;i<w->n_bitmaps;i++){
        h=hash_bytes(h,&w->bitmap[i],sizeof(BITMAP));
        if(w->bitmap[i].pixels&&w->bitmap[i].bytes>0)
            h=hash_bytes(h,w->bitmap[i].pixels,(unsigned long)w->bitmap[i].bytes);
    }
    if(w->framebuffer&&w->fb_bpp==32&&w->fb_stride>0&&w->fb_height>0 &&
       w->fb_stride<=GRAOS_WIDTH*4&&w->fb_height<=GRAOS_HEIGHT)
        h=hash_bytes(h,w->framebuffer,(unsigned long)w->fb_stride*(unsigned long)w->fb_height);
    return h;
}
static void blit_window_cache(VMODE *v,const WINDOW *w,const WINDOW_BITMAP_CACHE *c)
{
    int row,x0,x1,y0,y1;
    x0=w->x<0?0:w->x;y0=w->y<0?0:w->y;
    x1=w->x+w->width;if(x1>v->width)x1=v->width;
    y1=w->y+w->height;if(y1>v->height)y1=v->height;
    for(row=y0;row<y1;row++)
        if(x1>x0)memcpy(v->buf+(unsigned long)row*v->width+x0,
                        c->pixels+(unsigned long)(row-w->y)*c->width+(x0-w->x),
                        (unsigned long)(x1-x0)*sizeof(GRAOS_PIXEL));
    window_cache_blits++;
}
static int cached_window_draw(VMODE *v,WINDOW *w,int slot)
{
    WINDOW_BITMAP_CACHE *c;
    WINDOW localw;
    VMODE localv;
    GRAOS_PIXEL *newpixels;
    unsigned long signature,bytes;
    int active;
    if(slot<0||slot>=N_MAX_WINDOWS||w->width<=0||w->height<=0)return 0;
    if(w->width>GRAOS_WIDTH||w->height>GRAOS_HEIGHT)return 0;
    c=&window_cache[slot];
    bytes=(unsigned long)w->width*(unsigned long)w->height*sizeof(GRAOS_PIXEL);
    if(!c->pixels||c->width!=w->width||c->height!=w->height||c->id!=w->id){
        newpixels=(GRAOS_PIXEL*)malloc(bytes);
        if(!newpixels)return 0;
        if(c->pixels)free(c->pixels);
        c->pixels=newpixels;c->width=w->width;c->height=w->height;
        c->id=w->id;c->valid=0;
    }
    active=(v->selwin==w);
    /* Client framebuffers may be modified without a GraOS notification.
     * Until all producers use an explicit damage protocol, preserve the
     * framebuffer hash for correctness. Static windows can skip hashing
     * when neither the root widget nor their surface has changed. */
    if(c->valid && c->id==w->id && c->width==w->width &&
       c->height==w->height && c->active==active &&
       c->theme==v->desktop_color &&
       w->fb_type!=GRAOS_SURFACE_TERMINAL && !w->framebuffer &&
       !(w->root.flags&GRAOS_WIDGET_DIRTY))
        signature=c->signature;
    else signature=content_signature(w);
    if(!c->valid||c->signature!=signature||c->active!=active||
       c->theme!=v->desktop_color ){
        /* Render at local origin. Do not mutate the original window's
         * geometry; title bar active state uses local window pointer. */
        localw=*w;localw.x=0;localw.y=0;
        localv=*v;localv.buf=c->pixels;
        localv.width=w->width;localv.height=w->height;
        localv.selwin=active?&localw:NULL;
        memset(c->pixels,0,bytes);
        windowDraw(&localv,&localw);
        c->signature=signature;c->active=active;
        c->theme=v->desktop_color;c->valid=1;
        window_cache_renders++;
    }
    blit_window_cache(v,w,c);
    return 1;
}
void graos_window_cache_stats(unsigned long *renders,unsigned long *blits)
{
    if(renders)*renders=window_cache_renders;
    if(blits)*blits=window_cache_blits;
}
void graos_window_cache_reset(void)
{
    int i;
    for(i=0;i<N_MAX_WINDOWS;i++){
        if(window_cache[i].pixels)free(window_cache[i].pixels);
        memset(&window_cache[i],0,sizeof(window_cache[i]));
    }
}
void drawAllWindows(VMODE*v)
{
    int z,i,bestz,lastz=-2147483647,best;
    if(!v)return;
    for(z=0;z<wdb.n_windows;z++){
        best=-1;bestz=2147483647;
        for(i=0;i<wdb.n_windows;i++)
            if(window_drawable(v,&wdb.w[i])&&wdb.w[i].z>lastz&&wdb.w[i].z<bestz){best=i;bestz=wdb.w[i].z;}
        if(best<0)break;
        if(!window_fully_occluded(v,&wdb.w[best]))
            if(!cached_window_draw(v,&wdb.w[best],best))windowDraw(v,&wdb.w[best]);
        lastz=bestz;
    }
}
