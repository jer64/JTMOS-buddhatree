#ifndef __INCLUDED_GUILOOP_H__
#define __INCLUDED_GUILOOP_H__
#include "graos.h"
int guiLoop(VMODE *v);
void graosFlyWindow(VMODE *v,WINDOW *w,int restoring);
#endif
