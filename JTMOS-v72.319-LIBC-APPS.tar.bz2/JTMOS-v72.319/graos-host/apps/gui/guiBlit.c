#include "guiBlit.h"
void guiBlit(VMODE *v,int dx,int dy,int w,int h,const GRAOS_PIXEL *src,int stride,int mode)
{
    int x,y,sx0=0,sy0=0,cw=w,ch=h;
    if(!v || !v->buf || !src || v->width<=0 || v->height<=0 ||
       stride<w || w<=0 || h<=0) return;
    if(dx<0){if(dx<=-w)return;sx0=-dx;cw-=sx0;dx=0;}
    if(dy<0){if(dy<=-h)return;sy0=-dy;ch-=sy0;dy=0;}
    if(dx>=v->width || dy>=v->height) return;
    if(cw>v->width-dx) cw=v->width-dx;
    if(ch>v->height-dy) ch=v->height-dy;
    if(cw<=0||ch<=0)return;
    if(mode==GRAOS_BLIT_OPAQUE) {
        for(y=0;y<ch;y++)
            memcpy(v->buf+(size_t)(dy+y)*(size_t)v->width+(size_t)dx,
                   src+(size_t)(sy0+y)*(size_t)stride+(size_t)sx0,
                   (size_t)cw*4U);
    } else {
        for(y=0;y<ch;y++) for(x=0;x<cw;x++) {
            GRAOS_PIXEL s=src[(size_t)(sy0+y)*(size_t)stride+(size_t)(sx0+x)];
            GRAOS_PIXEL *d=&v->buf[(size_t)(dy+y)*(size_t)v->width+(size_t)(dx+x)];
            *d=graosAlphaOver(*d,s);
        }
    }
    v->dirty=1;
}

/* 16.16 bilinear interpolation. All products fit within unsigned 32 bits:
 * weighted channel contributions are accumulated in two successive lerps.
 * Endpoint mapping means the first and final destination pixels match source
 * endpoints. Clip only the destination iteration, preserving the transform. */
static unsigned lerp8(unsigned a,unsigned b,unsigned fraction)
{
    return (a*(65536U-fraction)+b*fraction+32768U)>>16;
}
static unsigned long sample_coord(int pos,int srclen,int dstlen)
{
    unsigned long n,d;
    if(dstlen<=1||srclen<=1)return 0;
    /* Avoid 64-bit division in the i386 kernel/runtime: quotient/remainder
     * decomposition fits 32-bit unsigned for the bounded dimensions. */
    n=(unsigned long)pos*(unsigned long)(srclen-1);
    d=(unsigned long)(dstlen-1);
    return ((n/d)<<16)+((n%d)*65536UL)/d;
}
static GRAOS_PIXEL interpolate(GRAOS_PIXEL a,GRAOS_PIXEL b,
                               GRAOS_PIXEL c,GRAOS_PIXEL d,unsigned fx,unsigned fy)
{
    unsigned r0=lerp8(GRAOS_R(a),GRAOS_R(b),fx);
    unsigned r1=lerp8(GRAOS_R(c),GRAOS_R(d),fx);
    unsigned g0=lerp8(GRAOS_G(a),GRAOS_G(b),fx);
    unsigned g1=lerp8(GRAOS_G(c),GRAOS_G(d),fx);
    unsigned b0=lerp8(GRAOS_B(a),GRAOS_B(b),fx);
    unsigned b1=lerp8(GRAOS_B(c),GRAOS_B(d),fx);
    unsigned a0=lerp8(GRAOS_A(a),GRAOS_A(b),fx);
    unsigned a1=lerp8(GRAOS_A(c),GRAOS_A(d),fx);
    return GRAOS_RGBA(lerp8(r0,r1,fy),lerp8(g0,g1,fy),
                      lerp8(b0,b1,fy),lerp8(a0,a1,fy));
}
void guiBlitBilinear(VMODE *v,int dx,int dy,int dw,int dh,
                     const GRAOS_PIXEL *src,int sw,int sh,int stride,int mode)
{
    int x,y,firstx,firsty,lastx,lasty;
    if(!v||!v->buf||!src||sw<1||sh<1||stride<sw||dw<1||dh<1||
       v->width<1||v->height<1||dw>32767||dh>32767||
       sw>32767||sh>32767||dx< -32767||dy< -32767)return;
    if(dx>=v->width||dy>=v->height||dx+dw<=0||dy+dh<=0)return;
    firstx=dx<0?0:dx;firsty=dy<0?0:dy;
    lastx=dx+dw>v->width?v->width:dx+dw;
    lasty=dy+dh>v->height?v->height:dy+dh;
    for(y=firsty;y<lasty;y++){
        unsigned long qy=sample_coord(y-dy,sh,dh);
        unsigned sy=(unsigned)(qy>>16),fy=(unsigned)(qy&65535ULL);
        unsigned sy1=sy+1<(unsigned)sh?sy+1:sy;
        for(x=firstx;x<lastx;x++){
            unsigned long qx=sample_coord(x-dx,sw,dw);
            unsigned sx=(unsigned)(qx>>16),fx=(unsigned)(qx&65535ULL);
            unsigned sx1=sx+1<(unsigned)sw?sx+1:sx;
            GRAOS_PIXEL p=interpolate(src[(size_t)sy*stride+sx],src[(size_t)sy*stride+sx1],
                                      src[(size_t)sy1*stride+sx],src[(size_t)sy1*stride+sx1],fx,fy);
            GRAOS_PIXEL *dest=&v->buf[(size_t)y*v->width+x];
            *dest=mode==GRAOS_BLIT_ALPHA?graosAlphaOver(*dest,p):p;
        }
    }
    v->dirty=1;
}
