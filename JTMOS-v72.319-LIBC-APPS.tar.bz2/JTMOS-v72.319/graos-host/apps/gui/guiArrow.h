#ifndef __INCLUDED_GUIARROW_H__
#define __INCLUDED_GUIARROW_H__
#include "graos.h"
int guiLoadCursor(VMODE *v,const char *name);
void guiDrawCursor(VMODE *v);
void guiCursorInitVariants(VMODE *v);
int guiCursorSetHand(VMODE *v,int hand);
#endif
