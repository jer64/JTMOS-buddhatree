#include "guiUpdate.h"

/* 32x16 RAM tile comparisons, coalesced into horizontal runs. No VGA reads.
 * Shadow represents the last successfully presented pixels. */
#define TILE_W 32
#define TILE_H 16
#define TILES_X (GRAOS_WIDTH/TILE_W)
#define TILES_Y (GRAOS_HEIGHT/TILE_H)
#define MAX_DIRTY_PERCENT 60
static GRAOS_PIXEL *shadow;
static int shadow_valid;
static const VMODE *shadow_owner;
static const GRAOS_PIXEL *shadow_source;
static unsigned long delta_full_frames, delta_partial_frames, delta_noop_frames;
static unsigned long delta_rectangles, delta_pixels_sent;
static int cursor_last_x, cursor_last_y, cursor_known;
static unsigned long cursor_moves;
/* Cursor damage is tracked independently of window damage. Its old and
 * new positions are useful for future exclusive-region compositing. */
void graos_cursor_moved(int x,int y)
{
    if(!cursor_known || x!=cursor_last_x || y!=cursor_last_y) {
        cursor_moves++;
        cursor_last_x=x;
        cursor_last_y=y;
        cursor_known=1;
    }
}
unsigned long graos_cursor_move_count(void) { return cursor_moves; }

void graos_delta_stats(unsigned long *full,unsigned long *partial,
                       unsigned long *noop,unsigned long *rects,
                       unsigned long *pixels)
{
    if(full)*full=delta_full_frames;
    if(partial)*partial=delta_partial_frames;
    if(noop)*noop=delta_noop_frames;
    if(rects)*rects=delta_rectangles;
    if(pixels)*pixels=delta_pixels_sent;
}

static unsigned char changed[TILES_Y][TILES_X];
/* Conservative damage hints: only used when caller certifies that no
 * other framebuffer pixels changed. Default remains full RAM comparison. */
static int damage_only;
static int damage_x0,damage_y0,damage_x1,damage_y1;
void graos_damage_reset(void) { damage_only=0; }
void graos_damage_region(int x,int y,int w,int h)
{
    int x1,y1;
    if(w<=0||h<=0)return;
    if(x<0){w+=x;x=0;}
    if(y<0){h+=y;y=0;}
    if(w<=0||h<=0||x>=GRAOS_WIDTH||y>=GRAOS_HEIGHT)return;
    if(w>GRAOS_WIDTH-x)w=GRAOS_WIDTH-x;
    if(h>GRAOS_HEIGHT-y)h=GRAOS_HEIGHT-y;
    x1=x+w;y1=y+h;
    if(!damage_only){damage_x0=x;damage_y0=y;damage_x1=x1;damage_y1=y1;damage_only=1;}
    else {
        if(x<damage_x0)damage_x0=x;
        if(y<damage_y0)damage_y0=y;
        if(x1>damage_x1)damage_x1=x1;
        if(y1>damage_y1)damage_y1=y1;
    }
}


static int present_rect(VMODE *v,int x,int y,int w,int h)
{
    unsigned long rowbytes=(unsigned long)GRAOS_WIDTH*4UL;
    return (int)scall(SYS_vgadrawframe,(DWORD)v->buf,
                      (DWORD)((unsigned long)y*rowbytes),
                      (DWORD)((unsigned long)h*rowbytes),
                      (DWORD)x,(DWORD)w,0);
}
int graos_present(VMODE *v)
{
    int tx,ty,y,dirty=0,ok=1;
    if(!v||!v->buf)return 0;
    if(shadow_owner!=v || shadow_source!=v->buf) {
        shadow_valid=0;
        shadow_owner=v;
        shadow_source=v->buf;
    }
    if(!shadow) {
        shadow=(GRAOS_PIXEL *)malloc(GRAOS_FRAME_BYTES);
        shadow_valid=0;
    }
    if(!shadow) return (int)scall(SYS_vgadrawframe,(DWORD)v->buf,0,
                                 GRAOS_FRAME_BYTES,0,0,0);
    if(!shadow_valid) {
        ok=(int)scall(SYS_vgadrawframe,(DWORD)v->buf,0,GRAOS_FRAME_BYTES,0,0,0);
        if(ok) {
            memcpy(shadow,v->buf,GRAOS_FRAME_BYTES);
            shadow_valid=1;
            delta_full_frames++;
            delta_pixels_sent+=GRAOS_FRAME_PIXELS;
        }
        return ok;
    }
    for(ty=0;ty<TILES_Y;ty++)for(tx=0;tx<TILES_X;tx++) {
        int different=0;
        /* Hints are advisory until all producers report damage.
         * Never skip comparisons: cursor, IPC, terminals and popups can
         * change pixels independently of a window's hint. */
        for(y=ty*TILE_H;y<(ty+1)*TILE_H;y++) {
            unsigned long i=(unsigned long)y*GRAOS_WIDTH+tx*TILE_W;
            if(memcmp(v->buf+i,shadow+i,TILE_W*4)!=0) {
                different=1;break;
            }
        }
        changed[ty][tx]=(unsigned char)different;
        dirty+=different;
    }
    if(!dirty) { delta_noop_frames++; return 1; }
    if(dirty*100 >= TILES_X*TILES_Y*MAX_DIRTY_PERCENT) {
        ok=(int)scall(SYS_vgadrawframe,(DWORD)v->buf,0,GRAOS_FRAME_BYTES,0,0,0);
        if(ok) {
            memcpy(shadow,v->buf,GRAOS_FRAME_BYTES);
            delta_full_frames++;
            delta_pixels_sent+=GRAOS_FRAME_PIXELS;
        }
        return ok;
    }
    /* Merge identical horizontal runs across adjacent tile rows. This
     * reduces syscall count for moving/resizing rectangular windows. */
    {
        struct rect { int x0,x1,y0,y1,used; };
        struct rect active[TILES_X], next[TILES_X];
        int active_count=0, next_count, i, j, start, end;
        for(ty=0;ty<=TILES_Y;ty++) {
            next_count=0;
            tx=0;
            while(ty<TILES_Y && tx<TILES_X) {
                while(tx<TILES_X && !changed[ty][tx])tx++;
                if(tx==TILES_X)break;
                start=tx;
                while(tx<TILES_X && changed[ty][tx])tx++;
                end=tx;
                j=-1;
                for(i=0;i<active_count;i++)
                    if(active[i].x0==start && active[i].x1==end) {
                        j=i; break;
                    }
                if(j>=0) {
                    next[next_count]=active[j];
                    next[next_count].y1=ty+1;
                    active[j].used=1;
                } else {
                    next[next_count].x0=start;
                    next[next_count].x1=end;
                    next[next_count].y0=ty;
                    next[next_count].y1=ty+1;
                    next[next_count].used=0;
                }
                next_count++;
            }
            for(i=0;i<active_count;i++)if(!active[i].used) {
                struct rect *r=&active[i];
                if(!present_rect(v,r->x0*TILE_W,r->y0*TILE_H,
                                 (r->x1-r->x0)*TILE_W,
                                 (r->y1-r->y0)*TILE_H)) {
                    shadow_valid=0;
                    return 0;
                }
                delta_rectangles++;
                delta_pixels_sent+=(unsigned long)(r->x1-r->x0)*TILE_W*
                                   (unsigned long)(r->y1-r->y0)*TILE_H;
                /* Commit this rectangle only after its successful write. */
                for(y=r->y0*TILE_H;y<r->y1*TILE_H;y++) {
                    unsigned long pos=(unsigned long)y*GRAOS_WIDTH+r->x0*TILE_W;
                    memcpy(shadow+pos,v->buf+pos,
                           (unsigned long)(r->x1-r->x0)*TILE_W*4UL);
                }
            }
            active_count=next_count;
            for(i=0;i<next_count;i++) {
                active[i]=next[i];
                active[i].used=0;
            }
        }
    }
    /* No full-frame shadow copy after sparse updates. */
    delta_partial_frames++;
    return ok;
}

/* Called with a clean desktop+windows buffer and old cursor snapshot.
 * First erase the old cursor on VGA, then the caller draws the new cursor
 * and invokes graos_present_cursor_finish(). */
int graos_present_cursor_erase(VMODE *v,int oldx,int oldy)
{
    int y;
    if(!v||!v->buf||!shadow_valid||shadow_owner!=v||shadow_source!=v->buf)
        return 0;
    if(oldx<0||oldy<0||oldx+32>v->width||oldy+32>v->height)return 0;
    if(!present_rect(v,oldx,oldy,32,32)) {shadow_valid=0;return 0;}
    for(y=0;y<32;y++) {
        unsigned long pos=(unsigned long)(oldy+y)*GRAOS_WIDTH+oldx;
        memcpy(shadow+pos,v->buf+pos,32*4);
    }
    delta_rectangles++;
    delta_pixels_sent+=1024UL;
    return 1;
}
int graos_present_cursor_finish(VMODE *v,int x,int y)
{
    int row;
    if(!v||!v->buf||!shadow_valid||shadow_owner!=v||shadow_source!=v->buf)
        return 0;
    if(x<0||y<0||x+32>v->width||y+32>v->height)return 0;
    if(!present_rect(v,x,y,32,32)) {shadow_valid=0;return 0;}
    for(row=0;row<32;row++) {
        unsigned long pos=(unsigned long)(y+row)*GRAOS_WIDTH+x;
        memcpy(shadow+pos,v->buf+pos,32*4);
    }
    delta_rectangles++;
    delta_pixels_sent+=1024UL;
    delta_partial_frames++;
    return 1;
}

int guiUpdate(VMODE *v)
{
    int ok;
    if(!v||!v->dirty)return 1;
    ok=graos_present(v);
    graos_damage_reset();
    if(ok)v->dirty=0;
    return ok;
}
