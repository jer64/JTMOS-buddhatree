#ifndef __INCLUDED_GUIBLIT_H__
#define __INCLUDED_GUIBLIT_H__
#include "graos.h"
void guiBlit(VMODE*,int,int,int,int,const GRAOS_PIXEL*,int,int);
/* Fixed-point bilinear RGBA resize. Source dimensions are in pixels,
 * stride is in pixels, and destination is clipped to VMODE. */
void guiBlitBilinear(VMODE *v,int dx,int dy,int dw,int dh,
                     const GRAOS_PIXEL *src,int sw,int sh,int stride,int mode);
#endif
