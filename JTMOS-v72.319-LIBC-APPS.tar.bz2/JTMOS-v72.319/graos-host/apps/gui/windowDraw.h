#ifndef __INCLUDED_WINDOWDRAW_H__
#define __INCLUDED_WINDOWDRAW_H__
#include "graos.h"
void drawAllWindows(VMODE *v);
void windowDraw(VMODE *v,WINDOW *w);
void graos_window_cache_stats(unsigned long *renders,unsigned long *blits);
void graos_window_cache_reset(void);
void graos_window_cache_invalidate(WINDOW *w);
void graos_window_cache_release(WINDOW *w);
int graos_terminal_poll_changed(void);
void graos_terminal_poll_stats(unsigned long *checks,unsigned long *changes);
void graos_terminal_dirty_cell_stats(unsigned long *cells);
#endif
