#include "windowMoving.h"
#include "wdb.h"
#include "windowFunc.h"
#include "guiWidget.h"
#include "guiTextBox.h"
#include "guiFocus.h"
#include "windowDraw.h"

static void send_window_mouse(WINDOW *w,int sx,int sy,int button)
{
    int cx,cy;
    if(!w || w->pid<=0 || !w->framebuffer) return;
    if(w->tiled || w->maximized) {
        int lx,ly,dw,dh,rx,ry;
        if(!guiLayoutSurfaceRect(w,&lx,&ly,&dw,&dh) || dw<=0 || dh<=0) return;
        rx=sx-(w->x+lx); ry=sy-(w->y+ly);
        if(rx<0 || ry<0 || rx>=dw || ry>=dh) return;
        cx=(int)(((long)rx*(long)w->fb_width)/(long)dw);
        cy=(int)(((long)ry*(long)w->fb_height)/(long)dh);
    } else {
        cx=sx-w->x-w->fb_x;
        cy=sy-w->y-w->captionHeight-w->fb_y;
        if(cx<0 || cy<0 || cx>=w->fb_width || cy>=w->fb_height) return;
    }

    /* V69.0 input hotfix: client mouse events must use the same per-window
     * GraOS event queue as native buttons/textboxes.  The old direct Postman
     * send could be lost when the client's tiny mailbox was occupied by a
     * synchronous refresh/poll response, making framebuffer UIs look alive
     * but completely unclickable.  POLLEVENT drains this queue reliably and
     * preserves the window association. */
    guiQueueWindowEvent(w,GRAOS_GSID_MOUSEBUTTON,cx,cy,button);
}

static void clamp_window(VMODE *v,WINDOW *w)
{
    int max_x,max_y;
    if(!v || !w) return;
    max_x=v->width-w->width;
    max_y=(v->height-GRAOS_PANEL_HEIGHT)-w->height;
    if(max_x<0) max_x=0;
    if(max_y<0) max_y=0;
    if(w->x<0) w->x=0;
    if(w->y<0) w->y=0;
    if(w->x>max_x) w->x=max_x;
    if(w->y>max_y) w->y=max_y;
    guiWidgetSetBounds(&w->root,w->x,w->y,w->width,w->height);
}
void windowInput(VMODE *v)
{
    int down=(v->buttons&1)!=0, was=(v->last_buttons&1)!=0;
    int right_down=(v->buttons&2)!=0,right_was=(v->last_buttons&2)!=0;
    WINDOW *bw=NULL; BUTTON *b=getButtonUnderCursor(v,&bw);
    /* v72.77: deliver right click to framebuffer applications (Navigator's
     * context menu), without starting window dragging or pressing widgets. */
    if(right_down&&!right_was){
        WINDOW *cw=getWindowUnderCursor(v,0);
        if(cw){SelectWindow(v,cw);send_window_mouse(cw,v->x,v->y,2);}
    }
    if(down&&!was){
        WINDOW *edgewin=getWindowUnderCursor(v,0);
        int edges=0;
        if(edgewin && !edgewin->isfree && !edgewin->minimized &&
           edgewin->width>=100 && edgewin->height>=80) {
            int rx=v->x-edgewin->x,ry=v->y-edgewin->y;
            if(rx>=0 && rx<6)edges|=1;
            if(rx>=edgewin->width-6 && rx<edgewin->width)edges|=2;
            if(ry>=edgewin->height-6 && ry<edgewin->height)edges|=4;
        }
        if(edges && !b){
            SelectWindow(v,edgewin);
            v->resizingWindow=1;v->resize_edges=edges;
            v->movwin=edgewin;v->origx=v->x;v->origy=v->y;
            v->oldx=edgewin->x;v->oldy=edgewin->y;
            v->resize_width=edgewin->width;v->resize_height=edgewin->height;
            v->dirty=1;
        } else if(b){v->pressed_button=b;v->pressed_window=bw;b->pressed=1;SelectWindow(v,bw);guiFocusButton(v,bw,b);v->dirty=1;}
        else {
            WINDOW *cw=getWindowUnderCursor(v,0);
            if(cw){
                TEXTBOX *tb; int local_x=v->x-cw->x,local_y=v->y-cw->y;
                SelectWindow(v,cw);
                tb=guiGetTextBoxAt(cw,local_x,local_y);
                if(tb) {
                    guiFocusTextBox(v,cw,tb);
                } else if(v->y < cw->y+cw->captionHeight){
                    guiBlurTextBox(v,cw);
                    v->movingWindow=1;v->movwin=cw;v->origx=v->x;v->origy=v->y;v->oldx=cw->x;v->oldy=cw->y;
                } else {
                    send_window_mouse(cw,v->x,v->y,1);
                }
            }
        }
    }
    if(down&&v->resizingWindow&&v->movwin){
        WINDOW *rw=v->movwin;
        int dx=v->x-v->origx,dy=v->y-v->origy;
        int x=v->oldx,y=v->oldy;
        int width=v->resize_width,height=v->resize_height;
        if(v->resize_edges&1){x+=dx;width-=dx;}
        if(v->resize_edges&2)width+=dx;
        if(v->resize_edges&4)height+=dy;
        if(width<160){if(v->resize_edges&1)x-=160-width;width=160;}
        if(height<90)height=90;
        if(x<0){if(v->resize_edges&1)width+=x;x=0;}
        if(x+width>v->width)width=v->width-x;
        if(y+height>v->height-GRAOS_PANEL_HEIGHT)height=v->height-GRAOS_PANEL_HEIGHT-y;
        if(width>=160 && height>=90 &&
           (rw->x!=x||rw->y!=y||rw->width!=width||rw->height!=height)){
            rw->x=x;rw->y=y;rw->width=width;rw->height=height;
            guiWidgetSetBounds(&rw->root,x,y,width,height);
            graos_window_cache_invalidate(rw);
            v->dirty=1;
        }
    }
    if(down&&v->movingWindow&&v->movwin){v->movwin->x=v->oldx+(v->x-v->origx);v->movwin->y=v->oldy+(v->y-v->origy);clamp_window(v,v->movwin);v->dirty=1;}
    if(!down&&was){
        if(v->pressed_button){BUTTON *pb=v->pressed_button;WINDOW *pw=v->pressed_window; if(b==pb&&bw==pw)onButtonClick(v,pw,pb); if(pw&&!pw->isfree)pb->pressed=0; v->pressed_button=NULL;v->pressed_window=NULL;v->dirty=1;}
        v->movingWindow=0;v->resizingWindow=0;v->movwin=NULL;
    }
}
