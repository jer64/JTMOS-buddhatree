#ifndef GRAOS_GUI_VECTOR_H
#define GRAOS_GUI_VECTOR_H
#include "graos.h"
/* Coordinates are in a normalized 0..1024 space relative to the destination
 * rectangle. Polygon vertices are independent of screen resolution. */
typedef struct { short x, y; } GRAOS_VPOINT;
typedef struct { const GRAOS_VPOINT *points; unsigned count; } GRAOS_VPOLYGON;
typedef enum { GRAOS_VSOLID=0, GRAOS_VSTRIPES=1, GRAOS_VCHECKER=2 } GRAOS_VFILL;
void graosVectorFill(VMODE *v, const GRAOS_VPOLYGON *shape,
                     int x, int y, int width, int height,
                     GRAOS_PIXEL primary, GRAOS_PIXEL secondary,
                     GRAOS_VFILL pattern, unsigned period);
void graosVectorPanel(VMODE *v, int x, int y, int width, int height,
                      GRAOS_PIXEL primary, GRAOS_PIXEL secondary,
                      GRAOS_VFILL pattern, unsigned period);
/* Engine 2.0: polygons with normalized texture coordinates and rounded
 * chrome panels. Texture values follow GraOS RGBA byte ordering. */
void graosVectorTextured(VMODE *v,const GRAOS_VPOLYGON *shape,
                        int x,int y,int width,int height,
                        const GRAOS_PIXEL *texture,int tw,int th,int stride,
                        int alpha_blend);
void graosVectorRoundRect(VMODE *v,int x,int y,int width,int height,
                          int radius,GRAOS_PIXEL color);
#endif
