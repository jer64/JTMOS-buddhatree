#include "guiArrow.h"
#include "guiBlit.h"
#include "guiResource.h"
static void guiFallbackCursor(VMODE*v)
{int x,y;if(!v)return;for(y=0;y<32;y++)for(x=0;x<32;x++)v->cursor[y*32+x]=GRAOS_RGBA(0,0,0,0);for(y=0;y<20;y++){int edge=(y<13)?(y/2+1):(20-y);if(edge<1)edge=1;if(edge>8)edge=8;for(x=0;x<edge;x++)v->cursor[y*32+x]=(x==0||x==edge-1||y==0)?GRAOS_RGB(0,0,0):GRAOS_RGB(255,255,255);}for(y=10;y<23;y++){x=4+(y-10)/2;if(x>=0&&x<32)v->cursor[y*32+x]=GRAOS_RGB(0,0,0);if(x+1<32)v->cursor[y*32+x+1]=GRAOS_RGB(255,255,255);}v->cursor_loaded=1;}
int guiLoadCursor(VMODE*v,const char*name){FILE*f;size_t n;if(!v)return 0;f=guiOpenResource(name,"rb");if(!f){guiFallbackCursor(v);return 1;}n=fread(v->cursor,1,sizeof(v->cursor),f);fclose(f);v->cursor_loaded=(n==sizeof(v->cursor));if(!v->cursor_loaded)guiFallbackCursor(v);return v->cursor_loaded;}
void guiDrawCursor(VMODE*v){if(v&&v->cursor_loaded)guiBlit(v,v->x,v->y,32,32,v->cursor,32,GRAOS_BLIT_ALPHA);}

/* Keep both cursor images in RAM. A hover transition must never reload or
 * overwrite the original arrow bitmap. */
static GRAOS_PIXEL arrow_image[32*32];
static GRAOS_PIXEL hand_image[32*32];
static int images_ready;
static int current_hand;
static void make_hand(void)
{
    int x,y;
    for(y=0;y<32;y++)for(x=0;x<32;x++)hand_image[y*32+x]=GRAOS_RGBA(0,0,0,0);
    /* Solid, outlined pointing finger. Top-left is the click hotspot. */
    for(y=0;y<27;y++) {
        int l=9,r=17;
        if(y<12){l=9;r=13;}
        else if(y<17){l=6;r=22;}
        else if(y<23){l=7;r=22;}
        else {l=9;r=20;}
        for(x=l;x<=r;x++)
            hand_image[y*32+x]=(x==l||x==r||y==0||y==26)
                ?GRAOS_RGB(18,18,18):GRAOS_RGB(246,246,246);
    }
    for(y=12;y<18;y++)for(x=6;x<9;x++)
        hand_image[y*32+x]=GRAOS_RGB(18,18,18);
}
void guiCursorInitVariants(VMODE *v)
{
    if(!v||!v->cursor_loaded)return;
    memcpy(arrow_image,v->cursor,sizeof(arrow_image));
    make_hand();
    images_ready=1;
    current_hand=0;
}
int guiCursorSetHand(VMODE *v,int hand)
{
    hand=!!hand;
    if(!v||!images_ready||current_hand==hand)return 0;
    memcpy(v->cursor,hand?hand_image:arrow_image,sizeof(v->cursor));
    current_hand=hand;
    return 1;
}
