/* GraOS normalized, filled/textured vector polygon rasterizer.
 * Integer-only scan conversion; no FPU required on the 32-bit kernel.
 * Clamps all drawing to the destination rect and framebuffer. */
#include "guiVector.h"
#include "guiRect.h"
#include "guiBlit.h"
#define VECTOR_MAX_POINTS 24
#define VECTOR_SCALE 1024
static int bound(int x, int lo, int hi) { return x<lo?lo:(x>hi?hi:x); }
static GRAOS_PIXEL pattern_pixel(int x,int y,int origin_x,int origin_y,
                                GRAOS_PIXEL a,GRAOS_PIXEL b,GRAOS_VFILL fill,
                                unsigned period)
{
 unsigned xx=(unsigned)(x-origin_x),yy=(unsigned)(y-origin_y);
 if(fill==GRAOS_VSTRIPES)return ((yy/period)&1U)?b:a;
 if(fill==GRAOS_VCHECKER)return (((xx/period)^(yy/period))&1U)?b:a;
 return a;
}
void graosVectorFill(VMODE *v,const GRAOS_VPOLYGON *shape,
                     int x,int y,int width,int height,
                     GRAOS_PIXEL a,GRAOS_PIXEL b,GRAOS_VFILL fill,unsigned period)
{
 int vx[VECTOR_MAX_POINTS],vy[VECTOR_MAX_POINTS],hits[VECTOR_MAX_POINTS];
 int i,j,k,count,sy,xstart,xend,scan_start,scan_end,clip_left,clip_right;
 if(!v||!v->buf||!shape||!shape->points||shape->count<3||
    shape->count>VECTOR_MAX_POINTS||width<=0||height<=0)return;
 if(period==0)period=1;
 /* Limit vertex coordinates to the documented normalized local viewport.
  * Multiplication remains bounded even with hostile widget geometry. */
 if(width>32767||height>32767||width>v->width*2||height>v->height*2)return;
 for(i=0;i<(int)shape->count;i++) {
    vx[i]=x+((int)shape->points[i].x*width)/VECTOR_SCALE;
    vy[i]=y+((int)shape->points[i].y*height)/VECTOR_SCALE;
 }
 clip_left=bound(x,0,v->width);clip_right=bound(x+width,0,v->width);
 scan_start=bound(y,0,v->height);scan_end=bound(y+height,0,v->height);
 if(clip_left>=clip_right||scan_start>=scan_end)return;
 for(sy=scan_start;sy<scan_end;sy++) {
    count=0;
    for(i=0;i<(int)shape->count;i++) {
       j=(i+1)%(int)shape->count;
       if((vy[i]<=sy&&vy[j]>sy)||(vy[j]<=sy&&vy[i]>sy)) {
          /* Component sizes are bounded above; the product fits in int.
           * Half-open edges keep shared vertices from being counted twice. */
          int dx=(vx[j]-vx[i])*(sy-vy[i]);
          hits[count++]=vx[i]+(int)(dx/(vy[j]-vy[i]));
       }
    }
    for(i=1;i<count;i++){int val=hits[i];j=i;while(j>0&&hits[j-1]>val){hits[j]=hits[j-1];j--;}hits[j]=val;}
    for(k=0;k+1<count;k+=2) {
       xstart=bound(hits[k],clip_left,clip_right);
       xend=bound(hits[k+1],clip_left,clip_right);
       if(xstart>=xend)continue;
       if(fill==GRAOS_VSOLID||fill==GRAOS_VSTRIPES) {
          GRAOS_PIXEL color=pattern_pixel(xstart,sy,x,y,a,b,fill,period);
          fillRectRGBA(v,xstart,sy,xend-1,sy,color);
       } else {
          int sx=xstart,run=xstart;
          GRAOS_PIXEL color=pattern_pixel(sx,sy,x,y,a,b,fill,period);
          while(++sx<xend) {
             GRAOS_PIXEL next=pattern_pixel(sx,sy,x,y,a,b,fill,period);
             if(next!=color){fillRectRGBA(v,run,sy,sx-1,sy,color);run=sx;color=next;}
          }
          fillRectRGBA(v,run,sy,xend-1,sy,color);
       }
    }
 }
}
void graosVectorPanel(VMODE *v,int x,int y,int width,int height,
                      GRAOS_PIXEL a,GRAOS_PIXEL b,GRAOS_VFILL pattern,unsigned period)
{
 static const GRAOS_VPOINT quad[]={{0,0},{1024,0},{1024,1024},{0,1024}};
 GRAOS_VPOLYGON p={quad,4};
 graosVectorFill(v,&p,x,y,width,height,a,b,pattern,period);
}

/* Rounded rectangles constructed as a 20-vertex normalized polygon.
 * Radius is specified in destination pixels and clamped to half the size. */
void graosVectorRoundRect(VMODE *v,int x,int y,int width,int height,
                          int radius,GRAOS_PIXEL color)
{
    GRAOS_VPOINT p[20]; GRAOS_VPOLYGON shape;
    /* Quarter circle samples, 5 vertices per corner, in units of 1024. */
    static const int co[5]={1024,946,724,392,0};
    static const int si[5]={0,392,724,946,1024};
    int i,n=0,ux,uy;
    if(width<=0||height<=0||!v)return;
    if(radius<0)radius=0;
    if(radius>width/2)radius=width/2;
    if(radius>height/2)radius=height/2;
    if(radius==0){graosVectorPanel(v,x,y,width,height,color,color,GRAOS_VSOLID,1);return;}
    /* 20-point clockwise polygon: top-right, bottom-right, bottom-left,
     * top-left. Integer coordinates avoid floating-point dependencies. */
    for(i=0;i<5;i++){
        ux=width-radius+(radius*si[i])/1024;
        uy=radius-(radius*co[i])/1024;
        p[n].x=(short)(ux*1024/width);p[n++].y=(short)(uy*1024/height);
    }
    for(i=0;i<5;i++){
        ux=width-radius+(radius*co[i])/1024;
        uy=height-radius+(radius*si[i])/1024;
        p[n].x=(short)(ux*1024/width);p[n++].y=(short)(uy*1024/height);
    }
    for(i=0;i<5;i++){
        ux=radius-(radius*si[i])/1024;
        uy=height-radius+(radius*co[i])/1024;
        p[n].x=(short)(ux*1024/width);p[n++].y=(short)(uy*1024/height);
    }
    for(i=0;i<5;i++){
        ux=radius-(radius*co[i])/1024;
        uy=radius-(radius*si[i])/1024;
        p[n].x=(short)(ux*1024/width);p[n++].y=(short)(uy*1024/height);
    }
    shape.points=p;shape.count=(unsigned)n;
    graosVectorFill(v,&shape,x,y,width,height,color,color,GRAOS_VSOLID,1);
}

/* UV sampling uses the polygon's normalized bounding viewport: the entire
 * texture is mapped to the viewport and clipped by the polygon. An internal
 * temporary surface avoids changing the compositor's global clip state. */
void graosVectorTextured(VMODE *v,const GRAOS_VPOLYGON *shape,
                        int x,int y,int width,int height,
                        const GRAOS_PIXEL *tex,int tw,int th,int stride,int blend)
{
    GRAOS_PIXEL *scaled;VMODE local;
    int sy,sx,j,k,crossing,ax,ay,bx,by;
    if(!v||!v->buf||!shape||!shape->points||shape->count<3||
       shape->count>VECTOR_MAX_POINTS||!tex||tw<1||th<1||stride<tw||
       width<1||height<1||width>v->width||height>v->height)return;
    if((size_t)width>(size_t)-1/(size_t)height/sizeof(GRAOS_PIXEL))return;
    scaled=(GRAOS_PIXEL*)malloc((size_t)width*height*sizeof(GRAOS_PIXEL));
    if(!scaled)return;
    local=*v;local.buf=scaled;local.width=width;local.height=height;
    guiBlitBilinear(&local,0,0,width,height,tex,tw,th,stride,GRAOS_BLIT_OPAQUE);
    for(sy=0;sy<height;sy++){
       int dy=y+sy;if(dy<0||dy>=v->height)continue;
       for(sx=0;sx<width;sx++){
          int dx=x+sx;if(dx<0||dx>=v->width)continue;
          crossing=0;
          for(j=0;j<(int)shape->count;j++){
             k=(j+1)%(int)shape->count;
             ax=(int)shape->points[j].x*width/1024;
             ay=(int)shape->points[j].y*height/1024;
             bx=(int)shape->points[k].x*width/1024;
             by=(int)shape->points[k].y*height/1024;
             if((ay<=sy&&by>sy)||(by<=sy&&ay>sy)){
                 long xx=ax+((long)(bx-ax)*(sy-ay))/(by-ay);
                 if(xx>sx)crossing=!crossing;
             }
          }
          if(crossing){
             GRAOS_PIXEL p=scaled[(size_t)sy*width+sx];
             GRAOS_PIXEL *d=&v->buf[(size_t)dy*v->width+dx];
             *d=blend?graosAlphaOver(*d,p):p;
          }
       }
    }
    free(scaled);v->dirty=1;
}
