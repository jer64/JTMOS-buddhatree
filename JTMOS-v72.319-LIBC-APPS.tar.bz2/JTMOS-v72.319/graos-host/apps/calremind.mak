# JTMOS v72.89 calendar reminder agent
APPNAME=calremind
APP_OBJS=calremind.o calendar4_remind.o calendar4_store.o calendar3_store.o calendar_store.o
include app-common.mk
