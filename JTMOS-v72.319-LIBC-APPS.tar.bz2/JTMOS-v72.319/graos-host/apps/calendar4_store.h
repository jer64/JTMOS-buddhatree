#ifndef JTMOS_CALENDAR4_STORE_H
#define JTMOS_CALENDAR4_STORE_H
#define CAL4_MAX 128
#define CAL4_TITLE_MAX 95
#define CAL4_DEFAULT_DURATION 60
#define CAL4_NONE 0
#define CAL4_DAILY 1
#define CAL4_WEEKLY 2
#define CAL4_MONTHLY 3
#define CAL4_YEARLY 4
#define CAL4_REMIND_OFF 9999

typedef struct {
    unsigned long id;
    int year,month,day,hour,minute,duration;
    int repeat; /* 0=none, 1=daily, 2=weekly, 3=monthly, 4=yearly */
    int remind; /* minutes before, 0..1440 or CAL4_REMIND_OFF */
    char title[CAL4_TITLE_MAX+1];
} CAL4_EVENT;
typedef struct {
    CAL4_EVENT items[CAL4_MAX];
    int count;
    unsigned long generation,next_id;
    int active_slot,read_only;
} CAL4_STORE;
enum { CAL4_OK=0,CAL4_IO=-1,CAL4_FULL=-2,CAL4_CORRUPT=-3,
       CAL4_BAD_DATE=-4,CAL4_BAD_TITLE=-5,CAL4_ID_EXHAUSTED=-6,
       CAL4_NOT_FOUND=-7,CAL4_BAD_TIME=-8,CAL4_BAD_REPEAT=-9 };
int cal4_load(CAL4_STORE *store);
int cal4_add(CAL4_STORE *s,int y,int m,int d,int h,int minute,int duration,const char *title,int repeat,int remind,unsigned long *new_id);
int cal4_update(CAL4_STORE *s,unsigned long id,int y,int m,int d,int h,int minute,int duration,const char *title,int repeat,int remind);
int cal4_delete(CAL4_STORE *s,unsigned long id);
int cal4_list_date(const CAL4_STORE *s,int y,int m,int d,int *indices,int cap);
int cal4_occurs(const CAL4_EVENT *e,int y,int m,int d);
int cal4_valid_time(int h,int m,int duration);
int cal4_validate(const CAL4_EVENT *e);
int cal4_import_batch(CAL4_STORE *s,const CAL4_EVENT *events,int n,int *imported);
/* Serial day number in proleptic Gregorian calendar; 1900..9999. */
int cal4_day_number(int y,int m,int d);
#endif
