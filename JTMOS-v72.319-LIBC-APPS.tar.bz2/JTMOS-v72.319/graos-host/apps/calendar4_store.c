/* JTMOS 72.89 calendar persistence: CRC32-checked, independently committed
 * generations, legacy v3/v2 reader only. Never modifies older slots.
 * Requires an exclusive writer (the desktop launcher prevents GUI duplicates).
 * fsync success depends on the installed filesystem implementation.
 */
#include "calendar4_store.h"
#include "calendar3_store.h"
#include "calendar_store.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#ifndef CAL4_FILE_A
#define CAL4_FILE_A "/calendar4.a"
#endif
#ifndef CAL4_FILE_B
#define CAL4_FILE_B "/calendar4.b"
#endif
#define CAL4_LINE 224
#define CAL4_HEADER 100
#define CAL4_MAX_GEN 0xFFFFFFFFUL
#define CAL4_MAX_ID 0xFFFFFFFEUL

static CAL4_STORE staging, validated;
static CAL3_STORE legacy;

int cal4_valid_time(int h,int m,int duration)
{
    return h>=0 && h<=23 && m>=0 && m<=59 && duration>=1 && duration<=1440;
}
int cal4_validate(const CAL4_EVENT *e)
{
    if(!e || !calendar_valid_date(e->year,e->month,e->day))return CAL4_BAD_DATE;
    if(!cal4_valid_time(e->hour,e->minute,e->duration))return CAL4_BAD_TIME;
    if(e->repeat<CAL4_NONE || e->repeat>CAL4_YEARLY ||
       (e->remind!=CAL4_REMIND_OFF && (e->remind<0 || e->remind>1440)))return CAL4_BAD_REPEAT;
    return CAL4_OK;
}
int cal4_day_number(int y,int m,int d)
{
    static const int before[12]={0,31,59,90,120,151,181,212,243,273,304,334};
    int yy=y-1;
    if(!calendar_valid_date(y,m,d))return -1;
    return 365*yy+yy/4-yy/100+yy/400+before[m-1]+d+(m>2&&((y%4==0 && y%100!=0)||y%400==0));
}
int cal4_occurs(const CAL4_EVENT *e,int y,int m,int d)
{
    int at,start;
    if(!e || !calendar_valid_date(y,m,d))return 0;
    at=cal4_day_number(y,m,d);start=cal4_day_number(e->year,e->month,e->day);
    if(at<start)return 0;
    switch(e->repeat){
    case CAL4_NONE:return at==start;
    case CAL4_DAILY:return 1;
    case CAL4_WEEKLY:return (at-start)%7==0;
    case CAL4_MONTHLY:return d==e->day;
    case CAL4_YEARLY:return m==e->month && d==e->day;
    default:return 0;
    }
}
static int good_title(const char *title)
{
    int i;
    if(!title || !*title) return 0;
    for(i=0;title[i];i++) {
        unsigned char c=(unsigned char)title[i];
        if(i>=CAL4_TITLE_MAX || c<32 || c==127) return 0;
    }
    return 1;
}
static unsigned long crc_update(unsigned long crc,const char *line)
{
    const unsigned char *p=(const unsigned char *)line;
    while(*p) {
        int b;
        crc^=(unsigned long)*p++;
        for(b=0;b<8;b++) crc=(crc>>1)^((crc&1UL)?0xEDB88320UL:0UL);
    }
    return crc&0xFFFFFFFFUL;
}
static int find_id(const CAL4_STORE *s,unsigned long id)
{
    int i;
    for(i=0;i<s->count;i++) if(s->items[i].id==id) return i;
    return -1;
}
static int format_row(char *row,size_t cap,const CAL4_EVENT *e)
{
    int n=snprintf(row,cap,"%08lX|%04d-%02d-%02d|%02d:%02d|%04d|%1d|%04d|%s\n",
       e->id,e->year,e->month,e->day,e->hour,e->minute,e->duration,e->repeat,e->remind,e->title);
    return n>0 && (size_t)n<cap;
}
/* Returns 0 valid; 1 absent; -1 corrupt or inaccessible. */
static int read_slot(const char *path,CAL4_STORE *out)
{
    FILE *f;
    char header[CAL4_HEADER],row[CAL4_LINE],extra;
    unsigned long generation,next_id,crc_expected,id,crc=0xFFFFFFFFUL,max_id=0;
    int count,i,rv=-1,n;
    memset(out,0,sizeof(*out));out->next_id=1;out->active_slot=-1;
    f=fopen(path,"rb");if(!f)return 1;
    if(!fgets(header,sizeof(header),f) || !strchr(header,'\n')) goto done;
    n=0;
    if(sscanf(header,"JTCAL4 %lx %d %lx %lx %n",&generation,&count,&next_id,&crc_expected,&n)!=4 ||
       n<=0 || header[n]!='\0' || generation==0 || generation>CAL4_MAX_GEN ||
       next_id==0 || next_id>CAL4_MAX_ID+1UL || crc_expected>0xFFFFFFFFUL ||
       count<0 || count>CAL4_MAX) goto done;
    for(i=0;i<count;i++) {
        CAL4_EVENT *e=&out->items[i];
        char idbuf[9],datebuf[11],timebuf[6],durbuf[5],*title;
        int consumed=0,j;
        if(!fgets(row,sizeof(row),f) || !strchr(row,'\n')) goto done;
        crc=crc_update(crc,row);
        if(strlen(row)<40 || row[8]!='|' || row[19]!='|' || row[25]!='|' || row[30]!='|' || row[32]!='|' || row[37]!='|') goto done;
        memcpy(idbuf,row,8);idbuf[8]=0;
        if(sscanf(idbuf,"%lx%n",&id,&consumed)!=1 || consumed!=8 || id==0 || id>CAL4_MAX_ID || find_id(out,id)>=0) goto done;
        memcpy(datebuf,row+9,10);datebuf[10]=0;
        consumed=0;
        if(sscanf(datebuf,"%4d-%2d-%2d%n",&e->year,&e->month,&e->day,&consumed)!=3 || consumed!=10 ||
            !calendar_valid_date(e->year,e->month,e->day))goto done;
        memcpy(timebuf,row+20,5);timebuf[5]=0;
        consumed=0;
        if(sscanf(timebuf,"%2d:%2d%n",&e->hour,&e->minute,&consumed)!=2 || consumed!=5)goto done;
        memcpy(durbuf,row+26,4);durbuf[4]=0;
        for(j=0;j<4;j++)if(durbuf[j]<'0'||durbuf[j]>'9')goto done;
        e->duration=atoi(durbuf);
        if(!cal4_valid_time(e->hour,e->minute,e->duration))goto done;
        if(row[31]<'0'||row[31]>'4')goto done;
        e->repeat=row[31]-'0';
        for(j=33;j<37;j++)if(row[j]<'0'||row[j]>'9')goto done;
        e->remind=(row[33]-'0')*1000+(row[34]-'0')*100+(row[35]-'0')*10+row[36]-'0';
        if(cal4_validate(e)!=CAL4_OK)goto done;
        title=row+38;
        title[strlen(title)-1]=0;
        if(!good_title(title))goto done;
        e->id=id;strcpy(e->title,title);out->count++;
        if(id>max_id)max_id=id;
    }
    if(fread(&extra,1,1,f) || ferror(f))goto done;
    if(((~crc)&0xFFFFFFFFUL)!=crc_expected || next_id<=max_id)goto done;
    out->generation=generation;out->next_id=next_id;rv=0;
done:
    if(fclose(f)!=0)rv=-1;
    return rv;
}
static int write_slot(const char *path,const CAL4_STORE *s)
{
    FILE *f;char header[CAL4_HEADER],row[CAL4_LINE];
    unsigned long crc=0xFFFFFFFFUL;int i,n,ok=1;
    for(i=0;i<s->count;i++){
        if(!format_row(row,sizeof(row),&s->items[i]))return CAL4_BAD_TITLE;
        crc=crc_update(crc,row);
    }
    n=snprintf(header,sizeof(header),"JTCAL4 %08lX %03d %08lX %08lX\n",
       s->generation,s->count,s->next_id,(~crc)&0xFFFFFFFFUL);
    if(n<=0 || n>=(int)sizeof(header))return CAL4_IO;
    f=fopen(path,"wb");if(!f)return CAL4_IO;
    if(fwrite(header,1,(size_t)n,f)!=(size_t)n)ok=0;
    for(i=0;ok && i<s->count;i++){
        size_t l;
        if(!format_row(row,sizeof(row),&s->items[i])){ok=0;break;}
        l=strlen(row);
        if(fwrite(row,1,l,f)!=l)ok=0;
    }
    if(ok && fflush(f)!=0)ok=0;
    if(ok && fsync(fileno(f))!=0)ok=0;
    if(fclose(f)!=0)ok=0;
    if(!ok)return CAL4_IO;
    if(read_slot(path,&validated)!=0 || validated.generation!=s->generation ||
       validated.count!=s->count || validated.next_id!=s->next_id)return CAL4_IO;
    for(i=0;i<s->count;i++){
        const CAL4_EVENT *a=&s->items[i],*b=&validated.items[i];
        if(a->id!=b->id || a->year!=b->year || a->month!=b->month || a->day!=b->day ||
           a->hour!=b->hour || a->minute!=b->minute || a->duration!=b->duration ||
           a->repeat!=b->repeat || a->remind!=b->remind ||
           strcmp(a->title,b->title))return CAL4_IO;
    }
    return CAL4_OK;
}
int cal4_load(CAL4_STORE *store)
{
    int a,b,i,old;
    if(!store)return CAL4_IO;
    a=read_slot(CAL4_FILE_A,store);
    b=read_slot(CAL4_FILE_B,&staging);
    if(a==0 && (b!=0 || store->generation>=staging.generation)){
        store->active_slot=0;return CAL4_OK;
    }
    if(b==0){*store=staging;store->active_slot=1;return CAL4_OK;}
    memset(store,0,sizeof(*store));store->next_id=1;store->active_slot=-1;
    if(a<0 || b<0){store->read_only=1;return CAL4_CORRUPT;}
    old=cal3_load(&legacy);
    if(old!=CAL3_OK){store->read_only=1;return old==CAL3_IO?CAL4_IO:CAL4_CORRUPT;}
    for(i=0;i<legacy.count;i++){
        CAL3_EVENT *e=&legacy.items[i];CAL4_EVENT *n=&store->items[i];
        n->id=e->id;n->year=e->year;n->month=e->month;n->day=e->day;
        n->hour=e->hour;n->minute=e->minute;n->duration=e->duration;
        n->repeat=CAL4_NONE;n->remind=CAL4_REMIND_OFF;
        strcpy(n->title,e->title);
        store->count++;
    }
    store->next_id=legacy.next_id;
    return CAL4_OK;
}
static int persist(CAL4_STORE *store)
{
    int target,rv;
    if(store->generation>=CAL4_MAX_GEN)return CAL4_ID_EXHAUSTED;
    staging.generation=store->generation+1UL;
    target=store->active_slot==0?1:0;
    rv=write_slot(target==0?CAL4_FILE_A:CAL4_FILE_B,&staging);
    if(rv==CAL4_OK){staging.active_slot=target;*store=staging;}
    return rv;
}
int cal4_add(CAL4_STORE *store,int y,int m,int d,int h,int minute,int duration,const char *title,int repeat,int remind,unsigned long *new_id)
{
    unsigned long id;
    CAL4_EVENT *e;
    int rv;
    if(!store || store->read_only)return CAL4_CORRUPT;
    if(!calendar_valid_date(y,m,d))return CAL4_BAD_DATE;
    if(!cal4_valid_time(h,minute,duration))return CAL4_BAD_TIME;
    if(!good_title(title))return CAL4_BAD_TITLE;
    if(repeat<CAL4_NONE || repeat>CAL4_YEARLY || (remind!=CAL4_REMIND_OFF && (remind<0 || remind>1440)))return CAL4_BAD_REPEAT;
    if(store->count>=CAL4_MAX)return CAL4_FULL;
    if(store->next_id==0 || store->next_id>CAL4_MAX_ID)return CAL4_ID_EXHAUSTED;
    staging=*store;
    id=staging.next_id++;
    e=&staging.items[staging.count++];
    e->id=id;e->repeat=repeat;e->remind=remind;
    e->year=y;e->month=m;e->day=d;e->hour=h;e->minute=minute;e->duration=duration;
    strcpy(e->title,title);
    rv=persist(store);
    if(rv==CAL4_OK && new_id)*new_id=id;
    return rv;
}
int cal4_update(CAL4_STORE *store,unsigned long id,int y,int m,int d,int h,int minute,int duration,const char *title,int repeat,int remind)
{
    CAL4_EVENT *e;
    int i;
    if(!store || store->read_only)return CAL4_CORRUPT;
    if(!calendar_valid_date(y,m,d))return CAL4_BAD_DATE;
    if(!cal4_valid_time(h,minute,duration))return CAL4_BAD_TIME;
    if(!good_title(title))return CAL4_BAD_TITLE;
    if(repeat<CAL4_NONE || repeat>CAL4_YEARLY || (remind!=CAL4_REMIND_OFF && (remind<0 || remind>1440)))return CAL4_BAD_REPEAT;
    i=find_id(store,id);if(i<0)return CAL4_NOT_FOUND;
    staging=*store;e=&staging.items[i];
    e->repeat=repeat;e->remind=remind;
    e->year=y;e->month=m;e->day=d;e->hour=h;e->minute=minute;e->duration=duration;
    strcpy(e->title,title);
    return persist(store);
}
int cal4_delete(CAL4_STORE *store,unsigned long id)
{
    int i;
    if(!store || store->read_only)return CAL4_CORRUPT;
    i=find_id(store,id);if(i<0)return CAL4_NOT_FOUND;
    staging=*store;
    memmove(&staging.items[i],&staging.items[i+1],(size_t)(staging.count-i-1)*sizeof(CAL4_EVENT));
    staging.count--;
    return persist(store);
}
int cal4_list_date(const CAL4_STORE *store,int y,int m,int d,int *indices,int cap)
{
    int count=0,i,j,t;
    if(!store || !indices || cap<1)return 0;
    for(i=0;i<store->count && count<cap;i++){
        const CAL4_EVENT *e=&store->items[i];
        if(cal4_occurs(e,y,m,d))indices[count++]=i;
    }
    for(i=1;i<count;i++){
        t=indices[i];j=i;
        while(j>0){
            const CAL4_EVENT *a=&store->items[indices[j-1]],*b=&store->items[t];
            if(a->hour*60+a->minute < b->hour*60+b->minute ||
               (a->hour==b->hour && a->minute==b->minute && a->id<b->id))break;
            indices[j]=indices[j-1];j--;
        }
        indices[j]=t;
    }
    return count;
}

/* Atomic from the calendar's perspective: validate and stage every event first.
 * One generation write commits the whole import or none of it. */
int cal4_import_batch(CAL4_STORE *store,const CAL4_EVENT *items,int count,int *imported)
{
    int i,rv;
    if(imported)*imported=0;
    if(!store || store->read_only || count<0)return CAL4_CORRUPT;
    if(count>CAL4_MAX-store->count)return CAL4_FULL;
    staging=*store;
    for(i=0;i<count;i++){
        CAL4_EVENT *e;
        if(cal4_validate(&items[i])!=CAL4_OK || !good_title(items[i].title))return CAL4_BAD_TITLE;
        if(staging.next_id==0 || staging.next_id>CAL4_MAX_ID)return CAL4_ID_EXHAUSTED;
        e=&staging.items[staging.count++];
        *e=items[i];e->id=staging.next_id++;
    }
    if(count==0)return CAL4_OK;
    rv=persist(store);
    if(rv==CAL4_OK && imported)*imported=count;
    return rv;
}
