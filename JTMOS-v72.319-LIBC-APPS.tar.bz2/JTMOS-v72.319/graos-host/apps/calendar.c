/* JTMOS v72.89 – GraOS Calendar stage 4.
 * Standalone app: multi-event days, local start times, duration, paged list,
 * per-event stable IDs. The integrated GraOS tray launches this app.
 * Stores v3 slots separately and imports v72.86 v2 slots read-only.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <jtmos/graos.h>
#include <jtmos/graosprotocol.h>
#include <jtmos/console.h>
#include <jtmos/process.h>
#include <jtmos/syscall.h>
#include <jtmos/syscallcodes.h>
#include "calendar4_store.h"
#include "calendar4_ics.h"

SYSMEMREQ(APPRAM_256K)
#define PANEL_H 30
#define CAL_W 240
#define CAL_H 208
#define CAL_IMPORT 7441
#define CAL_EXPORT 7442
#define CAL_PREV 7410
#define CAL_NEXT 7411
#define CAL_TITLE 7420
#define CAL_WEEKDAYS 7421
#define CAL_FOOTER 7440
#define CAL_DAY0 7500

#define DAY_W 445
#define DAY_H 316
#define DAY_TITLE 7810
#define DAY_INFO 7811
#define DAY_ROW0 7900
#define DAY_PAGE_PREV 7920
#define DAY_PAGE_NEXT 7921
#define DAY_ADD 7922
#define DAY_CLOSE 7923
#define DAY_PAGE_SIZE 8

#define EDIT_W 430
#define EDIT_H 265
#define EDIT_REPEAT 7608
#define EDIT_REMIND 7609
#define EDIT_TITLE 7600
#define EDIT_TIME 7601
#define EDIT_TEXT 7602
#define EDIT_DURATION 7603
#define EDIT_SAVE 7604
#define EDIT_DELETE 7605
#define EDIT_CANCEL 7606
#define EDIT_STATUS 7607

static CAL4_STORE store;
static int load_status;
static int day_index[CAL4_MAX],day_count,day_page;

static int events_on_day(int y,int m,int d)
{
    int i,n=0;
    for(i=0;i<store.count;i++)
        if(cal4_occurs(&store.items[i],y,m,d))n++;
    return n;
}
static CAL4_EVENT *event_by_id(unsigned long id)
{
    int i;
    for(i=0;i<store.count;i++)if(store.items[i].id==id)return &store.items[i];
    return NULL;
}
static void place_window(int sw,int sh,int w,int h,int *x,int *y)
{
    *x=sw-w-6;*y=sh-PANEL_H-h-5;
    if(*x<0)*x=0;
    if(*y<0)*y=0;
}
static void close_popup(int *w)
{
    if(w && *w>=0){closeWindow(*w);*w=-1;}
}

typedef struct {int second,minute,hour,day,month,year;int res[10];} SYS_DATE;
static int norm_year(int y){if(y>=1900)return y;if(y>=70)return 1900+y;if(y>=0)return 2000+y;return 2000;}
static int leap_year(int y){return y%4==0 && (y%100!=0 || y%400==0);}
static int month_days(int y,int m)
{
    static const int days[12]={31,28,31,30,31,30,31,31,30,31,30,31};
    if(m<1 || m>12)return 30;
    return days[m-1]+(m==2 && leap_year(y));
}
static int weekday_monday(int year,int month,int day)
{
    static const int t[12]={0,3,2,5,0,3,5,1,4,6,2,4};
    int y=year,s;
    if(month<3)y--;
    s=(y+y/4-y/100+y/400+t[month-1]+day)%7;
    return (s+6)%7;
}
static int read_clock(SYS_DATE *d)
{
    if(!d || jtmos_syscall7(SYS_getdate,(uintptr_t)d,0,0,0,0,0)<0)return -1;
    if(d->hour<0 || d->hour>23 || d->minute<0 || d->minute>59 ||
       d->month<1 || d->month>12 || d->day<1 ||
       d->day>month_days(norm_year(d->year),d->month))return -1;
    return 0;
}
static int make_calendar(int sw,int sh,int year,int month,const SYS_DATE *today)
{
    static const char *months[12]={"Tammikuu","Helmikuu","Maaliskuu","Huhtikuu",
        "Toukokuu","Kesakuu","Heinakuu","Elokuu","Syyskuu","Lokakuu","Marraskuu","Joulukuu"};
    int x,y,wid,i,first=weekday_monday(year,month,1),day,n;
    char label[18],header[60],footer[100];
    place_window(sw,sh,CAL_W,CAL_H,&x,&y);
    wid=createWindow(x,y,CAL_W,CAL_H,"JTMOS Calendar",GRAOS_WINDOW_HAS_BORDER|GRAOS_WINDOW_AUTOCLEAR);
    if(wid<0)return wid;
    createButtonStyled(wid,4,4,28,25,CAL_PREV,GRAOS_BUTTON_STANDARD,"<");
    createButtonStyled(wid,CAL_W-29,4,CAL_W-5,25,CAL_NEXT,GRAOS_BUTTON_STANDARD,">");
    snprintf(header,sizeof(header),"%s %d",months[month-1],year);
    createLabel(wid,32,8,CAL_W-64,12,CAL_TITLE,0,GRAOS_LABEL_TRANSPARENT,GRAOS_LABEL_ALIGN_CENTER,header);
    createLabel(wid,8,29,CAL_W-16,12,CAL_WEEKDAYS,0,GRAOS_LABEL_TRANSPARENT,GRAOS_LABEL_ALIGN_CENTER,
                "Ma    Ti    Ke    To    Pe    La    Su");
    for(i=0;i<42;i++){
        day=i-first+1;label[0]=0;
        if(day>=1 && day<=month_days(year,month)){
            n=events_on_day(year,month,day);
            if(today && year==norm_year(today->year) && month==today->month && day==today->day)
                snprintf(label,sizeof(label),n?"[%d]*":"[%d]",day);
            else snprintf(label,sizeof(label),n?"%d*":"%d",day);
        }
        createButtonStyled(wid,5+(i%7)*33,43+(i/7)*17,36+(i%7)*33,60+(i/7)*17,
                           CAL_DAY0+i,GRAOS_BUTTON_STANDARD,label);
    }
    snprintf(footer,sizeof(footer),"%d merkintaa   * tapahtumia",store.count);
    createLabel(wid,5,149,CAL_W-10,12,CAL_FOOTER,0,GRAOS_LABEL_TRANSPARENT,GRAOS_LABEL_ALIGN_CENTER,footer);
    createButtonStyled(wid,6,170,112,199,CAL_IMPORT,GRAOS_BUTTON_STANDARD,"ICS Import");
    createButtonStyled(wid,122,170,CAL_W-6,199,CAL_EXPORT,GRAOS_BUTTON_STANDARD,"ICS Export");
    refreshWindow(wid);
    return wid;
}
static void shift_month(int delta,int *year,int *month)
{
    if(delta<0 && *year==1900 && *month==1)return;
    if(delta>0 && *year==9999 && *month==12)return;
    *month+=delta;
    if(*month<1){*month=12;(*year)--;}
    if(*month>12){*month=1;(*year)++;}
}
static int make_day(int sw,int sh,int year,int month,int day,int page)
{
    int x,y,wid,i,j;
    char label[120],hdr[80],info[90];
    day_count=cal4_list_date(&store,year,month,day,day_index,CAL4_MAX);
    if(page<0)page=0;
    if(page>0 && page*DAY_PAGE_SIZE>=day_count)page=(day_count-1)/DAY_PAGE_SIZE;
    if(page<0)page=0;
    day_page=page;
    place_window(sw,sh,DAY_W,DAY_H,&x,&y);
    wid=createWindow(x,y,DAY_W,DAY_H,"Calendar day",GRAOS_WINDOW_HAS_BORDER|GRAOS_WINDOW_AUTOCLEAR);
    if(wid<0)return wid;
    snprintf(hdr,sizeof(hdr),"%02d.%02d.%04d  -  %d tapahtumaa",day,month,year,day_count);
    createLabel(wid,8,7,DAY_W-16,22,DAY_TITLE,0,GRAOS_LABEL_TRANSPARENT,GRAOS_LABEL_ALIGN_LEFT,hdr);
    for(i=0;i<DAY_PAGE_SIZE;i++){
        j=page*DAY_PAGE_SIZE+i;
        if(j>=day_count)break;
        {
            CAL4_EVENT *e=&store.items[day_index[j]];
            snprintf(label,sizeof(label),"%02d:%02d  %s",e->hour,e->minute,e->title);
            createButtonStyled(wid,8,37+i*27,DAY_W-8,61+i*27,DAY_ROW0+i,
                               GRAOS_BUTTON_STANDARD,label);
        }
    }
    if(!day_count)
        createLabel(wid,12,49,DAY_W-24,22,DAY_INFO,0,GRAOS_LABEL_TRANSPARENT,
                    GRAOS_LABEL_ALIGN_LEFT,"Ei tapahtumia. Valitse Uusi.");
    snprintf(info,sizeof(info),"Sivu %d/%d",page+1,
             (day_count+DAY_PAGE_SIZE-1)/DAY_PAGE_SIZE>0?
              (day_count+DAY_PAGE_SIZE-1)/DAY_PAGE_SIZE:1);
    createLabel(wid,100,265,130,18,DAY_INFO,0,GRAOS_LABEL_TRANSPARENT,GRAOS_LABEL_ALIGN_CENTER,info);
    createButtonStyled(wid,8,263,36,286,DAY_PAGE_PREV,GRAOS_BUTTON_STANDARD,"<");
    createButtonStyled(wid,40,263,68,286,DAY_PAGE_NEXT,GRAOS_BUTTON_STANDARD,">");
    createButtonStyled(wid,DAY_W-180,263,DAY_W-100,288,DAY_ADD,GRAOS_BUTTON_STANDARD,"Uusi");
    createButtonStyled(wid,DAY_W-92,263,DAY_W-8,288,DAY_CLOSE,GRAOS_BUTTON_STANDARD,"Sulje");
    refreshWindow(wid);return wid;
}
static int make_editor(int sw,int sh,int y,int m,int d,unsigned long id)
{
    int x,pos,wid;char label[85],time[6],duration[8],repeat[6],remind[6];
    CAL4_EVENT *e=id?event_by_id(id):NULL;
    if(id && !e)return -1;
    place_window(sw,sh,EDIT_W,EDIT_H,&x,&pos);
    wid=createWindow(x,pos,EDIT_W,EDIT_H,id?"Edit calendar event":"New calendar event",
                     GRAOS_WINDOW_HAS_BORDER|GRAOS_WINDOW_AUTOCLEAR);
    if(wid<0)return wid;
    snprintf(label,sizeof(label),"Tapahtuma %02d.%02d.%04d",d,m,y);
    createLabel(wid,8,8,EDIT_W-16,18,EDIT_TITLE,0,GRAOS_LABEL_TRANSPARENT,GRAOS_LABEL_ALIGN_LEFT,label);
    createLabel(wid,8,33,70,22,7700,0,GRAOS_LABEL_TRANSPARENT,GRAOS_LABEL_ALIGN_LEFT,"Aika HH:MM");
    snprintf(time,sizeof(time),"%02d:%02d",e?e->hour:9,e?e->minute:0);
    createTextBox(wid,90,30,68,26,EDIT_TIME,5,time);
    createLabel(wid,168,33,80,22,7701,0,GRAOS_LABEL_TRANSPARENT,GRAOS_LABEL_ALIGN_LEFT,"Kesto min");
    snprintf(duration,sizeof(duration),"%d",e?e->duration:CAL4_DEFAULT_DURATION);
    createTextBox(wid,265,30,60,26,EDIT_DURATION,4,duration);
    createLabel(wid,8,67,82,22,7702,0,GRAOS_LABEL_TRANSPARENT,GRAOS_LABEL_ALIGN_LEFT,"Otsikko");
    createTextBox(wid,90,62,EDIT_W-100,27,EDIT_TEXT,CAL4_TITLE_MAX,e?e->title:"");
    createLabel(wid,8,100,235,20,7703,0,GRAOS_LABEL_TRANSPARENT,GRAOS_LABEL_ALIGN_LEFT,"Toisto: 0 ei, 1 pv, 2 vk, 3 kk, 4 v");
    snprintf(repeat,sizeof(repeat),"%d",e?e->repeat:CAL4_NONE);
    createTextBox(wid,330,97,58,24,EDIT_REPEAT,2,repeat);
    createLabel(wid,8,132,290,22,7704,0,GRAOS_LABEL_TRANSPARENT,GRAOS_LABEL_ALIGN_LEFT,"Muistutus min ennen (9999=pois)");
    snprintf(remind,sizeof(remind),"%d",e?e->remind:CAL4_REMIND_OFF);
    createTextBox(wid,330,128,70,25,EDIT_REMIND,4,remind);
    createLabel(wid,8,163,EDIT_W-16,20,EDIT_STATUS,0,GRAOS_LABEL_TRANSPARENT,
                GRAOS_LABEL_ALIGN_LEFT,load_status<0?"Tallennus: vanhat tiedot ovat lukutilassa":"Useita merkintoja samalle paivalle");
    createButtonStyled(wid,8,195,116,231,EDIT_SAVE,GRAOS_BUTTON_STANDARD,"Tallenna");
    if(e)createButtonStyled(wid,125,195,233,231,EDIT_DELETE,GRAOS_BUTTON_STANDARD,"Poista");
    createButtonStyled(wid,245,195,EDIT_W-8,231,EDIT_CANCEL,GRAOS_BUTTON_STANDARD,"Peruuta");
    refreshWindow(wid);return wid;
}
static int parse_time(const char *s,int *h,int *m)
{
    if(strlen(s)!=5 || s[2]!=':' || s[0]<'0' || s[0]>'9' || s[1]<'0' || s[1]>'9' ||
       s[3]<'0' || s[3]>'9' || s[4]<'0' || s[4]>'9')return 0;
    *h=(s[0]-'0')*10+s[1]-'0';*m=(s[3]-'0')*10+s[4]-'0';
    return *h<=23 && *m<=59;
}
static int parse_duration(const char *s,int *d)
{
    unsigned int i;int v=0;
    if(!s[0])return 0;
    for(i=0;s[i];i++){
        if(i>=4 || s[i]<'0' || s[i]>'9')return 0;
        v=v*10+s[i]-'0';
    }
    *d=v;return v>=1 && v<=1440;
}
static const char *save_error(int err)
{
    switch(err){
    case CAL4_FULL:return "Kalenteri on taynna (128 tapahtumaa)";
    case CAL4_BAD_DATE:return "Virheellinen paivamaara";
    case CAL4_BAD_TITLE:return "Virheellinen otsikko";
    case CAL4_BAD_TIME:return "Virheellinen kellonaika tai kesto";
    case CAL4_CORRUPT:return "Tietokanta vain luku - palautus tarvitaan";
    case CAL4_ID_EXHAUSTED:return "Tapahtumatunniste loppui";
    case CAL4_BAD_REPEAT:return "Virheellinen toisto tai muistutus";
    default:return "Tallennus epaonnistui";
    }
}
static int calendar_loop(int sw,int sh)
{
    GUICMD ev;
    SYS_DATE today,previous;
    int have_today=0,year=2000,month=1,dy=0,dm=0,dd=0;
    int cal=-1,daywin=-1,editor=-1,rv,n;
    unsigned long edit_id=0,last_tick=0,now_tick;
    char title[CAL4_TITLE_MAX+1],time[16],dur[16],rep[16],rem[16];
    load_status=cal4_load(&store);
    if(read_clock(&today)==0){have_today=1;previous=today;year=norm_year(today.year);month=today.month;}
    cal=make_calendar(sw,sh,year,month,have_today?&previous:NULL);
    if(cal<0)return 3;
    for(;;){
        while((n=JtmosGraOSPollEvent(cal,&ev))>0){
            if(ev.id==GRAOS_GSID_EXIT || (ev.id==GRAOS_GSID_KEYPRESSED && ev.v[0]==JKEY_ESC)){
                close_popup(&editor);close_popup(&daywin);close_popup(&cal);return 0;
            }
            if(ev.id!=GRAOS_GSID_BUTTON)continue;
            if(ev.v[0]==CAL_PREV || ev.v[0]==CAL_NEXT){
                shift_month(ev.v[0]==CAL_PREV?-1:1,&year,&month);
                close_popup(&editor);close_popup(&daywin);close_popup(&cal);
                cal=make_calendar(sw,sh,year,month,have_today?&previous:NULL);
                if(cal<0)return 3;
            }else if(ev.v[0]==CAL_IMPORT || ev.v[0]==CAL_EXPORT){
                int changed=ev.v[0]==CAL_IMPORT,imported=0;
                rv=changed?cal4_ics_import(&store,CAL4_ICS_IMPORT,&imported):
                           cal4_ics_export(&store,CAL4_ICS_EXPORT);
                if(rv==CAL4_OK && changed){
                    close_popup(&editor);close_popup(&daywin);close_popup(&cal);
                    cal=make_calendar(sw,sh,year,month,have_today?&previous:NULL);
                    if(cal<0)return 3;
                }
                if(rv==CAL4_OK){
                    char msg[100];
                    if(changed)snprintf(msg,sizeof(msg),"ICS: %d tuotua tapahtumaa",imported);
                    else strcpy(msg,"ICS viety: /calendar-export.ics");
                    setLabelText(cal,CAL_FOOTER,msg);
                }else setLabelText(cal,CAL_FOOTER,
                    "ICS virhe. Tarkista tiedosto tai sen ominaisuudet.");
                refreshWindow(cal);
            }else if(ev.v[0]>=CAL_DAY0 && ev.v[0]<CAL_DAY0+42){
                int d=ev.v[0]-CAL_DAY0-weekday_monday(year,month,1)+1;
                if(d<1 || d>month_days(year,month))continue;
                close_popup(&editor);close_popup(&daywin);
                dy=year;dm=month;dd=d;day_page=0;
                daywin=make_day(sw,sh,dy,dm,dd,0);
            }
        }
        if(n<0){close_popup(&editor);close_popup(&daywin);return 4;}
        if(daywin>=0){
            while((n=JtmosGraOSPollEvent(daywin,&ev))>0){
                if(ev.id==GRAOS_GSID_EXIT){daywin=-1;close_popup(&editor);break;}
                if(ev.id!=GRAOS_GSID_BUTTON && !(ev.id==GRAOS_GSID_KEYPRESSED && ev.v[0]==JKEY_ESC))continue;
                if((ev.id==GRAOS_GSID_KEYPRESSED && ev.v[0]==JKEY_ESC) || ev.v[0]==DAY_CLOSE){
                    close_popup(&editor);close_popup(&daywin);break;
                }
                if(ev.v[0]==DAY_PAGE_PREV || ev.v[0]==DAY_PAGE_NEXT){
                    int next=day_page+(ev.v[0]==DAY_PAGE_NEXT?1:-1);
                    if(next<0 || (next*DAY_PAGE_SIZE>=day_count && next>0))continue;
                    close_popup(&editor);close_popup(&daywin);
                    daywin=make_day(sw,sh,dy,dm,dd,next);
                }else if(ev.v[0]==DAY_ADD){
                    close_popup(&editor);edit_id=0;
                    editor=make_editor(sw,sh,dy,dm,dd,0);
                }else if(ev.v[0]>=DAY_ROW0 && ev.v[0]<DAY_ROW0+DAY_PAGE_SIZE){
                    int index=day_page*DAY_PAGE_SIZE+ev.v[0]-DAY_ROW0;
                    if(index>=0 && index<day_count){
                        edit_id=store.items[day_index[index]].id;
                        close_popup(&editor);
                        editor=make_editor(sw,sh,dy,dm,dd,edit_id);
                    }
                }
            }
            if(n<0)daywin=-1;
        }
        if(editor>=0){
            while((n=JtmosGraOSPollEvent(editor,&ev))>0){
                int action=-1;
                if(ev.id==GRAOS_GSID_EXIT){editor=-1;break;}
                if(ev.id==GRAOS_GSID_KEYPRESSED && ev.v[0]==JKEY_ESC)action=EDIT_CANCEL;
                if(ev.id==GRAOS_GSID_BUTTON)action=ev.v[0];
                if(ev.id==GRAOS_GSID_TEXTBOX_ENTER && ev.v[0]==EDIT_TEXT)action=EDIT_SAVE;
                if(action==EDIT_CANCEL){close_popup(&editor);break;}
                if(action!=EDIT_SAVE && action!=EDIT_DELETE)continue;
                if(action==EDIT_SAVE){
                    int h,m,duration,repeat,remind,ok=1;
                    if(getTextBoxText(editor,EDIT_TEXT,title,sizeof(title))<0 ||
                       getTextBoxText(editor,EDIT_TIME,time,sizeof(time))<0 ||
                       getTextBoxText(editor,EDIT_DURATION,dur,sizeof(dur))<0 ||
                       getTextBoxText(editor,EDIT_REPEAT,rep,sizeof(rep))<0 ||
                       getTextBoxText(editor,EDIT_REMIND,rem,sizeof(rem))<0){
                        setLabelText(editor,EDIT_STATUS,"Kenttien lukeminen epaonnistui");continue;
                    }
                    if(!parse_time(time,&h,&m) || !parse_duration(dur,&duration)){
                        setLabelText(editor,EDIT_STATUS,"Anna aika HH:MM ja kesto 1..1440");continue;
                    }
                    {
                        int i;
                        for(i=0;rep[i];i++)if(rep[i]<'0'||rep[i]>'9'||i>=1)ok=0;
                        if(!rep[0])ok=0;
                        for(i=0;rem[i];i++)if(rem[i]<'0'||rem[i]>'9'||i>=4)ok=0;
                        if(!rem[0])ok=0;
                    }
                    if(!ok){setLabelText(editor,EDIT_STATUS,"Toisto 0..4, muistutus 0..1440/9999");continue;}
                    repeat=atoi(rep);remind=atoi(rem);
                    if(repeat<0||repeat>4||(remind!=CAL4_REMIND_OFF && (remind<0||remind>1440))){
                        setLabelText(editor,EDIT_STATUS,"Virheellinen toisto tai muistutus");continue;
                    }
                    if(edit_id){
                        CAL4_EVENT *original=event_by_id(edit_id);
                        /* An edit to a recurrence changes the series, not its
                         * anchor date when opened from a future occurrence. */
                        rv=original?cal4_update(&store,edit_id,original->year,original->month,
                            original->day,h,m,duration,title,repeat,remind):CAL4_NOT_FOUND;
                    }else rv=cal4_add(&store,dy,dm,dd,h,m,duration,title,repeat,remind,NULL);
                }else if(edit_id){rv=cal4_delete(&store,edit_id);}else continue;
                if(rv!=CAL4_OK){setLabelText(editor,EDIT_STATUS,save_error(rv));refreshWindow(editor);continue;}
                close_popup(&editor);close_popup(&daywin);close_popup(&cal);
                cal=make_calendar(sw,sh,year,month,have_today?&previous:NULL);
                if(cal<0)return 3;
                daywin=make_day(sw,sh,dy,dm,dd,day_page);
                break;
            }
            if(n<0)editor=-1;
        }
        now_tick=GetTickCount();
        if(!last_tick || (unsigned long)(now_tick-last_tick)>=1000UL){
            last_tick=now_tick;
            if(read_clock(&today)==0){
                int changed=!have_today || today.day!=previous.day ||
                    today.month!=previous.month || today.year!=previous.year;
                previous=today;have_today=1;
                if(changed){
                    close_popup(&editor);close_popup(&daywin);close_popup(&cal);
                    cal=make_calendar(sw,sh,year,month,&previous);
                    if(cal<0)return 3;
                }
            }
        }
        Sleep(40);SwitchToThread();
    }
}
int main(int argc,char **argv)
{
    int sw=GRAOS_SCREEN_WIDTH,sh=GRAOS_SCREEN_HEIGHT,bpp=GRAOS_SCREEN_BPP,panel=GRAOS_SCREEN_PANEL_HEIGHT;
    (void)argc;(void)argv;
    if(connectGraos()!=0)return 1;
    if(JtmosGraOSGetScreenInfo(&sw,&sh,&bpp,&panel)<0){sw=GRAOS_SCREEN_WIDTH;sh=GRAOS_SCREEN_HEIGHT;}
    if(sw<CAL_W || sh<PANEL_H+CAL_H+4)return 2;
    return calendar_loop(sw,sh);
}
