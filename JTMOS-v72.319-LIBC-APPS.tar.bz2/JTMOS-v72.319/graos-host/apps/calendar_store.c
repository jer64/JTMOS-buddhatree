/* JTMOS calendar persistence v2 (v72.86)
 *
 * Two independent generations /calendar.a and /calendar.b. No rename-over-
 * existing: JTMFS explicitly rejects that operation. Only the inactive slot
 * is overwritten; write, fflush, fsync, close and readback-check all precede
 * the active-slot switch. The existing /calendar.txt is never modified.
 * A filesystem lacking durable fsync cannot provide power-loss guarantees.
 * Do not run two taskbar writers concurrently (no cross-process lock yet).
 */
#include "calendar_store.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>

#ifndef CAL_SLOT_A
#define CAL_SLOT_A "/calendar.a"
#endif
#ifndef CAL_SLOT_B
#define CAL_SLOT_B "/calendar.b"
#endif
#ifndef CAL_LEGACY
#define CAL_LEGACY "/calendar.txt"
#endif
#define CAL_LINE_MAX 160
#define CAL_HEADER_MAX 96
#define CAL_MAGIC "JTCAL2"
#define CAL_MAX_GENERATION 0xFFFFFFFFUL
#define CAL_MAX_ID 0xFFFFFFFEUL

static CALENDAR_STORE scratch;
static CALENDAR_STORE check_store;

int calendar_valid_date(int year,int month,int day)
{
    static const int mdays[12]={31,28,31,30,31,30,31,31,30,31,30,31};
    int days;
    if(year<1900 || year>9999 || month<1 || month>12 || day<1) return 0;
    days=mdays[month-1];
    if(month==2 && year%4==0 && (year%100!=0 || year%400==0)) days++;
    return day<=days;
}

static int good_title(const char *title)
{
    int i;
    if(!title || !title[0]) return 0;
    for(i=0;title[i];i++) {
        unsigned char c=(unsigned char)title[i];
        if(i>=CALENDAR_TITLE_MAX || c<32 || c==127) return 0;
    }
    return 1;
}

static unsigned long crc_step(unsigned long crc, const char *text)
{
    const unsigned char *p=(const unsigned char *)text;
    int i;
    while(*p) {
        crc^=(unsigned long)*p++;
        for(i=0;i<8;i++) crc=(crc>>1)^((crc&1UL)?0xEDB88320UL:0UL);
    }
    return crc&0xFFFFFFFFUL;
}

static int event_line(char *buf,size_t cap,const CAL_EVENT *ev)
{
    int n;
    n=snprintf(buf,cap,"%08lX|%04d-%02d-%02d|%s\n",ev->id,
               ev->year,ev->month,ev->day,ev->title);
    return n>0 && (size_t)n<cap;
}

static int find_date(const CALENDAR_STORE *s,int y,int m,int d)
{
    int i;
    for(i=0;i<s->count;i++)
        if(s->items[i].year==y && s->items[i].month==m && s->items[i].day==d)
            return i;
    return -1;
}

static int find_id(const CALENDAR_STORE *s,unsigned long id)
{
    int i;
    for(i=0;i<s->count;i++) if(s->items[i].id==id) return i;
    return -1;
}

/* 0: file valid; 1: file absent; -1: present but invalid or unreadable. */
static int read_slot(const char *path,CALENDAR_STORE *out)
{
    FILE *f;
    char line[CAL_LINE_MAX],header[CAL_HEADER_MAX],extra[2];
    unsigned long gen,checksum,saved_next_id,crc=0xFFFFFFFFUL,id,max_id=0UL;
    int count,i,y,m,d,n,rv=-1;
    char *title;
    memset(out,0,sizeof(*out));
    out->next_id=1;
    out->active_slot=-1;
    f=fopen(path,"rb");
    if(!f) return 1;
    if(!fgets(header,sizeof(header),f) || !strchr(header,'\n')) goto done;
    n=0;
    if(sscanf(header,"JTCAL2 %lx %d %lx %lx %n",&gen,&count,&saved_next_id,&checksum,&n)!=4 ||
       n<=0 || header[n]!='\0' || gen==0UL || gen>CAL_MAX_GENERATION ||
       saved_next_id==0UL || saved_next_id>CAL_MAX_ID+1UL ||
       checksum>0xFFFFFFFFUL || count<0 || count>CALENDAR_EVENT_MAX) goto done;
    for(i=0;i<count;i++) {
        int consumed=0;
        if(!fgets(line,sizeof(line),f) || !strchr(line,'\n')) goto done;
        crc=crc_step(crc,line);
        if(strlen(line)<22 || line[8]!='|' || line[19]!='|') goto done;
        line[8]='\0';
        if(sscanf(line,"%lx%n",&id,&consumed)!=1 || consumed!=8 ||
           id==0 || id>CAL_MAX_ID) goto done;
        line[19]='\0';
        if(sscanf(line+9,"%4d-%2d-%2d%n",&y,&m,&d,&consumed)!=3 ||
           consumed!=10 || !calendar_valid_date(y,m,d)) goto done;
        title=line+20;
        title[strlen(title)-1]='\0'; /* trailing newline */
        if(!good_title(title) || find_date(out,y,m,d)>=0 || find_id(out,id)>=0) goto done;
        out->items[i].id=id;
        out->items[i].year=y;
        out->items[i].month=m;
        out->items[i].day=d;
        strcpy(out->items[i].title,title);
        out->count++;
        if(id>max_id) max_id=id;
    }
    /* Neither extra records nor a partial trailing record are allowed. */
    if(fread(extra,1,1,f)!=0 || ferror(f)) goto done;
    crc=(~crc)&0xFFFFFFFFUL;
    if(crc!=checksum || saved_next_id<=max_id) goto done;
    out->generation=gen;
    out->next_id=saved_next_id;
    rv=0;
done:
    if(fclose(f)!=0) rv=-1;
    return rv;
}

static int read_legacy(CALENDAR_STORE *out)
{
    FILE *f=fopen(CAL_LEGACY,"rb");
    char line[CAL_LINE_MAX],title[CALENDAR_TITLE_MAX+1];
    int y,m,d,n,malformed=0,too_long;
    memset(out,0,sizeof(*out));
    out->next_id=1;
    out->active_slot=-1;
    if(!f) return 0;  /* fresh installation: nothing to migrate */
    while(fgets(line,sizeof(line),f)) {
        size_t l=strlen(line);
        too_long=(l>0 && line[l-1]!='\n' && !feof(f));
        if(too_long) { int ch; while((ch=fgetc(f))!='\n' && ch!=EOF) {} malformed=1; continue; }
        n=0;
        if(sscanf(line,"%d-%d-%d %n",&y,&m,&d,&n)!=3 || n<=0 ||
           !calendar_valid_date(y,m,d) || find_date(out,y,m,d)>=0) { malformed=1; continue; }
        if((size_t)n>strlen(line)) { malformed=1;continue; }
        /* Reject oversized legacy records instead of silently truncating. */
        { size_t j,tl=strlen(line+n);
          if(tl && line[n+tl-1]=='\n') tl--;
          if(tl && line[n+tl-1]=='\r') tl--;
          if(tl>CALENDAR_TITLE_MAX) {malformed=1;continue;}
          memcpy(title,line+n,tl); title[tl]='\0';
          for(j=0;j<tl;j++) if(title[j]=='\r' || title[j]=='\n') {title[j]=0;break;}
        }
        if(!good_title(title) || out->count>=CALENDAR_EVENT_MAX) { malformed=1;continue; }
        out->items[out->count].id=out->next_id++;
        out->items[out->count].year=y;
        out->items[out->count].month=m;
        out->items[out->count].day=d;
        strcpy(out->items[out->count].title,title);
        out->count++;
    }
    { int io_error=ferror(f); if(fclose(f)!=0) io_error=1;
      if(io_error) return CALENDAR_ERR_IO;
    }
    /* Refuse to create fresh v2 data if legacy file existed and contained
     * nothing usable but nonempty malformed rows. Never destroy old data. */
    if(malformed && out->count==0) return CALENDAR_ERR_CORRUPT;
    return 0;
}

int calendar_store_load(CALENDAR_STORE *store)
{
    int a,b;
    if(!store) return CALENDAR_ERR_IO;
    a=read_slot(CAL_SLOT_A,store);
    b=read_slot(CAL_SLOT_B,&scratch);
    if(a==0 && (b!=0 || store->generation>=scratch.generation)) {
        store->active_slot=0;
        return CALENDAR_OK;
    }
    if(b==0) {
        *store=scratch;
        store->active_slot=1;
        return CALENDAR_OK;
    }
    if(a<0 || b<0) {
        memset(store,0,sizeof(*store));
        store->active_slot=-1;
        store->read_only=1;
        store->next_id=1;
        return CALENDAR_ERR_CORRUPT;
    }
    a=read_legacy(store);
    if(a<0) store->read_only=1;
    return a;
}

static int write_slot(const char *path,const CALENDAR_STORE *s)
{
    FILE *f;
    char row[CAL_LINE_MAX],header[CAL_HEADER_MAX];
    unsigned long crc=0xFFFFFFFFUL;
    int i,ok=1,n;
    for(i=0;i<s->count;i++) {
        if(!event_line(row,sizeof(row),&s->items[i])) return CALENDAR_ERR_BAD_TITLE;
        crc=crc_step(crc,row);
    }
    crc=(~crc)&0xFFFFFFFFUL;
    n=snprintf(header,sizeof(header),"JTCAL2 %08lX %03d %08lX %08lX\n",
               s->generation,s->count,s->next_id,crc);
    if(n<=0 || n>=(int)sizeof(header)) return CALENDAR_ERR_IO;
    f=fopen(path,"wb");
    if(!f) return CALENDAR_ERR_IO;
    if(fwrite(header,1,(size_t)n,f)!=(size_t)n) ok=0;
    for(i=0;ok && i<s->count;i++) {
        size_t l;
        if(!event_line(row,sizeof(row),&s->items[i])) {ok=0;break;}
        l=strlen(row);
        if(fwrite(row,1,l,f)!=l) ok=0;
    }
    if(ok && fflush(f)!=0) ok=0;
    /* JTMFS has an explicit SYS_fsync. A successful close alone isn't durable. */
    if(ok && fsync(fileno(f))!=0) ok=0;
    if(fclose(f)!=0) ok=0;
    if(!ok) return CALENDAR_ERR_IO;
    if(read_slot(path,&check_store)!=0 || check_store.generation!=s->generation ||
       check_store.count!=s->count || check_store.next_id!=s->next_id)
        return CALENDAR_ERR_IO;
    for(i=0;i<s->count;i++)
        if(check_store.items[i].id!=s->items[i].id ||
           strcmp(check_store.items[i].title,s->items[i].title)!=0 ||
           check_store.items[i].year!=s->items[i].year ||
           check_store.items[i].month!=s->items[i].month ||
           check_store.items[i].day!=s->items[i].day) return CALENDAR_ERR_IO;
    return CALENDAR_OK;
}

int calendar_store_put(CALENDAR_STORE *store,int y,int m,int d,const char *title)
{
    int idx,target,rv;
    CALENDAR_STORE *next=&scratch;
    if(!store || store->read_only) return CALENDAR_ERR_CORRUPT;
    if(!calendar_valid_date(y,m,d)) return CALENDAR_ERR_BAD_DATE;
    if(title && title[0] && !good_title(title)) return CALENDAR_ERR_BAD_TITLE;
    idx=find_date(store,y,m,d);
    if(!title || !title[0]) {
        if(idx<0) return CALENDAR_OK;
    } else if(idx<0 && store->count>=CALENDAR_EVENT_MAX) return CALENDAR_ERR_FULL;
    if(store->generation>=CAL_MAX_GENERATION) return CALENDAR_ERR_ID_EXHAUSTED;
    *next=*store;
    if(!title || !title[0]) {
        memmove(&next->items[idx],&next->items[idx+1],
                (size_t)(next->count-idx-1)*sizeof(CAL_EVENT));
        next->count--;
    } else {
        if(idx<0) {
            if(next->next_id==0 || next->next_id>CAL_MAX_ID) return CALENDAR_ERR_ID_EXHAUSTED;
            idx=next->count++;
            next->items[idx].id=next->next_id++;
        }
        next->items[idx].year=y;
        next->items[idx].month=m;
        next->items[idx].day=d;
        strcpy(next->items[idx].title,title);
    }
    next->generation=store->generation+1UL;
    target=store->active_slot==0 ? 1:0;
    rv=write_slot(target==0?CAL_SLOT_A:CAL_SLOT_B,next);
    if(rv==CALENDAR_OK) {
        next->active_slot=target;
        *store=*next;
    }
    return rv;
}
