/* RFC 5545 small, bounded floating-local-time subset for GraOS Calendar. */
#include "calendar4_ics.h"
#include "calendar_store.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ICS_LINE 512
#define ICS_MAX_BYTES 131072UL
#define ICS_BAD (-10)
static CAL4_EVENT incoming[CAL4_MAX];
static int number_in;
static int isdigitc(char c){return c>='0' && c<='9';}
static int dec(const char *p,int n){int i,k=0;for(i=0;i<n;i++){if(!isdigitc(p[i]))return -1;k=k*10+p[i]-'0';}return k;}
static int datetime(const char *s,int *y,int *m,int *d,int *h,int *min)
{
    if(strlen(s)!=15 || s[8]!='T' || dec(s+13,2)!=0)return 0;
    *y=dec(s,4);*m=dec(s+4,2);*d=dec(s+6,2);
    *h=dec(s+9,2);*min=dec(s+11,2);
    return calendar_valid_date(*y,*m,*d)&&*h>=0&&*h<=23&&*min>=0&&*min<=59;
}
static int unescape_summary(const char *src,char *dst)
{
    int n=0;
    while(*src){char c=*src++;
        if(c=='\\'){
            if(!*src)return 0;
            c=*src++;
            if(c=='n'||c=='N')c=' ';
            else if(c!=';' && c!=',' && c!='\\')return 0;
        }
        if(n>=CAL4_TITLE_MAX || (unsigned char)c<32 || (unsigned char)c==127)return 0;
        dst[n++]=c;
    }
    dst[n]=0;return n>0;
}
static int recurrence(const char *src,int *repeat)
{
    char f[20]={0};int n=0;
    const char *p=src;
    if(strncmp(p,"FREQ=",5))return 0;
    p+=5;
    while(*p && *p!=';'){
        if(n>=18)return 0;
        f[n++]=*p++;
    }
    if(!strcmp(f,"DAILY"))*repeat=CAL4_DAILY;
    else if(!strcmp(f,"WEEKLY"))*repeat=CAL4_WEEKLY;
    else if(!strcmp(f,"MONTHLY"))*repeat=CAL4_MONTHLY;
    else if(!strcmp(f,"YEARLY"))*repeat=CAL4_YEARLY;
    else return 0;
    /* Explicitly reject advanced RRULEs. INTERVAL=1 is equivalent to default. */
    return !*p || !strcmp(p,";INTERVAL=1");
}
static int trigger(const char *p,int *mins)
{
    int n=0;int digits=0;
    if(!strcmp(p,"PT0M")){*mins=0;return 1;}
    if(strncmp(p,"-PT",3))return 0;
    p+=3;
    while(isdigitc(*p)){
        if(n>1440)return 0;
        n=n*10+*p++-'0';digits++;
    }
    if(digits && !strcmp(p,"M") && n<=1440){*mins=n;return 1;}
    if(digits && !strcmp(p,"H") && n<=24){*mins=n*60;return 1;}
    return 0;
}
static int read_line(FILE *f,char *out,int cap,unsigned long *seen)
{
    int n=0,c;
    while((c=fgetc(f))!=EOF){
        if(++*seen>ICS_MAX_BYTES)return -1;
        if(c=='\n')break;
        if(n>=cap-1)return -1;
        out[n++]=(char)c;
    }
    if(c==EOF && n==0)return 0;
    if(n && out[n-1]=='\r')n--;
    out[n]=0;return 1;
}
/* v72.89: importer stages all events, and rejects partial/ambiguous input. */
int cal4_ics_import(CAL4_STORE *store,const char *path,int *added)
{
    FILE *f;char raw[ICS_LINE],line[ICS_LINE],next[ICS_LINE];
    unsigned long seen=0;
    int r,in_event=0,in_alarm=0,hasstart=0,hasend=0,hassummary=0,hasrrule=0,hastrigger=0,have_next=0;
    int endy=0,endm=0,endd=0,endh=0,endmin=0,hascalendar=0,closed=0;
    CAL4_EVENT e;
    if(added)*added=0;
    if(!store || !path || store->read_only)return CAL4_CORRUPT;
    f=fopen(path,"rb");if(!f)return CAL4_IO;
    number_in=0;memset(&e,0,sizeof(e));
    for(;;){
        /* Decode RFC5545 folded lines, without unlimited buffering. */
        if(have_next){strcpy(line,next);have_next=0;r=1;}
        else r=read_line(f,line,sizeof(line),&seen);
        if(r<=0)break;
        for(;;){
            int q=read_line(f,raw,sizeof(raw),&seen);
            if(q<0){r=-1;break;}
            if(q==0)break;
            if(raw[0]==' ' || raw[0]=='\t'){
                if(strlen(line)+strlen(raw)>=sizeof(line)){r=-1;break;}
                strcat(line,raw+1);
            }else{
                strcpy(next,raw);have_next=1;
                break;
            }
        }
        if(r<0)break;
        if(!strcmp(line,"BEGIN:VCALENDAR")){if(hascalendar){r=-1;break;}hascalendar=1;continue;}
        if(!strcmp(line,"END:VCALENDAR")){if(!hascalendar || in_event){r=-1;break;}closed=1;continue;}
        if(!strcmp(line,"BEGIN:VEVENT")){
            if(!hascalendar || closed || in_event || number_in>=CAL4_MAX){r=-1;break;}
            in_event=1;in_alarm=hasstart=hasend=hassummary=hasrrule=hastrigger=0;
            memset(&e,0,sizeof(e));e.duration=60;e.repeat=CAL4_NONE;e.remind=CAL4_REMIND_OFF;
            continue;
        }
        if(!strcmp(line,"END:VEVENT")){
            int days,minutes;
            if(!in_event || in_alarm || !hasstart || !hassummary){r=-1;break;}
            if(hasend){
                days=cal4_day_number(endy,endm,endd)-cal4_day_number(e.year,e.month,e.day);
                minutes=days*1440+endh*60+endmin-e.hour*60-e.minute;
                if(minutes<1 || minutes>1440){r=-1;break;}
                e.duration=minutes;
            }
            if(cal4_validate(&e)!=CAL4_OK){r=-1;break;}
            incoming[number_in++]=e;in_event=0;continue;
        }
        if(!in_event){
            if(!strcmp(line,"BEGIN:VTIMEZONE")){r=-1;break;}
            continue;
        }
        if(!strcmp(line,"BEGIN:VALARM")){if(in_alarm){r=-1;break;}in_alarm=1;continue;}
        if(!strcmp(line,"END:VALARM")){if(!in_alarm){r=-1;break;}in_alarm=0;continue;}
        if(in_alarm){
            if(!strncmp(line,"TRIGGER:",8)){
                if(hastrigger++ || !trigger(line+8,&e.remind)){r=-1;break;}
            }else if(!strncmp(line,"TRIGGER;",8)){r=-1;break;}
            continue;
        }
        if(!strncmp(line,"DTSTART:",8)){
            if(hasstart++ || !datetime(line+8,&e.year,&e.month,&e.day,&e.hour,&e.minute)){r=-1;break;}
        }else if(!strncmp(line,"DTEND:",6)){
            if(hasend++ || !datetime(line+6,&endy,&endm,&endd,&endh,&endmin)){r=-1;break;}
        }else if(!strncmp(line,"SUMMARY:",8)){
            if(hassummary++ || !unescape_summary(line+8,e.title)){r=-1;break;}
        }else if(!strncmp(line,"RRULE:",6)){
            if(hasrrule++ || !recurrence(line+6,&e.repeat)){r=-1;break;}
        }else if(!strncmp(line,"DTSTART;",8) || !strncmp(line,"DTEND;",6) ||
                 !strncmp(line,"RRULE;",6) || !strncmp(line,"DURATION:",9) ||
                 !strncmp(line,"RDATE",5) || !strncmp(line,"EXDATE",6) ||
                 !strncmp(line,"RECURRENCE-ID",13)){
            r=-1;break;
        }
    }
    if(ferror(f))r=-1;
    if(fclose(f)!=0)r=-1;
    if(r<0 || !closed || in_event || !hascalendar)return ICS_BAD;
    /* Do not silently truncate imports or partially commit the file. */
    if(number_in>CAL4_MAX-store->count)return CAL4_FULL;
    return cal4_import_batch(store,incoming,number_in,added);
}
static int put(FILE *f,const char *s){return fputs(s,f)!=EOF;}
static int put_summary(FILE *f,const char *s)
{
    int n=8; /* SUMMARY: */
    if(!put(f,"SUMMARY:"))return 0;
    while(*s){
        int escape=(*s==','||*s==';'||*s=='\\');
        if(n>=72){if(!put(f,"\r\n "))return 0;n=1;}
        if(escape){if(fputc('\\',f)==EOF)return 0;n++;}
        if(fputc(*s++,f)==EOF)return 0;
        n++;
    }
    return put(f,"\r\n");
}
int cal4_ics_export(const CAL4_STORE *store,const char *path)
{
    FILE *f;int i,ok=1;char line[160];
    if(!store||!path)return CAL4_IO;
    f=fopen(path,"wb");if(!f)return CAL4_IO;
    if(!put(f,"BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//JTMOS//GraOS Calendar 4//EN\r\nCALSCALE:GREGORIAN\r\n"))ok=0;
    for(i=0;ok&&i<store->count;i++){
        const CAL4_EVENT *e=&store->items[i];
        int mins=e->hour*60+e->minute+e->duration,days=mins/1440;
        int y=e->year,m=e->month,d=e->day,dh=mins%1440/60,dm=mins%60;
        if(cal4_validate(e)!=CAL4_OK){ok=0;break;}
        if(days){
            int remain=days;
            while(remain--){d++;if(!calendar_valid_date(y,m,d)){d=1;m++;if(m>12){m=1;y++;}}}
        }
        if(y>9999){ok=0;break;}
        snprintf(line,sizeof(line),"BEGIN:VEVENT\r\nUID:jtmos-%08lX@jtmos.local\r\nDTSTART:%04d%02d%02dT%02d%02d00\r\nDTEND:%04d%02d%02dT%02d%02d00\r\n",e->id,e->year,e->month,e->day,e->hour,e->minute,y,m,d,dh,dm);
        if(!put(f,line) || !put_summary(f,e->title)){ok=0;break;}
        if(e->repeat!=CAL4_NONE){
            const char *name=e->repeat==CAL4_DAILY?"DAILY":e->repeat==CAL4_WEEKLY?"WEEKLY":e->repeat==CAL4_MONTHLY?"MONTHLY":"YEARLY";
            snprintf(line,sizeof(line),"RRULE:FREQ=%s\r\n",name);
            if(!put(f,line)){ok=0;break;}
        }
        if(e->remind!=CAL4_REMIND_OFF){
            snprintf(line,sizeof(line),"BEGIN:VALARM\r\nACTION:DISPLAY\r\nDESCRIPTION:Reminder\r\nTRIGGER:-PT%dM\r\nEND:VALARM\r\n",e->remind);
            if(!put(f,line)){ok=0;break;}
        }
        if(!put(f,"END:VEVENT\r\n"))ok=0;
    }
    if(ok && !put(f,"END:VCALENDAR\r\n"))ok=0;
    if(fflush(f)!=0)ok=0;
    if(fclose(f)!=0)ok=0;
    return ok?CAL4_OK:CAL4_IO;
}
