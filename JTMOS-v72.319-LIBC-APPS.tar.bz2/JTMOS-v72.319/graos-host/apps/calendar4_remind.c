#include "calendar4_remind.h"
#include "calendar_store.h"
static int next_date(int *y,int *m,int *d)
{
    int yy=*y,mm=*m,dd=*d+1;
    if(calendar_valid_date(yy,mm,dd)){*d=dd;return 1;}
    dd=1;mm++;if(mm>12){mm=1;yy++;}
    if(yy>9999)return 0;
    *y=yy;*m=mm;*d=dd;return 1;
}
int cal4_reminder_due(const CAL4_EVENT *e,int y,int m,int d,int h,int minute)
{
    int serial,ey=y,em=m,ed=d,occ;
    long long when;
    if(!e || e->remind==CAL4_REMIND_OFF || h<0 || h>23 || minute<0 || minute>59)return 0;
    serial=cal4_day_number(y,m,d);
    if(serial<0)return 0;
    when=(long long)serial*1440+h*60+minute;
    occ=serial;
    if(cal4_occurs(e,ey,em,ed) &&
       (long long)occ*1440+e->hour*60+e->minute-e->remind==when)return occ;
    if(next_date(&ey,&em,&ed)){
        occ=cal4_day_number(ey,em,ed);
        if(cal4_occurs(e,ey,em,ed) &&
           (long long)occ*1440+e->hour*60+e->minute-e->remind==when)return occ;
    }
    return 0;
}
