# JTMOS V67 static ELF32 application
APPNAME=taskbar
APP_OBJS=taskbar.o calendar_store.o
include app-common.mk
