#!/usr/bin/env python3
"""Optional HOST-only differential tests (cryptography is NOT used by JTMOS)."""
import ctypes as c
import hashlib
import hmac
import os
import subprocess
from pathlib import Path
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

ROOT = Path(__file__).resolve().parent.parent
LIB = ROOT / 'tests' / '_libnavcryptotest.so'
subprocess.check_call(['cc', '-std=c11','-O2', '-shared', '-fPIC', '-Isrc',
                       'src/nav_crypto.c','src/nav_tls13.c','-o',str(LIB)], cwd=ROOT)
lib = c.CDLL(str(LIB))
U = c.c_uint8
P = c.POINTER(U)
lib.nav_aes128_gcm_encrypt.argtypes = [P,P,P,c.c_size_t,P,c.c_size_t,P,P]
lib.nav_aes128_gcm_encrypt.restype = c.c_int
lib.nav_aes128_gcm_decrypt.argtypes = [P,P,P,c.c_size_t,P,c.c_size_t,P,P]
lib.nav_aes128_gcm_decrypt.restype = c.c_int
lib.nav_x25519.argtypes = [P,P,P]
lib.nav_x25519.restype = c.c_int

def arr(x):
    return (U*len(x)).from_buffer_copy(x)

def check_gcm():
    for i in range(100):
        key=os.urandom(16); nonce=os.urandom(12); aad=os.urandom((i*7)%101)
        data=os.urandom((i*37)%4096)
        expected=AESGCM(key).encrypt(nonce,data,aad)
        dst=(U*max(1,len(data)))();tag=(U*16)()
        assert lib.nav_aes128_gcm_encrypt(arr(key),arr(nonce),arr(aad),len(aad),
                                          arr(data),len(data),dst,tag)==0
        assert bytes(dst)[:len(data)]+bytes(tag)==expected
        back=(U*max(1,len(data)))()
        assert lib.nav_aes128_gcm_decrypt(arr(key),arr(nonce),arr(aad),len(aad),
                                          dst,len(data),tag,back)==0
        assert bytes(back)[:len(data)]==data
        tag[0]^=1
        assert lib.nav_aes128_gcm_decrypt(arr(key),arr(nonce),arr(aad),len(aad),
                                          dst,len(data),tag,back)==-1
    print('PASS: 100 randomized AES-128-GCM tests against cryptography')

def check_x25519():
    for i in range(100):
        raw=os.urandom(32); private=X25519PrivateKey.from_private_bytes(raw)
        base=bytes([9])+bytes(31); out=(U*32)()
        assert lib.nav_x25519(out,arr(raw),arr(base))==0
        expected=private.public_key().public_bytes(Encoding.Raw,PublicFormat.Raw)
        assert bytes(out)==expected
        peer=X25519PrivateKey.generate()
        peerpub=peer.public_key().public_bytes(Encoding.Raw,PublicFormat.Raw)
        assert lib.nav_x25519(out,arr(raw),arr(peerpub))==0
        assert bytes(out)==private.exchange(X25519PublicKey.from_public_bytes(peerpub))
    print('PASS: 100 randomized X25519 agreements against cryptography')

if __name__=='__main__':
    try:
        check_gcm();check_x25519()
        print('ALL OPTIONAL DIFFERENTIAL TESTS PASSED')
    finally:
        LIB.unlink(missing_ok=True)
