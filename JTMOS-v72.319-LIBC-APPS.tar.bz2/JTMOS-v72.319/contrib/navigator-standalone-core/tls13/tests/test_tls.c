/* Host-only test harness; production src/ remains freestanding. */
#include "nav_crypto.h"
#include "nav_tls13.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
static unsigned tests;
static void check(int ok,const char *label){
    if(!ok){fprintf(stderr,"FAILED: %s\n",label);exit(1);}++tests;
    printf("PASS: %s\n",label);
}
static int fromhex(const char *s,uint8_t *dst,size_t cap){size_t i,n=strlen(s)/2;
    if(strlen(s)%2||n>cap)return -1;
    for(i=0;i<n;++i){unsigned x;if(sscanf(s+2*i,"%2x",&x)!=1)return -1;dst[i]=(uint8_t)x;}
    return (int)n;
}
static int samehex(const uint8_t *data,size_t n,const char *hex){
    uint8_t expected[128];if(n>sizeof(expected)||(int)n!=fromhex(hex,expected,sizeof(expected)))return 0;
    return memcmp(expected,data,n)==0;
}
int main(void){
    uint8_t h[32],prk[32],okm[42],ikm[22],salt[13],info[10],out[32],key[16]={0},nonce[12]={0};
    uint8_t plain[128]={0},cipher[128]={0},tag[16],decrypt[128],wire[128],tampered[128];
    uint8_t alice[32],bob[32],pub[32],pub_b[32],secret[32],secret2[32],client[32],server[32],master[32],capp[32],sapp[32];
    nav_tls13_keys write_keys,read_keys;
    uint8_t traffic[32],type;size_t len,content_len;
    size_t i;
    nav_sha256_hash((const uint8_t *)"abc",3,h);
    check(samehex(h,32,"ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"),"SHA-256 abc");
    nav_sha256_hash(NULL,0,h);
    check(samehex(h,32,"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"),"SHA-256 empty");
    {
        uint8_t hkey[20];
        memset(hkey,0x0b,sizeof(hkey));
        nav_hmac_sha256(hkey,sizeof(hkey),(const uint8_t *)"Hi There",8,h);
        check(samehex(h,32,"b0344c61d8db38535ca8afceaf0bf12b"
                          "881dc200c9833da726e9376c2e32cff7"),"RFC4231 HMAC-SHA256");
    }
    for(i=0;i<22;++i)ikm[i]=0x0b;
    fromhex("000102030405060708090a0b0c",salt,13);
    fromhex("f0f1f2f3f4f5f6f7f8f9",info,10);
    nav_hkdf_extract(salt,13,ikm,22,prk);
    check(samehex(prk,32,"077709362c2e32df0ddc3f0dc47bba63" "90b6c73bb50f9c3122ec844ad7c2b3e5"),"RFC5869 HKDF extract");
    check(nav_hkdf_expand(prk,info,10,okm,42)==0&&
          samehex(okm,42,"3cb25f25faacd57a90434f64d0362f2a" "2d2d0a90cf1a5a4c5db02d56ecc4c5bf" "34007208d5b887185865"),"RFC5869 HKDF expand");
    check(nav_hkdf_expand(prk,NULL,0,okm,8161)==-1,"HKDF max output enforcement");
    fromhex("77076d0a7318a57d3c16c17251b26645df4c2f87ebc0992ab177fba51db92c2a",alice,32);
    fromhex("5dab087e624a8a4b79e17f8b83800ee66f3bb1292618b6fd1c2f8b27ff88e0eb",bob,32);
    nav_x25519_public(pub,alice);
    check(samehex(pub,32,"8520f0098930a754748b7ddcb43ef75a0dbf3a0d26381af4eba4a98eaa9b4e6a"),"RFC7748 X25519 Alice public");
    nav_x25519_public(pub_b,bob);
    check(samehex(pub_b,32,"de9edb7d7b7dc1b4d35b61c2ece435373f8343c85b78674dadfc7e146f882b4f"),"RFC7748 X25519 Bob public");
    check(nav_x25519(secret,alice,pub_b)==0&&nav_x25519(secret2,bob,pub)==0&&
          memcmp(secret,secret2,32)==0&&
          samehex(secret,32,"4a5d9d5ba4ce2de1728e3bf480350f25" "e07e21c947d19e3376f09b3c1e161742"),"RFC7748 X25519 shared secret");
    memset(out,0,32);check(nav_x25519(secret,alice,out)==-1,"X25519 all-zero shared secret rejection");
    check(nav_aes128_gcm_encrypt(key,nonce,NULL,0,NULL,0,NULL,tag)==-1,"AES-GCM argument validation");
    check(nav_aes128_gcm_encrypt(key,nonce,NULL,0,plain,0,cipher,tag)==0&&
          samehex(tag,16,"58e2fccefa7e3061367f1d57a4e7455a"),"NIST AES-GCM empty message");
    check(nav_aes128_gcm_encrypt(key,nonce,NULL,0,plain,16,cipher,tag)==0&&
          samehex(cipher,16,"0388dace60b6a392f328c2b971b2fe78")&&
          samehex(tag,16,"ab6e47d42cec13bdf53a67b21257bddf"),"NIST AES-128-GCM 16-byte payload");
    memset(decrypt,0xa5,16);
    check(nav_aes128_gcm_decrypt(key,nonce,NULL,0,cipher,16,tag,decrypt)==0&&
          memcmp(decrypt,plain,16)==0,"AES-GCM decrypt authentic message");
    tag[0]^=1;memset(decrypt,0xa5,16);
    check(nav_aes128_gcm_decrypt(key,nonce,NULL,0,cipher,16,tag,decrypt)==-1&&
          decrypt[0]==0xa5,"AES-GCM reject forged tag without decryption");
    for(i=0;i<32;++i){traffic[i]=(uint8_t)(i+1);h[i]=(uint8_t)(i+2);}
    check(nav_tls13_expand_label(traffic,"finished",NULL,0,out,32)==0&&
          nav_tls13_finished_mac(traffic,h,prk)==0,"TLS 1.3 HKDF label / Finished MAC");
    check(nav_tls13_handshake_secrets(traffic,h,client,server,master)==0&&
          memcmp(client,server,32)!=0&&
          nav_tls13_application_secrets(master,h,capp,sapp)==0&&
          memcmp(capp,sapp,32)!=0,"TLS 1.3 no-PSK key schedule");
    check(nav_tls13_keys_init(&write_keys,traffic)==0&&
          nav_tls13_keys_init(&read_keys,traffic)==0,"TLS record write/read keys");
    check(nav_tls13_seal(&write_keys,NAV_TLS13_APPDATA,(const uint8_t *)"GET / HTTP/1.1",14,
                         wire,sizeof(wire),&len)==0&&len==5+14+1+16&&wire[0]==23,
          "TLS 1.3 encrypted record wire format");
    check(nav_tls13_open(&read_keys,wire,len,decrypt,sizeof(decrypt),&type,&content_len)==0&&
          type==NAV_TLS13_APPDATA&&content_len==14&&
          memcmp(decrypt,"GET / HTTP/1.1",14)==0&&read_keys.sequence==1,
          "TLS 1.3 encrypted record round trip");
    check(nav_tls13_seal(&write_keys,NAV_TLS13_HANDSHAKE,(const uint8_t *)"hi",2,wire,sizeof(wire),&len)==0&&
          nav_tls13_open(&read_keys,wire,len,decrypt,sizeof(decrypt),&type,&content_len)==0&&
          type==NAV_TLS13_HANDSHAKE&&content_len==2,"TLS 1.3 handshake record content type");
    check(nav_tls13_seal(&write_keys,NAV_TLS13_APPDATA,plain,16,wire,sizeof(wire),&len)==0,
          "TLS 1.3 record 3 encrypt");
    memcpy(tampered,wire,len);tampered[len-1]^=1;
    memset(decrypt,0xa5,sizeof(decrypt));
    check(nav_tls13_open(&read_keys,tampered,len,decrypt,sizeof(decrypt),&type,&content_len)==-2&&
          read_keys.active==0&&decrypt[0]==0xa5,
          "TLS 1.3 reject forged record and close");
    check(nav_tls13_open(&read_keys,wire,len,decrypt,sizeof(decrypt),&type,&content_len)==-1,
          "TLS keys unusable after failure");
    {
        static uint8_t big[NAV_TLS13_MAX_CONTENT];
        static uint8_t bigwire[NAV_TLS13_MAX_WIRE];
        static uint8_t bigout[NAV_TLS13_MAX_CONTENT+256];
        size_t j, biglen, resultlen;
        nav_tls13_keys bigtx,bigrx;
        for(j=0;j<sizeof(big);++j)big[j]=(uint8_t)j;
        check(nav_tls13_keys_init(&bigtx,traffic)==0 &&
              nav_tls13_keys_init(&bigrx,traffic)==0 &&
              nav_tls13_seal(&bigtx,NAV_TLS13_APPDATA,big,sizeof(big),
                             bigwire,sizeof(bigwire),&biglen)==0 &&
              nav_tls13_open(&bigrx,bigwire,biglen,bigout,sizeof(bigout),
                             &type,&resultlen)==0 &&
              resultlen==sizeof(big) && memcmp(big,bigout,sizeof(big))==0,
              "TLS 1.3 max-size 16 KiB content record");
        nav_tls13_keys_wipe(&bigtx);nav_tls13_keys_wipe(&bigrx);
    }
    nav_tls13_keys_wipe(&write_keys);nav_tls13_keys_wipe(&read_keys);
    printf("ALL %u CRYPTO/TLS TESTS PASSED\n",tests);
    return 0;
}
