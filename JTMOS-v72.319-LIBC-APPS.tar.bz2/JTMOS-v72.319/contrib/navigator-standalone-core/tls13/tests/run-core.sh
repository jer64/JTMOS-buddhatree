#!/bin/sh
set -eu
repo=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)
out=${1:?output directory required}
mkdir -p "$out"
out=$(CDPATH= cd -- "$out" && pwd)
cd "$repo"
python3 tests/v72204_tls13.py "$out/core"
${CC:-cc} -std=c11 -O1 -g -Wall -Wextra -Werror -Wno-misleading-indentation \
 -ffreestanding -fno-builtin -fsanitize=address,undefined -fno-omit-frame-pointer \
 -Isrc src/nav_crypto.c src/nav_tls13.c src/nav_rsa.c src/nav_x509.c src/nav_tls_client.c \
 tests/v72204_tls_sanitizer.c -o "$out/sanitizer"
ASAN_OPTIONS=detect_leaks=0:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 "$out/sanitizer" "$out/core"
make freestanding FREESTANDING_OUT="$out/i686"
