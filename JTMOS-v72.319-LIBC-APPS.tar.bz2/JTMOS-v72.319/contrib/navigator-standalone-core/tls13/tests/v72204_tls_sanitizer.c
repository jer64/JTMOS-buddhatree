#include "nav_tls_client.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct replay {uint8_t *data;size_t n,offset,written;} replay;
static int replay_read(void *v,uint8_t *out,size_t n){replay *r=v;
    if(n>7)n=7;if(n>r->n-r->offset)n=r->n-r->offset;
    memcpy(out,r->data+r->offset,n);r->offset+=n;return (int)n;
}
static int replay_write(void *v,const uint8_t *p,size_t n){replay *r=v;(void)p;if(n>3)n=3;r->written+=n;return (int)n;}
static int replay_random(void *v,uint8_t *out,size_t n){replay *r=v;if(n!=96||r->n<96)return -1;memcpy(out,r->data,n);r->offset=96;return 0;}
static size_t load(const char *directory,const char *name,uint8_t *out,size_t cap){
    char path[1024];FILE *f;size_t n;assert(snprintf(path,sizeof(path),"%s/%s",directory,name)>0);
    f=fopen(path,"rb");assert(f);n=fread(out,1,cap,f);assert(!ferror(f)&&feof(f));fclose(f);return n;
}
static void config_init(nav_tls_config *cfg,replay *r,const nav_trust_anchor *anchor,uint64_t now){
    memset(cfg,0,sizeof(*cfg));cfg->io.context=r;cfg->io.read=replay_read;cfg->io.write=replay_write;cfg->io.random=replay_random;
    cfg->anchors=anchor;cfg->anchor_count=1;cfg->hostname="localhost";cfg->utc_seconds=now;
}
int main(int argc,char **argv){
    static const char *cases[]={"ok","hrr","key-update","truncation","bad-sh","bad-ccs","bad-alpn","early-app","missing-cert","bad-cv","bad-finished","bad-tag"};
    nav_tls_client *c;nav_tls_config cfg;nav_trust_anchor anchor;nav_rsa_public leaf;nav_span chain[2];
    uint8_t dn[2048],mod[512],cert0[32768],cert1[32768],work[32768],fixture[65536],reference[65536],buffer[257];
    char filename[128],utc_text[32];size_t i,j,n,reference_n;uint64_t now;int rc,k;replay r;
    assert(argc==2);n=load(argv[1],"utc.txt",(uint8_t *)utc_text,sizeof(utc_text)-1);utc_text[n]=0;now=strtoull(utc_text,0,10);
    anchor.subject.p=dn;anchor.subject.n=load(argv[1],"root-subject.der",dn,sizeof(dn));
    anchor.key.modulus.p=mod;anchor.key.modulus.n=load(argv[1],"root-modulus.bin",mod,sizeof(mod));anchor.key.exponent=65537;
    chain[0].p=cert0;chain[0].n=load(argv[1],"chain0.der",cert0,sizeof(cert0));
    chain[1].p=cert1;chain[1].n=load(argv[1],"chain1.der",cert1,sizeof(cert1));
    assert(nav_x509_verify(chain,2,&anchor,1,"localhost",now,&leaf)==0);
    c=malloc(sizeof(*c));assert(c);
    for(i=0;i<sizeof(cases)/sizeof(cases[0]);i++){
        snprintf(filename,sizeof(filename),"replay-%s.bin",cases[i]);n=load(argv[1],filename,fixture,sizeof(fixture));
        r=(replay){fixture,n,0,0};config_init(&cfg,&r,&anchor,now);assert(nav_tls_client_init(c,&cfg)==0);
        rc=nav_tls_client_handshake(c);
        if(i<4){assert(rc==0&&c->state==NAV_TLS_READY);assert(nav_tls_client_write(c,"GET test",8)==8);
            j=0;while((k=nav_tls_client_read(c,buffer,sizeof(buffer)))>0)j+=(size_t)k;
            assert(k==0&&j==21&&c->truncated==(i==3));
        }else{assert(rc<0&&c->state==NAV_TLS_FAILED);assert(nav_tls_client_write(c,"no",2)<0);}
        nav_tls_client_close(c);assert(!c->tx.active&&!c->rx.active);nav_tls_client_wipe(c);
    }
    /* Every truncated DER prefix; then bounded deterministic mutation corpus. */
    chain[0].p=work;
    for(i=0;i<chain[0].n;i++){memcpy(work,cert0,chain[0].n);n=chain[0].n;chain[0].n=i;
        assert(nav_x509_verify(chain,2,&anchor,1,"localhost",now,&leaf)!=0);chain[0].n=n;}
    for(i=0;i<1200;i++){
        memcpy(work,cert0,chain[0].n);j=(i*37u)%chain[0].n;work[j]^=(uint8_t)(1u<<(i%8));
        (void)nav_x509_verify(chain,2,&anchor,1,"localhost",now,&leaf);
    }
    reference_n=load(argv[1],"replay-ok.bin",reference,sizeof(reference));
    for(i=0;i<256;i++){
        memcpy(fixture,reference,reference_n);j=96+(i*71u)%(reference_n-96);fixture[j]^=(uint8_t)(1u<<(i%8));
        r=(replay){fixture,reference_n,0,0};config_init(&cfg,&r,&anchor,now);assert(nav_tls_client_init(c,&cfg)==0);
        rc=nav_tls_client_handshake(c);if(!rc){assert(nav_tls_client_write(c,"GET test",8)==8);
            while(nav_tls_client_read(c,buffer,sizeof(buffer))>0){} }
        nav_tls_client_close(c);nav_tls_client_wipe(c);
    }
    free(c);puts("ASAN/UBSAN: 12 TLS replays, all DER truncations, 1200 certificate and 256 TLS mutations PASS");return 0;
}
