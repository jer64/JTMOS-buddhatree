#!/usr/bin/env python3
"""Own TLS core vs independent host RSA/AES/X25519 and real TLS 1.3.

Host test dependencies (never linked into Navigator): Python cryptography,
Python ssl/OpenSSL and a C compiler. All network traffic stays on loopback.
"""
import ctypes as C
import datetime as D
import hashlib
import hmac
import os
from pathlib import Path
import socket
import ssl
import subprocess
import sys
import threading

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa, x25519
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.x509.oid import NameOID, ExtendedKeyUsageOID

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'libc/libc/network/tls13'
if not SRC.is_dir():SRC=ROOT/'src' # standalone source distribution
OUT=Path(sys.argv[1] if len(sys.argv)>1 else '/tmp/navigator-tls204').resolve()
OUT.mkdir(parents=True,exist_ok=True)
sources=[SRC/(name+'.c') for name in ('nav_crypto','nav_tls13','nav_rsa','nav_x509','nav_tls_client')]
subprocess.run(['cc','-O2','-g','-std=c11','-Wall','-Wextra','-Werror','-Wno-misleading-indentation',
                '-ffreestanding','-fno-builtin','-shared','-fPIC','-I'+str(SRC),
                *map(str,sources),str(ROOT/'tests/v72204_tls_bridge.c'),'-o',str(OUT/'core.so')],check=True)
lib=C.CDLL(str(OUT/'core.so'))
U8=C.c_ubyte
P=C.POINTER(U8)
class Span(C.Structure): _fields_=[('p',P),('n',C.c_size_t)]
class Key(C.Structure): _fields_=[('modulus',Span),('exponent',C.c_uint32)]
class Anchor(C.Structure): _fields_=[('subject',Span),('key',Key)]
Read=C.CFUNCTYPE(C.c_int,C.c_void_p,P,C.c_size_t)
Write=C.CFUNCTYPE(C.c_int,C.c_void_p,P,C.c_size_t)
Random=C.CFUNCTYPE(C.c_int,C.c_void_p,P,C.c_size_t)
Cancel=C.CFUNCTYPE(C.c_int,C.c_void_p)
class IO(C.Structure): _fields_=[('context',C.c_void_p),('read',Read),('write',Write),('random',Random),('cancelled',Cancel)]
class Config(C.Structure): _fields_=[('io',IO),('anchors',C.POINTER(Anchor)),('count',C.c_size_t),('hostname',C.c_char_p),('utc',C.c_uint64)]
lib.test_tls_size.restype=C.c_size_t
for name in ('nav_tls_client_init','nav_tls_client_handshake','nav_tls_client_read','nav_tls_client_write','test_tls_state','test_tls_truncated','test_tls_keys_erased'):
    getattr(lib,name).restype=C.c_int
lib.nav_tls_client_init.argtypes=[C.c_void_p,C.POINTER(Config)]
lib.nav_tls_client_handshake.argtypes=[C.c_void_p]
lib.nav_tls_client_read.argtypes=[C.c_void_p,C.c_void_p,C.c_size_t]
lib.nav_tls_client_write.argtypes=[C.c_void_p,C.c_void_p,C.c_size_t]
lib.nav_tls_client_error.argtypes=[C.c_void_p];lib.nav_tls_client_error.restype=C.c_char_p
lib.nav_tls_client_close.argtypes=[C.c_void_p]
lib.nav_rsa_verify_sha256.argtypes=[C.POINTER(Key),C.c_int,P,Span]
lib.nav_x509_verify.argtypes=[C.POINTER(Span),C.c_size_t,C.POINTER(Anchor),C.c_size_t,C.c_char_p,C.c_uint64,C.POINTER(Key)]
owners=[]
def span(data):
    b=C.create_string_buffer(data);owners.append(b);return Span(C.cast(b,P),len(data))
def key(pub):
    k=pub.public_numbers();return Key(span(k.n.to_bytes((k.n.bit_length()+7)//8,'big')),k.e)
def check(condition,label):
    if not condition: raise AssertionError(label)
    print('PASS',label,flush=True)

now=D.datetime.now(D.timezone.utc).replace(microsecond=0)
utc=int(now.timestamp())
root_key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
inter_key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
leaf_key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
def name(s):return x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,s)])
def make_cert(subject,issuer,public,signer,ca=False,path=None,sans=None,valid=None,usage=True,extra=None,eku=True,pss=False):
    before,after=valid or (now-D.timedelta(days=1),now+D.timedelta(days=7))
    b=x509.CertificateBuilder().subject_name(subject).issuer_name(issuer).public_key(public).serial_number(x509.random_serial_number()).not_valid_before(before).not_valid_after(after)
    b=b.add_extension(x509.BasicConstraints(ca,path),critical=True)
    if usage:b=b.add_extension(x509.KeyUsage(digital_signature=True,content_commitment=False,key_encipherment=False,data_encipherment=False,key_agreement=False,key_cert_sign=ca,crl_sign=ca,encipher_only=False,decipher_only=False),critical=True)
    if not ca:b=b.add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH if eku else ExtendedKeyUsageOID.CLIENT_AUTH]),critical=False)
    if sans is not None:b=b.add_extension(x509.SubjectAlternativeName(sans),critical=False)
    if extra:b=b.add_extension(extra[0],critical=extra[1])
    return b.sign(signer,hashes.SHA256(),rsa_padding=padding.PSS(mgf=padding.MGF1(hashes.SHA256()),salt_length=32) if pss else None)
root=make_cert(name('Test root'),name('Test root'),root_key.public_key(),root_key,True,2)
inter=make_cert(name('Test intermediate'),root.subject,inter_key.public_key(),root_key,True,0)
sans=[x509.DNSName('localhost'),x509.IPAddress(__import__('ipaddress').ip_address('127.0.0.1'))]
leaf=make_cert(name('CN is ignored'),inter.subject,leaf_key.public_key(),inter_key,sans=sans)
der=lambda cert:cert.public_bytes(serialization.Encoding.DER)
anchors=(Anchor*1)(Anchor(span(root.subject.public_bytes()),key(root_key.public_key())))
good_chain=[der(leaf),der(inter)]
def verify(chain,host=b'localhost',when=utc,trust=anchors):
    values=(Span*len(chain))(*(span(x) for x in chain));out=Key()
    return lib.nav_x509_verify(values,len(chain),trust,len(trust),host,when,C.byref(out))

for bits in (2048,2049,3072,4096):
    private=leaf_key if bits==2048 else rsa.generate_private_key(public_exponent=65537,key_size=bits)
    pub=key(private.public_key())
    for scheme,pad in [(1,padding.PKCS1v15()),(2,padding.PSS(mgf=padding.MGF1(hashes.SHA256()),salt_length=32))]:
        data=os.urandom(73);digest=span(hashlib.sha256(data).digest());signature=private.sign(data,pad,hashes.SHA256())
        check(lib.nav_rsa_verify_sha256(C.byref(pub),scheme,digest.p,span(signature))==0,f'RSA {bits} padding {scheme} independent signature')
        damaged=bytearray(signature);damaged[-1]^=1
        check(lib.nav_rsa_verify_sha256(C.byref(pub),scheme,digest.p,span(bytes(damaged)))!=0,f'RSA {bits} padding {scheme} forgery rejected')
check(verify(good_chain)==0,'X509 ordered leaf/intermediate -> configured root')
check(verify(good_chain+[der(root)])==0,'X509 transmitted root checked against configured key')
check(verify(good_chain,b'LOCALHOST.')==0,'SAN ASCII case and trailing reference dot')
check(verify(good_chain,b'127.0.0.1')==0,'IPv4 SAN identity')
check(verify(good_chain,b'wrong.example')==-4,'hostname mismatch rejected')
check(verify(good_chain,when=0)==-3,'unknown clock rejected')
check(verify(good_chain,when=utc+9*86400)==-3,'expired certificate rejected')
check(verify([der(inter),der(leaf)])!=0,'reordered chain rejected')
check(verify([der(leaf)])!=0,'missing issuer rejected')
pss_leaf=make_cert(name('pss'),inter.subject,leaf_key.public_key(),inter_key,sans=sans,pss=True)
check(verify([der(pss_leaf),der(inter)])==0,'X509 RSA-PSS SHA256 certificate signature')
corrupt=bytearray(der(leaf));corrupt[-1]^=1
check(verify([bytes(corrupt),der(inter)])!=0,'certificate signature forgery rejected')
for label,kwargs,host in [
    ('CN fallback rejected',{'sans':None},b'localhost'),
    ('client-only EKU rejected',{'sans':sans,'eku':False},b'localhost'),
    ('unknown critical extension rejected',{'sans':sans,'extra':(x509.UnrecognizedExtension(x509.ObjectIdentifier('1.2.3.4'),b'\x05\0'),True)},b'localhost'),
    ('name constraints fail closed',{'sans':sans,'extra':(x509.NameConstraints([x509.DNSName('.example')],None),False)},b'localhost'),
    ('must staple fails closed',{'sans':sans,'extra':(x509.TLSFeature([x509.TLSFeatureType.status_request]),False)},b'localhost'),
]:
    cert=make_cert(name('localhost' if label=='CN fallback rejected' else 'CN is ignored'),inter.subject,leaf_key.public_key(),inter_key,**kwargs)
    check(verify([der(cert),der(inter)],host)!=0,label)
wild=make_cert(name('wild'),inter.subject,leaf_key.public_key(),inter_key,sans=[x509.DNSName('*.example.test')])
check(verify([der(wild),der(inter)],b'one.example.test')==0,'single-label wildcard match')
check(verify([der(wild),der(inter)],b'two.one.example.test')!=0,'wildcard cannot cross labels')
wrong_ca=make_cert(inter.subject,root.subject,inter_key.public_key(),root_key,False)
check(verify([der(leaf),der(wrong_ca)])!=0,'non-CA issuer rejected')

cert_path=OUT/'server.pem';key_path=OUT/'server.key'
cert_path.write_bytes(leaf.public_bytes(serialization.Encoding.PEM)+inter.public_bytes(serialization.Encoding.PEM))
key_path.write_bytes(leaf_key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
os.chmod(key_path,0o600)
for label,kwargs in [
    ('wrong-name',{'sans':[x509.DNSName('other.invalid')]}),
    ('expired',{'sans':sans,'valid':(now-D.timedelta(days=7),now-D.timedelta(days=2))}),
    ('wrong-eku',{'sans':sans,'eku':False}),
]:
    variant=make_cert(name(label),inter.subject,leaf_key.public_key(),inter_key,**kwargs)
    (OUT/(label+'.pem')).write_bytes(variant.public_bytes(serialization.Encoding.PEM)+inter.public_bytes(serialization.Encoding.PEM))
def listen():
    sock=socket.socket();sock.bind(('127.0.0.1',0));sock.listen();sock.settimeout(10);return sock
class Client:
    def __init__(self,sock,host=b'localhost',fragment=97,entropy_fail=False,cancel=False,when=utc):
        self.sock=sock;self.sent=0;self.received=0;self.incoming=bytearray();self.entropy=b''
        def read(_,out,n):
            try:
                data=sock.recv(min(n,fragment));self.incoming.extend(data);C.memmove(out,data,len(data));self.received+=len(data);return len(data)
            except OSError:return -1
        def write(_,data,n):
            try:
                k=sock.send(C.string_at(data,min(n,3)));self.sent+=k;return k
            except OSError:return -1
        def random(_,out,n):
            if entropy_fail:return -1
            self.entropy=os.urandom(n);C.memmove(out,self.entropy,n);return 0
        self.callbacks=(Read(read),Write(write),Random(random),Cancel(lambda _:int(cancel)))
        self.config=Config(IO(None,*self.callbacks),anchors,1,host,when)
        self.ctx=C.create_string_buffer(lib.test_tls_size());self.init=lib.nav_tls_client_init(self.ctx,C.byref(self.config))
    def handshake(self):return self.init or lib.nav_tls_client_handshake(self.ctx)
    def write(self,data):return lib.nav_tls_client_write(self.ctx,data,len(data))
    def read(self):
        b=C.create_string_buffer(257);n=lib.nav_tls_client_read(self.ctx,b,len(b));return n,b.raw[:max(0,n)]
    def error(self):return lib.nav_tls_client_error(self.ctx).decode()
    def close(self):lib.nav_tls_client_close(self.ctx);self.sock.close()

def openssl_server(listener,errors):
    try:
        ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);ctx.minimum_version=ctx.maximum_version=ssl.TLSVersion.TLSv1_3
        ctx.load_cert_chain(cert_path,key_path);ctx.set_alpn_protocols(['http/1.1'])
        raw,_=listener.accept();raw.settimeout(8)
        with ctx.wrap_socket(raw,server_side=True) as s:
            request=b''
            while b'\r\n\r\n' not in request:request+=s.recv(4096)
            assert request.startswith(b'GET / HTTP/1.1\r\n')
            s.sendall(b'HTTP/1.1 200 OK\r\nContent-Length: 12\r\nConnection: close\r\n\r\nHei maailma!')
            s.unwrap().close()
    except (OSError,AssertionError) as e:errors.append(str(e))
    finally:listener.close()

listener=listen();errors=[];thread=threading.Thread(target=openssl_server,args=(listener,errors));thread.start()
s=socket.create_connection(listener.getsockname());s.settimeout(8);client=Client(s,fragment=1)
check(client.handshake()==0,'real OpenSSL TLS1.3 handshake / partial writes / one-byte TCP reads: '+client.error())
check(client.write(b'GET / HTTP/1.1\r\nHost: localhost\r\n\r\n')>0,'authenticated HTTP request')
response=b''
while True:
    n,data=client.read()
    if n<=0:break
    response+=data
check(n==0 and response.endswith(b'Hei maailma!') and not lib.test_tls_truncated(client.ctx),'real TLS HTTPS response and authenticated close_notify')
client.close();thread.join(10);check(not thread.is_alive() and not errors,'real TLS server received reciprocal close_notify')

# Independent, scripted TLS server to reach protocol branches deterministically.
def v16(x):return len(x).to_bytes(2,'big')+x
def v24(x):return len(x).to_bytes(3,'big')+x
def hs(t,x):return bytes([t])+v24(x)
def ext(t,x):return t.to_bytes(2,'big')+v16(x)
def recv_exact(s,n):
    data=b''
    while len(data)<n:
        chunk=s.recv(n-len(data))
        if not chunk:raise EOFError()
        data+=chunk
    return data
def recv_record(s):
    h=recv_exact(s,5);return h,recv_exact(s,int.from_bytes(h[3:],'big'))
def record(t,data):return bytes([t,3,3])+v16(data)
def extract(salt,data):return hmac.new(salt,data,hashlib.sha256).digest()
def expand(secret,label,context=b'',length=32):
    label=b'tls13 '+label;info=length.to_bytes(2,'big')+bytes([len(label)])+label+bytes([len(context)])+context
    return hmac.new(secret,info+b'\x01',hashlib.sha256).digest()[:length]
def digest(x):return hashlib.sha256(x).digest()
class RecordKeys:
    def __init__(self,secret):self.secret=secret;self.seq=0;self.key=expand(secret,b'key',length=16);self.iv=expand(secret,b'iv',length=12)
    def nonce(self):return (int.from_bytes(self.iv,'big')^self.seq).to_bytes(12,'big')
    def seal(self,t,data):
        inner=data+bytes([t]);header=b'\x17\x03\x03'+(len(inner)+16).to_bytes(2,'big')
        out=header+AESGCM(self.key).encrypt(self.nonce(),inner,header);self.seq+=1;return out
    def open(self,h,data):
        inner=AESGCM(self.key).decrypt(self.nonce(),data,h);self.seq+=1
        inner=inner.rstrip(b'\0');return inner[-1],inner[:-1]
    def update(self):self.__init__(expand(self.secret,b'traffic upd'))
def hello_fields(ch):
    b=ch[4:];sid=b[35:35+b[34]];p=35+b[34];p+=2+int.from_bytes(b[p:p+2],'big');p+=1+b[p]
    extensions=b[p+2:];found={}
    while extensions:
        t=int.from_bytes(extensions[:2],'big');n=int.from_bytes(extensions[2:4],'big');found[t]=extensions[4:4+n];extensions=extensions[4+n:]
    return sid,found
def scripted_server(listener,case,errors):
    try:
        s,_=listener.accept();s.settimeout(8)
        with s:
            _,ch=recv_record(s);sid,extensions=hello_fields(ch);transcript=ch
            if case=='hrr':
                retry_random=bytes.fromhex('cf21ad74e59a6111be1d8c021e65b891c2a211167abb8c5e079e09e2c8a8339c')
                retry=hs(2,b'\x03\x03'+retry_random+bytes([len(sid)])+sid+b'\x13\x01\x00'+v16(ext(43,b'\x03\x04')+ext(44,v16(b'cookie-test'))))
                s.sendall(record(22,retry));_,ch2=recv_record(s);sid2,extensions2=hello_fields(ch2)
                assert sid2==sid and extensions2[44]==v16(b'cookie-test')
                assert {k:v for k,v in extensions2.items() if k!=44}==extensions
                transcript=hs(254,digest(ch))+retry+ch2
            private=x25519.X25519PrivateKey.generate();pub=private.public_key().public_bytes_raw()
            hello=hs(2,b'\x03\x03'+os.urandom(32)+bytes([len(sid)])+sid+b'\x13\x01\x00'+v16(ext(43,b'\x03\x04')+ext(51,b'\x00\x1d'+v16(pub))))
            if case=='bad-sh':hello=hello.replace(b'\x13\x01\0',b'\x13\x02\0',1)
            s.sendall(record(22,hello));transcript+=hello
            if case=='bad-sh':return
            shared=private.exchange(x25519.X25519PublicKey.from_public_bytes(extensions[51][6:38]))
            early=extract(bytes(32),bytes(32));handshake_secret=extract(expand(early,b'derived',digest(b'')),shared)
            client_hs=expand(handshake_secret,b'c hs traffic',digest(transcript));server_hs=expand(handshake_secret,b's hs traffic',digest(transcript))
            rx=RecordKeys(client_hs);tx=RecordKeys(server_hs)
            master=extract(expand(handshake_secret,b'derived',digest(b'')),bytes(32))
            if case=='bad-ccs':s.sendall(record(20,b'\x02'));return
            s.sendall(record(20,b'\x01'))
            ee=hs(8,v16(ext(16,v16(bytes([8])+b'http/1.1'))))
            if case=='bad-alpn':ee=hs(8,v16(ext(16,v16(b'\x02h2'))))
            certificate_msg=hs(11,b'\0'+v24(b''.join(v24(cert)+b'\0\0' for cert in good_chain)))
            if case=='early-app':s.sendall(tx.seal(23,b'unverified'));return
            if case=='missing-cert':flight=ee+hs(20,bytes(32))
            else:
                transcript+=ee+certificate_msg
                sig_input=b' '*64+b'TLS 1.3, server CertificateVerify\0'+digest(transcript)
                signature=leaf_key.sign(sig_input,padding.PSS(mgf=padding.MGF1(hashes.SHA256()),salt_length=32),hashes.SHA256())
                if case=='bad-cv':signature=signature[:-1]+bytes([signature[-1]^1])
                cv=hs(15,b'\x08\x04'+v16(signature));transcript+=cv
                mac=extract(expand(server_hs,b'finished'),digest(transcript))
                if case=='bad-finished':mac=bytes(32)
                fin=hs(20,mac);flight=ee+certificate_msg+cv+fin;transcript+=fin
            if case=='bad-tag':
                wire=bytearray(tx.seal(22,flight));wire[-1]^=1;s.sendall(wire);return
            # A certificate and handshake headers cross record boundaries.
            for i in range(0,len(flight),113):s.sendall(tx.seal(22,flight[i:i+113]))
            if case in ('bad-cv','bad-finished','missing-cert','bad-alpn'):return
            h,data=recv_record(s);t,client_fin=rx.open(h,data)
            assert t==22 and client_fin==hs(20,extract(expand(client_hs,b'finished'),digest(transcript)))
            rx=RecordKeys(expand(master,b'c ap traffic',digest(transcript)));tx=RecordKeys(expand(master,b's ap traffic',digest(transcript)))
            h,data=recv_record(s);t,request=rx.open(h,data);assert t==23 and request==b'GET test'
            if case=='key-update':
                s.sendall(tx.seal(22,hs(24,b'\x01')));tx.update()
                h,data=recv_record(s);t,reply=rx.open(h,data);assert t==22 and reply==hs(24,b'\0');rx.update()
            s.sendall(tx.seal(23,b'authenticated payload'))
            if case!='truncation':s.sendall(tx.seal(21,b'\x01\0'))
    except (OSError,EOFError) as e:
        if case in ('ok','hrr','key-update','truncation'):errors.append(repr(e))
    except Exception as e:errors.append(repr(e))
    finally:listener.close()

for case in ('ok','hrr','key-update','truncation','bad-sh','bad-ccs','bad-alpn','early-app','missing-cert','bad-cv','bad-finished','bad-tag'):
    listener=listen();errors=[];thread=threading.Thread(target=scripted_server,args=(listener,case,errors));thread.start()
    sock=socket.create_connection(listener.getsockname());sock.settimeout(8);client=Client(sock,fragment=17)
    rc=client.handshake()
    if case in ('ok','hrr','key-update','truncation'):
        check(rc==0,'scripted '+case+' authenticated handshake: '+client.error());check(client.write(b'GET test')==8,'scripted '+case+' send')
        result=b''
        while True:
            n,data=client.read()
            if n<=0:break
            result+=data
        check(n==0 and result==b'authenticated payload','scripted '+case+' data after verification')
        check(bool(lib.test_tls_truncated(client.ctx))==(case=='truncation'),'scripted '+case+' close integrity')
    else:
        check(rc<0 and lib.test_tls_state(client.ctx)==4 and lib.test_tls_keys_erased(client.ctx),'scripted '+case+' rejected / secrets erased: '+client.error())
        check(client.write(b'must not send')<0,'scripted '+case+' cannot release application data')
    client.close();thread.join(10);check(not thread.is_alive() and not errors,'scripted '+case+' server completed')
    (OUT/('replay-'+case+'.bin')).write_bytes(client.entropy+client.incoming)
for label,kwargs in [('entropy unavailable',{'entropy_fail':True}),('cancelled',{'cancel':True}),('unknown UTC',{'when':0})]:
    a,b=socket.socketpair();client=Client(a,**kwargs);check(client.handshake()<0 and client.sent==0,label+' rejected before ClientHello');client.close();b.close()

# Sanitizer harness inputs, plus standalone JTMOS socket probe trust input.
for i,cert in enumerate(good_chain): (OUT/('chain%d.der'%i)).write_bytes(cert)
(OUT/'root-subject.der').write_bytes(root.subject.public_bytes())
mod=root_key.public_key().public_numbers().n.to_bytes(256,'big');(OUT/'root-modulus.bin').write_bytes(mod)
(OUT/'utc.txt').write_text(str(utc))
print('ALL TLS1.3 CORE / X509 / INTEROPERABILITY CHECKS PASSED',flush=True)
