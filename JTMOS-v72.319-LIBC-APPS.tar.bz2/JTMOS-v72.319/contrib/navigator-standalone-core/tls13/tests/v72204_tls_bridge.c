/* Host-only introspection shim for the allocation-free TLS context. */
#include "nav_tls_client.h"
size_t test_tls_size(void){return sizeof(nav_tls_client);}
int test_tls_state(const nav_tls_client *c){return c->state;}
int test_tls_truncated(const nav_tls_client *c){return c->truncated;}
int test_tls_keys_erased(const nav_tls_client *c){
    const uint8_t *p=(const uint8_t *)&c->rx;size_t i;unsigned v=0;
    for(i=0;i<sizeof(c->rx);i++)v|=p[i];p=(const uint8_t *)&c->tx;
    for(i=0;i<sizeof(c->tx);i++)v|=p[i];for(i=0;i<32;i++)v|=c->private_key[i]|c->master[i];return v==0;
}
