/* JTMOS Navigator TLS record-layer integration skeleton.
 * Expects the wire-level handshake, certificate validation, and Finished
 * verification to be implemented separately. This file MUST NOT be used
 * to skip peer authentication. Does not perform TCP framing or I/O.
 */
#include "nav_tls13.h"

typedef struct navigator_tls_link {
    nav_tls13_keys tx;
    nav_tls13_keys rx;
} navigator_tls_link;

/* Call ONLY AFTER correctly verifying the server's Certificate, hostname,
 * CertificateVerify signature and Finished, AND sending client Finished.
 * `client_traffic` and `server_traffic` are application traffic secrets,
 * not the raw X25519 shared secret. No hardcoded test keys in production.
 */
int navigator_tls_link_install_verified_secrets(navigator_tls_link *link,
      const uint8_t client_traffic[32], const uint8_t server_traffic[32]) {
    if (!link || !client_traffic || !server_traffic) return -1;
    if (nav_tls13_keys_init(&link->tx, client_traffic) != 0) return -1;
    if (nav_tls13_keys_init(&link->rx, server_traffic) != 0) {
        nav_tls13_keys_wipe(&link->tx);
        return -1;
    }
    return 0;
}
int navigator_tls_link_send(navigator_tls_link *link,
    const uint8_t *bytes, size_t count, uint8_t *wire,
    size_t wire_capacity, size_t *wire_size) {
    if (!link) return -1;
    return nav_tls13_seal(&link->tx, NAV_TLS13_APPDATA,
                          bytes, count, wire, wire_capacity, wire_size);
}
int navigator_tls_link_receive(navigator_tls_link *link,
    const uint8_t *wire, size_t wire_size, uint8_t *plain,
    size_t plain_capacity, size_t *plain_size) {
    uint8_t inner_type = 0;
    int rc;
    if (!link) return -1;
    rc = nav_tls13_open(&link->rx, wire, wire_size,
                         plain, plain_capacity, &inner_type, plain_size);
    if (rc != 0) return rc;
    if (inner_type != NAV_TLS13_APPDATA) {
        /* Handshake, KeyUpdate and close_notify need dedicated handling. */
        nav_tls13_keys_wipe(&link->tx);
        nav_tls13_keys_wipe(&link->rx);
        return -2;
    }
    return 0;
}
void navigator_tls_link_close(navigator_tls_link *link) {
    if (!link) return;
    nav_tls13_keys_wipe(&link->tx);
    nav_tls13_keys_wipe(&link->rx);
}
