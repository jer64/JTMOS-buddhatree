/* OSDEV integration: io callbacks are supplied by the operating system.
 * This helper returns success only after chain/SAN/time/CV/Finished validation.
 * Keep client on caller-owned heap/arena, and anchors alive for the connection.
 */
#include "../src/nav_tls_client.h"
int navigator_tls_open(nav_tls_client *client,nav_tls_io io,
                       const nav_trust_anchor *anchors,size_t anchor_count,
                       const char *hostname,uint64_t utc_seconds){
    nav_tls_config config;int rc;
    config.io=io;config.anchors=anchors;config.anchor_count=anchor_count;
    config.hostname=hostname;config.utc_seconds=utc_seconds;
    rc=nav_tls_client_init(client,&config);
    return rc?rc:nav_tls_client_handshake(client);
}
