# Navigator v72.204 — oma TLS 1.3 / HTTPS

Vaihe 2 lisää aiemman kryptopohjan päälle toimivan TLS 1.3 -asiakkaan ja
RSA/SHA-256-varmenneprofiilin. C-ydin on irrallinen käyttöjärjestelmästä:
se ei kutsu libc:tä, varaa muistia eikä linkitä OpenSSL:ää, BearSSL:ää tai
muita kryptokirjastoja. Navigatorin TCP-sovitin käyttää JTMOS:n omia
socket-, aika-, muistivaraus- ja satunnaisuuspalveluja.

## Käyttöönotto Navigatorissa

Normaali `navigator-v72.204.bin` sisältää molemmat TLS-toteutukset.
Sen oletus on aiempi BearSSL/TLS 1.2. Valitse uusi toteutus asettamalla
prosessin ympäristömuuttuja `NAV_TLS_BACKEND=standalone13` ennen Navigatorin
ja sen verkkotyöntekijän käynnistystä. `bearssl12` valitsee aiemman toteutuksen.
Tuntematon valinta hylätään. Epäonnistunutta yhteyttä ei yritetä automaattisesti
uudestaan toisella TLS-taustalla tai salaamattomalla HTTP:llä.

Erillinen `navigator-v72.204-tls13.bin` on käännetty asetuksilla
`NAV_WITH_BEARSSL=0 NAV_WITH_TLS13=1`. Sen HTTPS käyttää suoraan uutta
toteutusta, eikä binääri sisällä BearSSL:n koodia. Muut selaimen riippuvuudet
(oma libc, Lexbor, QuickJS, WebP) säilyvät molemmissa binääreissä.

Asenna valittu binääri JTMOS:n aktiivisen levyn `/bin/navigator.bin`-tiedostoksi.
ZIP sisältää koko lähdepuun; asennusmediat ja kernel ovat perittyjä, eikä ISO:ssa
ole tätä uudelleen käännettyä Navigatoria. Täysi mediapäivitys vaatii OS:n
normaalin käännös- ja paketointiketjun.

## Toteutettu profiili ja rajat

| Osa | Toteutus |
|---|---|
| Protokolla | TLS 1.3, TLS_AES_128_GCM_SHA256, uusi X25519-avain joka yhteydelle |
| Kättely | ClientHello, ServerHello, EncryptedExtensions, Certificate, CertificateVerify, Finished ja asiakkaan Finished |
| Palvelin | SNI DNS-nimelle; ALPN http/1.1 tarkistetaan, jos palvelin lähettää sen |
| Uudelleenyritys | Yksi cookie-only HelloRetryRequest; jo tarjottua X25519-avainta ei saa pyytää uudelleen |
| Allekirjoitus | CertificateVerify: rsa_pss_rsae_sha256; varmenteet: RSA PKCS1/SHA256 tai PSS/SHA256, MGF1-SHA256, 32 tavun salt |
| RSA | Oma Montgomery-kertolasku; 2048–4096 bitin julkiset avaimet, enintään 32-bittinen pariton eksponentti |
| Luottamus | Kutsujan ankkurit; Navigatorissa 78 RSA-ankkuria aiemmasta 117 varmenteen hash-kiinnitetystä Mozilla-aineistosta |
| Tunnistus | SAN dNSName / IPv4, ASCII-kirjainkoosta riippumaton vertailu; wildcard vain yhteen vasempaan nimiosaan |
| Varmenneketju | Enintään 8 varmennetta oikeassa järjestyksessä; allekirjoitus, aika, CA, keyUsage, serverAuth/EKU ja pathLen |
| Tietueet | Osittaiset TCP-luvut/kirjoitukset; useita kättelyviestejä tietueessa ja viesti usean tietueen yli |
| Yhteyden jatko | KeyUpdate ja vastauspyyntö; liput jäsennetään ja hylätään tallentamatta; ei istunnon jatkamista |
| Lopetus | Salattu close_notify; TCP EOF ilman sitä merkitään katkeamiseksi |

Tämä on kehitysversio rajatulle profiilille. Se ei toteuta koko TLS 1.3:n
pakollista algoritmivalikoimaa eikä koko Web PKI:n yhteensopivuutta. ECDSA,
EdDSA, P-256, SHA-384/512-varmenneketjut, IPv6-palvelinnimen tarkistus,
asiakasvarmenteet, PSK, 0-RTT ja vaihtoehtoisten ketjujen rakentaminen puuttuvat.
Issuer/subject vertautuvat täsmälleen DER-muodossa; vaihtoehtoinen DN-koodaus
voi siksi hylätä muuten kelvollisen ketjun.

NameConstraints, policyConstraints, inhibitAnyPolicy, policyMappings ja
must-staple hylätään myös ei-kriittisinä; tuntemattomat kriittiset laajennukset
hylätään. Näiden ehtoja ei ohiteta. Tavallinen certificatePolicies ei rajoita
tätä any-policy-profiilia. AIA-hakua, CRL:ää tai OCSP-tarkistusta ei tehdä:
peruutettu varmenne voi jäädä havaitsematta. Common Name -varatunnistusta ei ole.
Ankkurit ovat ennalta asetettua paikallista luottamuspolitiikkaa; niiden
itseallekirjoitus tai voimassaoloaika ei muodosta uutta luottamusta.

Omaa kryptokoodia ei ole riippumattomasti auditoitu. AES välttää salaisuudesta
riippuvia hakutaulukoita, mutta on hidas; kääntäjän ja kohde-CPU:n ajoitusominaisuuksia
ei ole todistettu. Host-yhteentoimivuus- ja muistiturvatestit eivät osoita
tuotantoturvallisuutta tai fyysisen JTMOS-laitteen toimivuutta.

## C-rajapinta ja muistinomistus

Päätiedosto on `libc/libc/network/tls13/nav_tls_client.h`.

```c
/* Kutsu verkkotyöntekijässä. io ja anchors tulevat OS-sovittimelta. */
nav_tls_config cfg = {0};
cfg.io = io;
cfg.anchors = anchors;
cfg.anchor_count = anchor_count;
cfg.hostname = "example.com";
cfg.utc_seconds = trusted_utc;

/* client osoittaa kutsujan varaamaan sizeof(nav_tls_client)-alueeseen. */
int rc = nav_tls_client_init(client, &cfg);
if (rc == 0)
    rc = nav_tls_client_handshake(client);
if (rc == 0) {
    /* write/read sallivat sovellusdataa vasta vahvistetun kättelyn jälkeen. */
    rc = nav_tls_client_write(client, request, request_size);
}
nav_tls_client_close(client);
nav_tls_client_wipe(client);
```

Konteksti kannattaa sijoittaa omaan kekoon tai areenaan. Se sisältää noin
162 KiB muistia (host-testissä `sizeof` on 165672 tavua); sitä ei saa sijoittaa pieneen kernelpinoon.
Luottamusankkurien tavujen pitää pysyä voimassa koko yhteyden ajan. Yhdellä
kontekstilla on yksi omistaja, eikä samaa yhteyttä saa käyttää rinnakkain.

`read` ja `write` ovat osittaisia TCP-operaatioita, joilla OS-sovitin ylläpitää
yhteistä aikarajaa koko operaatiolle. `random` tuottaa alustetusta CSPRNG:stä
pyydetyt tavut tai palauttaa virheen. Navigator jakaa 96 tavun alustuspyynnön
OS:n nykyisen entropiarajapinnan sallimiin enintään 64 tavun pyyntöihin.
Vanhan koneen yksityinen seed-pooli kulutetaan ja synkronoidaan aiemmalla
kertakäyttöisellä mekanismilla; mitään levyn tai osion nimeä ei oleteta.

`nav_tls_client_read` palauttaa 0 sekä close_notify- että TCP EOF -tilanteessa;
`client->truncated` erottaa jälkimmäisen. HTTP-koodin Content-Length/chunked
tarkistukset säilyvät, ja close-delimited-vastaus hylätään katkenneelta TLS:ltä.
Virhe tyhjentää salaisuudet ja sulkee tilakoneen uusilta kirjoituksilta.

## Tiedostot ja kääntäminen

| Tiedosto | Vastuu |
|---|---|
| `tls13/nav_crypto.c` | Aiempi SHA256/HMAC/HKDF/X25519/AES-GCM-pohja; freestanding SIZE_MAX -yhteensopivuuskorjaus |
| `tls13/nav_tls13.c` | Avainten johdanto ja salatut tietueet |
| `tls13/nav_rsa.c` | Julkinen RSA-operaatio ja tarkat PKCS1/PSS-koodaukset |
| `tls13/nav_x509.c` | Rajattu DER/varmenneketju ja SAN-tunnistus |
| `tls13/nav_tls_client.c` | Kättelytilakone, TCP-kehystys, KeyUpdate ja sulkeminen |
| `jt_net_transport13.inc` | JTMOS:n socket-, aika- ja entropiasovitin |
| `jt_tls13_roots.generated.h` | Julkinen, uudelleen tuotettava ankkuriaineisto |

Polut ovat suhteessa `libc/libc/network/`-hakemistoon. Kanoninen koodi on siellä;
`contrib/navigator-standalone-core/tls13/` sisältää saman julkaistun lähdekoodin.
Memory v2 säilyy saman contrib-paketin `memory/`-hakemistossa erillisenä moduulina.
Sen GC/quota-toteutusta ei tässä vaiheessa vaihdeta Navigatorin nykyiseen runtimeen.

```sh
make -C libc/apps -f navigator.mak -j2 navigator.bin
make -C libc/apps -f navigator.mak -j2 NAV_WITH_BEARSSL=0 NAV_WITH_TLS13=1 navigator.bin
sh tests/run-v72204-tls13.sh /tmp/nav-tls13
python3 tools/generate_tls13_roots.py
```

Host-testit tarvitsevat Pythonin cryptography-paketin ja ssl-tuen; niitä ei
linkitetä JTMOS-binääriin. Testit käyttävät vain loopback-yhteyksiä ja luovat
omat lyhytikäiset varmenteensa ja avaimensa testihakemistoon. Näiden testien
luomat yksityiset avaimet, entropiapoolit ja TLS-liikennetallenteet eivät sisälly julkaisuun.
Testaustulokset ovat tiedostossa `QA-V72.204.md`.

Standardiviitteet: [TLS 1.3, RFC 8446](https://www.rfc-editor.org/rfc/rfc8446.html),
[RSA, RFC 8017](https://www.rfc-editor.org/rfc/rfc8017.html),
[X.509, RFC 5280](https://www.rfc-editor.org/rfc/rfc5280.html) ja
[palvelimen tunnistus, RFC 9525](https://www.rfc-editor.org/rfc/rfc9525.html).
