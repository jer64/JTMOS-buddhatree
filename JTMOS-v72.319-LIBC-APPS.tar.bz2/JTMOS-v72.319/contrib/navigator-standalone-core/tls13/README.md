# Navigator standalone TLS 1.3 v2 — JTMOS v72.204

The previous SHA256/HKDF/X25519/AES128-GCM foundation now has a working client
handshake, bounded RSA/SHA256 X509 validation, TCP record framing, authenticated
application data, KeyUpdate and close handling. All production src/ code is
C99 freestanding, caller-owned and allocation-free; there are no libc, OpenSSL,
BearSSL or compiler-runtime imports in the combined i686 core object.

This package is the complete source for this component. The separate JTMOS
v72.204 FULL-SOURCE-UNBUILT archive contains the OS, Navigator HTTP/TCP adapter,
Mozilla trust data and rebuilt browser binaries. Canonical integrated sources
are libc/libc/network/tls13/ in that release; this directory is an identical
release copy. No OS syscalls are emulated by the standalone package.

## Supported development profile

- TLS1.3 / TLS_AES_128_GCM_SHA256 / fresh X25519 / SNI / HTTP1.1 ALPN.
- Chain signatures: RSA PKCS1-SHA256 or PSS-SHA256; CertificateVerify:
  rsa_pss_rsae_sha256. RSA 2048–4096 bits, bounded 32-bit exponent.
- Explicit configured trust anchors, trusted UTC, SAN DNS/IPv4, single-label
  wildcard, CA/keyUsage/EKU/serverAuth/pathLen, ordered chain up to eight certs.
- Bounded fragmentation, cookie-only retry, KeyUpdate request/reply,
  discarded session tickets, authenticated close and TCP truncation flag.

This is a restricted development profile, without an independent security or
side-channel audit. It lacks full TLS mandatory algorithm and Web PKI coverage.
ECDSA/EdDSA/P256, SHA384/512 chains, IPv6 names, client authentication, resumption,
PSK/0-RTT, alternate chain building, OCSP/CRLs are not implemented. Constrained
name/policy chains, must-staple and unknown critical extensions are rejected;
there is no certificate/hostname verification bypass or CN fallback. Revoked
certificates may go undetected. Portable AES is deliberately table-free and slow.

## API

Include src/nav_tls_client.h; allocate sizeof(nav_tls_client) in a caller
heap/arena, not on a small task stack. Supply partial TCP read/write callbacks,
a deadline/cancellation policy, seeded CSPRNG callback, persistent trust anchors,
hostname and trusted UTC. Call init, handshake, read/write, close, wipe.
Only successful authenticated handshake enables application data. Check
truncated when interpreting EOF in an HTTP close-delimited body.
See examples/https_port.c and JTMOS-INTEGRATION.md for ownership and OS details.
The old jtmos_tls_adapter.c remains a historical low-level key-install example;
normal clients must use the new handshake API.

## Build and verify

```sh
make test                      # 25 original crypto/record known-answer checks
make freestanding              # i686 core + nm undefined-symbol gate
sh tests/run-core.sh /tmp/nav-tls13-v2
python3 tests/crosscheck.py     # 100 random AES-GCM + 100 X25519 comparisons
```

Host integration tests require Python cryptography >=42 and Python ssl/OpenSSL;
none is linked into the C component. Tests generate their own ephemeral keys,
test trust anchors and replay secrets under the selected temporary output.
They are not included in distributed sources. The full release adds a separate
Navigator HTTP/OS-entropy integration suite. See JTMOS-INTEGRATION.md for exact
profile limits, references and release status.
