#include "nav_tls_client.h"

typedef struct cursor {const uint8_t *p;size_t n;} cursor;
static void cp(void *dst,const void *src,size_t n){volatile uint8_t *d=(volatile uint8_t *)dst;const uint8_t *s=(const uint8_t *)src;while(n--)*d++=*s++;}
static unsigned u16(const uint8_t *p){return ((unsigned)p[0]<<8)|p[1];}
static size_t u24(const uint8_t *p){return ((size_t)p[0]<<16)|((size_t)p[1]<<8)|p[2];}
static void w16(uint8_t *p,size_t n){p[0]=(uint8_t)(n>>8);p[1]=(uint8_t)n;}
static void w24(uint8_t *p,size_t n){p[0]=(uint8_t)(n>>16);p[1]=(uint8_t)(n>>8);p[2]=(uint8_t)n;}
static int bytes(cursor *c,size_t n,cursor *out){if(n>c->n)return -1;if(out){out->p=c->p;out->n=n;}c->p+=n;c->n-=n;return 0;}
static int vector(cursor *c,unsigned prefix,cursor *out){size_t n;
    if(c->n<prefix)return -1;n=prefix==1?c->p[0]:prefix==2?u16(c->p):u24(c->p);
    if(bytes(c,prefix,0))return -1;return bytes(c,n,out);
}
static void hash_now(nav_tls_client *c,uint8_t out[32]){nav_sha256 s;cp(&s,&c->transcript,sizeof(s));nav_sha256_final(&s,out);}
static void erase_secrets(nav_tls_client *c){
    nav_secure_zero(c->private_key,32);nav_secure_zero(c->master,32);
    nav_tls13_keys_wipe(&c->rx);nav_tls13_keys_wipe(&c->tx);
    nav_secure_zero(&c->transcript,sizeof(c->transcript));
    nav_secure_zero(c->wire,sizeof(c->wire));nav_secure_zero(c->plain,sizeof(c->plain));
    nav_secure_zero(c->handshake,sizeof(c->handshake));c->handshake_used=c->plain_offset=c->plain_size=0;
}
static int cancelled(nav_tls_client *c){return c->io.cancelled&&c->io.cancelled(c->io.context);}
static int write_all(nav_tls_client *c,const uint8_t *p,size_t n){
    while(n){int k;if(cancelled(c))return NAV_TLS_CANCELLED;
        k=c->io.write(c->io.context,p,n);if(k<=0||(size_t)k>n)return NAV_TLS_IO;p+=k;n-=(size_t)k;}
    return 0;
}
static int read_all(nav_tls_client *c,uint8_t *p,size_t n,int allow_eof){size_t used=0;
    while(used<n){int k;if(cancelled(c))return NAV_TLS_CANCELLED;
        k=c->io.read(c->io.context,p+used,n-used);
        if(k==0&&allow_eof&&used==0)return 1;
        if(k<=0||(size_t)k>n-used)return NAV_TLS_IO;used+=(size_t)k;}
    return 0;
}
static int send_record(nav_tls_client *c,uint8_t type,const uint8_t *data,size_t n){size_t out;int rc;
    if(c->tx.active){rc=nav_tls13_seal(&c->tx,type,data,n,c->wire,sizeof(c->wire),&out);if(rc)return NAV_TLS_AUTH;}
    else{if(n>NAV_TLS13_MAX_CONTENT)return NAV_TLS_LIMIT;
        c->wire[0]=type;c->wire[1]=3;c->wire[2]=3;w16(c->wire+3,n);cp(c->wire+5,data,n);out=n+5;}
    return write_all(c,c->wire,out);
}
static int fail(nav_tls_client *c,int error,unsigned alert){uint8_t a[2];
    if(c->state!=NAV_TLS_FAILED){
        if(alert&&error!=NAV_TLS_IO&&error!=NAV_TLS_CANCELLED){a[0]=2;a[1]=(uint8_t)alert;(void)send_record(c,21,a,2);}
        c->state=NAV_TLS_FAILED;c->error=error;erase_secrets(c);
    }return c->error;
}
static int receive_record(nav_tls_client *c,uint8_t *type,size_t *n){size_t len;int rc;
    rc=read_all(c,c->wire,5,1);if(rc)return rc==1?1:rc;
    len=u16(c->wire+3);
    if(c->wire[1]!=3||c->wire[2]!=3||!len||len>sizeof(c->wire)-5)return NAV_TLS_PROTOCOL;
    rc=read_all(c,c->wire+5,len,0);if(rc)return rc;
    if(c->wire[0]==20&&c->state==NAV_TLS_HANDSHAKING){
        if(len!=1||c->wire[5]!=1||++c->ccs_count>32)return NAV_TLS_PROTOCOL;
        *type=20;*n=0;return 0;
    }
    if(c->rx.active){if(c->wire[0]!=23)return NAV_TLS_PROTOCOL;
        if(nav_tls13_open(&c->rx,c->wire,len+5,c->plain,sizeof(c->plain),type,n))return NAV_TLS_AUTH;
    }else{
        if(len>NAV_TLS13_MAX_CONTENT||(c->wire[0]!=22&&c->wire[0]!=21))return NAV_TLS_PROTOCOL;
        *type=c->wire[0];*n=len;cp(c->plain,c->wire+5,len);
    }
    return 0;
}
static int alert_received(nav_tls_client *c,size_t n){
    if(n!=2||(c->plain[0]!=1&&c->plain[0]!=2))return fail(c,NAV_TLS_PROTOCOL,50);
    c->peer_alert=c->plain[1];
    if(c->plain[1]==0&&c->state==NAV_TLS_READY){
        /* Reciprocal close is sent by close(), before erasing write keys. */
        c->state=NAV_TLS_CLOSED;nav_tls13_keys_wipe(&c->rx);return 1;
    }
    return fail(c,NAV_TLS_PROTOCOL,0);
}
static size_t extension(uint8_t *p,unsigned type,const uint8_t *data,size_t n){w16(p,type);w16(p+2,n);cp(p+4,data,n);return n+4;}
static int client_hello(nav_tls_client *c,const uint8_t *cookie,size_t cookie_n){
    uint8_t hello[2048],data[800],public_key[32];size_t p=4,e,hn=0,n;int rc;
    while(c->hostname[hn])hn++;
    hello[p++]=3;hello[p++]=3;cp(hello+p,c->client_random,32);p+=32;
    hello[p++]=32;cp(hello+p,c->session_id,32);p+=32;
    hello[p++]=0;hello[p++]=2;hello[p++]=0x13;hello[p++]=1;
    hello[p++]=1;hello[p++]=0;e=p;p+=2;
    /* SNI is omitted for a literal IPv4 target. */
    {size_t i;int numeric=1;for(i=0;i<hn;i++)if((c->hostname[i]<'0'||c->hostname[i]>'9')&&c->hostname[i]!='.')numeric=0;
        if(!numeric){w16(data,hn+3);data[2]=0;w16(data+3,hn);cp(data+5,c->hostname,hn);p+=extension(hello+p,0,data,hn+5);}}
    data[0]=2;data[1]=3;data[2]=4;p+=extension(hello+p,43,data,3);
    data[0]=0;data[1]=2;data[2]=0;data[3]=29;p+=extension(hello+p,10,data,4);
    /* TLS CV uses RSA-PSS. PKCS1 SHA256 is offered for certificate signatures. */
    data[0]=0;data[1]=4;data[2]=8;data[3]=4;data[4]=4;data[5]=1;p+=extension(hello+p,13,data,6);
    data[0]=0;data[1]=9;data[2]=8;cp(data+3,"http/1.1",8);p+=extension(hello+p,16,data,11);
    nav_x25519_public(public_key,c->private_key);
    w16(data,36);w16(data+2,29);w16(data+4,32);cp(data+6,public_key,32);p+=extension(hello+p,51,data,38);
    if(cookie_n){w16(data,cookie_n);cp(data+2,cookie,cookie_n);p+=extension(hello+p,44,data,cookie_n+2);}
    w16(hello+e,p-e-2);hello[0]=1;w24(hello+1,p-4);
    nav_sha256_update(&c->transcript,hello,p);n=p;
    rc=send_record(c,22,hello,n);
    nav_secure_zero(hello,sizeof(hello));nav_secure_zero(data,sizeof(data));nav_secure_zero(public_key,32);return rc;
}
static int server_hello(nav_tls_client *c,const uint8_t *message,size_t size){
    static const uint8_t hrr[32]={0xcf,0x21,0xad,0x74,0xe5,0x9a,0x61,0x11,0xbe,0x1d,0x8c,0x02,0x1e,0x65,0xb8,0x91,
        0xc2,0xa2,0x11,0x16,0x7a,0xbb,0x8c,0x5e,0x07,0x9e,0x09,0xe2,0xc8,0xa8,0x33,0x9c};
    cursor d,random,sid,ext,x,cookie;unsigned seen=0,t;int retry,rc;
    uint8_t shared[32],point[32],hash[32],client[32],server[32],synthetic[4]={254,0,0,32},retry_cookie[512];size_t retry_n=0;
    d.p=message+4;d.n=size-4;cookie.p=0;cookie.n=0;
    if(d.n<2||u16(d.p)!=0x0303||bytes(&d,2,0)||bytes(&d,32,&random)||vector(&d,1,&sid)||sid.n!=32||
       !nav_ct_equal(sid.p,c->session_id,32)||d.n<3||u16(d.p)!=0x1301||d.p[2]!=0||bytes(&d,3,0)||vector(&d,2,&ext)||d.n)
        return fail(c,NAV_TLS_PROTOCOL,47);
    retry=nav_ct_equal(random.p,hrr,32);
    while(ext.n){if(ext.n<4)return fail(c,NAV_TLS_PROTOCOL,50);t=u16(ext.p);bytes(&ext,2,0);
        if(vector(&ext,2,&x))return fail(c,NAV_TLS_PROTOCOL,50);
        if(t==43){if((seen&1)||x.n!=2||u16(x.p)!=0x0304)return fail(c,NAV_TLS_PROTOCOL,47);seen|=1;}
        else if(t==51){if(retry||(seen&2)||x.n!=36||u16(x.p)!=29||u16(x.p+2)!=32)return fail(c,NAV_TLS_PROTOCOL,47);
            cp(point,x.p+4,32);seen|=2;}
        else if(t==44&&retry){if((seen&4)||vector(&x,2,&cookie)||x.n||!cookie.n||cookie.n>512)return fail(c,NAV_TLS_PROTOCOL,47);seen|=4;}
        else return fail(c,NAV_TLS_UNSUPPORTED,110);
    }
    if(retry){
        /* Only X25519 was offered with a key share, so HRR cannot request it
         * again. A cookie-only retry is valid; exactly one retry is allowed. */
        if(c->retried||seen!=5)return fail(c,NAV_TLS_PROTOCOL,47);
        retry_n=cookie.n;cp(retry_cookie,cookie.p,retry_n);
        hash_now(c,hash);nav_sha256_init(&c->transcript);nav_sha256_update(&c->transcript,synthetic,4);
        nav_sha256_update(&c->transcript,hash,32);nav_sha256_update(&c->transcript,message,size);c->retried=1;
        rc=client_hello(c,retry_cookie,retry_n);nav_secure_zero(hash,32);nav_secure_zero(retry_cookie,sizeof(retry_cookie));
        return rc?fail(c,rc,0):0;
    }
    if(seen!=3)return fail(c,NAV_TLS_PROTOCOL,109);
    if(nav_x25519(shared,c->private_key,point))return fail(c,NAV_TLS_AUTH,47);
    nav_sha256_update(&c->transcript,message,size);hash_now(c,hash);
    rc=nav_tls13_handshake_secrets(shared,hash,client,server,c->master);
    if(!rc)rc=nav_tls13_keys_init(&c->tx,client);
    if(!rc)rc=nav_tls13_keys_init(&c->rx,server);
    nav_secure_zero(shared,32);nav_secure_zero(hash,32);nav_secure_zero(client,32);nav_secure_zero(server,32);nav_secure_zero(c->private_key,32);
    if(rc)return fail(c,NAV_TLS_AUTH,80);c->phase=1;return 0;
}
static int encrypted_extensions(nav_tls_client *c,const uint8_t *p,size_t n){cursor d,ext,x,list,name;unsigned seen=0,t;
    d.p=p;d.n=n;if(vector(&d,2,&ext)||d.n)return fail(c,NAV_TLS_PROTOCOL,50);
    while(ext.n){if(ext.n<4)return fail(c,NAV_TLS_PROTOCOL,50);t=u16(ext.p);bytes(&ext,2,0);
        if(vector(&ext,2,&x))return fail(c,NAV_TLS_PROTOCOL,50);
        if(t==0){if((seen&1)||x.n)return fail(c,NAV_TLS_PROTOCOL,47);seen|=1;}
        else if(t==16){if((seen&2)||vector(&x,2,&list)||x.n||vector(&list,1,&name)||list.n||name.n!=8||
            !nav_ct_equal(name.p,(const uint8_t *)"http/1.1",8))return fail(c,NAV_TLS_PROTOCOL,120);seen|=2;}
        else if(t==10){if((seen&4)||vector(&x,2,&list)||x.n||!list.n||(list.n&1))return fail(c,NAV_TLS_PROTOCOL,50);seen|=4;}
        else return fail(c,NAV_TLS_UNSUPPORTED,110);
    }return 0;
}
static int certificate(nav_tls_client *c,const uint8_t *p,size_t n){cursor d,context,list,x,ext;nav_span chain[NAV_X509_MAX_CHAIN];size_t count=0;nav_rsa_public key;int rc;
    d.p=p;d.n=n;if(vector(&d,1,&context)||context.n||vector(&d,3,&list)||d.n||!list.n)return fail(c,NAV_TLS_PROTOCOL,50);
    while(list.n){if(count==NAV_X509_MAX_CHAIN)return fail(c,NAV_TLS_LIMIT,80);
        if(vector(&list,3,&x)||!x.n||vector(&list,2,&ext)||ext.n)return fail(c,NAV_TLS_UNSUPPORTED,110);
        chain[count].p=x.p;chain[count].n=x.n;count++;}
    rc=nav_x509_verify(chain,count,c->anchors,c->anchor_count,c->hostname,c->utc,&key);
    if(rc){c->certificate_error=rc;return fail(c,NAV_TLS_CERTIFICATE,rc==NAV_X509_TIME?45:rc==NAV_X509_TRUST?48:42);}
    cp(c->leaf_modulus,key.modulus.p,key.modulus.n);c->leaf_size=key.modulus.n;c->leaf_exponent=key.exponent;return 0;
}
static int certificate_verify(nav_tls_client *c,const uint8_t *p,size_t n){
    uint8_t signed_data[130],hash[32],digest[32];nav_rsa_public key;nav_span sig;size_t i;int rc;
    if(n<4||u16(p)!=0x0804||u16(p+2)!=n-4)return fail(c,NAV_TLS_PROTOCOL,47);
    hash_now(c,hash);for(i=0;i<64;i++)signed_data[i]=32;
    cp(signed_data+64,"TLS 1.3, server CertificateVerify",33);signed_data[97]=0;cp(signed_data+98,hash,32);
    nav_sha256_hash(signed_data,130,digest);key.modulus.p=c->leaf_modulus;key.modulus.n=c->leaf_size;key.exponent=c->leaf_exponent;
    sig.p=p+4;sig.n=n-4;rc=nav_rsa_verify_sha256(&key,NAV_RSA_PSS_SHA256,digest,sig);
    nav_secure_zero(signed_data,sizeof(signed_data));nav_secure_zero(hash,32);nav_secure_zero(digest,32);
    return rc?fail(c,NAV_TLS_AUTH,51):0;
}
static int finished(nav_tls_client *c,const uint8_t *message,size_t n){
    uint8_t hash[32],mac[36],client[32],server[32];int rc;
    if(n!=36)return fail(c,NAV_TLS_PROTOCOL,50);
    hash_now(c,hash);rc=nav_tls13_finished_mac(c->rx.secret,hash,mac);
    if(rc||!nav_ct_equal(mac,message+4,32)){nav_secure_zero(mac,sizeof(mac));nav_secure_zero(hash,32);return fail(c,NAV_TLS_AUTH,51);}
    nav_sha256_update(&c->transcript,message,n);hash_now(c,hash);
    rc=nav_tls13_application_secrets(c->master,hash,client,server);
    mac[0]=20;w24(mac+1,32);
    if(!rc)rc=nav_tls13_finished_mac(c->tx.secret,hash,mac+4);
    if(!rc)rc=send_record(c,22,mac,36);
    if(!rc)rc=nav_tls13_keys_init(&c->rx,server);
    if(!rc)rc=nav_tls13_keys_init(&c->tx,client);
    nav_secure_zero(hash,32);nav_secure_zero(mac,sizeof(mac));nav_secure_zero(client,32);nav_secure_zero(server,32);nav_secure_zero(c->master,32);
    nav_secure_zero(&c->transcript,sizeof(c->transcript));
    if(rc)return fail(c,rc,0);c->state=NAV_TLS_READY;c->phase=5;return 0;
}
static int handshake_messages(nav_tls_client *c){size_t size,i;unsigned type;int rc;
    while(c->handshake_used>=4){
        size=u24(c->handshake+1)+4;type=c->handshake[0];
        if(size>sizeof(c->handshake))return fail(c,NAV_TLS_LIMIT,50);
        if(size>c->handshake_used)return 0;
        if(c->phase==0&&type==2){
            /* Key changes must align with the end of a record. */
            if(size!=c->handshake_used)return fail(c,NAV_TLS_PROTOCOL,10);
            rc=server_hello(c,c->handshake,size);
        }else if(c->phase==1&&type==8){rc=encrypted_extensions(c,c->handshake+4,size-4);if(!rc)c->phase=2;}
        else if(c->phase==2&&type==11){rc=certificate(c,c->handshake+4,size-4);if(!rc)c->phase=3;}
        else if(c->phase==3&&type==15){rc=certificate_verify(c,c->handshake+4,size-4);if(!rc)c->phase=4;}
        else if(c->phase==4&&type==20){
            if(size!=c->handshake_used)return fail(c,NAV_TLS_PROTOCOL,10);
            rc=finished(c,c->handshake,size);
        }else return fail(c,type==13?NAV_TLS_UNSUPPORTED:NAV_TLS_PROTOCOL,10);
        if(rc)return rc;
        if(type!=2&&type!=20)nav_sha256_update(&c->transcript,c->handshake,size);
        c->handshake_used-=size;for(i=0;i<c->handshake_used;i++)c->handshake[i]=c->handshake[size+i];
    }return 0;
}
int nav_tls_client_init(nav_tls_client *c,const nav_tls_config *config){size_t n;uint8_t entropy[96];int rc;
    if(!c)return NAV_TLS_ARGUMENT;nav_secure_zero(c,sizeof(*c));
    if(!config||!config->io.read||!config->io.write||!config->io.random||!config->anchors||!config->anchor_count||
       config->anchor_count>256||!config->utc_seconds||config->utc_seconds>253402300799ULL||!nav_x509_hostname_valid(config->hostname)){
        c->state=NAV_TLS_FAILED;c->error=NAV_TLS_ARGUMENT;return c->error;}
    cp(&c->io,&config->io,sizeof(c->io));c->anchors=config->anchors;c->anchor_count=config->anchor_count;c->utc=config->utc_seconds;
    for(n=0;config->hostname[n];n++)c->hostname[n]=config->hostname[n];
    if(n&&c->hostname[n-1]=='.')c->hostname[--n]=0;
    if(cancelled(c))return fail(c,NAV_TLS_CANCELLED,0);
    rc=c->io.random(c->io.context,entropy,sizeof(entropy));
    if(rc){nav_secure_zero(entropy,sizeof(entropy));return fail(c,NAV_TLS_ENTROPY,0);}
    cp(c->private_key,entropy,32);cp(c->client_random,entropy+32,32);cp(c->session_id,entropy+64,32);nav_secure_zero(entropy,sizeof(entropy));
    nav_sha256_init(&c->transcript);c->state=NAV_TLS_HANDSHAKING;return 0;
}
int nav_tls_client_handshake(nav_tls_client *c){int rc;uint8_t type;size_t n,i;
    if(!c||c->state!=NAV_TLS_HANDSHAKING)return NAV_TLS_ARGUMENT;
    rc=client_hello(c,0,0);if(rc)return fail(c,rc,0);
    while(c->state==NAV_TLS_HANDSHAKING){
        if(++c->record_count>1024)return fail(c,NAV_TLS_LIMIT,80);
        rc=receive_record(c,&type,&n);if(rc)return fail(c,rc==1?NAV_TLS_IO:rc,rc==NAV_TLS_AUTH?20:50);
        if(type==20)continue;if(type==21)return alert_received(c,n);
        if(type!=22||!n||n>sizeof(c->handshake)-c->handshake_used)return fail(c,NAV_TLS_PROTOCOL,10);
        cp(c->handshake+c->handshake_used,c->plain,n);c->handshake_used+=n;
        rc=handshake_messages(c);if(rc)return rc;
        for(i=0;i<n;i++)c->plain[i]=0;
    }
    nav_secure_zero(c->handshake,sizeof(c->handshake));nav_secure_zero(c->leaf_modulus,sizeof(c->leaf_modulus));c->leaf_size=0;
    return c->state==NAV_TLS_READY?0:NAV_TLS_PROTOCOL;
}
static int traffic_update(nav_tls13_keys *keys){uint8_t secret[32];int rc;
    rc=nav_tls13_expand_label(keys->secret,"traffic upd",0,0,secret,32);
    if(!rc)rc=nav_tls13_keys_init(keys,secret);nav_secure_zero(secret,32);return rc;
}
static int send_key_update(nav_tls_client *c){uint8_t message[5]={24,0,0,1,0};int rc;
    rc=send_record(c,22,message,5);if(!rc)rc=traffic_update(&c->tx);return rc;
}
static int post_handshake(nav_tls_client *c,size_t n){size_t size,i;cursor d,ticket,nonce,extensions;int rc;
    if(n>sizeof(c->handshake)-c->handshake_used)return fail(c,NAV_TLS_LIMIT,50);
    cp(c->handshake+c->handshake_used,c->plain,n);c->handshake_used+=n;
    while(c->handshake_used>=4){
        size=u24(c->handshake+1)+4;if(size>16384)return fail(c,NAV_TLS_LIMIT,50);if(size>c->handshake_used)return 0;
        if(c->handshake[0]==24){
            if(size!=5||size!=c->handshake_used||c->handshake[4]>1)return fail(c,NAV_TLS_PROTOCOL,47);
            rc=traffic_update(&c->rx);if(!rc&&c->handshake[4])rc=send_key_update(c);
            if(rc)return fail(c,rc,0);
        }else if(c->handshake[0]==4){
            d.p=c->handshake+4;d.n=size-4;
            if(d.n<8||bytes(&d,8,0)||vector(&d,1,&nonce)||vector(&d,2,&ticket)||!ticket.n||
               vector(&d,2,&extensions)||d.n)return fail(c,NAV_TLS_PROTOCOL,50);
            /* No PSK offered, no ticket retained and no resumption/0-RTT. */
        }else return fail(c,NAV_TLS_UNSUPPORTED,10);
        c->handshake_used-=size;for(i=0;i<c->handshake_used;i++)c->handshake[i]=c->handshake[size+i];
    }return 0;
}
int nav_tls_client_read(nav_tls_client *c,void *buffer,size_t capacity){size_t n,take;unsigned records=0;uint8_t type;int rc;
    if(!c||!buffer||!capacity)return NAV_TLS_ARGUMENT;
    if(c->state==NAV_TLS_CLOSED)return 0;if(c->state!=NAV_TLS_READY)return c->error?c->error:NAV_TLS_ARGUMENT;
    if(capacity>0x7fffffffu)capacity=0x7fffffffu;
    for(;;){
        if(c->plain_offset<c->plain_size){take=c->plain_size-c->plain_offset;if(take>capacity)take=capacity;
            cp(buffer,c->plain+c->plain_offset,take);nav_secure_zero(c->plain+c->plain_offset,take);c->plain_offset+=take;return (int)take;}
        if(++records>64)return fail(c,NAV_TLS_LIMIT,80);
        rc=receive_record(c,&type,&n);
        if(rc==1){c->truncated=1;c->state=NAV_TLS_CLOSED;erase_secrets(c);return 0;}
        if(rc)return fail(c,rc,rc==NAV_TLS_AUTH?20:50);
        if(type==21)return alert_received(c,n)==1?0:c->error;
        if(type==22){rc=post_handshake(c,n);if(rc)return rc;continue;}
        if(type!=23||c->handshake_used)return fail(c,NAV_TLS_PROTOCOL,10);
        c->plain_size=n;c->plain_offset=0;
    }
}
int nav_tls_client_write(nav_tls_client *c,const void *buffer,size_t n){int rc;
    if(!c||!buffer||!n)return NAV_TLS_ARGUMENT;
    if(c->state!=NAV_TLS_READY)return c->error?c->error:NAV_TLS_ARGUMENT;
    if(n>NAV_TLS13_MAX_CONTENT)n=NAV_TLS13_MAX_CONTENT;
    if(c->tx.records_used>=900000){rc=send_key_update(c);if(rc)return fail(c,rc,0);}
    rc=send_record(c,23,(const uint8_t *)buffer,n);return rc?fail(c,rc,0):(int)n;
}
void nav_tls_client_close(nav_tls_client *c){uint8_t alert[2]={1,0};
    if(!c)return;if((c->state==NAV_TLS_READY||c->state==NAV_TLS_CLOSED)&&c->tx.active)(void)send_record(c,21,alert,2);
    erase_secrets(c);if(c->state!=NAV_TLS_FAILED)c->state=NAV_TLS_CLOSED;
}
void nav_tls_client_wipe(nav_tls_client *c){if(c)nav_secure_zero(c,sizeof(*c));}
const char *nav_tls_client_error(const nav_tls_client *c){if(!c)return "TLS context missing";
    switch(c->error){case NAV_TLS_OK:return "TLS 1.3 ready";case NAV_TLS_ARGUMENT:return "TLS configuration / UTC / hostname invalid";
    case NAV_TLS_IO:return "TLS TCP EOF / I/O failure";case NAV_TLS_ENTROPY:return "TLS secure entropy unavailable";
    case NAV_TLS_PROTOCOL:return "TLS peer alert / protocol failure";case NAV_TLS_AUTH:return "TLS signature / Finished / record authentication failure";
    case NAV_TLS_CERTIFICATE:return nav_x509_error_string(c->certificate_error);case NAV_TLS_UNSUPPORTED:return "TLS unsupported handshake / extension";
    case NAV_TLS_LIMIT:return "TLS message / record limit exceeded";case NAV_TLS_CANCELLED:return "TLS operation cancelled";
    default:return "TLS failure";}
}
