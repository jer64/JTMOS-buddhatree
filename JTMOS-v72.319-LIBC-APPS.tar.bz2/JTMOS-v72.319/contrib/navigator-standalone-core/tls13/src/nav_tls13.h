#ifndef NAV_TLS13_H
#define NAV_TLS13_H
/* TLS 1.3 SHA256 / AES_128_GCM_SHA256 key schedule and encrypted records.
 * Low-level record API does not authenticate peers by itself. Use
 * nav_tls_client.h for the wire handshake and mandatory X509 validation.
 */
#include "nav_crypto.h"
#define NAV_TLS13_MAX_CONTENT 16384u
#define NAV_TLS13_MAX_WIRE (5u + NAV_TLS13_MAX_CONTENT + 256u)
#define NAV_TLS13_ALERT 21u
#define NAV_TLS13_HANDSHAKE 22u
#define NAV_TLS13_APPDATA 23u

typedef struct nav_tls13_keys {
    uint8_t secret[32];
    uint8_t key[16];
    uint8_t iv[12];
    uint64_t sequence;
    uint32_t records_used;
    uint8_t active;
} nav_tls13_keys;

/* RFC 8446 HKDF-Expand-Label("tls13 " + label). */
int nav_tls13_expand_label(const uint8_t secret[32], const char *label,
                           const uint8_t *context, size_t context_len,
                           uint8_t *out, size_t out_len);
/* Schedule for a fresh ECDHE connection with no pre-shared key. */
int nav_tls13_handshake_secrets(const uint8_t shared[32],
                                const uint8_t hello_hash[32],
                                uint8_t client_hs[32], uint8_t server_hs[32],
                                uint8_t master[32]);
int nav_tls13_application_secrets(const uint8_t master[32],
                                  const uint8_t server_finished_hash[32],
                                  uint8_t client_app[32], uint8_t server_app[32]);
int nav_tls13_finished_mac(const uint8_t traffic_secret[32],
                            const uint8_t transcript_hash[32], uint8_t out[32]);
/* Key state must be caller-owned and not concurrently accessed. */
int nav_tls13_keys_init(nav_tls13_keys *keys, const uint8_t traffic_secret[32]);
void nav_tls13_keys_wipe(nav_tls13_keys *keys);
/* These record functions do not establish or assert peer authentication.
 * Calls return 0 on success; -1 invalid arguments; -2 auth/protocol failure.
 * On -2 ctx is wiped; TLS connection must close.
 * Functions accept whole wire records only; TCP framing is caller's job.
 */
int nav_tls13_seal(nav_tls13_keys *keys, uint8_t inner_type,
                   const uint8_t *content, size_t len,
                   uint8_t *wire, size_t capacity, size_t *wire_len);
int nav_tls13_open(nav_tls13_keys *keys,
                   const uint8_t *wire, size_t wire_len,
                   uint8_t *content, size_t capacity,
                   uint8_t *inner_type, size_t *content_len);
#endif
