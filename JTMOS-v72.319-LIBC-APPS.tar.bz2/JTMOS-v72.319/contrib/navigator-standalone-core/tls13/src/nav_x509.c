#include "nav_x509.h"

typedef struct der { const uint8_t *p; size_t n; } der;
typedef struct cert {
    nav_span tbs,issuer,subject,signature,san;
    nav_rsa_public key;
    uint64_t not_before,not_after;
    int signature_type,ca,path_length,has_basic,has_usage,sign,cert_sign,eku;
} cert;
static int same(nav_span a,nav_span b){return a.n==b.n&&nav_ct_equal(a.p,b.p,a.n);}
static nav_span span(const uint8_t *p,size_t n){nav_span s;s.p=p;s.n=n;return s;}
/* Single-octet tags only, minimal definite DER length, bounded by parent. */
static int take(der *d,unsigned tag,der *out,nav_span *whole){
    const uint8_t *start;size_t n,k,i,header;
    if(!d||d->n<2||d->p[0]!=tag||(tag&31)==31)return -1;
    start=d->p;n=d->p[1];header=2;
    if(n&128){k=n&127;if(!k||k>sizeof(size_t)||k>d->n-2||!d->p[2])return -1;
        n=0;for(i=0;i<k;i++){if(n>(SIZE_MAX>>8))return -1;n=(n<<8)|d->p[2+i];}
        if(n<128)return -1;header+=k;}
    if(n>d->n-header)return -1;
    if(out){out->p=start+header;out->n=n;}
    if(whole)*whole=span(start,header+n);
    d->p+=header+n;d->n-=header+n;return 0;
}
static int oid(nav_span s,const uint8_t *p,size_t n){return s.n==n&&nav_ct_equal(s.p,p,n);}
#define OID(s,...) oid((s),(const uint8_t[]){__VA_ARGS__},sizeof((const uint8_t[]){__VA_ARGS__}))
static int integer(der *d,nav_span *value){der x;
    if(take(d,2,&x,0)||!x.n||(x.p[0]&128)||(x.n>1&&x.p[0]==0&&!(x.p[1]&128)))return -1;
    if(x.n>1&&x.p[0]==0){x.p++;x.n--;}
    *value=span(x.p,x.n);return 0;
}
static int number(der *d,uint32_t *out){nav_span s;size_t i;uint32_t v=0;
    if(integer(d,&s)||s.n>4)return -1;
    for(i=0;i<s.n;i++)v=(v<<8)|s.p[i];*out=v;return 0;
}
static int null_or_absent(der d){der n;
    return !d.n?0:(take(&d,5,&n,0)||n.n||d.n?-1:0);
}
static int sha_algorithm(der d){der a,o;
    if(take(&d,0x30,&a,0)||d.n||take(&a,6,&o,0)||
       !OID(span(o.p,o.n),0x60,0x86,0x48,0x01,0x65,0x03,0x04,0x02,0x01)||null_or_absent(a))return -1;
    return 0;
}
static int signature_algorithm(der d){der a,o,p,x,mgf,mgfo;uint32_t salt;
    if(take(&d,0x30,&a,0)||d.n||take(&a,6,&o,0))return -1;
    if(OID(span(o.p,o.n),0x2a,0x86,0x48,0x86,0xf7,0x0d,0x01,0x01,0x0b))
        return null_or_absent(a)?-1:NAV_RSA_PKCS1_SHA256;
    if(!OID(span(o.p,o.n),0x2a,0x86,0x48,0x86,0xf7,0x0d,0x01,0x01,0x0a))return -1;
    /* PSS parameters must explicitly select SHA256, MGF1-SHA256, salt32.
     * SHA1 defaults and other parameter profiles are deliberately unsupported. */
    if(take(&a,0x30,&p,0)||a.n||take(&p,0xa0,&x,0)||sha_algorithm(x)||
       take(&p,0xa1,&x,0)||take(&x,0x30,&mgf,0)||x.n||take(&mgf,6,&mgfo,0)||
       !OID(span(mgfo.p,mgfo.n),0x2a,0x86,0x48,0x86,0xf7,0x0d,0x01,0x01,0x08)||sha_algorithm(mgf)||
       take(&p,0xa2,&x,0)||number(&x,&salt)||x.n||salt!=32)return -1;
    /* trailerField DEFAULT 1 must be omitted in DER. */
    return p.n?-1:NAV_RSA_PSS_SHA256;
}
static int public_key(der spki,nav_rsa_public *key){der alg,o,bits,rsa;nav_span m,e;uint32_t exponent=0;size_t i;
    if(take(&spki,0x30,&alg,0)||take(&alg,6,&o,0)||
       !OID(span(o.p,o.n),0x2a,0x86,0x48,0x86,0xf7,0x0d,0x01,0x01,0x01)||null_or_absent(alg)||
       take(&spki,3,&bits,0)||spki.n||bits.n<1||bits.p[0]!=0)return -1;
    bits.p++;bits.n--;
    if(take(&bits,0x30,&rsa,0)||bits.n||integer(&rsa,&m)||integer(&rsa,&e)||rsa.n||
       m.n<256||m.n>512||!(m.p[m.n-1]&1)||!m.p[0]||e.n>4)return -1;
    if(m.n==256&&!(m.p[0]&128))return -1;
    for(i=0;i<e.n;i++)exponent=(exponent<<8)|e.p[i];
    if(exponent<3||!(exponent&1))return -1;
    key->modulus=m;key->exponent=exponent;return 0;
}
static int leap(unsigned y){return !(y%4)&&(y%100||!(y%400));}
static int decimal(const uint8_t *p,size_t n,unsigned *v){size_t i;unsigned x=0;
    for(i=0;i<n;i++){if(p[i]<'0'||p[i]>'9')return -1;x=x*10+p[i]-'0';}*v=x;return 0;
}
static int date(der *d,uint64_t *seconds){
    static const unsigned months[12]={31,28,31,30,31,30,31,31,30,31,30,31};
    der x;unsigned y,m,day,h,min,sec,t;size_t off;uint64_t days=0;
    if(!d->n)return -1;
    if(d->p[0]==0x17){if(take(d,0x17,&x,0)||x.n!=13||decimal(x.p,2,&y))return -1;
        y+=y>=50?1900:2000;off=2;
    }else{if(take(d,0x18,&x,0)||x.n!=15||decimal(x.p,4,&y))return -1;off=4;}
    if(x.p[x.n-1]!='Z'||y<1970||y>9999||decimal(x.p+off,2,&m)||
       decimal(x.p+off+2,2,&day)||decimal(x.p+off+4,2,&h)||
       decimal(x.p+off+6,2,&min)||decimal(x.p+off+8,2,&sec)||
       m<1||m>12||day<1||day>months[m-1]+(m==2&&leap(y))||h>23||min>59||sec>59)return -1;
    for(t=1970;t<y;t++)days+=365+leap(t);
    for(t=1;t<m;t++)days+=months[t-1]+(t==2&&leap(y));
    days+=day-1;*seconds=days*86400u+h*3600u+min*60u+sec;return 0;
}
static int bool_value(der *d,int *value){der x;
    if(take(d,1,&x,0)||x.n!=1||(x.p[0]!=0&&x.p[0]!=255))return -1;
    *value=x.p[0]!=0;return 0;
}
static int extensions(der outer,cert *c){
    der all,e,o,value,inner,bits;nav_span seen[32],id;size_t count=0,i;int critical,flag;uint32_t path;
    if(take(&outer,0x30,&all,0)||outer.n||!all.n)return NAV_X509_DER;
    while(all.n){
        if(count==32)return NAV_X509_LIMIT;
        if(take(&all,0x30,&e,0)||take(&e,6,&o,0)||!o.n)return NAV_X509_DER;
        id=span(o.p,o.n);for(i=0;i<count;i++)if(same(seen[i],id))return NAV_X509_DER;
        seen[count++]=id;critical=0;
        if(e.n&&e.p[0]==1){if(bool_value(&e,&critical)||!critical)return NAV_X509_DER;}
        if(take(&e,4,&value,0)||e.n)return NAV_X509_DER;
        if(OID(id,0x55,0x1d,0x13)){
            c->has_basic=1;
            if(take(&value,0x30,&inner,0)||value.n)return NAV_X509_DER;
            if(inner.n&&inner.p[0]==1){if(bool_value(&inner,&flag)||!flag)return NAV_X509_DER;c->ca=flag;}
            if(inner.n){if(number(&inner,&path)||path>16||!c->ca)return NAV_X509_DER;c->path_length=(int)path;}
            if(inner.n|| (c->ca&&!critical))return NAV_X509_DER;
        }else if(OID(id,0x55,0x1d,0x0f)){
            c->has_usage=1;
            if(take(&value,3,&bits,0)||value.n||bits.n<2||bits.n>3||bits.p[0]>7||
               (bits.p[bits.n-1]&((1u<<bits.p[0])-1u)))return NAV_X509_DER;
            c->sign=(bits.p[1]&0x80)!=0;c->cert_sign=(bits.p[1]&4)!=0;
        }else if(OID(id,0x55,0x1d,0x25)){
            c->eku=0;if(take(&value,0x30,&inner,0)||value.n||!inner.n)return NAV_X509_DER;
            while(inner.n){if(take(&inner,6,&o,0))return NAV_X509_DER;
                if(OID(span(o.p,o.n),0x2b,6,1,5,5,7,3,1)||OID(span(o.p,o.n),0x55,0x1d,0x25,0))c->eku=1;}
        }else if(OID(id,0x55,0x1d,0x11)){
            if(take(&value,0x30,&inner,0)||value.n||!inner.n)return NAV_X509_DER;c->san=span(inner.p,inner.n);
        }else if(OID(id,0x55,0x1d,0x1e)||OID(id,0x55,0x1d,0x24)||
                 OID(id,0x55,0x1d,0x36)||OID(id,0x55,0x1d,0x21)||
                 OID(id,0x2b,6,1,5,5,7,1,24)){
            return NAV_X509_UNSUPPORTED; /* Constraints / must-staple need a separate profile. */
        }else if(critical)return NAV_X509_UNSUPPORTED;
    }
    return 0;
}
static int parse(nav_span input,cert *c){
    der d,body,tbs,v,serial,alg,issuer,validity,subject,spki,sig,ext;nav_span inner_alg,outer_alg;uint32_t version;
    int rc;
    nav_secure_zero(c,sizeof(*c));c->path_length=-1;c->eku=1;
    if(!input.p||input.n>32768)return NAV_X509_LIMIT;
    d.p=input.p;d.n=input.n;
    if(take(&d,0x30,&body,0)||d.n||take(&body,0x30,&tbs,&c->tbs)||
       take(&body,0x30,&alg,&outer_alg)||take(&body,3,&sig,0)||body.n||sig.n<2||sig.p[0])return NAV_X509_DER;
    d.p=outer_alg.p;d.n=outer_alg.n;c->signature_type=signature_algorithm(d);
    if(c->signature_type<0)return NAV_X509_UNSUPPORTED;
    c->signature=span(sig.p+1,sig.n-1);
    if(take(&tbs,0xa0,&v,0)||number(&v,&version)||v.n||version!=2||
       take(&tbs,2,&serial,0)||!serial.n||serial.n>20||(serial.p[0]&128)||
       (serial.n>1&&serial.p[0]==0&&!(serial.p[1]&128))||
       take(&tbs,0x30,&alg,&inner_alg)||!same(inner_alg,outer_alg)||
       take(&tbs,0x30,&issuer,&c->issuer)||take(&tbs,0x30,&validity,0)||
       date(&validity,&c->not_before)||date(&validity,&c->not_after)||validity.n||c->not_before>c->not_after||
       take(&tbs,0x30,&subject,&c->subject)||take(&tbs,0x30,&spki,0))return NAV_X509_DER;
    if(public_key(spki,&c->key))return NAV_X509_UNSUPPORTED;
    /* Unique IDs are outside this v3 profile. */
    if(tbs.n){if(take(&tbs,0xa3,&ext,0)||tbs.n)return NAV_X509_DER;
        rc=extensions(ext,c);if(rc)return rc;}
    return 0;
}
static int ascii_equal(const uint8_t *a,const uint8_t *b,size_t n){size_t i;
    for(i=0;i<n;i++){unsigned x=a[i],y=b[i];if(x>='A'&&x<='Z')x+=32;if(y>='A'&&y<='Z')y+=32;if(x!=y)return 0;}return 1;
}
static int dns(const uint8_t *s,size_t n,int wildcard){
    size_t i,start=0,labels=0;if(!s||!n||n>253)return 0;
    for(i=0;i<=n;i++)if(i==n||s[i]=='.'){
        size_t len=i-start,j;if(!len||len>63)return 0;
        if(wildcard&&start==0&&len==1&&s[0]=='*'){}
        else{
            if(s[start]=='-'||s[i-1]=='-')return 0;
            for(j=start;j<i;j++)if(!((s[j]>='A'&&s[j]<='Z')||(s[j]>='a'&&s[j]<='z')||
                (s[j]>='0'&&s[j]<='9')||s[j]=='-'))return 0;
        }
        start=i+1;labels++;
    }
    return !(s[0]=='*'&&labels<3);
}
static int ip4(const uint8_t *s,size_t n,uint8_t out[4]){
    size_t p=0,start;unsigned i,v;
    for(i=0;i<4;i++){
        start=p;v=0;while(p<n&&s[p]>='0'&&s[p]<='9'){v=v*10+s[p++]-'0';if(v>255||p-start>3)return 0;}
        if(p==start||(p-start>1&&s[start]=='0'))return 0;out[i]=(uint8_t)v;
        if(i<3){if(p==n||s[p++]!='.')return 0;}else if(p!=n)return 0;
    }return 1;
}
static size_t host_length(const char *s){size_t n=0;if(!s)return 0;while(n<255&&s[n])n++;
    if(n&&s[n-1]=='.')n--;return n;
}
int nav_x509_hostname_valid(const char *s){size_t n=host_length(s);return dns((const uint8_t *)s,n,0);}
static int name_matches(nav_span san,const char *host){
    der d,x;size_t n=host_length(host),i;uint8_t address[4];int is_ip,matched=0;
    if(!dns((const uint8_t *)host,n,0))return 0;
    is_ip=ip4((const uint8_t *)host,n,address);d.p=san.p;d.n=san.n;
    while(d.n){unsigned tag=d.p[0];
        if(take(&d,tag,&x,0))return 0;
        if(tag==0x82){
            if(!dns(x.p,x.n,1))return 0;
            if(is_ip)continue;
            if(x.n==n&&ascii_equal(x.p,(const uint8_t *)host,n))matched=1;
            if(x.n>2&&x.p[0]=='*'&&x.p[1]=='.'){
                for(i=0;i<n&&host[i]!='.';i++){}
                if(i<n&&n-i==x.n-1&&ascii_equal(x.p+1,(const uint8_t *)host+i,x.n-1))matched=1;
            }
        }else if(tag==0x87){if(x.n!=4&&x.n!=16)return 0;if(is_ip&&x.n==4&&nav_ct_equal(x.p,address,4))matched=1;}
        else if((tag&0xc0)!=0x80)return 0;
    }
    return matched;
}
static int verify_signature(const cert *c,const nav_rsa_public *issuer){uint8_t hash[32];int rc;
    nav_sha256_hash(c->tbs.p,c->tbs.n,hash);rc=nav_rsa_verify_sha256(issuer,c->signature_type,hash,c->signature);
    nav_secure_zero(hash,sizeof(hash));return rc?NAV_X509_SIGNATURE:0;
}
int nav_x509_verify(const nav_span *chain,size_t count,const nav_trust_anchor *anchors,size_t anchor_count,
                    const char *hostname,uint64_t now,nav_rsa_public *leaf_key){
    cert current,next;nav_rsa_public leaf;size_t i,j;int rc,trusted;
    if(leaf_key)nav_secure_zero(leaf_key,sizeof(*leaf_key));
    if(!now||now>253402300799ULL)return NAV_X509_TIME;
    if(!chain||!count||count>NAV_X509_MAX_CHAIN||!anchors||!anchor_count||anchor_count>256||!leaf_key)return NAV_X509_LIMIT;
    rc=parse(chain[0],&current);if(rc)return rc;leaf=current.key;
    if(current.ca||(current.has_usage&&!current.sign)||!current.eku)return NAV_X509_USAGE;
    if(!name_matches(current.san,hostname))return NAV_X509_NAME;
    for(i=0;i<count;i++){
        if(now<current.not_before||now>current.not_after)return NAV_X509_TIME;
        if(!current.eku)return NAV_X509_USAGE;
        if(i&&(!current.has_basic||!current.ca||!current.has_usage||!current.cert_sign||
           (current.path_length>=0&&i-1>(size_t)current.path_length)))return NAV_X509_USAGE;
        if(i+1<count){
            if(same(current.subject,current.issuer)&&i)return NAV_X509_USAGE;
            rc=parse(chain[i+1],&next);if(rc)return rc;
            if(!same(current.issuer,next.subject))return NAV_X509_TRUST;
            rc=verify_signature(&current,&next.key);if(rc)return rc;current=next;
        }else{
            trusted=0;
            for(j=0;j<anchor_count;j++){
                const nav_trust_anchor *a=anchors+j;
                /* A transmitted root is trusted only by its preconfigured DN AND key. */
                if(i&&same(current.subject,a->subject)&&same(current.key.modulus,a->key.modulus)&&current.key.exponent==a->key.exponent){trusted=1;break;}
                if(same(current.issuer,a->subject)&&!verify_signature(&current,&a->key)){trusted=1;break;}
            }
            if(!trusted)return NAV_X509_TRUST;
        }
    }
    *leaf_key=leaf;return 0;
}
const char *nav_x509_error_string(int error){switch(error){
    case NAV_X509_OK:return "certificate verified";case NAV_X509_DER:return "invalid certificate DER";
    case NAV_X509_UNSUPPORTED:return "unsupported certificate algorithm or constraint";
    case NAV_X509_TIME:return "certificate validity or UTC clock failure";case NAV_X509_NAME:return "certificate SAN hostname mismatch";
    case NAV_X509_USAGE:return "certificate key usage / CA / path length failure";case NAV_X509_TRUST:return "certificate chain is not trusted";
    case NAV_X509_SIGNATURE:return "invalid certificate signature";default:return "certificate size / chain limit";
}}
