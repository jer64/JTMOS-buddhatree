#ifndef NAV_TLS_CLIENT_H
#define NAV_TLS_CLIENT_H
#include "nav_tls13.h"
#include "nav_x509.h"

#define NAV_TLS_HANDSHAKE_CAPACITY 131072u
typedef struct nav_tls_io {
    void *context;
    /* Blocking with a caller-enforced operation deadline; partial I/O allowed.
     * read: positive bytes, zero TCP EOF, negative error. write: positive/error.
     * random: 0 success from a seeded system CSPRNG; no deterministic fallback.
     */
    int (*read)(void *,uint8_t *,size_t);
    int (*write)(void *,const uint8_t *,size_t);
    int (*random)(void *,uint8_t *,size_t);
    int (*cancelled)(void *);
} nav_tls_io;
typedef struct nav_tls_config {
    nav_tls_io io;
    const nav_trust_anchor *anchors;
    size_t anchor_count;
    const char *hostname;
    uint64_t utc_seconds;
} nav_tls_config;
enum nav_tls_state { NAV_TLS_EMPTY, NAV_TLS_HANDSHAKING, NAV_TLS_READY, NAV_TLS_CLOSED, NAV_TLS_FAILED };
enum nav_tls_error {
    NAV_TLS_OK=0,NAV_TLS_ARGUMENT=-1,NAV_TLS_IO=-2,NAV_TLS_ENTROPY=-3,
    NAV_TLS_PROTOCOL=-4,NAV_TLS_AUTH=-5,NAV_TLS_CERTIFICATE=-6,
    NAV_TLS_UNSUPPORTED=-7,NAV_TLS_LIMIT=-8,NAV_TLS_CANCELLED=-9
};
/* Caller-owned context. Place on a heap/arena, not a small kernel/task stack.
 * Single owner, no concurrent calls, no global state and no dynamic allocation.
 * Initialization consumes config pointers; anchors must outlive the connection.
 */
typedef struct nav_tls_client {
    nav_tls_io io;
    const nav_trust_anchor *anchors;
    size_t anchor_count;
    uint64_t utc;
    char hostname[254];
    enum nav_tls_state state;
    int error,certificate_error,truncated,peer_alert;
    unsigned phase,retried,ccs_count,record_count;
    uint8_t private_key[32],client_random[32],session_id[32],master[32];
    uint8_t leaf_modulus[NAV_RSA_MAX_BYTES];
    size_t leaf_size;
    uint32_t leaf_exponent;
    nav_sha256 transcript;
    nav_tls13_keys rx,tx;
    uint8_t wire[NAV_TLS13_MAX_WIRE];
    uint8_t plain[NAV_TLS13_MAX_CONTENT+256];
    uint8_t handshake[NAV_TLS_HANDSHAKE_CAPACITY];
    size_t handshake_used,plain_offset,plain_size;
} nav_tls_client;

int nav_tls_client_init(nav_tls_client *,const nav_tls_config *);
int nav_tls_client_handshake(nav_tls_client *); /* 0 only after peer verification AND client Finished */
int nav_tls_client_read(nav_tls_client *,void *,size_t); /* bytes / 0 EOF / negative error */
int nav_tls_client_write(nav_tls_client *,const void *,size_t); /* at most 16KiB per call */
void nav_tls_client_close(nav_tls_client *); /* sends close_notify; does not close caller TCP */
void nav_tls_client_wipe(nav_tls_client *);
const char *nav_tls_client_error(const nav_tls_client *);
#endif
