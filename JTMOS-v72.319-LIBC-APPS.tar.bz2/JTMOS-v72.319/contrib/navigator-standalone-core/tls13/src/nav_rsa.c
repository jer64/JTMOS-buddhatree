#include "nav_x509.h"

/* Public-key verification only. Fixed-size, little-endian 32-bit limbs.
 * Montgomery reduction avoids division and compiler big-integer libraries.
 * Exponents and all branches here depend only on public inputs.
 */
#define LIMBS (NAV_RSA_MAX_BYTES / 4u)
static int cmp(const uint32_t *a,const uint32_t *b,size_t n){
    while(n){--n;if(a[n]!=b[n])return a[n]>b[n]?1:-1;}return 0;
}
static void sub(uint32_t *a,const uint32_t *b,size_t n){
    size_t i;uint64_t borrow=0;
    for(i=0;i<n;i++){uint64_t v=(uint64_t)b[i]+borrow;
        uint32_t old=a[i];a[i]=(uint32_t)((uint64_t)old-v);borrow=(uint64_t)old<v;}
}
static void twice(uint32_t *a,const uint32_t *mod,size_t n){
    size_t i;uint32_t carry=0;
    for(i=0;i<n;i++){uint32_t next=a[i]>>31;a[i]=(a[i]<<1)|carry;carry=next;}
    if(carry||cmp(a,mod,n)>=0)sub(a,mod,n);
}
static void mont(uint32_t *out,const uint32_t *a,const uint32_t *b,
                 const uint32_t *mod,size_t n,uint32_t inverse){
    uint32_t t[2*LIMBS+2];size_t i,j,k;uint64_t v,carry;
    nav_secure_zero(t,sizeof(t));
    for(i=0;i<n;i++){
        carry=0;
        for(j=0;j<n;j++){v=(uint64_t)a[i]*b[j]+t[i+j]+carry;
            t[i+j]=(uint32_t)v;carry=v>>32;}
        k=i+n;
        while(carry){v=(uint64_t)t[k]+carry;t[k++]=(uint32_t)v;carry=v>>32;}
    }
    for(i=0;i<n;i++){
        uint32_t q=t[i]*inverse;carry=0;
        for(j=0;j<n;j++){v=(uint64_t)q*mod[j]+t[i+j]+carry;
            t[i+j]=(uint32_t)v;carry=v>>32;}
        k=i+n;
        while(carry){v=(uint64_t)t[k]+carry;t[k++]=(uint32_t)v;carry=v>>32;}
    }
    for(i=0;i<n;i++)out[i]=t[n+i];
    if(t[2*n]||cmp(out,mod,n)>=0)sub(out,mod,n);
    nav_secure_zero(t,sizeof(t));
}
static int public_op(const nav_rsa_public *key,nav_span sig,uint8_t em[512],unsigned *bits){
    uint32_t mod[LIMBS],a[LIMBS],r2[LIMBS],r[LIMBS],one[LIMBS];
    size_t n,i;uint32_t inverse;unsigned b,top;int rc=-1;
    if(!key||!key->modulus.p||!sig.p||key->modulus.n<256||key->modulus.n>512||
       sig.n!=key->modulus.n||!key->modulus.p[0]||!(key->modulus.p[key->modulus.n-1]&1)||
       key->exponent<3||!(key->exponent&1))return -1;
    top=key->modulus.p[0];b=0;while(top){++b;top>>=1;}
    *bits=(unsigned)(8*(key->modulus.n-1))+b;if(*bits<2048)return -1;
    n=(key->modulus.n+3)/4;
    nav_secure_zero(mod,sizeof(mod));nav_secure_zero(a,sizeof(a));
    nav_secure_zero(r2,sizeof(r2));nav_secure_zero(one,sizeof(one));
    for(i=0;i<key->modulus.n;i++){
        size_t from=key->modulus.n-1-i;
        mod[i/4]|=(uint32_t)key->modulus.p[from]<<(8*(i%4));
        a[i/4]|=(uint32_t)sig.p[from]<<(8*(i%4));
    }
    if(cmp(a,mod,n)>=0)goto done;
    inverse=1;for(i=0;i<5;i++)inverse*=2u-mod[0]*inverse;inverse=0u-inverse;
    one[0]=r2[0]=1;
    for(i=0;i<64*n;i++)twice(r2,mod,n);
    mont(a,a,r2,mod,n,inverse);mont(r,one,r2,mod,n,inverse);
    for(b=32;b>0;b--){mont(r,r,r,mod,n,inverse);
        if((key->exponent>>(b-1))&1)mont(r,r,a,mod,n,inverse);}
    mont(r,r,one,mod,n,inverse);
    for(i=0;i<key->modulus.n;i++)em[key->modulus.n-1-i]=(uint8_t)(r[i/4]>>(8*(i%4)));
    rc=0;
done:
    nav_secure_zero(mod,sizeof(mod));nav_secure_zero(a,sizeof(a));
    nav_secure_zero(r2,sizeof(r2));nav_secure_zero(r,sizeof(r));nav_secure_zero(one,sizeof(one));
    return rc;
}
static int pkcs1(const uint8_t *em,size_t n,const uint8_t hash[32]){
    static const uint8_t prefix[]={0x30,0x31,0x30,0x0d,0x06,0x09,0x60,0x86,0x48,
        0x01,0x65,0x03,0x04,0x02,0x01,0x05,0x00,0x04,0x20};
    size_t i,separator=n-32-sizeof(prefix)-1;
    if(n<62||separator<10||em[0]!=0||em[1]!=1||em[separator]!=0)return -1;
    for(i=2;i<separator;i++)if(em[i]!=255)return -1;
    return nav_ct_equal(em+separator+1,prefix,sizeof(prefix))&&nav_ct_equal(em+n-32,hash,32)?0:-1;
}
static int pss(uint8_t *em,size_t n,unsigned bits,const uint8_t hash[32]){
    uint8_t db[512],mask[32],counter[4],digest[32],zeros[8]={0};nav_sha256 s;
    size_t emlen=(bits-1+7)/8,dbn,i,j,take;unsigned unused;int rc=-1;
    if(emlen<66||emlen>n)return -1;
    for(i=0;i<n-emlen;i++)if(em[i])return -1;
    em+=n-emlen;unused=(unsigned)(8*emlen-(bits-1));dbn=emlen-33;
    if(em[emlen-1]!=0xbc||(em[0]&(uint8_t)(255u<<(8-unused))))return -1;
    for(i=0;i<dbn;i+=32){
        uint32_t k=(uint32_t)(i/32);
        counter[0]=(uint8_t)(k>>24);counter[1]=(uint8_t)(k>>16);
        counter[2]=(uint8_t)(k>>8);counter[3]=(uint8_t)k;
        nav_sha256_init(&s);nav_sha256_update(&s,em+dbn,32);
        nav_sha256_update(&s,counter,4);nav_sha256_final(&s,mask);
        take=dbn-i;if(take>32)take=32;
        for(j=0;j<take;j++)db[i+j]=em[i+j]^mask[j];
    }
    db[0]&=(uint8_t)(255u>>unused);
    for(i=0;i<dbn-33;i++)if(db[i])goto done;
    if(db[dbn-33]!=1)goto done;
    nav_sha256_init(&s);nav_sha256_update(&s,zeros,8);nav_sha256_update(&s,hash,32);
    nav_sha256_update(&s,db+dbn-32,32);nav_sha256_final(&s,digest);
    if(nav_ct_equal(digest,em+dbn,32))rc=0;
done:
    nav_secure_zero(db,sizeof(db));nav_secure_zero(mask,sizeof(mask));nav_secure_zero(digest,sizeof(digest));return rc;
}
int nav_rsa_verify_sha256(const nav_rsa_public *key,int padding,const uint8_t hash[32],nav_span signature){
    uint8_t em[512];unsigned bits=0;int rc;
    if(!hash||(padding!=NAV_RSA_PKCS1_SHA256&&padding!=NAV_RSA_PSS_SHA256))return -1;
    rc=public_op(key,signature,em,&bits);
    if(!rc)rc=padding==NAV_RSA_PKCS1_SHA256?pkcs1(em,key->modulus.n,hash):pss(em,key->modulus.n,bits,hash);
    nav_secure_zero(em,sizeof(em));return rc;
}
