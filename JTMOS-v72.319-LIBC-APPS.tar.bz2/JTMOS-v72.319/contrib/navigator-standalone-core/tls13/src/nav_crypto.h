#ifndef NAV_CRYPTO_H
#define NAV_CRYPTO_H
/* Navigator TLS 1.3 crypto foundations. C99 freestanding; no libc calls.
 * Experimental implementation; review before deployment for browser security.
 */
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
#define NAV_SHA256_LEN 32u
#define NAV_AES128_KEY_LEN 16u
#define NAV_GCM_NONCE_LEN 12u
#define NAV_GCM_TAG_LEN 16u

typedef struct nav_sha256 {
    uint32_t h[8];
    uint64_t bytes;
    uint8_t buffer[64];
    size_t used;
} nav_sha256;
void nav_sha256_init(nav_sha256 *s);
void nav_sha256_update(nav_sha256 *s, const uint8_t *data, size_t len);
void nav_sha256_final(nav_sha256 *s, uint8_t hash[32]);
void nav_sha256_hash(const uint8_t *data, size_t len, uint8_t hash[32]);
void nav_secure_zero(void *buf, size_t len);
int nav_ct_equal(const uint8_t *a, const uint8_t *b, size_t len);
void nav_hmac_sha256(const uint8_t *key, size_t key_len, const uint8_t *data,
                     size_t data_len, uint8_t mac[32]);
void nav_hkdf_extract(const uint8_t *salt, size_t salt_len, const uint8_t *ikm,
                      size_t ikm_len, uint8_t prk[32]);
/* HKDF expansion limited to 255 hash blocks; 0 success, -1 invalid inputs. */
int nav_hkdf_expand(const uint8_t prk[32], const uint8_t *info, size_t info_len,
                    uint8_t *out, size_t out_len);
/* X25519 as specified by RFC 7748; out=0 shared secret -> -1, else 0. */
int nav_x25519(uint8_t out[32], const uint8_t scalar[32], const uint8_t point[32]);
void nav_x25519_public(uint8_t out[32], const uint8_t secret[32]);
/* AES-128-GCM. Data in & out may be identical; other overlap unsupported.
 * No plaintext is released on auth failure. Return 0 success, -1 failure.
 */
int nav_aes128_gcm_encrypt(const uint8_t key[16], const uint8_t nonce[12],
                           const uint8_t *aad, size_t aad_len,
                           const uint8_t *plain, size_t len,
                           uint8_t *cipher, uint8_t tag[16]);
int nav_aes128_gcm_decrypt(const uint8_t key[16], const uint8_t nonce[12],
                           const uint8_t *aad, size_t aad_len,
                           const uint8_t *cipher, size_t len,
                           const uint8_t tag[16], uint8_t *plain);
#ifdef __cplusplus
}
#endif
#endif
