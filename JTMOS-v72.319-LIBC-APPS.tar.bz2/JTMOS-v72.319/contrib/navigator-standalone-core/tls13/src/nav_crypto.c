#include "nav_crypto.h"

void nav_secure_zero(void *p, size_t len) {
    volatile uint8_t *b = (volatile uint8_t *)p;
    while (len--) *b++ = 0;
}
int nav_ct_equal(const uint8_t *a, const uint8_t *b, size_t len) {
    size_t i; uint32_t difference = 0;
    for (i = 0; i < len; i++) difference |= (uint32_t)(a[i] ^ b[i]);
    return difference == 0;
}
static void copy(uint8_t *d, const uint8_t *s, size_t n) {
    size_t i; for (i = 0; i < n; ++i) d[i] = s[i];
}
static void zero(uint8_t *d, size_t n) {
    size_t i; for (i = 0; i < n; ++i) d[i] = 0;
}
static uint32_t rr(uint32_t x, unsigned n) { return (x >> n) | (x << (32 - n)); }
static uint32_t rd32(const uint8_t *p) {
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | (uint32_t)p[3];
}
static void wr32(uint8_t *p, uint32_t x) {
    p[0] = (uint8_t)(x >> 24); p[1] = (uint8_t)(x >> 16);
    p[2] = (uint8_t)(x >> 8); p[3] = (uint8_t)x;
}
static void wr64(uint8_t *p, uint64_t x) {
    unsigned i; for (i = 0; i < 8; ++i) p[i] = (uint8_t)(x >> (56 - 8 * i));
}
static const uint32_t k256[64] = {
    0x428a2f98u,0x71374491u,0xb5c0fbcfu,0xe9b5dba5u,0x3956c25bu,0x59f111f1u,0x923f82a4u,0xab1c5ed5u,
    0xd807aa98u,0x12835b01u,0x243185beu,0x550c7dc3u,0x72be5d74u,0x80deb1feu,0x9bdc06a7u,0xc19bf174u,
    0xe49b69c1u,0xefbe4786u,0x0fc19dc6u,0x240ca1ccu,0x2de92c6fu,0x4a7484aau,0x5cb0a9dcu,0x76f988dau,
    0x983e5152u,0xa831c66du,0xb00327c8u,0xbf597fc7u,0xc6e00bf3u,0xd5a79147u,0x06ca6351u,0x14292967u,
    0x27b70a85u,0x2e1b2138u,0x4d2c6dfcu,0x53380d13u,0x650a7354u,0x766a0abbu,0x81c2c92eu,0x92722c85u,
    0xa2bfe8a1u,0xa81a664bu,0xc24b8b70u,0xc76c51a3u,0xd192e819u,0xd6990624u,0xf40e3585u,0x106aa070u,
    0x19a4c116u,0x1e376c08u,0x2748774cu,0x34b0bcb5u,0x391c0cb3u,0x4ed8aa4au,0x5b9cca4fu,0x682e6ff3u,
    0x748f82eeu,0x78a5636fu,0x84c87814u,0x8cc70208u,0x90befffau,0xa4506cebu,0xbef9a3f7u,0xc67178f2u
};
static void transform(nav_sha256 *s, const uint8_t blk[64]) {
    uint32_t w[64], a,b,c,d,e,f,g,h,t1,t2;
    unsigned i;
    for (i = 0; i < 16; ++i) w[i] = rd32(blk + 4*i);
    for (i = 16; i < 64; ++i) {
        uint32_t x = w[i-15], y = w[i-2];
        w[i] = w[i-16] + (rr(x,7) ^ rr(x,18) ^ (x >> 3)) + w[i-7] + (rr(y,17) ^ rr(y,19) ^ (y >> 10));
    }
    a=s->h[0]; b=s->h[1]; c=s->h[2]; d=s->h[3];
    e=s->h[4]; f=s->h[5]; g=s->h[6]; h=s->h[7];
    for (i=0;i<64;++i) {
        t1=h+(rr(e,6)^rr(e,11)^rr(e,25))+((e&f)^(~e&g))+k256[i]+w[i];
        t2=(rr(a,2)^rr(a,13)^rr(a,22))+((a&b)^(a&c)^(b&c));
        h=g;g=f;f=e;e=d+t1;d=c;c=b;b=a;a=t1+t2;
    }
    s->h[0]+=a;s->h[1]+=b;s->h[2]+=c;s->h[3]+=d;
    s->h[4]+=e;s->h[5]+=f;s->h[6]+=g;s->h[7]+=h;
    nav_secure_zero(w,sizeof(w));
}
void nav_sha256_init(nav_sha256 *s) {
    static const uint32_t init[8]={0x6a09e667u,0xbb67ae85u,0x3c6ef372u,0xa54ff53au,
                                    0x510e527fu,0x9b05688cu,0x1f83d9abu,0x5be0cd19u};
    unsigned i;
    for (i=0;i<8;++i)s->h[i]=init[i];
    s->used=0; s->bytes=0;
}
void nav_sha256_update(nav_sha256 *s, const uint8_t *data, size_t len) {
    size_t i;
    /* RFC SHA-256 maximum length is 2^64-1 bits; callers must not exceed it. */
    for (i=0;i<len;++i) {
        s->buffer[s->used++]=data[i];
        if (s->used==64) { transform(s,s->buffer);s->used=0; }
    }
    s->bytes+=(uint64_t)len;
}
void nav_sha256_final(nav_sha256 *s, uint8_t hash[32]) {
    uint64_t bits=s->bytes*8;
    unsigned i;
    s->buffer[s->used++]=0x80;
    if(s->used>56) {
        while(s->used<64) s->buffer[s->used++]=0;
        transform(s,s->buffer);s->used=0;
    }
    while(s->used<56) s->buffer[s->used++]=0;
    wr64(s->buffer+56,bits);transform(s,s->buffer);
    for(i=0;i<8;++i)wr32(hash+4*i,s->h[i]);
    nav_secure_zero(s,sizeof(*s));
}
void nav_sha256_hash(const uint8_t *data,size_t n,uint8_t hash[32]) {
    nav_sha256 s;nav_sha256_init(&s);nav_sha256_update(&s,data,n);nav_sha256_final(&s,hash);
}
typedef struct hmac_ctx { nav_sha256 inner; uint8_t opad[64]; } hmac_ctx;
static void hmac_init(hmac_ctx *h,const uint8_t *key,size_t n) {
    uint8_t kb[64]; size_t i;
    zero(kb,64);
    if(n>64) nav_sha256_hash(key,n,kb);
    else if(n)copy(kb,key,n);
    for(i=0;i<64;++i){h->opad[i]=(uint8_t)(kb[i]^0x5cu);kb[i]^=0x36u;}
    nav_sha256_init(&h->inner);nav_sha256_update(&h->inner,kb,64);
    nav_secure_zero(kb,sizeof(kb));
}
static void hmac_final(hmac_ctx *h,uint8_t out[32]) {
    nav_sha256 outer;uint8_t ih[32];
    nav_sha256_final(&h->inner,ih);
    nav_sha256_init(&outer);nav_sha256_update(&outer,h->opad,64);
    nav_sha256_update(&outer,ih,32);nav_sha256_final(&outer,out);
    nav_secure_zero(ih,sizeof(ih));nav_secure_zero(h,sizeof(*h));
}
void nav_hmac_sha256(const uint8_t *key,size_t kn,const uint8_t *data,size_t n,uint8_t out[32]) {
    hmac_ctx h;hmac_init(&h,key,kn);nav_sha256_update(&h.inner,data,n);hmac_final(&h,out);
}
void nav_hkdf_extract(const uint8_t *salt,size_t sn,const uint8_t *ikm,size_t in,uint8_t prk[32]) {
    uint8_t zeros[32];zero(zeros,32);
    nav_hmac_sha256(salt ? salt : zeros,salt ? sn : 32,ikm,in,prk);
    nav_secure_zero(zeros,sizeof(zeros));
}
int nav_hkdf_expand(const uint8_t prk[32],const uint8_t *info,size_t info_len,uint8_t *out,size_t n) {
    uint8_t t[32];size_t done=0,block=0;uint8_t ctr;hmac_ctx h;
    if(n>255u*32u || (info_len && !info) || (n && !out))return -1;
    zero(t,32);
    while(done<n) {
        size_t take=n-done;ctr=(uint8_t)(block+1);
        hmac_init(&h,prk,32);
        if(block)nav_sha256_update(&h.inner,t,32);
        nav_sha256_update(&h.inner,info,info_len);
        nav_sha256_update(&h.inner,&ctr,1);
        hmac_final(&h,t);
        if(take>32)take=32;
        copy(out+done,t,take);done+=take;++block;
    }
    nav_secure_zero(t,sizeof(t));return 0;
}

/* Portable fixed-iteration X25519 field arithmetic, radix 2^16.
 * Uses int64_t so it also compiles for 32-bit x86 with compiler rt support.
 * Review side-channel properties for each compiler target before production.
 */
typedef int64_t fe[16];
static void fe_copy(fe o,const fe a) {int i;for(i=0;i<16;++i)o[i]=a[i];}
static void fe_add(fe o,const fe a,const fe b) {int i;for(i=0;i<16;++i)o[i]=a[i]+b[i];}
static void fe_sub(fe o,const fe a,const fe b) {int i;for(i=0;i<16;++i)o[i]=a[i]-b[i];}
static void fe_carry(fe a) {
    int i;int64_t c;
    for(i=0;i<16;++i){a[i]+=65536;c=a[i]>>16;a[i]-=c*65536;
        if(i<15)a[i+1]+=c-1;else a[0]+=38*(c-1);}
}
static void fe_mul(fe o,const fe a,const fe b) {
    int i,j;int64_t t[31];
    for(i=0;i<31;++i)t[i]=0;
    for(i=0;i<16;++i)for(j=0;j<16;++j)t[i+j]+=a[i]*b[j];
    for(i=16;i<31;++i)t[i-16]+=38*t[i];
    for(i=0;i<16;++i)o[i]=t[i];
    fe_carry(o);fe_carry(o);
    nav_secure_zero(t,sizeof(t));
}
static void fe_sq(fe o,const fe a){fe_mul(o,a,a);}
static void fe_sel(fe p,fe q,int swap){int i;int64_t mask=-(int64_t)swap;
    for(i=0;i<16;++i){int64_t t=mask&(p[i]^q[i]);p[i]^=t;q[i]^=t;}}
static void fe_unpack(fe o,const uint8_t p[32]) {int i;
    for(i=0;i<16;++i)o[i]=(int64_t)p[2*i]+((int64_t)p[2*i+1]<<8);
    o[15]&=0x7fff;
}
static void fe_pack(uint8_t p[32],const fe a){fe t,m;int i,j;int64_t b;
    fe_copy(t,a);fe_carry(t);fe_carry(t);fe_carry(t);
    for(j=0;j<2;++j){
        m[0]=t[0]-0xffed;
        for(i=1;i<15;++i){m[i]=t[i]-0xffff-((m[i-1]>>16)&1);m[i-1]&=0xffff;}
        m[15]=t[15]-0x7fff-((m[14]>>16)&1);
        b=(m[15]>>16)&1;m[14]&=0xffff;fe_sel(t,m,(int)(1-b));
    }
    for(i=0;i<16;++i){p[2*i]=(uint8_t)t[i];p[2*i+1]=(uint8_t)(t[i]>>8);}
    nav_secure_zero(t,sizeof(t));nav_secure_zero(m,sizeof(m));
}
static void fe_inv(fe o,const fe a){fe c;int i;
    fe_copy(c,a);
    for(i=253;i>=0;--i){fe_sq(c,c);if(i!=2 && i!=4)fe_mul(c,c,a);}
    fe_copy(o,c);nav_secure_zero(c,sizeof(c));
}
int nav_x25519(uint8_t out[32],const uint8_t scalar[32],const uint8_t point[32]) {
    static const fe a24={121665};
    uint8_t k[32];fe x1,x2,z2,x3,z3,a,aa,b,bb,e,c,d,da,cb,t;
    int bit,swap=0,i;uint8_t any=0;
    if(!out||!scalar||!point)return -1;
    copy(k,scalar,32);k[0]&=248;k[31]&=127;k[31]|=64;
    fe_unpack(x1,point);
    for(i=0;i<16;++i){x2[i]=z2[i]=x3[i]=z3[i]=0;}
    x2[0]=1;fe_copy(x3,x1);z3[0]=1;
    for(bit=254;bit>=0;--bit){
        int kt=(k[bit>>3]>>(bit&7))&1;
        swap^=kt;fe_sel(x2,x3,swap);fe_sel(z2,z3,swap);swap=kt;
        fe_add(a,x2,z2);fe_sq(aa,a);fe_sub(b,x2,z2);fe_sq(bb,b);
        fe_sub(e,aa,bb);fe_add(c,x3,z3);fe_sub(d,x3,z3);
        fe_mul(da,d,a);fe_mul(cb,c,b);
        fe_add(t,da,cb);fe_sq(x3,t);
        fe_sub(t,da,cb);fe_sq(t,t);fe_mul(z3,t,x1);
        fe_mul(x2,aa,bb);fe_mul(t,e,a24);fe_add(t,aa,t);fe_mul(z2,e,t);
    }
    fe_sel(x2,x3,swap);fe_sel(z2,z3,swap);
    fe_inv(z2,z2);fe_mul(x2,x2,z2);fe_pack(out,x2);
    for(i=0;i<32;++i)any|=out[i];
    nav_secure_zero(k,sizeof(k));nav_secure_zero(x1,sizeof(x1));
    nav_secure_zero(x2,sizeof(x2));nav_secure_zero(z2,sizeof(z2));
    nav_secure_zero(x3,sizeof(x3));nav_secure_zero(z3,sizeof(z3));
    nav_secure_zero(a,sizeof(a));nav_secure_zero(aa,sizeof(aa));
    nav_secure_zero(b,sizeof(b));nav_secure_zero(bb,sizeof(bb));
    nav_secure_zero(e,sizeof(e));nav_secure_zero(c,sizeof(c));
    nav_secure_zero(d,sizeof(d));nav_secure_zero(da,sizeof(da));
    nav_secure_zero(cb,sizeof(cb));nav_secure_zero(t,sizeof(t));
    if(!any){nav_secure_zero(out,32);return -1;}return 0;
}
void nav_x25519_public(uint8_t out[32],const uint8_t secret[32]) {
    static const uint8_t base[32]={9};
    if(nav_x25519(out,secret,base)!=0)nav_secure_zero(out,32);
}

/* AES-128 ECB block primitive, constant-time S box via finite field inversion. */
static uint8_t gf_mul(uint8_t a,uint8_t b){uint8_t r=0;unsigned i;
    for(i=0;i<8;++i){uint8_t mask=(uint8_t)(0u-(unsigned)(b&1u));
        r^=a&mask;a=(uint8_t)((a<<1)^(0x1bu&(uint8_t)(0u-(unsigned)(a>>7))));b>>=1;}
    return r;
}
static uint8_t rot8(uint8_t a,unsigned n){return (uint8_t)((a<<n)|(a>>(8u-n)));}
static uint8_t aes_sbox(uint8_t a){uint8_t x=a,x2,x4,x8,x16,x32,x64,x128,y;
    x2=gf_mul(x,x);x4=gf_mul(x2,x2);x8=gf_mul(x4,x4);
    x16=gf_mul(x8,x8);x32=gf_mul(x16,x16);x64=gf_mul(x32,x32);
    x128=gf_mul(x64,x64);
    /* a^254 = a^2 * a^4 * ... * a^128, including a=0. */
    y=gf_mul(x2,x4);y=gf_mul(y,x8);y=gf_mul(y,x16);
    y=gf_mul(y,x32);y=gf_mul(y,x64);y=gf_mul(y,x128);
    return (uint8_t)(y^rot8(y,1)^rot8(y,2)^rot8(y,3)^rot8(y,4)^0x63u);
}
static void aes_keys(const uint8_t key[16],uint8_t rk[176]){
    unsigned pos,i;uint8_t tmp[4],rcon=1;
    copy(rk,key,16);
    for(pos=16;pos<176;pos+=4){
        for(i=0;i<4;++i)tmp[i]=rk[pos-4+i];
        if((pos%16)==0){uint8_t u=tmp[0];
            tmp[0]=(uint8_t)(aes_sbox(tmp[1])^rcon);
            tmp[1]=aes_sbox(tmp[2]);tmp[2]=aes_sbox(tmp[3]);tmp[3]=aes_sbox(u);
            rcon=gf_mul(rcon,2);
        }
        for(i=0;i<4;++i)rk[pos+i]=(uint8_t)(rk[pos-16+i]^tmp[i]);
    }
    nav_secure_zero(tmp,sizeof(tmp));
}
static void aes_block(const uint8_t rk[176],const uint8_t in[16],uint8_t out[16]){
    uint8_t s[16],z[16];unsigned round,i,j;
    for(i=0;i<16;++i)s[i]=in[i]^rk[i];
    for(round=1;round<=10;++round){
        for(i=0;i<16;++i)s[i]=aes_sbox(s[i]);
        for(i=0;i<4;++i)for(j=0;j<4;++j)z[4*i+j]=s[4*((i+j)%4)+j];
        if(round<10){
            for(i=0;i<4;++i){uint8_t a=z[4*i],b=z[4*i+1],c=z[4*i+2],d=z[4*i+3];
                s[4*i]=(uint8_t)(gf_mul(a,2)^gf_mul(b,3)^c^d);
                s[4*i+1]=(uint8_t)(a^gf_mul(b,2)^gf_mul(c,3)^d);
                s[4*i+2]=(uint8_t)(a^b^gf_mul(c,2)^gf_mul(d,3));
                s[4*i+3]=(uint8_t)(gf_mul(a,3)^b^c^gf_mul(d,2));
            }
        } else copy(s,z,16);
        for(i=0;i<16;++i)s[i]^=rk[16*round+i];
    }
    copy(out,s,16);nav_secure_zero(s,sizeof(s));nav_secure_zero(z,sizeof(z));
}
static void gh_mul(uint8_t x[16],const uint8_t h[16]){
    uint8_t z[16],v[16];unsigned i,j;zero(z,16);copy(v,h,16);
    for(i=0;i<128;++i){uint8_t bit=(uint8_t)((x[i>>3]>>(7-(i&7)))&1);
        uint8_t mask=(uint8_t)(0u-(unsigned)bit),carry=(uint8_t)(v[15]&1u);
        for(j=0;j<16;++j)z[j]^=(uint8_t)(v[j]&mask);
        for(j=15;j>0;--j)v[j]=(uint8_t)((v[j]>>1)|(v[j-1]<<7));
        v[0]=(uint8_t)((v[0]>>1)^(0xe1u&(uint8_t)(0u-(unsigned)carry)));
    }
    copy(x,z,16);nav_secure_zero(z,16);nav_secure_zero(v,16);
}
static void gh_update(uint8_t y[16],const uint8_t h[16],const uint8_t *data,size_t n){
    size_t i;
    while(n){size_t take=n<16?n:16;
        for(i=0;i<take;++i)y[i]^=data[i];
        gh_mul(y,h);data+=take;n-=take;
    }
}
static void gcm_tag(const uint8_t rk[176],const uint8_t h[16],const uint8_t nonce[12],
                    const uint8_t *aad,size_t al,const uint8_t *cipher,size_t cl,uint8_t tag[16]){
    uint8_t y[16],lens[16],j0[16],mask[16];unsigned i;
    zero(y,16);gh_update(y,h,aad,al);gh_update(y,h,cipher,cl);
    wr64(lens,(uint64_t)al*8);wr64(lens+8,(uint64_t)cl*8);
    for(i=0;i<16;++i)y[i]^=lens[i];
    gh_mul(y,h);
    copy(j0,nonce,12);j0[12]=j0[13]=j0[14]=0;j0[15]=1;
    aes_block(rk,j0,mask);
    for(i=0;i<16;++i)tag[i]=(uint8_t)(mask[i]^y[i]);
    nav_secure_zero(y,16);nav_secure_zero(lens,16);nav_secure_zero(j0,16);nav_secure_zero(mask,16);
}
static void ctr_xor(const uint8_t rk[176],const uint8_t nonce[12],
                    const uint8_t *in,size_t n,uint8_t *out){
    uint8_t counter[16],stream[16];size_t i,offset=0;uint32_t ctr=2;
    copy(counter,nonce,12);
    while(offset<n){size_t take=n-offset<16?n-offset:16;
        wr32(counter+12,ctr++);aes_block(rk,counter,stream);
        for(i=0;i<take;++i)out[offset+i]=(uint8_t)(in[offset+i]^stream[i]);
        offset+=take;
    }
    nav_secure_zero(counter,16);nav_secure_zero(stream,16);
}
static int gcm_valid(const uint8_t *key,const uint8_t *nonce,const uint8_t *aad,size_t al,
                     const uint8_t *data,size_t n,const uint8_t *result){
    /* 96-bit nonce only; limit matches GCM counter capacity and 64-bit bit lengths. */
    if (!key || !nonce || !result || (al && !aad) || (n && !data)) return 0;
    /* Do not use SIZE_MAX in #if: freestanding headers may define it with
     * a size_t cast. Shifts work on both 32- and 64-bit targets. */
    if (((uint64_t)n >> 61) || ((uint64_t)al >> 61)) return 0;
    return ((uint64_t)n/16u) < UINT32_MAX-2u;
}
int nav_aes128_gcm_encrypt(const uint8_t key[16],const uint8_t nonce[12],
                          const uint8_t *aad,size_t al,const uint8_t *plain,size_t n,
                          uint8_t *cipher,uint8_t tag[16]){
    uint8_t rk[176],h[16],z[16];
    if(!gcm_valid(key,nonce,aad,al,plain,n,cipher)||!tag)return -1;
    aes_keys(key,rk);zero(z,16);aes_block(rk,z,h);
    ctr_xor(rk,nonce,plain,n,cipher);gcm_tag(rk,h,nonce,aad,al,cipher,n,tag);
    nav_secure_zero(rk,sizeof(rk));nav_secure_zero(h,16);return 0;
}
int nav_aes128_gcm_decrypt(const uint8_t key[16],const uint8_t nonce[12],
                          const uint8_t *aad,size_t al,const uint8_t *cipher,size_t n,
                          const uint8_t tag[16],uint8_t *plain){
    uint8_t rk[176],h[16],z[16],expected[16];int good;
    if(!gcm_valid(key,nonce,aad,al,cipher,n,plain)||!tag)return -1;
    aes_keys(key,rk);zero(z,16);aes_block(rk,z,h);
    gcm_tag(rk,h,nonce,aad,al,cipher,n,expected);
    good=nav_ct_equal(expected,tag,16);
    if(good)ctr_xor(rk,nonce,cipher,n,plain);
    nav_secure_zero(rk,sizeof(rk));nav_secure_zero(h,16);
    nav_secure_zero(expected,16);
    return good?0:-1;
}
