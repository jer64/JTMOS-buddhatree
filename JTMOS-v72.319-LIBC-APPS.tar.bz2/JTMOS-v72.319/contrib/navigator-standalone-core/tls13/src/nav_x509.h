#ifndef NAV_X509_H
#define NAV_X509_H
#include "nav_crypto.h"

/* Bounded RSA/SHA-256 certificate profile. All slices borrow caller storage.
 * No allocation, I/O, global trust, clock source, or external crypto calls.
 * Unsupported algorithms/constraints are errors, never validation bypasses.
 */
typedef struct nav_span { const uint8_t *p; size_t n; } nav_span;
typedef struct nav_rsa_public { nav_span modulus; uint32_t exponent; } nav_rsa_public;
typedef struct nav_trust_anchor { nav_span subject; nav_rsa_public key; } nav_trust_anchor;
enum nav_x509_error {
    NAV_X509_OK=0, NAV_X509_DER=-1, NAV_X509_UNSUPPORTED=-2,
    NAV_X509_TIME=-3, NAV_X509_NAME=-4, NAV_X509_USAGE=-5,
    NAV_X509_TRUST=-6, NAV_X509_SIGNATURE=-7, NAV_X509_LIMIT=-8
};
#define NAV_X509_MAX_CHAIN 8u
#define NAV_RSA_MAX_BYTES 512u
enum { NAV_RSA_PKCS1_SHA256=1, NAV_RSA_PSS_SHA256=2 };

int nav_rsa_verify_sha256(const nav_rsa_public *key, int padding,
                         const uint8_t hash[32], nav_span signature);
/* Ordered leaf-first chain. Trust anchors are explicit policy inputs.
 * Exact DER DN matching; no AIA, alternate path building, OCSP or CRLs.
 * Rejects name/policy constraints and must-staple instead of ignoring them.
 * Only SAN DNS / IPv4 identities; no common-name fallback.
 * now is trusted UTC seconds since 1970; zero/unknown is rejected.
 */
int nav_x509_verify(const nav_span *chain, size_t chain_count,
                    const nav_trust_anchor *anchors, size_t anchor_count,
                    const char *hostname, uint64_t now,
                    nav_rsa_public *leaf_key);
int nav_x509_hostname_valid(const char *hostname);
const char *nav_x509_error_string(int error);
#endif
