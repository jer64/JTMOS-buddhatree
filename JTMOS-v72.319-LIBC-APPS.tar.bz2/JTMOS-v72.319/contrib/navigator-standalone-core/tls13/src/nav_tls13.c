#include "nav_tls13.h"

static void cp(uint8_t *d,const uint8_t *s,size_t n){size_t i;for(i=0;i<n;++i)d[i]=s[i];}
static size_t string_len_limited(const char *s,size_t max){size_t i;
    if(!s)return (size_t)-1;
    for(i=0;i<=max;++i)if(!s[i])return i;
    return (size_t)-1;
}
int nav_tls13_expand_label(const uint8_t secret[32],const char *label,
                           const uint8_t *context,size_t ctx_len,
                           uint8_t *out,size_t out_len){
    uint8_t info[2+1+255+1+255];size_t ln,i,n;
    if(!secret||!label||(ctx_len && !context)||(out_len && !out)||
       out_len>255u*32u||out_len>65535u||ctx_len>255u)return -1;
    ln=string_len_limited(label,249);
    if(ln==(size_t)-1)return -1;
    n=6+ln;
    info[0]=(uint8_t)(out_len>>8);info[1]=(uint8_t)out_len;
    info[2]=(uint8_t)n;
    cp(info+3,(const uint8_t *)"tls13 ",6);
    cp(info+9,(const uint8_t *)label,ln);
    info[3+n]=(uint8_t)ctx_len;
    for(i=0;i<ctx_len;++i)info[4+n+i]=context[i];
    i=nav_hkdf_expand(secret,info,4+n+ctx_len,out,out_len);
    nav_secure_zero(info,sizeof(info));return (int)i;
}
static int derive(const uint8_t s[32],const char *label,const uint8_t hash[32],uint8_t out[32]){
    return nav_tls13_expand_label(s,label,hash,32,out,32);
}
int nav_tls13_handshake_secrets(const uint8_t shared[32],const uint8_t hello_hash[32],
                               uint8_t client_hs[32],uint8_t server_hs[32],uint8_t master[32]){
    uint8_t z[32]={0},empty_hash[32],early[32],derived[32],hs[32],next[32];int rc=-1;
    if(!shared||!hello_hash||!client_hs||!server_hs||!master)return -1;
    nav_sha256_hash(NULL,0,empty_hash);
    nav_hkdf_extract(z,32,z,32,early);
    if(nav_tls13_expand_label(early,"derived",empty_hash,32,derived,32))goto done;
    nav_hkdf_extract(derived,32,shared,32,hs);
    if(derive(hs,"c hs traffic",hello_hash,client_hs))goto done;
    if(derive(hs,"s hs traffic",hello_hash,server_hs))goto done;
    if(nav_tls13_expand_label(hs,"derived",empty_hash,32,next,32))goto done;
    nav_hkdf_extract(next,32,z,32,master);
    rc=0;
done:
    nav_secure_zero(z,sizeof(z));nav_secure_zero(empty_hash,32);
    nav_secure_zero(early,32);nav_secure_zero(derived,32);
    nav_secure_zero(hs,32);nav_secure_zero(next,32);return rc;
}
int nav_tls13_application_secrets(const uint8_t master[32],const uint8_t hash[32],
                                  uint8_t client_app[32],uint8_t server_app[32]){
    if(!master||!hash||!client_app||!server_app)return -1;
    if(derive(master,"c ap traffic",hash,client_app))return -1;
    return derive(master,"s ap traffic",hash,server_app);
}
int nav_tls13_finished_mac(const uint8_t traffic_secret[32],const uint8_t hash[32],uint8_t out[32]){
    uint8_t k[32];int rc;
    if(!traffic_secret||!hash||!out)return -1;
    rc=nav_tls13_expand_label(traffic_secret,"finished",NULL,0,k,32);
    if(!rc)nav_hmac_sha256(k,32,hash,32,out);
    nav_secure_zero(k,32);return rc;
}
int nav_tls13_keys_init(nav_tls13_keys *k,const uint8_t secret[32]){
    if(!k||!secret)return -1;
    nav_secure_zero(k,sizeof(*k));cp(k->secret,secret,32);
    if(nav_tls13_expand_label(secret,"key",NULL,0,k->key,16)||
       nav_tls13_expand_label(secret,"iv",NULL,0,k->iv,12)){
        nav_secure_zero(k,sizeof(*k));return -1;
    }
    k->active=1;return 0;
}
void nav_tls13_keys_wipe(nav_tls13_keys *k){if(k)nav_secure_zero(k,sizeof(*k));}
static void record_nonce(const nav_tls13_keys *k,uint8_t nonce[12]){
    unsigned i;cp(nonce,k->iv,12);
    for(i=0;i<8;++i)nonce[11-i]^=(uint8_t)(k->sequence>>(8*i));
}
static int allowed(uint8_t type){return type==NAV_TLS13_APPDATA||type==NAV_TLS13_HANDSHAKE||type==NAV_TLS13_ALERT;}
/* Conservative local limit: rekey well before RFC 8446 AES-GCM use limits. */
#define NAV_TLS13_RECORD_LIMIT 1000000u
int nav_tls13_seal(nav_tls13_keys *k,uint8_t type,const uint8_t *in,size_t len,
                   uint8_t *wire,size_t cap,size_t *out_len){
    uint8_t nonce[12];size_t encrypted;
    if(!k||!k->active||!wire||!out_len||!allowed(type)||
       (len&&!in)||len>NAV_TLS13_MAX_CONTENT||
       ((type==NAV_TLS13_HANDSHAKE||type==NAV_TLS13_ALERT)&&len==0))return -1;
    if(k->sequence==UINT64_MAX||k->records_used>=NAV_TLS13_RECORD_LIMIT){nav_tls13_keys_wipe(k);return -2;}
    encrypted=len+1+16;
    if(cap<5+encrypted)return -1;
    wire[0]=23;wire[1]=3;wire[2]=3;
    wire[3]=(uint8_t)(encrypted>>8);wire[4]=(uint8_t)encrypted;
    if(len)cp(wire+5,in,len);
    wire[5+len]=type;
    record_nonce(k,nonce);
    if(nav_aes128_gcm_encrypt(k->key,nonce,wire,5,wire+5,len+1,wire+5,wire+5+len+1)){
        nav_secure_zero(nonce,12);nav_tls13_keys_wipe(k);return -2;
    }
    nav_secure_zero(nonce,12);k->sequence++;k->records_used++;
    *out_len=5+encrypted;return 0;
}
int nav_tls13_open(nav_tls13_keys *k,const uint8_t *wire,size_t len,
                   uint8_t *out,size_t cap,uint8_t *type,size_t *out_len){
    size_t enclen,inner_len,n;uint8_t nonce[12],inner_type;
    if(!k||!k->active||!wire||!out||!type||!out_len)return -1;
    if(k->sequence==UINT64_MAX||k->records_used>=NAV_TLS13_RECORD_LIMIT)goto bad;
    if(len<5+17||len>NAV_TLS13_MAX_WIRE||wire[0]!=23||wire[1]!=3||wire[2]!=3)goto bad;
    enclen=((size_t)wire[3]<<8)|wire[4];
    if(enclen<17||enclen>NAV_TLS13_MAX_CONTENT+256||len!=5+enclen)goto bad;
    inner_len=enclen-16;
    if(cap<inner_len)return -1;
    record_nonce(k,nonce);
    if(nav_aes128_gcm_decrypt(k->key,nonce,wire,5,wire+5,inner_len,wire+5+inner_len,out)){
        nav_secure_zero(nonce,12);goto bad;
    }
    nav_secure_zero(nonce,12);
    n=inner_len;
    while(n>0&&out[n-1]==0)--n;
    if(!n)goto bad_clear;
    inner_type=out[n-1];
    if(!allowed(inner_type)||n-1>NAV_TLS13_MAX_CONTENT||
       ((inner_type==NAV_TLS13_ALERT||inner_type==NAV_TLS13_HANDSHAKE)&&n==1))goto bad_clear;
    *type=inner_type;*out_len=n-1;
    k->sequence++;k->records_used++;return 0;
bad_clear:
    nav_secure_zero(out,inner_len);
bad:
    nav_tls13_keys_wipe(k);return -2;
}
