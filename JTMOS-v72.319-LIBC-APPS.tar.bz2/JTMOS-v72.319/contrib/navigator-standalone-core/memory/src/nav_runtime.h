#ifndef NAV_RUNTIME_H
#define NAV_RUNTIME_H
/* Navigator runtime memory extensions: bounded per-tab heaps, cooperative
 * stop-the-world exact mark/sweep GC, and user-supplied heap locks.
 * Freestanding C11, no libc functions or OS dependencies.
 */
#include "nav_mem.h"

#ifdef __cplusplus
extern "C" {
#endif

#define NAV_GC_BUCKETS 1024u

typedef void (*nav_page_lock_fn)(void *context);

typedef struct nav_page {
    nav_heap heap;                 /* Separate heap for each browser tab/page. */
    size_t quota_bytes;           /* HARD limit on backing region sizes. */
    size_t backing_bytes;         /* Includes metadata, fragmentation, arenas. */
    size_t quota_denials;
    nav_mem_acquire_fn acquire;
    nav_mem_release_fn release;
    void *provider_context;
    nav_page_lock_fn lock;
    nav_page_lock_fn unlock;
    void *lock_context;
} nav_page;

void nav_page_init(nav_page *page, size_t quota_bytes);
/* Install lock callbacks before any worker threads begin. Both or neither.
 * Lock must block other threads; cannot be recursively acquired.
 * Thread/IRQ safety is the caller's responsibility (e.g., never sleep with
 * interrupts disabled). One JavaScript VM mutator per page is REQUIRED.
 */
int nav_page_set_lock(nav_page *page, nav_page_lock_fn lock,
                      nav_page_lock_fn unlock, void *context);
/* Provider MUST support release for rejected allocations and teardown.
 * May be NULL if all memory is preallocated via add_region().
 * Do not change after allocations or use across different pages.
 */
int nav_page_set_provider(nav_page *page, nav_mem_acquire_fn acquire,
                          nav_mem_release_fn release, void *context,
                          size_t growth_minimum);
/* Borrowed memory remains owned by the caller, including after destroy. */
int nav_page_add_region(nav_page *page, void *memory, size_t bytes);
void *nav_page_alloc(nav_page *page, size_t bytes);
void *nav_page_calloc(nav_page *page, size_t count, size_t size);
void *nav_page_realloc(nav_page *page, void *p, size_t bytes);
int nav_page_free(nav_page *page, void *p);
void nav_page_get_stats(nav_page *page, nav_heap_stats *out,
                        size_t *backing, size_t *denials);
/* Destroy only after all arenas + GC objects have been released. */
int nav_page_destroy(nav_page *page);

/* Page-aware arena operations: do NOT call bare nav_arena_*(...) on a shared
 * page. Each wrapper holds the same page lock used by GC and allocations.
 */
void nav_page_arena_init(nav_page *page, nav_arena *arena, size_t chunk_bytes);
void *nav_page_arena_alloc(nav_page *page, nav_arena *arena, size_t bytes);
void *nav_page_arena_calloc(nav_page *page, nav_arena *arena,
                            size_t count, size_t size);
nav_arena_mark nav_page_arena_get_mark(nav_page *page, nav_arena *arena);
int nav_page_arena_rewind(nav_page *page, nav_arena *arena, nav_arena_mark mark);
void nav_page_arena_reset(nav_page *page, nav_arena *arena);

typedef struct nav_gc nav_gc;
typedef struct nav_gc_header nav_gc_header;
/* Called during GC only, under the page lock and with the JS VM stopped.
 * Enumerate each child GC object using nav_gc_mark(gc, child).
 * NEVER allocate, mutate the graph, or call a locking API in a tracer.
 */
typedef void (*nav_gc_trace_fn)(nav_gc *gc, void *object, void *context);

typedef struct nav_gc_root {
    struct nav_gc_root *next;
    nav_gc *owner;
    void **slot; /* points to a stable void* slot; not an interior pointer */
} nav_gc_root;

typedef struct nav_gc_stats {
    size_t live_objects;
    size_t live_payload_bytes;
    size_t peak_payload_bytes;
    size_t collections;
    size_t automatic_collections;
    size_t total_collected_objects;
    size_t total_collected_bytes;
} nav_gc_stats;

struct nav_gc {
    nav_page *page;
    nav_gc_header *objects;
    nav_gc_header *grey;
    nav_gc_header *buckets[NAV_GC_BUCKETS];
    nav_gc_root *roots;
    nav_gc_stats stats;
    size_t automatic_threshold_bytes;
    size_t bytes_since_collection;
    unsigned collecting;
};

void nav_gc_init(nav_gc *gc, nav_page *page);
/* Automatic GC when cumulative new payload bytes exceed threshold and once
 * on allocation failure. Default 256 KiB; threshold=0 disables only the
 * periodic trigger, not the OOM retry. Exact VM roots must be kept current
 * BEFORE any allocation; all new unrooted objects may be collected.
 */
void nav_gc_set_threshold(nav_gc *gc, size_t threshold_bytes);
/* Always allocate JS objects through nav_gc_new; tracing callback may be NULL
 * for leaf objects. GC object addresses are fixed (no moving collector).
 */
void *nav_gc_new(nav_gc *gc, size_t bytes,
                 nav_gc_trace_fn trace, void *context);
/* Roots live in caller-owned storage and MUST outlive their registration.
 * nav_gc_root_init() before add(), including for stack-allocated roots.
 * Roots must be explicitly removed before their stack frame exits.
 */
void nav_gc_root_init(nav_gc_root *root);
int nav_gc_root_add(nav_gc *gc, nav_gc_root *root, void **slot);
int nav_gc_root_remove(nav_gc *gc, nav_gc_root *root);
/* Only call from a GC tracer while collecting. Ignores NULL/non-GC refs.
 * An old stale pointer equal to a newly allocated object cannot be detected:
 * never retain stale raw GC pointers across page lifetimes.
 */
void nav_gc_mark(nav_gc *gc, void *object);
/* Exact, non-moving, cycle-safe mark/sweep. Returns objects reclaimed or 0
 * for empty heap; no allocations are made by the collector.
 * JS graph MUST NOT mutate concurrently with collection. */
size_t nav_gc_collect(nav_gc *gc);
/* Page navigation / teardown: invalidates all JS objects AND roots. Caller
 * must stop event callbacks, workers and pending VM work first. */
void nav_gc_reset(nav_gc *gc);
void nav_gc_get_stats(nav_gc *gc, nav_gc_stats *out);

#ifdef __cplusplus
}
#endif
#endif
