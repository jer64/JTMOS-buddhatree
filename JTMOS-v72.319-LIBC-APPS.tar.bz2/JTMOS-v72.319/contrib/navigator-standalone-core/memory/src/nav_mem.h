#ifndef NAV_MEM_H
#define NAV_MEM_H

/* Navigator memory core - ISO C11 freestanding, no libc calls. */
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define NAV_MEM_ALIGNMENT 16u
#define NAV_MEM_MAX_REGIONS 32u

#define NAV_MEM_OK         0
#define NAV_MEM_EINVAL    -1
#define NAV_MEM_ENOMEM    -2
#define NAV_MEM_ECORRUPT  -3
#define NAV_MEM_EBUSY     -4

/* The provider returns writable, non-overlapping memory >= min_size.
 * actual_size MUST report the exact available extent. Backing memory
 * is owned by the provider, not by nav_heap_free().
 * The optional release callback runs on heap destruction (if no live blocks).
 */
typedef void *(*nav_mem_acquire_fn)(void *context, size_t min_size,
                                     size_t *actual_size);
typedef void (*nav_mem_release_fn)(void *context, void *address,
                                    size_t actual_size);

typedef struct nav_mem_block nav_mem_block;

typedef struct nav_mem_region {
    unsigned char *begin;
    unsigned char *end;
    void *backing_base;
    size_t backing_size;
    unsigned from_provider;
} nav_mem_region;

typedef struct nav_heap {
    nav_mem_block *free_head;
    nav_mem_region regions[NAV_MEM_MAX_REGIONS];
    size_t region_count;
    size_t total_managed;
    size_t requested_in_use;
    size_t requested_peak;
    size_t active_allocations;
    size_t peak_allocations;
    size_t failed_allocations;
    nav_mem_acquire_fn acquire;
    nav_mem_release_fn release;
    void *provider_context;
    size_t growth_minimum;
} nav_heap;

typedef struct nav_heap_stats {
    size_t managed_bytes;
    size_t requested_live_bytes;
    size_t peak_requested_bytes;
    size_t live_allocations;
    size_t peak_allocations;
    size_t failed_allocations;
    size_t region_count;
    size_t free_blocks;
    size_t available_payload_bytes;
    size_t largest_free_payload;
} nav_heap_stats;

void nav_heap_init(nav_heap *heap);
int nav_heap_add_region(nav_heap *heap, void *memory, size_t bytes);
void nav_heap_set_provider(nav_heap *heap, nav_mem_acquire_fn acquire,
                           nav_mem_release_fn release, void *context,
                           size_t growth_minimum);
void *nav_heap_alloc(nav_heap *heap, size_t bytes);
void *nav_heap_calloc(nav_heap *heap, size_t count, size_t size);
void *nav_heap_realloc(nav_heap *heap, void *ptr, size_t bytes);
int nav_heap_free(nav_heap *heap, void *ptr);
void nav_heap_get_stats(const nav_heap *heap, nav_heap_stats *out);
/* Runs a full O(N^2) structural audit. Use in tests/debug builds, not per frame. */
int nav_heap_validate(const nav_heap *heap);
/* Fails with NAV_MEM_EBUSY while allocations are live. */
int nav_heap_destroy(nav_heap *heap);

typedef struct nav_arena_chunk nav_arena_chunk;
typedef struct nav_arena {
    nav_heap *heap;
    nav_arena_chunk *head;
    nav_arena_chunk *tail;
    size_t chunk_bytes;
    size_t requested_live;
    unsigned generation;
} nav_arena;

typedef struct nav_arena_mark {
    const nav_arena *owner;
    nav_arena_chunk *chunk;
    size_t used;
    size_t requested_live;
    unsigned generation;
} nav_arena_mark;

void nav_arena_init(nav_arena *arena, nav_heap *heap, size_t chunk_bytes);
void *nav_arena_alloc(nav_arena *arena, size_t bytes);
void *nav_arena_calloc(nav_arena *arena, size_t count, size_t size);
nav_arena_mark nav_arena_get_mark(const nav_arena *arena);
/* Marks must be rewound in stack order; old marks are invalid after reset. */
int nav_arena_rewind(nav_arena *arena, nav_arena_mark mark);
void nav_arena_reset(nav_arena *arena);

#ifdef __cplusplus
}
#endif
#endif
