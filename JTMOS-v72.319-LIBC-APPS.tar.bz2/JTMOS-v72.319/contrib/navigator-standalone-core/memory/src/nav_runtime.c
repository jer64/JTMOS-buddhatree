#include "nav_runtime.h"

/* No reliance on libc, atomics, or a platform's syscall ABI. */
#define NAV_GC_MAGIC 0x4E47434Fu

struct nav_gc_header {
    nav_gc_header *next;       /* Object list, newest first. */
    nav_gc_header *bucket_next;
    nav_gc_header *grey_next;
    nav_gc *owner;
    nav_gc_trace_fn trace;
    void *context;
    size_t payload_bytes;
    uint32_t magic;
    unsigned char marked;
};

static void zero_bytes(void *p, size_t n) {
    unsigned char *b = (unsigned char *)p;
    while (n--) *b++ = 0;
}

static size_t gc_head_bytes(void) {
    return (sizeof(nav_gc_header) + NAV_MEM_ALIGNMENT - 1u) &
           ~(size_t)(NAV_MEM_ALIGNMENT - 1u);
}

static void page_lock(nav_page *p) {
    if (p && p->lock) p->lock(p->lock_context);
}
static void page_unlock(nav_page *p) {
    if (p && p->unlock) p->unlock(p->lock_context);
}

static size_t page_remaining(const nav_page *p) {
    return p->quota_bytes - p->backing_bytes;
}

static void *page_acquire(void *context, size_t minimum, size_t *actual) {
    nav_page *p = (nav_page *)context;
    void *mem;
    size_t received = 0;
    if (!p->acquire || minimum > page_remaining(p)) {
        ++p->quota_denials;
        return NULL;
    }
    mem = p->acquire(p->provider_context, minimum, &received);
    if (!mem) return NULL;
    if (received < minimum || received > page_remaining(p)) {
        /* Required: return the entire unexpected region to the OS. */
        p->release(p->provider_context, mem, received);
        ++p->quota_denials;
        return NULL;
    }
    p->backing_bytes += received;
    *actual = received;
    return mem;
}

static void page_release(void *context, void *memory, size_t bytes) {
    nav_page *p = (nav_page *)context;
    p->release(p->provider_context, memory, bytes);
    /* When destroyed, nav_heap_destroy() calls this for each region. */
    p->backing_bytes -= bytes;
}

/* A large growth_minimum must not turn a small allocation at the end of a
 * quota into an unnecessary OOM, so temporarily cap the provider request.
 * Only used while holding the page lock. */
static void page_adjust_growth(nav_page *p, size_t *saved) {
    *saved = p->heap.growth_minimum;
    if (*saved > page_remaining(p))
        p->heap.growth_minimum = page_remaining(p);
}
static void page_restore_growth(nav_page *p, size_t saved) {
    p->heap.growth_minimum = saved;
}

void nav_page_init(nav_page *page, size_t quota_bytes) {
    if (!page) return;
    zero_bytes(page, sizeof(*page));
    nav_heap_init(&page->heap);
    page->quota_bytes = quota_bytes;
}

int nav_page_set_lock(nav_page *p, nav_page_lock_fn lock,
                      nav_page_lock_fn unlock, void *context) {
    if (!p || ((lock == NULL) != (unlock == NULL))) return NAV_MEM_EINVAL;
    if (p->lock || p->unlock) return NAV_MEM_EBUSY;
    p->lock = lock;
    p->unlock = unlock;
    p->lock_context = context;
    return NAV_MEM_OK;
}

int nav_page_set_provider(nav_page *p, nav_mem_acquire_fn acquire,
                          nav_mem_release_fn release, void *context,
                          size_t growth_minimum) {
    if (!p || (acquire && !release) || (!acquire && release))
        return NAV_MEM_EINVAL;
    page_lock(p);
    if (p->heap.acquire || p->heap.region_count) {
        page_unlock(p);
        return NAV_MEM_EBUSY;
    }
    p->acquire = acquire;
    p->release = release;
    p->provider_context = context;
    if (acquire)
        nav_heap_set_provider(&p->heap, page_acquire, page_release, p,
                              growth_minimum);
    page_unlock(p);
    return NAV_MEM_OK;
}

int nav_page_add_region(nav_page *p, void *memory, size_t bytes) {
    int rc;
    if (!p || !memory) return NAV_MEM_EINVAL;
    page_lock(p);
    if (bytes > page_remaining(p)) {
        ++p->quota_denials;
        rc = NAV_MEM_ENOMEM;
    } else {
        rc = nav_heap_add_region(&p->heap, memory, bytes);
        if (rc == NAV_MEM_OK) p->backing_bytes += bytes;
    }
    page_unlock(p);
    return rc;
}

void *nav_page_alloc(nav_page *p, size_t bytes) {
    void *result;
    size_t saved;
    if (!p) return NULL;
    page_lock(p);
    page_adjust_growth(p, &saved);
    result = nav_heap_alloc(&p->heap, bytes);
    page_restore_growth(p, saved);
    page_unlock(p);
    return result;
}

void *nav_page_calloc(nav_page *p, size_t count, size_t size) {
    void *result;
    size_t saved;
    if (!p) return NULL;
    page_lock(p);
    page_adjust_growth(p, &saved);
    result = nav_heap_calloc(&p->heap, count, size);
    page_restore_growth(p, saved);
    page_unlock(p);
    return result;
}

void *nav_page_realloc(nav_page *p, void *memory, size_t bytes) {
    void *result;
    size_t saved;
    if (!p) return NULL;
    page_lock(p);
    page_adjust_growth(p, &saved);
    result = nav_heap_realloc(&p->heap, memory, bytes);
    page_restore_growth(p, saved);
    page_unlock(p);
    return result;
}

int nav_page_free(nav_page *p, void *memory) {
    int rc;
    if (!p) return NAV_MEM_EINVAL;
    page_lock(p);
    rc = nav_heap_free(&p->heap, memory);
    page_unlock(p);
    return rc;
}

void nav_page_get_stats(nav_page *p, nav_heap_stats *out,
                        size_t *backing, size_t *denials) {
    if (!p) return;
    page_lock(p);
    if (out) nav_heap_get_stats(&p->heap, out);
    if (backing) *backing = p->backing_bytes;
    if (denials) *denials = p->quota_denials;
    page_unlock(p);
}

int nav_page_destroy(nav_page *p) {
    int rc;
    if (!p) return NAV_MEM_EINVAL;
    page_lock(p);
    rc = nav_heap_destroy(&p->heap);
    if (rc == NAV_MEM_OK) {
        /* Borrowed regions are not released; account resets on destruction. */
        p->backing_bytes = 0;
        p->acquire = NULL;
        p->release = NULL;
        p->provider_context = NULL;
    }
    page_unlock(p);
    return rc;
}

void nav_page_arena_init(nav_page *p, nav_arena *a, size_t bytes) {
    if (!p || !a) return;
    page_lock(p);
    nav_arena_init(a, &p->heap, bytes);
    page_unlock(p);
}
void *nav_page_arena_alloc(nav_page *p, nav_arena *a, size_t bytes) {
    size_t saved;
    void *result;
    if (!p || !a) return NULL;
    page_lock(p);
    if (a->heap != &p->heap) { page_unlock(p); return NULL; }
    page_adjust_growth(p, &saved);
    result = nav_arena_alloc(a, bytes);
    page_restore_growth(p, saved);
    page_unlock(p);
    return result;
}
void *nav_page_arena_calloc(nav_page *p, nav_arena *a,
                            size_t count, size_t size) {
    size_t saved;
    void *result;
    if (!p || !a) return NULL;
    page_lock(p);
    if (a->heap != &p->heap) { page_unlock(p); return NULL; }
    page_adjust_growth(p, &saved);
    result = nav_arena_calloc(a, count, size);
    page_restore_growth(p, saved);
    page_unlock(p);
    return result;
}
nav_arena_mark nav_page_arena_get_mark(nav_page *p, nav_arena *a) {
    nav_arena_mark mark = {0};
    if (!p || !a) return mark;
    page_lock(p);
    if (a->heap == &p->heap) mark = nav_arena_get_mark(a);
    page_unlock(p);
    return mark;
}
int nav_page_arena_rewind(nav_page *p, nav_arena *a, nav_arena_mark mark) {
    int rc;
    if (!p || !a) return NAV_MEM_EINVAL;
    page_lock(p);
    rc = (a->heap == &p->heap) ? nav_arena_rewind(a, mark) : NAV_MEM_EINVAL;
    page_unlock(p);
    return rc;
}
void nav_page_arena_reset(nav_page *p, nav_arena *a) {
    if (!p || !a) return;
    page_lock(p);
    if (a->heap == &p->heap) nav_arena_reset(a);
    page_unlock(p);
}

static unsigned gc_bucket(const void *obj) {
    uintptr_t n = (uintptr_t)obj >> 4;
    n ^= n >> 9;
    n ^= n >> 17;
    return (unsigned)(n & (NAV_GC_BUCKETS - 1u));
}

static nav_gc_header *gc_lookup(const nav_gc *gc, void *obj) {
    nav_gc_header *h;
    if (!obj) return NULL;
    for (h = gc->buckets[gc_bucket(obj)]; h; h = h->bucket_next)
        if ((unsigned char *)h + gc_head_bytes() == (unsigned char *)obj)
            return h;
    return NULL;
}

static void gc_remove_from_bucket(nav_gc *gc, nav_gc_header *h) {
    unsigned index = gc_bucket((unsigned char *)h + gc_head_bytes());
    nav_gc_header **link = &gc->buckets[index];
    while (*link && *link != h) link = &(*link)->bucket_next;
    if (*link == h) *link = h->bucket_next;
}

void nav_gc_init(nav_gc *gc, nav_page *p) {
    if (!gc) return;
    zero_bytes(gc, sizeof(*gc));
    gc->page = p;
    gc->automatic_threshold_bytes = 256u * 1024u;
}

void nav_gc_set_threshold(nav_gc *gc, size_t threshold_bytes) {
    if (!gc || !gc->page) return;
    page_lock(gc->page);
    gc->automatic_threshold_bytes = threshold_bytes;
    page_unlock(gc->page);
}

static size_t gc_collect_locked(nav_gc *gc);

void *nav_gc_new(nav_gc *gc, size_t bytes,
                 nav_gc_trace_fn trace, void *context) {
    nav_gc_header *h;
    nav_page *p;
    size_t saved;
    unsigned bucket;
    void *obj;
    int should_collect;
    if (!gc || !gc->page || !bytes ||
        bytes > SIZE_MAX - gc_head_bytes()) return NULL;
    p = gc->page;
    page_lock(p);
    if (gc->collecting || gc->stats.live_payload_bytes > SIZE_MAX - bytes ||
        gc->stats.live_objects == SIZE_MAX) {
        page_unlock(p);
        return NULL;
    }
    should_collect = gc->automatic_threshold_bytes &&
        (bytes >= gc->automatic_threshold_bytes ||
         gc->bytes_since_collection >= gc->automatic_threshold_bytes - bytes);
    if (should_collect) {
        (void)gc_collect_locked(gc);
        ++gc->stats.automatic_collections;
    }
    page_adjust_growth(p, &saved);
    h = (nav_gc_header *)nav_heap_alloc(&p->heap, gc_head_bytes() + bytes);
    page_restore_growth(p, saved);
    if (!h && !should_collect && gc->objects) {
        /* OOM: reclaim unreachable JS objects before giving up. */
        (void)gc_collect_locked(gc);
        ++gc->stats.automatic_collections;
        page_adjust_growth(p, &saved);
        h = (nav_gc_header *)nav_heap_alloc(&p->heap, gc_head_bytes() + bytes);
        page_restore_growth(p, saved);
    }
    if (!h) { page_unlock(p); return NULL; }
    zero_bytes(h, gc_head_bytes() + bytes);
    h->owner = gc;
    h->magic = NAV_GC_MAGIC;
    h->trace = trace;
    h->context = context;
    h->payload_bytes = bytes;
    h->next = gc->objects;
    gc->objects = h;
    obj = (unsigned char *)h + gc_head_bytes();
    bucket = gc_bucket(obj);
    h->bucket_next = gc->buckets[bucket];
    gc->buckets[bucket] = h;
    ++gc->stats.live_objects;
    gc->stats.live_payload_bytes += bytes;
    if (gc->bytes_since_collection > SIZE_MAX - bytes)
        gc->bytes_since_collection = SIZE_MAX;
    else
        gc->bytes_since_collection += bytes;
    if (gc->stats.live_payload_bytes > gc->stats.peak_payload_bytes)
        gc->stats.peak_payload_bytes = gc->stats.live_payload_bytes;
    page_unlock(p);
    return obj;
}

void nav_gc_root_init(nav_gc_root *root) {
    if (root) zero_bytes(root, sizeof(*root));
}
int nav_gc_root_add(nav_gc *gc, nav_gc_root *root, void **slot) {
    nav_page *p;
    if (!gc || !gc->page || !root || !slot) return NAV_MEM_EINVAL;
    p = gc->page;
    page_lock(p);
    if (gc->collecting || root->owner) { page_unlock(p); return NAV_MEM_EBUSY; }
    root->owner = gc;
    root->slot = slot;
    root->next = gc->roots;
    gc->roots = root;
    page_unlock(p);
    return NAV_MEM_OK;
}
int nav_gc_root_remove(nav_gc *gc, nav_gc_root *root) {
    nav_gc_root **cur;
    nav_page *p;
    if (!gc || !gc->page || !root) return NAV_MEM_EINVAL;
    p = gc->page;
    page_lock(p);
    if (gc->collecting || root->owner != gc) {
        page_unlock(p);
        return NAV_MEM_EINVAL;
    }
    for (cur = &gc->roots; *cur && *cur != root; cur = &(*cur)->next) { }
    if (!*cur) { page_unlock(p); return NAV_MEM_ECORRUPT; }
    *cur = root->next;
    nav_gc_root_init(root);
    page_unlock(p);
    return NAV_MEM_OK;
}

void nav_gc_mark(nav_gc *gc, void *object) {
    nav_gc_header *h;
    if (!gc || !gc->collecting || !object) return;
    h = gc_lookup(gc, object);
    if (!h || h->magic != NAV_GC_MAGIC || h->owner != gc || h->marked)
        return;
    h->marked = 1;
    h->grey_next = gc->grey;
    gc->grey = h;
}

static size_t gc_collect_locked(nav_gc *gc) {
    nav_page *p;
    nav_gc_root *root;
    nav_gc_header *h, **link;
    size_t collected = 0;
    if (gc->collecting) return 0;
    p = gc->page;
    gc->collecting = 1;
    gc->grey = NULL;
    for (root = gc->roots; root; root = root->next)
        nav_gc_mark(gc, *root->slot);
    while (gc->grey) {
        h = gc->grey;
        gc->grey = h->grey_next;
        h->grey_next = NULL;
        if (h->trace)
            h->trace(gc, (unsigned char *)h + gc_head_bytes(), h->context);
    }
    link = &gc->objects;
    while (*link) {
        h = *link;
        if (h->marked) {
            h->marked = 0;
            link = &h->next;
        } else {
            *link = h->next;
            gc_remove_from_bucket(gc, h);
            --gc->stats.live_objects;
            gc->stats.live_payload_bytes -= h->payload_bytes;
            ++gc->stats.total_collected_objects;
            gc->stats.total_collected_bytes += h->payload_bytes;
            ++collected;
            h->magic = 0;
            (void)nav_heap_free(&p->heap, h);
        }
    }
    ++gc->stats.collections;
    gc->bytes_since_collection = 0;
    gc->collecting = 0;
    return collected;
}

size_t nav_gc_collect(nav_gc *gc) {
    size_t reclaimed;
    if (!gc || !gc->page) return 0;
    page_lock(gc->page);
    reclaimed = gc_collect_locked(gc);
    page_unlock(gc->page);
    return reclaimed;
}

void nav_gc_reset(nav_gc *gc) {
    nav_gc_header *h, *next;
    nav_gc_root *root, *rn;
    nav_page *p;
    unsigned i;
    if (!gc || !gc->page) return;
    p = gc->page;
    page_lock(p);
    if (gc->collecting) { page_unlock(p); return; }
    for (root = gc->roots; root; root = rn) {
        rn = root->next;
        nav_gc_root_init(root);
    }
    gc->roots = NULL;
    for (h = gc->objects; h; h = next) {
        next = h->next;
        h->magic = 0;
        (void)nav_heap_free(&p->heap, h);
    }
    gc->objects = NULL;
    gc->grey = NULL;
    for (i = 0; i < NAV_GC_BUCKETS; ++i) gc->buckets[i] = NULL;
    gc->stats.live_objects = 0;
    gc->stats.live_payload_bytes = 0;
    gc->bytes_since_collection = 0;
    page_unlock(p);
}
void nav_gc_get_stats(nav_gc *gc, nav_gc_stats *out) {
    nav_page *p;
    if (!gc || !gc->page || !out) return;
    p = gc->page;
    page_lock(p);
    *out = gc->stats;
    page_unlock(p);
}
