#include "nav_mem.h"

#define NAV_BLOCK_USED ((size_t)1u)
#define NAV_BLOCK_MAGIC ((size_t)0x4E564D42u)
#define NAV_SIZE_MASK (~(size_t)(NAV_MEM_ALIGNMENT - 1u))

struct nav_mem_block {
    size_t size_flags;              /* Total block size (header + payload), low bit = used */
    size_t prev_size;               /* Previous physical block size, zero at region start */
    size_t requested;               /* Exact caller request; zero for free blocks */
    struct nav_mem_block *free_prev;
    struct nav_mem_block *free_next;
    size_t magic;
};

struct nav_arena_chunk {
    struct nav_arena_chunk *next;
    size_t capacity;
    size_t used;
    unsigned char data[];
};

static size_t nav_align_down(size_t v) {
    return v & NAV_SIZE_MASK;
}

static int nav_align_up(size_t v, size_t *result) {
    if (v > SIZE_MAX - (NAV_MEM_ALIGNMENT - 1u)) return 0;
    *result = (v + (NAV_MEM_ALIGNMENT - 1u)) & NAV_SIZE_MASK;
    return 1;
}

static size_t nav_header_bytes(void) {
    size_t n = sizeof(nav_mem_block);
    return (n + (NAV_MEM_ALIGNMENT - 1u)) & NAV_SIZE_MASK;
}

static size_t nav_min_block_bytes(void) {
    return nav_header_bytes() + NAV_MEM_ALIGNMENT;
}

static size_t nav_block_bytes(const nav_mem_block *b) {
    return b->size_flags & NAV_SIZE_MASK;
}

static int nav_used(const nav_mem_block *b) {
    return (b->size_flags & NAV_BLOCK_USED) != 0;
}

static void nav_fill_zero(void *buffer, size_t bytes) {
    unsigned char *p = (unsigned char *)buffer;
    while (bytes--) *p++ = 0;
}

static void nav_copy(void *dest, const void *src, size_t bytes) {
    unsigned char *d = (unsigned char *)dest;
    const unsigned char *s = (const unsigned char *)src;
    while (bytes--) *d++ = *s++;
}

static void nav_free_link(nav_heap *h, nav_mem_block *b) {
    b->free_prev = NULL;
    b->free_next = h->free_head;
    if (h->free_head) h->free_head->free_prev = b;
    h->free_head = b;
}

static void nav_free_unlink(nav_heap *h, nav_mem_block *b) {
    if (b->free_prev) b->free_prev->free_next = b->free_next;
    else h->free_head = b->free_next;
    if (b->free_next) b->free_next->free_prev = b->free_prev;
    b->free_prev = NULL;
    b->free_next = NULL;
}

static void nav_init_block(nav_mem_block *b, size_t size,
                           size_t prev_size, int used) {
    b->size_flags = size | (used ? NAV_BLOCK_USED : 0);
    b->prev_size = prev_size;
    b->requested = 0;
    b->free_prev = NULL;
    b->free_next = NULL;
    b->magic = NAV_BLOCK_MAGIC;
}

void nav_heap_init(nav_heap *heap) {
    if (heap) nav_fill_zero(heap, sizeof(*heap));
}

/* This internal entry point also records provider-owned backing memory. */
static int nav_add_region(nav_heap *h, void *memory, size_t bytes,
                          unsigned from_provider) {
    size_t address, aligned, end, length, i;
    nav_mem_block *first;
    nav_mem_region *region;

    if (!h || !memory || h->region_count >= NAV_MEM_MAX_REGIONS) return NAV_MEM_EINVAL;
    address = (size_t)(uintptr_t)memory;
    if (!nav_align_up(address, &aligned) || bytes > SIZE_MAX - address)
        return NAV_MEM_EINVAL;
    end = nav_align_down(address + bytes);
    if (end <= aligned || end - aligned < nav_min_block_bytes())
        return NAV_MEM_EINVAL;
    length = end - aligned;
    if (h->total_managed > SIZE_MAX - length) return NAV_MEM_EINVAL;

    for (i = 0; i < h->region_count; ++i) {
        if (aligned < (size_t)(uintptr_t)h->regions[i].end &&
            end > (size_t)(uintptr_t)h->regions[i].begin)
            return NAV_MEM_EINVAL;
    }
    region = &h->regions[h->region_count++];
    region->begin = (unsigned char *)(uintptr_t)aligned;
    region->end = (unsigned char *)(uintptr_t)end;
    region->backing_base = memory;
    region->backing_size = bytes;
    region->from_provider = from_provider;
    h->total_managed += length;
    first = (nav_mem_block *)(void *)region->begin;
    nav_init_block(first, length, 0, 0);
    nav_free_link(h, first);
    return NAV_MEM_OK;
}

int nav_heap_add_region(nav_heap *heap, void *memory, size_t bytes) {
    return nav_add_region(heap, memory, bytes, 0);
}

void nav_heap_set_provider(nav_heap *heap, nav_mem_acquire_fn acquire,
                           nav_mem_release_fn release, void *context,
                           size_t growth_minimum) {
    if (!heap) return;
    heap->acquire = acquire;
    heap->release = release;
    heap->provider_context = context;
    heap->growth_minimum = growth_minimum;
}

static nav_mem_block *nav_find_fit(nav_heap *h, size_t needed) {
    nav_mem_block *b;
    for (b = h->free_head; b; b = b->free_next) {
        if (nav_block_bytes(b) >= needed) return b;
    }
    return NULL;
}

static nav_mem_region *nav_region_for(const nav_heap *h, const void *p) {
    size_t i, point = (size_t)(uintptr_t)p;
    for (i = 0; i < h->region_count; ++i) {
        if (point >= (size_t)(uintptr_t)h->regions[i].begin &&
            point < (size_t)(uintptr_t)h->regions[i].end)
            return (nav_mem_region *)&h->regions[i];
    }
    return NULL;
}

static void nav_split_used(nav_heap *h, nav_mem_block *b,
                           nav_mem_region *r, size_t needed) {
    size_t oldsize = nav_block_bytes(b);
    nav_mem_block *tail, *after;
    size_t leftover;
    if (oldsize - needed < nav_min_block_bytes()) return;
    leftover = oldsize - needed;
    b->size_flags = needed | NAV_BLOCK_USED;
    tail = (nav_mem_block *)(void *)((unsigned char *)b + needed);
    nav_init_block(tail, leftover, needed, 0);
    after = (nav_mem_block *)(void *)((unsigned char *)tail + leftover);
    /* When shrinking, coalesce the split remainder with the free successor. */
    if ((unsigned char *)after < r->end && !nav_used(after)) {
        nav_free_unlink(h, after);
        tail->size_flags += nav_block_bytes(after);
        after->magic = 0;
    }
    after = (nav_mem_block *)(void *)((unsigned char *)tail + nav_block_bytes(tail));
    if ((unsigned char *)after < r->end) after->prev_size = nav_block_bytes(tail);
    nav_free_link(h, tail);
}

void *nav_heap_alloc(nav_heap *heap, size_t bytes) {
    size_t needed, request_size;
    nav_mem_block *block;
    nav_mem_region *region;
    void *memory;
    size_t acquired;
    if (!heap || bytes == 0) return NULL;
    if (bytes > SIZE_MAX - nav_header_bytes() ||
        !nav_align_up(bytes + nav_header_bytes(), &needed)) {
        ++heap->failed_allocations;
        return NULL;
    }
    block = nav_find_fit(heap, needed);
    if (!block && heap->acquire && heap->region_count < NAV_MEM_MAX_REGIONS) {
        request_size = needed > heap->growth_minimum ? needed : heap->growth_minimum;
        acquired = 0;
        memory = heap->acquire(heap->provider_context, request_size, &acquired);
        if (memory) {
            if (nav_add_region(heap, memory, acquired, 1) != NAV_MEM_OK) {
                if (heap->release) heap->release(heap->provider_context, memory, acquired);
            } else {
                block = nav_find_fit(heap, needed);
            }
        }
    }
    if (!block || heap->requested_in_use > SIZE_MAX - bytes) {
        ++heap->failed_allocations;
        return NULL;
    }
    nav_free_unlink(heap, block);
    block->size_flags |= NAV_BLOCK_USED;
    region = nav_region_for(heap, block);
    nav_split_used(heap, block, region, needed);
    block->requested = bytes;
    heap->requested_in_use += bytes;
    if (heap->requested_in_use > heap->requested_peak)
        heap->requested_peak = heap->requested_in_use;
    ++heap->active_allocations;
    if (heap->active_allocations > heap->peak_allocations)
        heap->peak_allocations = heap->active_allocations;
    return (unsigned char *)block + nav_header_bytes();
}

void *nav_heap_calloc(nav_heap *heap, size_t count, size_t size) {
    void *p;
    size_t bytes;
    if (size && count > SIZE_MAX / size) return NULL;
    bytes = count * size;
    p = nav_heap_alloc(heap, bytes);
    if (p) nav_fill_zero(p, bytes);
    return p;
}

/* Resolve and cross-check a candidate pointer before modifying metadata. */
static nav_mem_block *nav_checked_block(const nav_heap *h, const void *ptr,
                                        nav_mem_region **region_out) {
    nav_mem_region *r;
    nav_mem_block *b, *neighbor;
    size_t point, start, total, header = nav_header_bytes();
    if (!h || !ptr) return NULL;
    point = (size_t)(uintptr_t)ptr;
    r = nav_region_for(h, ptr);
    if (!r) return NULL;
    start = (size_t)(uintptr_t)r->begin;
    if (point < start + header || (point & (NAV_MEM_ALIGNMENT - 1u))) return NULL;
    b = (nav_mem_block *)(void *)(point - header);
    if (b->magic != NAV_BLOCK_MAGIC) return NULL;
    total = nav_block_bytes(b);
    if (total < nav_min_block_bytes() || (total & (NAV_MEM_ALIGNMENT - 1u)) ||
        total > (size_t)(r->end - (unsigned char *)b)) return NULL;
    if (b->requested > total - header) return NULL;
    if ((unsigned char *)b == r->begin) {
        if (b->prev_size != 0) return NULL;
    } else {
        if (b->prev_size < nav_min_block_bytes() ||
            (b->prev_size & (NAV_MEM_ALIGNMENT - 1u)) ||
            b->prev_size > (size_t)((unsigned char *)b - r->begin)) return NULL;
        neighbor = (nav_mem_block *)(void *)((unsigned char *)b - b->prev_size);
        if (neighbor->magic != NAV_BLOCK_MAGIC ||
            nav_block_bytes(neighbor) != b->prev_size) return NULL;
    }
    if ((unsigned char *)b + total < r->end) {
        neighbor = (nav_mem_block *)(void *)((unsigned char *)b + total);
        if (neighbor->magic != NAV_BLOCK_MAGIC || neighbor->prev_size != total)
            return NULL;
    }
    if (region_out) *region_out = r;
    return b;
}

int nav_heap_free(nav_heap *heap, void *ptr) {
    nav_mem_region *r;
    nav_mem_block *b, *next, *prev, *after;
    size_t size;
    if (!ptr) return NAV_MEM_OK;
    b = nav_checked_block(heap, ptr, &r);
    if (!b) return NAV_MEM_EINVAL;
    if (!nav_used(b)) return NAV_MEM_EINVAL;
    heap->requested_in_use -= b->requested;
    --heap->active_allocations;
    size = nav_block_bytes(b);
    b->size_flags = size;
    b->requested = 0;
    next = (nav_mem_block *)(void *)((unsigned char *)b + size);
    if ((unsigned char *)next < r->end && !nav_used(next)) {
        nav_free_unlink(heap, next);
        size += nav_block_bytes(next);
        b->size_flags = size;
        next->magic = 0;
    }
    if (b->prev_size) {
        prev = (nav_mem_block *)(void *)((unsigned char *)b - b->prev_size);
        if (!nav_used(prev)) {
            nav_free_unlink(heap, prev);
            prev->size_flags = nav_block_bytes(prev) + size;
            b->magic = 0;
            b = prev;
            size = nav_block_bytes(b);
        }
    }
    after = (nav_mem_block *)(void *)((unsigned char *)b + size);
    if ((unsigned char *)after < r->end) after->prev_size = size;
    nav_free_link(heap, b);
    return NAV_MEM_OK;
}

void *nav_heap_realloc(nav_heap *heap, void *ptr, size_t bytes) {
    nav_mem_block *b, *next;
    nav_mem_region *r;
    size_t need, old_requested, old_total, combined;
    void *replacement;
    if (!ptr) return nav_heap_alloc(heap, bytes);
    if (!bytes) { (void)nav_heap_free(heap, ptr); return NULL; }
    b = nav_checked_block(heap, ptr, &r);
    if (!b || !nav_used(b)) return NULL;
    if (bytes > SIZE_MAX - nav_header_bytes() ||
        !nav_align_up(bytes + nav_header_bytes(), &need)) return NULL;
    old_requested = b->requested;
    old_total = nav_block_bytes(b);
    if (need <= old_total) {
        if (bytes > old_requested && heap->requested_in_use > SIZE_MAX - (bytes - old_requested))
            return NULL;
        heap->requested_in_use = heap->requested_in_use - old_requested + bytes;
        if (heap->requested_in_use > heap->requested_peak)
            heap->requested_peak = heap->requested_in_use;
        b->requested = bytes;
        nav_split_used(heap, b, r, need);
        return ptr;
    }
    next = (nav_mem_block *)(void *)((unsigned char *)b + old_total);
    if ((unsigned char *)next < r->end && !nav_used(next) &&
        nav_block_bytes(next) <= SIZE_MAX - old_total) {
        combined = old_total + nav_block_bytes(next);
        if (combined >= need &&
            heap->requested_in_use <= SIZE_MAX - (bytes - old_requested)) {
            nav_free_unlink(heap, next);
            next->magic = 0;
            b->size_flags = combined | NAV_BLOCK_USED;
            next = (nav_mem_block *)(void *)((unsigned char *)b + combined);
            if ((unsigned char *)next < r->end) next->prev_size = combined;
            nav_split_used(heap, b, r, need);
            heap->requested_in_use += bytes - old_requested;
            if (heap->requested_in_use > heap->requested_peak)
                heap->requested_peak = heap->requested_in_use;
            b->requested = bytes;
            return ptr;
        }
    }
    replacement = nav_heap_alloc(heap, bytes);
    if (!replacement) return NULL;
    nav_copy(replacement, ptr, old_requested < bytes ? old_requested : bytes);
    (void)nav_heap_free(heap, ptr);
    return replacement;
}

void nav_heap_get_stats(const nav_heap *heap, nav_heap_stats *out) {
    size_t i, size;
    unsigned char *p;
    nav_mem_block *b;
    if (!out) return;
    nav_fill_zero(out, sizeof(*out));
    if (!heap) return;
    out->managed_bytes = heap->total_managed;
    out->requested_live_bytes = heap->requested_in_use;
    out->peak_requested_bytes = heap->requested_peak;
    out->live_allocations = heap->active_allocations;
    out->peak_allocations = heap->peak_allocations;
    out->failed_allocations = heap->failed_allocations;
    out->region_count = heap->region_count;
    for (i = 0; i < heap->region_count; ++i) {
        p = heap->regions[i].begin;
        while (p < heap->regions[i].end) {
            b = (nav_mem_block *)(void *)p;
            size = nav_block_bytes(b);
            if (size < nav_min_block_bytes() || size > (size_t)(heap->regions[i].end - p))
                return; /* Corrupt heap: run nav_heap_validate for diagnostics. */
            if (!nav_used(b)) {
                ++out->free_blocks;
                size -= nav_header_bytes();
                out->available_payload_bytes += size;
                if (size > out->largest_free_payload) out->largest_free_payload = size;
            }
            p += nav_block_bytes(b);
        }
    }
}

int nav_heap_validate(const nav_heap *heap) {
    size_t i, blocksize, previous, count_used = 0, requested = 0;
    size_t free_physical = 0, free_list_count = 0, found;
    const unsigned char *p;
    const nav_mem_block *b, *item, *prev_item;
    if (!heap) return NAV_MEM_EINVAL;
    for (i = 0; i < heap->region_count; ++i) {
        p = heap->regions[i].begin;
        previous = 0;
        while (p < heap->regions[i].end) {
            b = (const nav_mem_block *)(const void *)p;
            blocksize = nav_block_bytes(b);
            if (b->magic != NAV_BLOCK_MAGIC || b->prev_size != previous ||
                blocksize < nav_min_block_bytes() ||
                (blocksize & (NAV_MEM_ALIGNMENT - 1u)) ||
                blocksize > (size_t)(heap->regions[i].end - p))
                return NAV_MEM_ECORRUPT;
            if (nav_used(b)) {
                if (b->requested == 0 || b->requested > blocksize - nav_header_bytes() ||
                    requested > SIZE_MAX - b->requested) return NAV_MEM_ECORRUPT;
                ++count_used;
                requested += b->requested;
            } else {
                if (b->requested != 0) return NAV_MEM_ECORRUPT;
                ++free_physical;
                found = 0;
                for (item = heap->free_head; item; item = item->free_next) {
                    if (++found > heap->total_managed / nav_min_block_bytes())
                        return NAV_MEM_ECORRUPT; /* cycle or invalid list */
                    if (item == b) break;
                }
                if (!item) return NAV_MEM_ECORRUPT;
            }
            previous = blocksize;
            p += blocksize;
        }
    }
    prev_item = NULL;
    for (item = heap->free_head; item; item = item->free_next) {
        if (++free_list_count > free_physical ||
            !nav_region_for(heap, item) || item->magic != NAV_BLOCK_MAGIC ||
            nav_used(item) || item->free_prev != prev_item)
            return NAV_MEM_ECORRUPT;
        prev_item = item;
    }
    if (free_list_count != free_physical || count_used != heap->active_allocations ||
        requested != heap->requested_in_use) return NAV_MEM_ECORRUPT;
    return NAV_MEM_OK;
}

int nav_heap_destroy(nav_heap *heap) {
    size_t i;
    if (!heap) return NAV_MEM_EINVAL;
    if (heap->active_allocations) return NAV_MEM_EBUSY;
    if (heap->release) {
        for (i = 0; i < heap->region_count; ++i) {
            if (heap->regions[i].from_provider)
                heap->release(heap->provider_context,
                              heap->regions[i].backing_base,
                              heap->regions[i].backing_size);
        }
    }
    nav_heap_init(heap);
    return NAV_MEM_OK;
}

static size_t nav_chunk_header_bytes(void) {
    size_t n = offsetof(nav_arena_chunk, data);
    return (n + (NAV_MEM_ALIGNMENT - 1u)) & NAV_SIZE_MASK;
}

void nav_arena_init(nav_arena *arena, nav_heap *heap, size_t chunk_bytes) {
    if (!arena) return;
    nav_fill_zero(arena, sizeof(*arena));
    arena->heap = heap;
    arena->chunk_bytes = chunk_bytes ? chunk_bytes : 4096u;
    arena->generation = 1;
}

void *nav_arena_alloc(nav_arena *arena, size_t bytes) {
    size_t aligned, capacity, allocation_size;
    nav_arena_chunk *chunk;
    unsigned char *p;
    if (!arena || !arena->heap || !bytes ||
        !nav_align_up(bytes, &aligned) ||
        arena->requested_live > SIZE_MAX - bytes) return NULL;
    chunk = arena->tail;
    if (!chunk || aligned > chunk->capacity - chunk->used) {
        capacity = arena->chunk_bytes > aligned ? arena->chunk_bytes : aligned;
        if (!nav_align_up(capacity, &capacity) ||
            capacity > SIZE_MAX - nav_chunk_header_bytes()) return NULL;
        allocation_size = nav_chunk_header_bytes() + capacity;
        chunk = (nav_arena_chunk *)nav_heap_alloc(arena->heap, allocation_size);
        if (!chunk) return NULL;
        chunk->next = NULL;
        chunk->capacity = capacity;
        chunk->used = 0;
        if (arena->tail) arena->tail->next = chunk;
        else arena->head = chunk;
        arena->tail = chunk;
    }
    p = (unsigned char *)chunk + nav_chunk_header_bytes() + chunk->used;
    chunk->used += aligned;
    arena->requested_live += bytes;
    return p;
}

void *nav_arena_calloc(nav_arena *arena, size_t count, size_t size) {
    size_t bytes;
    void *p;
    if (size && count > SIZE_MAX / size) return NULL;
    bytes = count * size;
    p = nav_arena_alloc(arena, bytes);
    if (p) nav_fill_zero(p, bytes);
    return p;
}

nav_arena_mark nav_arena_get_mark(const nav_arena *arena) {
    nav_arena_mark mark;
    nav_fill_zero(&mark, sizeof(mark));
    if (!arena) return mark;
    mark.owner = arena;
    mark.chunk = arena->tail;
    mark.used = arena->tail ? arena->tail->used : 0;
    mark.requested_live = arena->requested_live;
    mark.generation = arena->generation;
    return mark;
}

int nav_arena_rewind(nav_arena *arena, nav_arena_mark mark) {
    nav_arena_chunk *c, *next;
    if (!arena || mark.owner != arena || mark.generation != arena->generation ||
        mark.requested_live > arena->requested_live) return NAV_MEM_EINVAL;
    if (mark.chunk) {
        for (c = arena->head; c && c != mark.chunk; c = c->next) { }
        if (!c || mark.used > c->used) return NAV_MEM_EINVAL;
        c = mark.chunk->next;
        mark.chunk->next = NULL;
        arena->tail = mark.chunk;
        mark.chunk->used = mark.used;
    } else {
        if (mark.used != 0 || mark.requested_live != 0) return NAV_MEM_EINVAL;
        c = arena->head;
        arena->head = NULL;
        arena->tail = NULL;
    }
    while (c) {
        next = c->next;
        (void)nav_heap_free(arena->heap, c);
        c = next;
    }
    arena->requested_live = mark.requested_live;
    return NAV_MEM_OK;
}

void nav_arena_reset(nav_arena *arena) {
    nav_arena_chunk *c, *next;
    if (!arena) return;
    for (c = arena->head; c; c = next) {
        next = c->next;
        (void)nav_heap_free(arena->heap, c);
    }
    arena->head = NULL;
    arena->tail = NULL;
    arena->requested_live = 0;
    ++arena->generation;
    if (arena->generation == 0) arena->generation = 1;
}
