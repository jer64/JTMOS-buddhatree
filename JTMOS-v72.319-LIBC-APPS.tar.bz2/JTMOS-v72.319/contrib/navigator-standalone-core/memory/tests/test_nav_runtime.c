#include "nav_runtime.h"
#include <assert.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define MiB (1024u * 1024u)
static _Alignas(16) unsigned char page_pool[2u * MiB];
static _Alignas(16) unsigned char scratch_pool[256u * 1024u];
static _Alignas(16) unsigned char p_region[65536];

typedef struct test_node {
    struct test_node *a;
    struct test_node *b;
    void *dom_non_gc;
    unsigned generation;
} test_node;

static void node_trace(nav_gc *gc, void *obj, void *ctx) {
    test_node *n = (test_node *)obj;
    (void)ctx;
    nav_gc_mark(gc, n->a);
    nav_gc_mark(gc, n->b);
    /* DOM arena pointers are deliberately NOT traversed here. */
}

static void test_gc_graph(void) {
    nav_page page;
    nav_gc gc;
    nav_arena dom;
    nav_gc_root root;
    nav_gc_stats s;
    nav_heap_stats hs;
    void *top = NULL;
    test_node *a, *b, *c, *d;
    nav_page_init(&page, sizeof(page_pool));
    assert(nav_page_add_region(&page, page_pool, sizeof(page_pool)) == NAV_MEM_OK);
    nav_gc_init(&gc, &page);
    nav_page_arena_init(&page, &dom, 4096);
    nav_gc_root_init(&root);
    assert(nav_gc_root_add(&gc, &root, &top) == NAV_MEM_OK);
    assert(nav_gc_root_add(&gc, &root, &top) == NAV_MEM_EBUSY);
    a = (test_node *)nav_gc_new(&gc, sizeof(*a), node_trace, NULL);
    b = (test_node *)nav_gc_new(&gc, sizeof(*b), node_trace, NULL);
    c = (test_node *)nav_gc_new(&gc, sizeof(*c), node_trace, NULL);
    d = (test_node *)nav_gc_new(&gc, sizeof(*d), node_trace, NULL);
    assert(a && b && c && d);
    a->a = b; b->b = a; /* reachable cycle */
    c->a = d; d->b = c; /* unreachable cycle */
    a->dom_non_gc = nav_page_arena_calloc(&page, &dom, 1, 128);
    assert(a->dom_non_gc);
    top = a;
    assert(nav_gc_collect(&gc) == 2);
    nav_gc_get_stats(&gc, &s);
    assert(s.live_objects == 2 && s.collections == 1);
    /* Invalid pointers passed to mark are ignored rather than dereferenced. */
    assert(nav_gc_collect(&gc) == 0);
    top = NULL;
    assert(nav_gc_collect(&gc) == 2);
    assert(nav_gc_root_remove(&gc, &root) == NAV_MEM_OK);
    assert(nav_gc_root_remove(&gc, &root) == NAV_MEM_EINVAL);
    nav_page_arena_reset(&page, &dom);
    nav_page_get_stats(&page, &hs, NULL, NULL);
    assert(hs.live_allocations == 0);
    assert(nav_heap_validate(&page.heap) == NAV_MEM_OK);
    assert(nav_page_destroy(&page) == NAV_MEM_OK);
    puts("GC cycles + roots + DOM arena separation: OK");
}

static void test_deep_graph(void) {
    nav_page page;
    nav_gc gc;
    nav_gc_root root;
    nav_gc_stats stats;
    test_node *head = NULL;
    void *global_ref = NULL;
    size_t i;
    nav_page_init(&page, sizeof(page_pool));
    assert(nav_page_add_region(&page, page_pool, sizeof(page_pool)) == NAV_MEM_OK);
    nav_gc_init(&gc, &page);
    nav_gc_root_init(&root);
    assert(nav_gc_root_add(&gc, &root, &global_ref) == NAV_MEM_OK);
    for (i = 0; i < 12000; i++) {
        test_node *n = (test_node *)nav_gc_new(&gc, sizeof(*n), node_trace, NULL);
        assert(n);
        n->a = head;
        head = n;
        global_ref = head;
    }
    assert(nav_gc_collect(&gc) == 0);
    nav_gc_get_stats(&gc, &stats);
    assert(stats.live_objects == 12000);
    assert(nav_gc_root_remove(&gc, &root) == NAV_MEM_OK);
    assert(nav_gc_collect(&gc) == 12000);
    assert(nav_heap_validate(&page.heap) == NAV_MEM_OK);
    assert(nav_page_destroy(&page) == NAV_MEM_OK);
    puts("12,000-node nonrecursive graph traversal: OK");
}

static void test_quota_and_arena(void) {
    nav_page page;
    nav_arena arena;
    nav_arena_mark mark;
    nav_heap_stats stats;
    size_t backing, denials;
    void *p;
    nav_page_init(&page, sizeof(scratch_pool));
    assert(nav_page_add_region(&page, page_pool, sizeof(page_pool)) == NAV_MEM_ENOMEM);
    assert(nav_page_add_region(&page, scratch_pool, sizeof(scratch_pool)) == NAV_MEM_OK);
    nav_page_arena_init(&page, &arena, 4096);
    mark = nav_page_arena_get_mark(&page, &arena);
    assert(nav_page_arena_calloc(&page, &arena, 32, 32));
    assert(nav_page_arena_rewind(&page, &arena, mark) == NAV_MEM_OK);
    assert(nav_page_alloc(&page, 512u * 1024u) == NULL);
    p = nav_page_alloc(&page, 128u * 1024u);
    assert(p);
    memset(p, 0x5a, 128u * 1024u);
    assert(nav_page_realloc(&page, p, 256u * 1024u) == NULL);
    assert(((unsigned char *)p)[0] == 0x5a);
    assert(nav_page_free(&page, p) == NAV_MEM_OK);
    nav_page_arena_reset(&page, &arena);
    nav_page_get_stats(&page, &stats, &backing, &denials);
    assert(backing == sizeof(scratch_pool) && denials == 1);
    assert(stats.live_allocations == 0 && nav_heap_validate(&page.heap) == NAV_MEM_OK);
    assert(nav_page_destroy(&page) == NAV_MEM_OK);
    puts("Per-page quota + arena wrappers + realloc failure safety: OK");
}

typedef struct provider_state { unsigned acquisitions, releases; } provider_state;
static void *provider_acquire(void *ctx, size_t min, size_t *actual) {
    provider_state *s = (provider_state *)ctx;
    ++s->acquisitions;
    if (min > sizeof(p_region)) return NULL;
    *actual = sizeof(p_region);
    return p_region;
}
static void provider_release(void *ctx, void *mem, size_t actual) {
    provider_state *s = (provider_state *)ctx;
    assert(mem == p_region && actual == sizeof(p_region));
    ++s->releases;
}
static void test_provider_quota(void) {
    nav_page p;
    provider_state s = {0, 0};
    void *obj;
    size_t backing, denials;
    nav_page_init(&p, 50000);
    assert(nav_page_set_provider(&p, provider_acquire, NULL, &s, 4096) == NAV_MEM_EINVAL);
    assert(nav_page_set_provider(&p, provider_acquire, provider_release, &s, 4096) == NAV_MEM_OK);
    obj = nav_page_alloc(&p, 1000);
    assert(obj == NULL && s.acquisitions == 1 && s.releases == 1);
    nav_page_get_stats(&p, NULL, &backing, &denials);
    assert(backing == 0 && denials == 1);
    assert(nav_page_destroy(&p) == NAV_MEM_OK);
    nav_page_init(&p, sizeof(p_region));
    assert(nav_page_set_provider(&p, provider_acquire, provider_release, &s, 8192) == NAV_MEM_OK);
    obj = nav_page_alloc(&p, 2000);
    assert(obj != NULL && s.acquisitions == 2);
    assert(nav_page_alloc(&p, 75000) == NULL);
    assert(nav_page_free(&p, obj) == NAV_MEM_OK);
    assert(nav_page_destroy(&p) == NAV_MEM_OK);
    assert(s.releases == 2);
    puts("Provider exact backing quota + rejected allocation release: OK");
}

typedef struct worker_ctx { nav_page *page; unsigned seed; } worker_ctx;
static void *worker(void *param) {
    worker_ctx *w = (worker_ctx *)param;
    unsigned i;
    for (i = 0; i < 2500; ++i) {
        unsigned char *p;
        size_t n = (w->seed + 31u * i) % 1023u + 1;
        p = (unsigned char *)nav_page_alloc(w->page, n);
        assert(p);
        memset(p, (int)(i & 255u), n);
        assert(p[n-1] == (unsigned char)(i & 255u));
        assert(nav_page_free(w->page, p) == NAV_MEM_OK);
    }
    return NULL;
}
static void mutex_lock(void *ctx) { assert(pthread_mutex_lock((pthread_mutex_t *)ctx) == 0); }
static void mutex_unlock(void *ctx) { assert(pthread_mutex_unlock((pthread_mutex_t *)ctx) == 0); }
static void test_multithread(void) {
    enum { NWORKERS = 6 };
    pthread_t threads[NWORKERS];
    worker_ctx workers[NWORKERS];
    pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
    nav_page page;
    nav_heap_stats stats;
    int i;
    nav_page_init(&page, sizeof(page_pool));
    assert(nav_page_add_region(&page, page_pool, sizeof(page_pool)) == NAV_MEM_OK);
    assert(nav_page_set_lock(&page, mutex_lock, mutex_unlock, &mutex) == NAV_MEM_OK);
    for (i = 0; i < NWORKERS; ++i) {
        workers[i].page = &page;
        workers[i].seed = (unsigned)i * 17u;
        assert(pthread_create(&threads[i], NULL, worker, &workers[i]) == 0);
    }
    for (i = 0; i < NWORKERS; ++i) assert(pthread_join(threads[i], NULL) == 0);
    nav_page_get_stats(&page, &stats, NULL, NULL);
    assert(stats.live_allocations == 0);
    assert(nav_heap_validate(&page.heap) == NAV_MEM_OK);
    assert(nav_page_destroy(&page) == NAV_MEM_OK);
    assert(pthread_mutex_destroy(&mutex) == 0);
    puts("6 threads x 2,500 allocations + lock injection: OK");
}

static void test_automatic_gc(void) {
    nav_page page;
    nav_gc gc;
    nav_gc_stats stats;
    size_t i;
    nav_page_init(&page, 32768);
    assert(nav_page_add_region(&page, page_pool, 32768) == NAV_MEM_OK);
    nav_gc_init(&gc, &page);
    nav_gc_set_threshold(&gc, 64); /* 2 objects of 40 bytes => collect */
    for (i = 0; i < 100; ++i)
        assert(nav_gc_new(&gc, 40, NULL, NULL) != NULL);
    nav_gc_get_stats(&gc, &stats);
    assert(stats.automatic_collections >= 40);
    assert(stats.live_objects <= 2);
    assert(nav_gc_collect(&gc) == stats.live_objects);
    assert(nav_page_destroy(&page) == NAV_MEM_OK);

    /* Disable periodic GC; filling the page must invoke an automatic
     * stop-the-world collection once at allocation failure. */
    nav_page_init(&page, 32768);
    assert(nav_page_add_region(&page, page_pool, 32768) == NAV_MEM_OK);
    nav_gc_init(&gc, &page);
    nav_gc_set_threshold(&gc, 0);
    for (i = 0; i < 100; ++i)
        assert(nav_gc_new(&gc, 1024, NULL, NULL) != NULL);
    nav_gc_get_stats(&gc, &stats);
    assert(stats.automatic_collections >= 1);
    assert(stats.total_collected_objects > 0);
    nav_gc_reset(&gc);
    assert(nav_page_destroy(&page) == NAV_MEM_OK);
    puts("Automatic threshold GC and out-of-memory GC retry: OK");
}

static void test_navigation_reset(void) {
    nav_page page;
    nav_gc gc;
    nav_gc_root r;
    nav_arena dom;
    nav_gc_stats stats;
    void *global = NULL;
    nav_page_init(&page, sizeof(page_pool));
    assert(nav_page_add_region(&page, page_pool, sizeof(page_pool)) == NAV_MEM_OK);
    nav_gc_init(&gc, &page);
    nav_page_arena_init(&page, &dom, 4096);
    nav_gc_root_init(&r);
    assert(nav_gc_root_add(&gc, &r, &global) == NAV_MEM_OK);
    global = nav_gc_new(&gc, 100, NULL, NULL);
    assert(global && nav_page_arena_alloc(&page, &dom, 100));
    assert(nav_page_destroy(&page) == NAV_MEM_EBUSY);
    nav_gc_reset(&gc);  /* after stopping JS callbacks and workers */
    global = NULL;     /* DOM/JS bridge must clear dangling handles */
    assert(r.owner == NULL);
    nav_page_arena_reset(&page, &dom);
    nav_gc_get_stats(&gc, &stats);
    assert(stats.live_objects == 0);
    assert(nav_page_destroy(&page) == NAV_MEM_OK);
    puts("Page navigation reset / empty heap for destruction: OK");
}

int main(void) {
    test_gc_graph();
    test_deep_graph();
    test_quota_and_arena();
    test_provider_quota();
    test_multithread();
    test_navigation_reset();
    test_automatic_gc();
    puts("ALL RUNTIME TESTS PASSED");
    return 0;
}
