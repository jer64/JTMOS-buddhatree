/* Host-only test harness; nav_mem.c itself remains completely freestanding. */
#include "nav_mem.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define POOL_SIZE (512u * 1024u)
static _Alignas(16) unsigned char pool[POOL_SIZE];
static _Alignas(16) unsigned char extra_a[65536];
static _Alignas(16) unsigned char extra_b[65536];

typedef struct {
    int obtained;
    int released;
} provider_state;

static void *get_more(void *ctx, size_t min, size_t *actual) {
    provider_state *state = (provider_state *)ctx;
    if (min > sizeof(extra_a)) return NULL;
    if (state->obtained == 0) {
        ++state->obtained;
        *actual = sizeof(extra_a);
        return extra_a;
    }
    if (state->obtained == 1) {
        ++state->obtained;
        *actual = sizeof(extra_b);
        return extra_b;
    }
    return NULL;
}

static void release_more(void *ctx, void *ptr, size_t actual) {
    provider_state *state = (provider_state *)ctx;
    assert((ptr == extra_a || ptr == extra_b) && actual == sizeof(extra_a));
    ++state->released;
}

static uint32_t random_state = 0x12345678u;
static uint32_t next_random(void) {
    random_state ^= random_state << 13;
    random_state ^= random_state >> 17;
    random_state ^= random_state << 5;
    return random_state;
}

static void basic_test(void) {
    nav_heap h;
    nav_heap_stats s;
    unsigned char *a, *b, *c, *d;
    size_t i;
    nav_heap_init(&h);
    assert(nav_heap_add_region(&h, pool, sizeof(pool)) == NAV_MEM_OK);
    assert(nav_heap_add_region(&h, pool + 4096, 2048) == NAV_MEM_EINVAL);
    assert(nav_heap_validate(&h) == NAV_MEM_OK);
    a = nav_heap_alloc(&h, 100);
    b = nav_heap_alloc(&h, 300);
    c = nav_heap_calloc(&h, 256, 2);
    assert(a && b && c);
    assert(((uintptr_t)a & 15u) == 0 && ((uintptr_t)b & 15u) == 0);
    for (i = 0; i < 100; ++i) a[i] = (unsigned char)i;
    for (i = 0; i < 512; ++i) assert(c[i] == 0);
    assert(nav_heap_free(&h, c) == NAV_MEM_OK);
    assert(nav_heap_free(&h, b) == NAV_MEM_OK);
    d = nav_heap_realloc(&h, a, 700);
    assert(d == a); /* Expands in place into freed neighbor. */
    for (i = 0; i < 100; ++i) assert(d[i] == (unsigned char)i);
    a = nav_heap_realloc(&h, d, 40);
    assert(a == d);
    for (i = 0; i < 40; ++i) assert(a[i] == (unsigned char)i);
    assert(nav_heap_validate(&h) == NAV_MEM_OK);
    assert(nav_heap_free(&h, a + 1) == NAV_MEM_EINVAL);
    assert(nav_heap_free(&h, a) == NAV_MEM_OK);
    assert(nav_heap_free(&h, a) == NAV_MEM_EINVAL);
    assert(nav_heap_calloc(&h, SIZE_MAX, SIZE_MAX) == NULL);
    assert(nav_heap_alloc(&h, SIZE_MAX) == NULL);
    nav_heap_get_stats(&h, &s);
    assert(s.live_allocations == 0 && s.requested_live_bytes == 0);
    assert(s.free_blocks == 1 && s.region_count == 1);
    assert(nav_heap_validate(&h) == NAV_MEM_OK);
    assert(nav_heap_destroy(&h) == NAV_MEM_OK);
    puts("basic allocator / realloc / coalescing: OK");
}

static void arena_test(void) {
    nav_heap h;
    nav_arena dom, frame;
    nav_arena_mark mark;
    nav_heap_stats stats;
    unsigned char *p;
    size_t i;
    nav_heap_init(&h);
    assert(nav_heap_add_region(&h, pool, sizeof(pool)) == NAV_MEM_OK);
    nav_arena_init(&dom, &h, 4096);
    nav_arena_init(&frame, &h, 1024);
    for (i = 0; i < 500; ++i) {
        p = nav_arena_alloc(&dom, 65);
        assert(p && ((uintptr_t)p & 15u) == 0);
        p[0] = (unsigned char)(i & 255u);
    }
    mark = nav_arena_get_mark(&dom);
    for (i = 0; i < 80; ++i) assert(nav_arena_calloc(&dom, 10, 9));
    assert(nav_arena_rewind(&dom, mark) == NAV_MEM_OK);
    assert(dom.requested_live == 500u * 65u);
    assert(nav_arena_alloc(&frame, 200));
    nav_arena_reset(&frame);
    nav_arena_reset(&dom);
    assert(nav_arena_rewind(&dom, mark) == NAV_MEM_EINVAL);
    nav_heap_get_stats(&h, &stats);
    assert(stats.live_allocations == 0);
    assert(nav_heap_validate(&h) == NAV_MEM_OK);
    assert(nav_heap_destroy(&h) == NAV_MEM_OK);
    puts("DOM and scratch arenas / marks / rewind: OK");
}

static void provider_test(void) {
    nav_heap h;
    provider_state state = {0, 0};
    void *a, *b;
    nav_heap_init(&h);
    nav_heap_set_provider(&h, get_more, release_more, &state, 16384);
    a = nav_heap_alloc(&h, 30000);
    b = nav_heap_alloc(&h, 40000);
    assert(a && b && state.obtained == 2);
    assert(nav_heap_destroy(&h) == NAV_MEM_EBUSY);
    assert(nav_heap_free(&h, a) == NAV_MEM_OK);
    assert(nav_heap_free(&h, b) == NAV_MEM_OK);
    assert(nav_heap_validate(&h) == NAV_MEM_OK);
    assert(nav_heap_destroy(&h) == NAV_MEM_OK);
    assert(state.released == 2);
    puts("on-demand growth / OS backing provider / cleanup: OK");
}

#define SLOTS 128
#define OPERATIONS 8000

typedef struct { unsigned char *ptr; size_t n; unsigned char stamp; } slot;
static void stress_test(void) {
    nav_heap h;
    slot slots[SLOTS] = {{0}};
    size_t i, j, k, n;
    unsigned index;
    unsigned char *replacement;
    nav_heap_stats s;
    nav_heap_init(&h);
    assert(nav_heap_add_region(&h, pool, sizeof(pool)) == NAV_MEM_OK);
    for (i = 0; i < OPERATIONS; ++i) {
        index = next_random() % SLOTS;
        if (slots[index].ptr) {
            for (j = 0; j < slots[index].n; ++j)
                assert(slots[index].ptr[j] == slots[index].stamp);
            if ((next_random() & 3u) == 0) {
                n = 1 + next_random() % 2500;
                replacement = nav_heap_realloc(&h, slots[index].ptr, n);
                if (replacement) {
                    k = slots[index].n < n ? slots[index].n : n;
                    for (j = 0; j < k; ++j)
                        assert(replacement[j] == slots[index].stamp);
                    slots[index].ptr = replacement;
                    slots[index].n = n;
                    memset(replacement, slots[index].stamp, n);
                }
            } else {
                assert(nav_heap_free(&h, slots[index].ptr) == NAV_MEM_OK);
                slots[index].ptr = NULL;
            }
        } else {
            n = 1 + next_random() % 2500;
            replacement = nav_heap_alloc(&h, n);
            if (replacement) {
                slots[index].ptr = replacement;
                slots[index].n = n;
                slots[index].stamp = (unsigned char)(next_random() & 255u);
                memset(replacement, slots[index].stamp, n);
            }
        }
        if (i % 173u == 0) assert(nav_heap_validate(&h) == NAV_MEM_OK);
    }
    for (i = 0; i < SLOTS; ++i) {
        if (slots[i].ptr) {
            for (j = 0; j < slots[i].n; ++j)
                assert(slots[i].ptr[j] == slots[i].stamp);
            assert(nav_heap_free(&h, slots[i].ptr) == NAV_MEM_OK);
        }
    }
    assert(nav_heap_validate(&h) == NAV_MEM_OK);
    nav_heap_get_stats(&h, &s);
    assert(s.live_allocations == 0 && s.free_blocks == 1);
    assert(nav_heap_destroy(&h) == NAV_MEM_OK);
    puts("8000 randomized alloc/free/realloc operations: OK");
}

int main(void) {
    basic_test();
    arena_test();
    provider_test();
    stress_test();
    puts("ALL TESTS PASSED");
    return 0;
}
