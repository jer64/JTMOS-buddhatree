/* JTMOS Navigator v2 memory integration sketch. Does NOT depend on JTMOS ABI:
 * The caller supplies a writable, pinned, dedicated region and optional mutex.
 * Replace JTMOS mutex function declarations with verified kernel/syscall ABI.
 * Keep all JS VM mutation on the owning thread or implement a safepoint.
 */
#include "nav_runtime.h"

typedef struct navigator_js_node {
    struct navigator_js_node *next;
    unsigned type;
} navigator_js_node;

typedef struct navigator_context {
    nav_page page;
    nav_gc gc;
    nav_arena dom;
    nav_arena scratch;
    nav_gc_root document_root;
    void *document_js_root;    /* exact GC root slot, not a transient local */
} navigator_context;

static void js_node_trace(nav_gc *gc, void *object, void *unused) {
    navigator_js_node *node = (navigator_js_node *)object;
    (void)unused;
    nav_gc_mark(gc, node->next);
}

int navigator_context_init(navigator_context *ctx, void *memory, size_t bytes) {
    if (!ctx || !memory || bytes < 65536u) return NAV_MEM_EINVAL;
    nav_page_init(&ctx->page, bytes);
    if (nav_page_add_region(&ctx->page, memory, bytes) != NAV_MEM_OK)
        return NAV_MEM_ENOMEM;
    nav_gc_init(&ctx->gc, &ctx->page);
    nav_page_arena_init(&ctx->page, &ctx->dom, 32768u);
    nav_page_arena_init(&ctx->page, &ctx->scratch, 8192u);
    ctx->document_js_root = NULL;
    nav_gc_root_init(&ctx->document_root);
    return nav_gc_root_add(&ctx->gc, &ctx->document_root,
                           &ctx->document_js_root);
}

navigator_js_node *navigator_new_js_node(navigator_context *ctx) {
    if (!ctx) return NULL;
    return (navigator_js_node *)nav_gc_new(&ctx->gc, sizeof(navigator_js_node),
                                           js_node_trace, NULL);
}

void navigator_begin_document(navigator_context *ctx) {
    /* Event queue and VM must be stopped and all old GC references cleared. */
    ctx->document_js_root = NULL;
    (void)nav_gc_collect(&ctx->gc);
    nav_page_arena_reset(&ctx->page, &ctx->dom);
    nav_page_arena_reset(&ctx->page, &ctx->scratch);
}

int navigator_context_shutdown(navigator_context *ctx) {
    if (!ctx) return NAV_MEM_EINVAL;
    ctx->document_js_root = NULL;
    (void)nav_gc_root_remove(&ctx->gc, &ctx->document_root);
    nav_gc_reset(&ctx->gc);
    nav_page_arena_reset(&ctx->page, &ctx->dom);
    nav_page_arena_reset(&ctx->page, &ctx->scratch);
    return nav_page_destroy(&ctx->page);
}
