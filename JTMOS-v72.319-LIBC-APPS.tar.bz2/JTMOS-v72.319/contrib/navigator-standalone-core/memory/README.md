# Navigator Memory Runtime v2 – standalone JTMOS integration foundation

This is a **freestanding C11** memory library with no external runtime dependencies in `src/`.
It is NOT a compiled JTMOS release: the actual Navigator and `sysmemreq` ABI are not supplied.

## Features

- `nav_mem.c/.h`: 16-byte aligned free-list allocator with block splitting,
  coalescing, `realloc`, `calloc`, owned/borrowed regions and arenas.
- `nav_runtime.c/.h`: per-page backing memory quota, page-aware arena wrappers,
  exact non-moving mark/sweep JavaScript object collector (cycles supported),
  explicit root registration, allocation threshold GC and GC retry on OOM.
- Optional lock/unlock callbacks for page/heap operations. **The VM graph must be
  quiescent during collection**; an allocator mutex alone cannot protect a JS
  object graph that is being mutated concurrently.
- Object trace callbacks enumerate direct GC child pointers. DOM arena pointers
  must not outlive a document, and JS/DOM wrappers need explicit invalidation.

## Build & tests

```sh
make clean && make test
make freestanding
# Optional sanitizers on a host with Clang:
clang -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer \
  -std=c11 -Wall -Wextra -Werror -Isrc -pthread \
  src/nav_mem.c src/nav_runtime.c tests/test_nav_runtime.c -o test_nav_runtime_san
./test_nav_runtime_san
```

Tests cover 12,000-node nonrecursive GC traversal, cycles and exact roots,
OOM retry, quotas including metadata and fragmentation, and 6 concurrent
allocators using a user-provided host pthread lock. The source modules themselves
never call pthread or libc.

## JTMOS integration

`examples/jtmos_integration.c` is an ABI-agnostic example using a preallocated,
exclusive memory region. For real JTMOS, hook `nav_page_set_provider` to the verified
kernel memory allocation and release signatures, or supply retained regions.
Attach JTMOS mutex callbacks via `nav_page_set_lock` before starting threads.

**Important:** Register every live JS VM local, stack slot, global, closure and
asynchronous task handle as a reachable GC root **before subsequent allocations**.
Unregistered local variables are not automatically traced. The collector is not
safe if VM mutation runs concurrently. Do not treat this as an audited production GC.

Memory ownership rules and application teardown are requirements for a leak-free
browser; the allocator alone cannot guarantee there are no retained references.
