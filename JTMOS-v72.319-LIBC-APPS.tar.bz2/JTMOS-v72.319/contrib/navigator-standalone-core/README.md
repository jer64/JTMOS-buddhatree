# Navigator standalone components — JTMOS v72.204

memory/ retains the earlier Memory v2 free-list/arena/GC/quota source.
It is not substituted for the current browser allocator in this release.

tls13/ extends Crypto v1 to the TLS1.3 v2 client and restricted RSA/SHA256
certificate profile. Its src/ is an identical release copy of the canonical
integrated code under libc/libc/network/tls13/. The full JTMOS source tree
also supplies the real socket/entropy/clock/HTTP adapter and native binaries.

Run each module's Makefile/tests; see tls13/README.md and the release-root
NAVIGATOR-TLS13-V72.204.md for API, validation evidence and profile limits.
