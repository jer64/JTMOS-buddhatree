# JTMOS Screen v0.1 – portability preview

This is an independently implemented, MIT-licensed **screen-like prototype**, not GNU Screen source or a native JTMOS binary.

## Build and test on Linux
`make && make check && ./screen /bin/sh`

## Keys
Ctrl-A c: new window; Ctrl-A n/p: next/previous; Ctrl-A 0..7: select; Ctrl-A k: terminate child; Ctrl-A ?: help; Ctrl-A a: send literal Ctrl-A; Ctrl-A d: exit and terminate children.

## JTMOS integration plan
1. Replace POSIX PTY calls (`posix_openpt`, `grantpt`, `unlockpt`, `ptsname`, `TIOCSCTTY`) with JTMOS PTY master/slave allocation, or add a POSIX-compatible PTY layer to kernel32 and libc.
2. Confirm `fork`, `setsid`, `exec`, `waitpid`, `kill`, `poll`, `termios`, `ioctl(TIOCGWINSZ/TIOCSWINSZ)` and SIGWINCH semantics; add missing calls or implement a JTMOS process/session adapter.
3. Build as i486 freestanding JTMOS app linked against JTMOS libc, not host libc.
4. Validate with SQSH, ircII and BitchX, including canonical/raw input, ANSI escape sequences, window resize and process exit.
5. Add terminal screen buffers, scrollback, real detach/reattach via persistent supervisor, socket IPC, and robust session cleanup.

## Limitations
This preview does **not** implement GNU Screen protocol/config, scrollback, persistent detach/reattach, session restoration, or a native JTMOS backend. Inactive window output is discarded. Ctrl-A d exits and terminates children, rather than detaching. Input/output buffering is minimal. No claims of native JTMOS compilation or execution are made.
