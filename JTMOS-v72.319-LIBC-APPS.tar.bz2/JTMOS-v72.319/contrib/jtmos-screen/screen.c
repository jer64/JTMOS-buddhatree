/*
 * JTMOS Screen preview: portable multi-session terminal manager.
 * Host backend: POSIX PTYs. JTMOS requires PTY/TTY backend port.
 * SPDX-License-Identifier: MIT
 */
#define _XOPEN_SOURCE 600
#define _DEFAULT_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <termios.h>
#include <unistd.h>
#define MAX_SESSIONS 8
#define BUFFER 4096
typedef struct {int master; pid_t child; int alive; char label[32];} Session;
static Session sessions[MAX_SESSIONS];
static int active=-1, count=0, raw_enabled=0;
static struct termios saved;
static volatile sig_atomic_t resized=0, stopped=0;
static void on_resize(int sig){(void)sig;resized=1;}
static void on_stop(int sig){(void)sig;stopped=1;}
static void restore(void){if(raw_enabled)tcsetattr(STDIN_FILENO,TCSANOW,&saved);raw_enabled=0;}
static int raw_mode(void){
 struct termios t;
 if(tcgetattr(STDIN_FILENO,&saved)<0)return -1;
 t=saved;cfmakeraw(&t);
 if(tcsetattr(STDIN_FILENO,TCSANOW,&t)<0)return -1;
 raw_enabled=1;return 0;
}
static void write_all(int fd,const void *buf,size_t n){
 const char *p=buf;
 while(n){ssize_t k=write(fd,p,n);if(k>0){p+=k;n-=(size_t)k;}else if(k<0&&errno==EINTR)continue;else break;}
}
static void terminal_size(int fd){
 struct winsize ws;
 if(ioctl(STDIN_FILENO,TIOCGWINSZ,&ws)==0)ioctl(fd,TIOCSWINSZ,&ws);
}
static int spawn(const char *shell){
 int fd=posix_openpt(O_RDWR|O_NOCTTY);
 if(fd<0||grantpt(fd)<0||unlockpt(fd)<0){if(fd>=0)close(fd);return -1;}
 char *name=ptsname(fd);
 if(!name){close(fd);return -1;}
 pid_t pid=fork();
 if(pid<0){close(fd);return -1;}
 if(pid==0){
  setsid();
  int slave=open(name,O_RDWR);
  if(slave<0)_exit(126);
  ioctl(slave,TIOCSCTTY,0);
  dup2(slave,STDIN_FILENO);dup2(slave,STDOUT_FILENO);dup2(slave,STDERR_FILENO);
  if(slave>2)close(slave);close(fd);
  execlp(shell,shell,(char*)NULL);_exit(127);
 }
 for(int i=0;i<MAX_SESSIONS;i++)if(!sessions[i].alive){
  sessions[i].master=fd;sessions[i].child=pid;sessions[i].alive=1;
  snprintf(sessions[i].label,sizeof(sessions[i].label),"window %d",i);
  active=i;count++;terminal_size(fd);return i;
 }
 kill(pid,SIGHUP);close(fd);waitpid(pid,NULL,0);return -1;
}
static void banner(void){
 char b[160];
 int n=snprintf(b,sizeof(b),"\r\n\033[7m JTMOS Screen | window %d | Ctrl-A ? help \033[0m\r\n",active);
 if(n>0)write_all(STDOUT_FILENO,b,(size_t)n);
}
static void help(void){
 const char *s="\r\nJTMOS Screen: Ctrl-A c create | n next | p previous | 0-7 select | k kill | ? help | a literal Ctrl-A | d detach/exit\r\n";
 write_all(STDOUT_FILENO,s,strlen(s));
}
static void switch_to(int idx){
 if(idx<0||idx>=MAX_SESSIONS||!sessions[idx].alive)return;
 active=idx;terminal_size(sessions[idx].master);
 write_all(STDOUT_FILENO,"\033[2J\033[H",7);banner();
}
static void cycle(int direction){
 if(count==0)return;
 for(int j=1;j<=MAX_SESSIONS;j++){
  int idx=(active+direction*j+MAX_SESSIONS*2)%MAX_SESSIONS;
  if(sessions[idx].alive){switch_to(idx);return;}
 }
}
static void close_session(int i){
 if(i<0||!sessions[i].alive)return;
 close(sessions[i].master);sessions[i].alive=0;count--;
 if(i==active){active=-1;cycle(1);}
}
static void reap(void){
 int status;pid_t p;
 while((p=waitpid(-1,&status,WNOHANG))>0)
  for(int i=0;i<MAX_SESSIONS;i++)if(sessions[i].alive&&sessions[i].child==p){close_session(i);break;}
}
int main(int argc,char **argv){
 const char *shell=(argc>1)?argv[1]:getenv("SHELL");
 if(!shell||!*shell)shell="/bin/sh";
 for(int i=0;i<MAX_SESSIONS;i++)sessions[i].master=-1;
 if(!isatty(STDIN_FILENO)||!isatty(STDOUT_FILENO)){fprintf(stderr,"screen: interactive TTY required\n");return 2;}
 if(raw_mode()<0){perror("raw terminal");return 2;}
 atexit(restore);
 signal(SIGWINCH,on_resize);signal(SIGINT,on_stop);signal(SIGTERM,on_stop);
 if(spawn(shell)<0){restore();perror("spawn PTY");return 1;}
 banner();
 int prefix=0;
 while(!stopped&&count){
  if(resized){resized=0;for(int i=0;i<MAX_SESSIONS;i++)if(sessions[i].alive)terminal_size(sessions[i].master);}
  struct pollfd fds[MAX_SESSIONS+1];int map[MAX_SESSIONS+1],nf=0;
  fds[nf]=(struct pollfd){STDIN_FILENO,POLLIN,0};map[nf++]=-1;
  for(int i=0;i<MAX_SESSIONS;i++)if(sessions[i].alive){
   fds[nf]=(struct pollfd){sessions[i].master,POLLIN|POLLHUP,0};map[nf++]=i;
  }
  int rc=poll(fds,(nfds_t)nf,250);
  if(rc<0){if(errno==EINTR)continue;break;}
  if(rc==0){reap();continue;}
  for(int j=0;j<nf;j++){
   if(!(fds[j].revents&(POLLIN|POLLHUP|POLLERR)))continue;
   if(map[j]<0){
    unsigned char b[BUFFER];ssize_t n=read(STDIN_FILENO,b,sizeof(b));
    if(n<=0){stopped=1;break;}
    for(ssize_t k=0;k<n;k++){
     unsigned char c=b[k];
     if(prefix){
      prefix=0;
      if(c=='c'){if(count<MAX_SESSIONS&&spawn(shell)>=0)switch_to(active);}
      else if(c=='n'||c==' ')cycle(1);
      else if(c=='p')cycle(-1);
      else if(c>='0'&&c<'0'+MAX_SESSIONS)switch_to(c-'0');
      else if(c=='?')help();
      else if(c=='d'){stopped=1;break;}
      else if(c=='k'&&active>=0){kill(sessions[active].child,SIGHUP);}
      else if(c=='a'&&active>=0){unsigned char a=1;write_all(sessions[active].master,&a,1);}
     }else if(c==1)prefix=1;
     else if(active>=0)write_all(sessions[active].master,&c,1);
    }
   }else{
    unsigned char b[BUFFER];ssize_t n=read(fds[j].fd,b,sizeof(b));
    if(n>0&&map[j]==active)write_all(STDOUT_FILENO,b,(size_t)n);
    else if(n==0||(n<0&&errno==EIO))close_session(map[j]);
   }
  }
  reap();
 }
 for(int i=0;i<MAX_SESSIONS;i++)if(sessions[i].alive){kill(sessions[i].child,SIGHUP);close(sessions[i].master);}
 while(waitpid(-1,NULL,0)>0){}
 restore();
 return 0;
}
