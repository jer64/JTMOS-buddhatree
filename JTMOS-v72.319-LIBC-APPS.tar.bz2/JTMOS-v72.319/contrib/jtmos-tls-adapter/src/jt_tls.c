#include "jt_tls.h"
#include <string.h>
#include <limits.h>
static int low_read(void *ctx, unsigned char *dst, size_t len) {
  jt_tls *t = (jt_tls *)ctx;
  int n = t->transport.read(t->transport.opaque, dst, len);
  return n > 0 && (size_t)n <= len ? n : -1;
}
static int low_write(void *ctx, const unsigned char *src, size_t len) {
  jt_tls *t = (jt_tls *)ctx;
  int n = t->transport.write(t->transport.opaque, src, len);
  return n > 0 && (size_t)n <= len ? n : -1;
}
int jt_tls_open(jt_tls *t, const char *host, const br_x509_trust_anchor *ca,
                size_t count, const unsigned char entropy[32],
                uint32_t now, jt_tls_transport io) {
  if (!t || !host || !*host || !ca || !count || !entropy || !now || !io.read || !io.write)
    return -1;
  /* Caller MUST obtain entropy from a ready kernel CSPRNG, not tlsseed.bin alone. */
  memset(t, 0, sizeof(*t));
  t->transport = io;
  br_ssl_client_init_full(&t->client, &t->x509, ca, count);
  br_x509_minimal_set_time(&t->x509, 0, now);
  br_ssl_engine_set_versions(&t->client.eng, BR_TLS12, BR_TLS12);
  br_ssl_engine_set_buffer(&t->client.eng, t->iobuf, sizeof(t->iobuf), 1);
  br_ssl_engine_inject_entropy(&t->client.eng, entropy, 32);
  if (!br_ssl_client_reset(&t->client, host, 0)) return -2;
  br_sslio_init(&t->io, &t->client.eng, low_read, t, low_write, t);
  t->active = 1;
  return 0;
}
int jt_tls_read(jt_tls *t, void *buf, size_t len) {
  if (!t || !t->active || (!buf && len)) return -1;
  if (!len) return 0;
  return br_sslio_read(&t->io, buf, len > INT_MAX ? INT_MAX : len);
}
int jt_tls_write(jt_tls *t, const void *buf, size_t len) {
  if (!t || !t->active || (!buf && len)) return -1;
  if (!len) return 0;
  return br_sslio_write_all(&t->io, buf, len) == 0 && br_sslio_flush(&t->io) == 0 ? 0 : -1;
}
int jt_tls_close(jt_tls *t) {
  if (!t || !t->active) return -1;
  int rc = br_sslio_close(&t->io);
  t->active = 0;
  return rc;
}
