# JTMOS TLS stage – integration source (not a JTMOS release)

This is an implementation of the BearSSL client transport adapter, NOT a completed Navigator/kernel port. It has not been compiled against JTMOS headers.

## Integration
1. Vendor and compile BearSSL for JTMOS i486 freestanding ABI; include its `bearssl.h`.
2. Add `src/jt_tls.c` to the Navigator build. The `jt_tls` context must stay at a fixed address throughout its lifetime.
3. Wire transport callbacks to the existing Navigator TCP socket. They must handle EINTR, short I/O, timeouts and close; zero-length reads/writes indicate closure and must map to -1.
4. Provide CA trust anchors from a vetted, versioned CA bundle; preserve the memory backing them for the entire TLS connection.
5. Obtain 32 fresh bytes from a cryptographically initialized `/dev/urandom` and valid UTC Unix time from a trusted clock. Refuse TLS otherwise.
6. Use the hostname, not IP, as `host`; BearSSL checks server name with X.509 validation.
7. For HTTPS, connect TCP port 443, call `jt_tls_open`, then `jt_tls_write` and `jt_tls_read`; inspect `br_ssl_engine_last_error` on failures. Close socket after TLS shutdown.
8. Add CA parsing and certificate store management separately; do not disable certificate validation.

## Security notes
- This stage forces TLS 1.2. BearSSL does not provide TLS 1.3.
- Do not credit disk-seed bytes as independent entropy. Never use `rand()`, RTC ticks or a static seed to initialize TLS.
- `tlsseed.bin` may be optional and root-VFS-relative; it cannot replace a seeded CSPRNG.
- A valid clock is mandatory for X.509 validity checks.
- A production kernel CSPRNG requires separate audited entropy collection and seed accounting.

## Test plan
Compile on target, run valid HTTPS, wrong hostname, expired/untrusted certificate, interrupted read, short writes, connection timeout, missing CA store, uninitialized entropy, unformatted hda1 with RAM root.
