# JTMOS TLS Adapter v0.1.0 — source preview
Release date: 2026-10-18

Status: SOURCE PREVIEW / NOT AN OS RELEASE / NOT PRODUCTION READY.

Contents: include/jt_tls.h and src/jt_tls.c implement a BearSSL TLS 1.2 client adapter with caller-supplied TCP transport, 32-byte CSPRNG output, CA trust anchors and UTC Unix time.

NOT included: BearSSL vendor library; JTMOS kernel32 integration; entropy collector and /dev/random /dev/urandom; CA bundle loading; Navigator HTTPS wiring; compiled navigator.bin; bootable image.

Build status: not compiled against JTMOS or BearSSL headers. No functional HTTPS tests performed.

Security constraints: Never bypass X.509 checks. The entropy argument must come from a securely initialized CSPRNG. A disk seed alone is insufficient. CA anchors must remain valid for connection lifetime. Ensure trustworthy UTC clock.

Known integration issue: transport callbacks must be backed by working Navigator TCP and handle partial I/O, EINTR and timeout. Hostname validation depends on BearSSL X.509 and supplied anchors. No TLS 1.3 support.

Acceptance criteria for future OS release: clean i486 build; HTTPS success with trusted cert; failures for wrong host/expired/untrusted cert; timeout/partial I/O; cold boot without formatted hda1; safe entropy initialization; CA load; regression HTTP and DNS.
