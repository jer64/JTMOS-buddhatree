#ifndef JT_TLS_H
#define JT_TLS_H
#include <stddef.h>
#include <stdint.h>
#include <bearssl.h>
/* Platform callbacks must block until progress or return -1; never return 0. */
typedef struct {
  int (*read)(void *, unsigned char *, size_t);
  int (*write)(void *, const unsigned char *, size_t);
  void *opaque;
} jt_tls_transport;
typedef struct {
  br_ssl_client_context client;
  br_x509_minimal_context x509;
  br_sslio_context io;
  unsigned char iobuf[BR_SSL_BUFSIZE_BIDI];
  jt_tls_transport transport;
  int active;
} jt_tls;
/* CA trust anchors and backing data must outlive the connection. */
int jt_tls_open(jt_tls *tls, const char *host, const br_x509_trust_anchor *ca,
                size_t ca_count, const unsigned char entropy[32],
                uint32_t unix_time, jt_tls_transport transport);
int jt_tls_read(jt_tls *tls, void *buf, size_t len);
int jt_tls_write(jt_tls *tls, const void *buf, size_t len);
int jt_tls_close(jt_tls *tls);
#endif
