import importlib.util, json, os, threading, unittest, urllib.request, urllib.error
from http.server import ThreadingHTTPServer
from pathlib import Path
spec=importlib.util.spec_from_file_location('gateway', Path(__file__).with_name('gateway.py'))
g=importlib.util.module_from_spec(spec); spec.loader.exec_module(g)
class Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  g.TOKEN='test-token'; g.BACKEND=''
  cls.server=ThreadingHTTPServer(('127.0.0.1',0),g.Handler)
  cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start()
 @classmethod
 def tearDownClass(cls): cls.server.shutdown();cls.server.server_close()
 def post(self,payload,token='test-token'):
  data=json.dumps(payload).encode(); req=urllib.request.Request('http://127.0.0.1:%d/v1/chat'%self.server.server_port,data=data,headers={'Authorization':'Bearer '+token})
  try:
   with urllib.request.urlopen(req) as r: return r.status,json.load(r)
  except urllib.error.HTTPError as e: return e.code,json.load(e)
 def test_offline(self):
  status,obj=self.post({'message':'Hei'});self.assertEqual(status,200);self.assertEqual(obj['mode'],'offline')
 def test_auth(self): self.assertEqual(self.post({'message':'Hei'},'wrong')[0],401)
 def test_bad_message(self): self.assertEqual(self.post({'message':42})[0],400)
 def test_long_message(self): self.assertEqual(self.post({'message':'x'*8100})[0],400)
if __name__=='__main__': unittest.main()
