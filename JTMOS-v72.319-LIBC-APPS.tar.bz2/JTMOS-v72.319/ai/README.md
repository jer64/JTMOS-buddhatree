# JTMOS v72.10 AI gateway prototype

This release adds a **working Ubuntu-side gateway and reference client**, not yet a native JTMOS `ai.bin` or Navigator integration.

## Run on Ubuntu

```sh
export JTMOS_AI_TOKEN='replace-with-a-long-random-secret'
python3 ai/gateway.py
# in another terminal, same token:
python3 ai/client.py 'Hei!'
python3 -m unittest discover -s ai -p 'test_*.py' -v
```

Without a model configured, the gateway returns an explicit offline/fallback response. To use an OpenAI-compatible chat-completions backend, set `JTMOS_AI_BACKEND_URL` to the full `/v1/chat/completions` URL, `JTMOS_AI_MODEL`, and optionally `JTMOS_AI_BACKEND_KEY`. Never embed backend keys in the JTMOS client. The gateway binds to loopback only; remote JTMOS connections require a properly secured HTTPS reverse proxy or tunnel. `/v1/chat` accepts `{"message":"..."}` with bearer token and responds `{"reply":"...","mode":"model|offline"}`. `/health` is unauthenticated and exposes no secrets.

## Next phase

Implement `libai` and native `ai.bin` using JTMOS's existing TCP/IP + TLS interfaces, then a GraOS interface and Navigator integration. Add rate limits, concurrency limits, and deployment monitoring before internet exposure. Treat RAG content as untrusted data.
