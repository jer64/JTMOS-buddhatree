#!/usr/bin/env python3
"""JTMOS AI gateway: localhost-only, no dependencies, optional OpenAI-compatible backend."""
import json, os, urllib.request, urllib.error
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit

HOST = os.getenv('JTMOS_AI_HOST', '127.0.0.1')
PORT = int(os.getenv('JTMOS_AI_PORT', '8765'))
TOKEN = os.getenv('JTMOS_AI_TOKEN', '')
BACKEND = os.getenv('JTMOS_AI_BACKEND_URL', '')
MODEL = os.getenv('JTMOS_AI_MODEL', 'local-model')
MAX_BODY = 32768

def respond(message):
    if not BACKEND:
        return {'reply': 'Tekoälymallia ei ole määritetty. Aseta JTMOS_AI_BACKEND_URL ja JTMOS_AI_MODEL.', 'mode': 'offline'}
    parsed = urlsplit(BACKEND)
    if parsed.scheme != 'https' and not (parsed.scheme == 'http' and parsed.hostname in ('localhost', '127.0.0.1', '::1')):
        raise ValueError('Backend must use HTTPS or local HTTP')
    payload = json.dumps({'model': MODEL, 'messages': [{'role': 'user', 'content': message}], 'stream': False}, ensure_ascii=False).encode()
    headers = {'Content-Type': 'application/json'}
    key = os.getenv('JTMOS_AI_BACKEND_KEY', '')
    if key: headers['Authorization'] = 'Bearer ' + key
    request = urllib.request.Request(BACKEND, data=payload, headers=headers, method='POST')
    with urllib.request.urlopen(request, timeout=25) as result:
        data = json.load(result)
    return {'reply': data['choices'][0]['message']['content'], 'mode': 'model'}

class Handler(BaseHTTPRequestHandler):
    def send_json(self, status, data):
        body = json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)
    def do_GET(self):
        if self.path == '/health': self.send_json(200, {'status':'ok','backend_configured':bool(BACKEND)})
        else: self.send_json(404, {'error':'not found'})
    def do_POST(self):
        if self.path != '/v1/chat': return self.send_json(404, {'error':'not found'})
        if not TOKEN or self.headers.get('Authorization') != 'Bearer ' + TOKEN:
            return self.send_json(401, {'error':'unauthorized'})
        try:
            length = int(self.headers.get('Content-Length', '-1'))
            if not 0 < length <= MAX_BODY: return self.send_json(413, {'error':'invalid request size'})
            obj = json.loads(self.rfile.read(length))
            msg = obj.get('message')
            if not isinstance(msg, str) or not 0 < len(msg) <= 8000:
                return self.send_json(400, {'error':'invalid message'})
            self.send_json(200, respond(msg))
        except (ValueError, KeyError, TypeError, urllib.error.URLError, TimeoutError) as exc:
            self.send_json(502, {'error':'backend failure'})
        except json.JSONDecodeError:
            self.send_json(400, {'error':'invalid json'})
    def log_message(self, fmt, *args):
        # No message content or credentials in access logs.
        pass

def main():
    if not TOKEN: raise SystemExit('Set JTMOS_AI_TOKEN to a strong secret before starting')
    if HOST not in ('127.0.0.1', '::1', 'localhost'):
        raise SystemExit('Remote binding disabled: use TLS reverse proxy with access controls')
    print('JTMOS AI gateway listening on %s:%d' % (HOST, PORT), flush=True)
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()

if __name__ == '__main__': main()
