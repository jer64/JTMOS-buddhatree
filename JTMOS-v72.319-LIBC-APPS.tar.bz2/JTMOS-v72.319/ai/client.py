#!/usr/bin/env python3
"""Reference client for the JTMOS AI wire protocol."""
import json, os, sys, urllib.request
url = os.getenv('JTMOS_AI_URL', 'http://127.0.0.1:8765/v1/chat')
token = os.getenv('JTMOS_AI_TOKEN', '')
if not token: raise SystemExit('Set JTMOS_AI_TOKEN')
message = ' '.join(sys.argv[1:]) or input('Kysymys: ')
data = json.dumps({'message': message}, ensure_ascii=False).encode()
req = urllib.request.Request(url, data=data, headers={'Content-Type':'application/json', 'Authorization':'Bearer '+token})
with urllib.request.urlopen(req, timeout=30) as resp: print(json.load(resp)['reply'])
