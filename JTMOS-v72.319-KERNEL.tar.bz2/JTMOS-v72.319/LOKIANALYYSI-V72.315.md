# JTMOS V72.315 – lokianalyysi 11.11.2026

Lähde: `logs11-11.zip` (hda1:/var/log, per-PID `kern-N.log`, `navigator.log`,
`diskspace.log`). PID-kartta: 6 CP, 11 kasync, 12 KJTMFSC, 15 KTLS, 17 uip,
18 GraOS, 20 calremind.bin, 22 mp3.bin, 26 smsh-gui, 28 bitchxfull.bin,
29/32 navigator.bin, 30 navwatch.bin. Levytila ei ollut ongelma
(hda1 ~622 Gt vapaana, enospc=0 kaikissa 128 näytteessä).

| # | Havainto | Syy | Korjaus V72.315 |
|---|----------|-----|-----------------|
| 1 | bitchxfull.bin: 3 538 nimikyselyä, 3 520 × `rc=-110`, 4 × `rc=-16` | BitchX yritti uudelleen 1 s välein ikuisesti; yksi resolveripaikka, ei uudelleenlähetystä, ei negatiivista välimuistia; rinnakkainen kysely sai heti EBUSY | `server.c` eksponentiaalinen viive (5–300 s); `jnet.c` uudelleenlähetys 1/2/4 s, välimuisti (+5 min / −30 s), paikan odotus EBUSY:n sijaan, vastauksen kopiointikilpa korjattu |
| 2 | `open: unable to create '.../nvc-external-content.duckduckgo.com-100.bin.tmp.32' (rv=1)` | JTMFS-nimen raja 31 merkkiä; Navigatorin välimuistinimet 33–51 merkkiä → `resolveFileNamePath` ETOOLONG → rv=1 → EIO | `nav_cache.c` lyhyet nimet (≤30), indeksi v2; `open()` → ENAMETOOLONG |
| 3 | JTMFS-mutaatiolukko: 1 489 slow-acquirea, ka. 277 ms, max 9,1 s | KJTMFSC-flush (ATA flush + readback) ja KLOGGER kirjoittavat lukon alla; KLOGGER kirjoitti valtavan määrän diagnostiikkaa (alla), joka itse tuotti uusia lukko-odotuksia | Lokikuorma pois (kohdat 4 ja 6). Flushin readback säilytetään (T400-eheys, V72.305) |
| 4 | 7 143 `[MUTEX] wait ... ethdev_mutex held_ms=0` (KTLS ↔ uip) | Jokainen kilpailtu odotus kirjattiin, myös mikrosekuntien luovutukset | wait-rivi vain kun held ≥ 20 ms, max 8/s, ylijäämästä yhteenveto |
| 5 | `fork: PID29 child VM setup failed` | Lapsen 512 MiB -ikkunan laajennuksen jälkeinen vaihe epäonnistui; loki ei kertonut mikä | Virheilmoitus kertoo vaiheen, koon ja ytimen VA-vapaan/suurimman yhtenäisen alueen. Seuraavasta lokista nähdään juurisyy |
| 6 | GraOS heartbeat 23 886 riviä (4 Mt), findfirst-jäljitys, uIP-konsolirivit, `info record crosses device block ... bs=1` | Diagnostiikka liian tiheää / merkkilaitteiden turha tarkistus | heartbeat 60 s; findfirst-jäljitys pois; uIP-pudotukset vain laskureihin; bs<512 hiljaa |
| 7 | `TCP send failed fd=1024 errno=32` heti TLS 1.3 -kättelyn jälkeen | Palvelin sulki yhteyden; Navigator avasi heti uuden yhteyden (loki näyttää uuden transport connectin) | Ei muutosta: virhe käsitellään jo |
| 8 | `HDA: stream stalled lpib=31676` (1 ×) | mp3.bin-toiston aikana, yksittäinen | Ei muutosta, seurataan |

## Stunt Circuit

`update_player()`: kaarrevoima oli `bend·v²·16`. Huippunopeudella se oli
10–20-kertainen suurimpaan ohjausvoimaan (0,12 + 0,075·v) nähden, joten
auto suistui radalta joka kaarteessa. Uusi malli: `bend·v²·0,95 / pito`,
rajattu ±1,2 × ohjausvoima; boost ja yli 50 %:n vauriot heikentävät pitoa.

Testi `tests/run-v72315-stunt-handling.sh` kääntää pelin oikean
fysiikkakoodin isännällä (BGI-tynkä) ja ajaa 3 kierrosta ohjaavalla
kuljettajalla:

| Versio | Kierrokset | Aika | Suurin sivupoikkeama | Vauriot |
|--------|-----------|------|----------------------|---------|
| V72.314 | 3 | 51 s | 140 (radan puolileveys 92) | 100 % |
| V72.315 | 3 | 21 s | 28–47 | 0 % |

Lisäksi: GraOS lähettää Enterin arvona 10 (LF), mutta aloitus- ja
loppuruutu hyväksyivät vain 13:n, joten kisaa ei voinut aloittaa Enterillä
(välilyönti toimi). Korjattu. QEMU-testi (2 Gt): `stunt.bin` käynnistyy
GraOS:n Activities-haulla ("Stunt Circuit"), Enter aloittaa kisan.
`stunt.bin` on sama peli uudella nimellä; käynnistimet, työpöytä ja
tehtäväpalkin pelivalikko käyttävät sitä.
