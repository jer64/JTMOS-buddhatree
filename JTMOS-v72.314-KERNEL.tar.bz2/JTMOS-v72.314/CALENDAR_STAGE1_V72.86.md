# JTMOS v72.86 – GraOS Calendar, Phase 1

Changes are deliberately restricted to the external GraOS taskbar's calendar
persistence layer and its build integration. This is a full-source release.

## What changed

- New `libc/apps/calendar_store.{c,h}`: a dedicated calendar storage module,
  with a matching source mirror under `graos-host/apps/`.
- Fixed the JTMFS incompatibility: older taskbar wrote `/calendar.tmp` then
  `rename()`d it over `/calendar.txt`. JTMFS refuses rename-over-existing.
- New **alternating storage slots** `/calendar.a` and `/calendar.b`.
  A new revision is written ONLY to the inactive slot and checked by
  `fflush()`, `fsync()`, `fclose()`, and a parsed+CRC32 verified readback.
  Only then is it selected as the in-memory current version. Both files
  include a monotonically increasing generation number.
- Files use `JTCAL2` header + count + persisted next event ID + CRC32.
- If the newest slot is damaged, the other valid slot is recovered.
  If both are damaged, the calendar is read-only rather than silently erased.
- The original `/calendar.txt` is read for import when neither slot exists;
  it is **never overwritten or deleted**. The first successful edit creates
  a new slot. Malformed legacy dates are skipped; a legacy file containing
  *only* malformed records locks edits to avoid losing potentially useful data.
- Added persistent, monotonically increasing event IDs. Current user interface
  still restricts entries to **one event per day**; multiple daily events and
  reminders are reserved for later phases.
- Reject invalid calendar dates (`2026-02-31`, `2026-04-31`, etc.), excessive
  title length, and control characters. Leap years follow Gregorian rules.
- Calendar write failure leaves the in-memory state unchanged and displays an
  error in the existing native GraOS editor.
- `taskbar.mak` now links `calendar_store.o`; the **new `taskbar.bin` ELF32**
  is included in `libc/apps/`.

## Recovery, storage and limits

**IMPORTANT**: A writable, persistent root filesystem is required. When root
is RAM-backed, files will be lost on reboot; when mounted read-only or when
`SYS_fsync` is unavailable, saving fails. JTMOS implements `SYS_fsync` for
JTMFS and FAT12; write durability still depends on the underlying filesystem,
storage device, and power-loss behaviour. The tests do not establish that JTMFS
is power-fail atomic on physical hardware. Back up important events.

A slot that was inactive during a failed write may be truncated. The previous
active slot is not touched; a subsequent load selects the highest intact
verified generation. No file is removed automatically. Keep `/calendar.txt`
when upgrading. Do not launch multiple calendar-capable taskbars concurrently:
there is no interprocess writer lock in this phase.

The calendar still belongs to the **separate `taskbar.bin`**. The built-in
GraOS taskbar clock integration and multi-event editor belong to later phases.

## Build and verification

```
cd libc/apps
make -f taskbar.mak taskbar.bin
```

Host-side persistence tests:

```
sh tests/calendar/run_v7286_store_test.sh
```

Also validated in this release:
- JTMOS 32-bit ELF32 build of `taskbar.bin`: **PASS**
- Repeat edits, delete, legacy migration, CRC recovery, write-failure rollback,
  stable event IDs and Gregorian date validation: **PASS** in host tests
- DOSBOOT prompt test: **PASS**
- GraOS VESA/mouse regression: **PASS**
- Old v72.84 ICH9LAN static test: one **version-number assertion fails**;
  all other source checks pass, and Ethernet source is unchanged
- Real GraOS/T400 runtime: **NOT TESTED**
- Kernel/DOSBOOT rebuilt: **NO** – previous binaries preserved as-is
