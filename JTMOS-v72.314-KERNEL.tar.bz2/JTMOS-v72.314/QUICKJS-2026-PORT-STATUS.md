# QuickJS 2026-06-04 source refresh (v71.138)

Replaced bundled 2021-03-27 source with user-supplied upstream QuickJS 2026-06-04.
Updated tools/build_navigator_quickjs.sh to use dtoa.c instead of removed libbf.c, and updated version checks.
Disabled CONFIG_ATOMICS because JTMOS lacks pthreads; avoided Linux malloc.h include for JTMOS.

## Build verification
The cross-build was attempted, but **does not yet pass**. It reaches quickjs.c and reports missing malloc_usable_size declaration and missing UINT64_C definition in JTMOS libc headers (initial test). Build script now supplies UINT64_C macro but full rebuild and linkage remain unverified.

Do not claim Navigator executes JavaScript or that Google sign-in works from this source refresh alone.
