# JTMOS v72.166: ohjelma-analyysi ja päivitys

28.10.2026. Pohja on koko v72.165-julkaisu. Päivitys sisältää ohjelmien
virheenkorjaukset, edit.bin-editorin Nano-toiminnot ja mp3.bin-soittimen
komentorivitilan. Muutoksia tutkittiin lähdekoodista ja oikeilla ELF32-ohjelmilla
QEMU:ssa. Tämä on rajattu katselmus alla mainittuihin ohjelmiin ja yhteisiin
palveluihin; kaikkien JTMOS-ohjelmien täydellistä auditointia ei väitetä tehdyksi.

## Löydökset ja vaikutukset

| Kohde | Todettu ongelma | Korjaus |
|---|---|---|
| nutget | Epäonnistunut lataus poisti aikaisemman kohdetiedoston. V72.165:n QEMU-toistossa alkuperäinen tiedosto katosi katkenneen HTTP-vastauksen jälkeen. | Ladataan yksilölliseen, yksinomaisesti luotuun väliaikaistiedostoon. Julkaistaan vasta täydellisen latauksen, flushin ja sulkemisen jälkeen. Vanha kohde palautetaan, jos julkaisu epäonnistuu. |
| grep | strlen katkaisi nollatavuun; fgets oli jo kuluttanut loppurivin. Haku ohitti osan sisällöstä ja rivit saattoivat yhdistyä. | Rivit luetaan ja käsitellään todellisen tavumäärän perusteella. Haku ja tulostus säilyttävät nollatavut. |
| tail | fputs jätti nollatavun jälkeisen osan tulostamatta. | Rengaspuskuri tallentaa sekä rivin että sen pituuden; tulostus käyttää fwrite-kutsua. |
| cp/mv | Merkkijonopolkujen vertailu ei tunnistanut kaikkia saman tiedoston nimiä. mv ilmoitti puuttuvan lähteen siirretyksi, jos lähde- ja kohdemerkkijonot olivat samat. | Tarkistetaan olemassaolo ja tiedoston tai vanhemman hakemiston tunniste. Eri tyhjien tiedostojen nollainodeja ei pidetä samoina. |
| SQSH | Ulkoisen ohjelman käynnistyminen tulkittiin onnistuneeksi suoritukseksi. Operaattorin jälkeinen välilyönti päätyi ohjelman nimeen. | Odotettavat lapsiprosessit ja oikea exit-/signaalistatus; komentojen alun ja lopun tyhjät merkit poistetaan. |
| SQSH:n > | Jaetun O_TRUNC-kahvan väliaikainen korvaustiedosto jäi julkaisematta viimeisen omistajan poistuessa. | Komentotulkki pitää tuoreen tulostetiedoston kahvan itsellään, odottaa lapset, tyhjentää puskurit ja julkaisee tiedoston erikseen. |
| JTMFS | Välimuistin B+puu, hakemistopuskuri ja FAT-rakenteet saattoivat kuulua lyhytikäiselle ohjelmaprosessille. V72.165:n ohjelmatestissä vertailuohjelma kaatui jtmfs_index_lookup-kohdassa. | Pysyvät rakenteet kuuluvat ytimen resurssiomistajalle. Väliaikaiset rakennuspuskurit vapautetaan entiseen tapaan. |
| Prosessin lopetus | SYS_EXIT tuli keskeytykset estettyinä ja saattoi jäädä odottamaan elinkaaren lukkoa. | Oma lopetus julkaisee karanteenin ilman lukon odotusta. Resurssien vapautus tehdään toisesta prosessista. |
| Äänipalvelu | Ensimmäisen soittimen lopetus vapautti yhteisen FIFO:n ja HDA:n työpuskurit. Seuraava MP3-toisto kaatui audio_fifo_read-kohdassa. | Äänilaitteen yhteiset puskurit säilyvät soittimien yli. |

JTMFS:n nimet ovat kirjainkoon erottelevia. Vertailua ei korjattu muuttamalla
koko tiedostojärjestelmää kirjainkoosta riippumattomaksi. FAT12:n oikea
identiteetti saadaan sen stat-tiedoista.

## edit.bin: Nano-toiminnot

Pikanäppäinten viite: [GNU nanon virallinen näppäinohje](https://www.nano-editor.org/dist/latest/cheatsheet.html).
Toiminnot on toteutettu editorin omaan JTMOS-koodiin.

| Näppäin | Toiminto |
|---|---|
| Ctrl+G / F1 | Ohje |
| Ctrl+S | Tallenna nykyiseen nimeen |
| Ctrl+O / F2 | Kysy tallennusnimi |
| Ctrl+X / F10 | Poistu; muuttuneelle tekstille tallennuskysymys |
| Alt+U / Alt+E | Kumoa / tee uudelleen |
| Alt+A | Aloita tai lopeta tekstialueen merkintä |
| Alt+6 | Kopioi alue tai koko rivi |
| Ctrl+K / Ctrl+U | Leikkaa alue tai koko rivi / liitä |
| Ctrl+W tai Ctrl+F / Ctrl+B | Hae eteenpäin / taaksepäin |
| Alt+F tai Alt+W / Alt+B tai Alt+Q | Toista haku eteenpäin / taaksepäin |
| Ctrl+\ tai Alt+R | Korvaa kaikki kirjaimelliset osumat vahvistuksen jälkeen |
| Alt+G tai Ctrl+_ | Siirry kohtaan rivi,sarake |
| Alt+N / Alt+I | Rivinumerot / automaattinen sisennys |
| Alt+\ / Alt+/ | Asiakirjan alku / loppu |

Alt-komennon voi antaa myös painamalla Esc ja sitten kyseistä näppäintä.
Peräkkäiset Ctrl+K-komennot kokoavat usean rivin leikkeen. Alueen leikkaus,
liittäminen ja kaikkien osumien korvaus ovat kukin yksi kumottava muutos.
Kumous palauttaa myös kohdistimen ja tallennettuun versioon vertaillun
muutostilan. Uusi muokkaus kumoamisen jälkeen katkaisee uudelleentekohistorian.

```text
edit.bin tiedosto.txt
edit.bin -l -i +12,5 tiedosto.txt
terminal.bin /bin/edit.bin tiedosto.txt
```

Viimeinen muoto avaa editorin GraOSin pääteikkunaan. Myös GraOSin Squirrel
Shell -pääteikkunasta voi ajaa edit.bin-komennon suoraan. Erillinen graafinen
editori on edelleen nutedit.bin. Muokkaus lukee päätteen todellisen koon,
sovittaa tilarivin ja ohjerivin myös GraOSin 24-riviseen pääteikkunaan ja
käyttää näppäinkomentoja varten raakaa termios-tilaa. Tila palautetaan poistuessa.
Myös GraOSin palvelin välittää ohjausnäppäimet raakamuodossa, jotta sen oma
vuonohjaussuodatin ei niele editorille tarkoitettua Ctrl+S:ää. Uuden
pääteikkunan koonmuutos säilyttää yläreunaan tulostetun komentokehotteen,
kun poistettavat alareunan rivit ovat vielä tyhjiä.

Tallennus käyttää lyhyttä, yksilöllistä sivutiedostonimeä, joten alkuperäiseen
pitkään nimeen ei lisätä JTMFS:n nimirajan ylittävää päätettä. Epäonnistuneen
palautuksen yhteydessä säilytetään molemmat palautustiedostot.

Tämä ei ole täydellinen GNU nano -porttaus: ei nanorc-tulkintaa, regex-hakua,
useita samanaikaisia tiedostopuskureita, syntaksiväritystä tai Unicoden
näyttöleveyslaskentaa. Nykyinen tekstimalli säilyttää LF/CRLF-valinnan mutta
laajentaa tiedoston tabulaattorit välilyönneiksi kuten aikaisempi Edit.
Rajat ovat 10 001 riviä ja 4 096 tavua rivillä. Kumous säilyttää enintään
32 muutosta, ja suurten koko asiakirjan muutosten muistivaraus on rajattu.
Tallennus on palautettavissa raportoiduista virheistä; sähkökatkon yli
atomisuutta ei luvata sovelluksen kahden nimeämisen vaihdolle.

## mp3.bin ilman GraOSia

```text
mp3.bin kappale.mp3
mp3.bin --cli kappale.mp3
mp3.bin --cli musiikkihakemisto --loop
mp3.bin --cli --quiet kappale.mp3
```

Kun GraOS ei ole käynnissä, annettu tiedosto tai hakemisto valitsee
komentorivitilan automaattisesti. --cli ja --no-gui pakottavat sen; --gui
valitsee ikkunan. Ilman tiedostopolkua graafinen tila käyttää vanhaa
valitsinta, ja komentorivitila näyttää käyttöohjeen.

Ctrl+C lopettaa toiston siististi ja palauttaa arvon 130. Q tai Esc lopettaa,
N siirtyy seuraavaan ja P edelliseen kappaleeseen. Välilyönti pysäyttää tai
jatkaa dekoodausta; jo äänilaitteeseen jonotettu ääni soi ensin loppuun.
Hakemiston MP3-tiedostot toistetaan nimijärjestyksessä. Toisto käyttää samaa
Layer III -dekooderia ja ääniajuria kuin graafinen soitin. --quiet jättää
toiston etenemisviestit pois. Virheellinen tai puuttuva tiedosto ei palauta
onnistumista. Yksi tiedosto tai hakemisto on yksi komentorivin syöte.

## Testaus ja rajaus

Päivitä koko julkaisu: MP3:n puskurien korjaus ja prosessien lopetuskorjaus
kuuluvat ytimeen, ja editorin ohjausnäppäinten välitys myös GraOS-palvelimeen.
Paketointi sarjoittaa kirjoittajat ja poistaa irtonaiset kaksoiskopiot vasta,
kun niiden koko sisältö on verrattu tavutasolla jo tehtyyn SQA-pakettiin.
Myös pakettien sisäiset GNU/FHS-paketit tarkistetaan.

Tarkat tulokset ovat tiedostossa QA-V72.166.md ja hakemistossa
release/qa/v72.166/. Vertailu v72.165:een tehtiin erillisillä muuttamattomilla
medioilla. GraOSin oikeassa pääteikkunassa varmistettiin kirjoitus, kumous,
uudelleenteko, Ctrl+S-tallennus ja tallennetun sisällön lukeminen takaisin.
Rinnakkainen kaatumisrasitus paljasti ajoittaisen fork-luontivirheen
elinkaaren lukon ollessa varattu; käyttöjärjestelmä jatkoi toimintaansa.
Tämä tunnettu rajoitus ja epäonnistuneiden ajojen todisteet on kirjattu
QA-raporttiin. Kehityksen välituloksia ei lasketa hyväksytyiksi testeiksi.
ASan ja UBSan tarkistavat editorin oikeaa moottoria ja näppäinkäyttöliittymää.
LeakSanitizerin prosessitarkastus ei ole tämän ajoalustan käytettävissä.

Vanha make -C libc/apps audit -koontitesti pysähtyy v71.80:n testiin, joka
edellyttää kirjaimellisesti VERSION=71.80 ja vanhaa Makefile-rivitystä.
Sitä ei tulkita nykyjulkaisun toiminnalliseksi testitulokseksi eikä koko
vanhan koontitestin väitetä läpäisseen. Muutetut ohjelmat kootaan ja
niiden käyttäytyminen testataan erikseen. Fyysisen T400:n testiä ei tehty.
