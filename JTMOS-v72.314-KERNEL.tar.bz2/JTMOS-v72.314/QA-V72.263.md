# JTMOS V72.263 – tarkistukset

## Tulos

Koko julkaisun käännös (`make -j2 full-build`) ja alla kuvatut Navigatorin
host-testit onnistuivat. Kernel, ohjelmat, ISO, käynnistyslevykuvat ja DOSBOOT
rakennettiin uudestaan. Julkaisumedioiden sisällön tarkistus läpäistiin.
Navigatorin host-testit käyttävät ohjattuja käyttöjärjestelmä- ja
verkkovastauksia. Lisäksi uusi käynnistyslevykuva ajettiin oikeassa QEMU-VM:ssä.
Fyysisen T400:n toimintaa ei testattu tässä ympäristössä.

| Tarkistus | Tulos |
| --- | --- |
| Oikea `navigate_request()` sekä parseri/layout; vanhan 24 MiB:n eston toisto | PASS |
| Osoiterivin Enter ja toinen sivu kahden 4 MiB:n kuvapuskurin kanssa | PASS |
| Vanha sivu säilyy keskeneräisessä latauksessa, Stopissa, HTTP 204:ssä ja verkkovirheessä | PASS |
| Todellinen epäonnistunut `malloc()` ja liian pieni kokonaisbudjetti | PASS |
| Viisi peräkkäistä sivunvaihtoa ja F5; HTTP-varaus palautuu 20 MiB:uun | PASS |
| Pienemmät puskurit, kokonaisbudjetin raja ja laskennan ylivuodon torjunta | PASS |
| ASan ja UBSan samassa tuotannon UI-koodia käyttävässä testissä | PASS |
| Aiempi adaptiivisen muistisuunnitelman testi, 27 tarkistusta | PASS |
| Kaksi samanaikaista yli 1 MiB:n IPC-siirtoa; erilliset puskurit ja siivous | PASS |
| Kuvajonon omistajuus, dekooderin yksinoikeus ja varhainen CSS-pyyntö | PASS |
| Julkisen lähdeversion tarkistus | PASS |
| Native-käännös: ELF32 / Intel 80386 / entry 0x80004000 | PASS |
| QEMU-käynnistystesti: BIOS/NZIP, kernel, SMSH, RAM mkdir/cd, help | PASS |
| T400-ajotesti | Ei ajettu |
| Työprosessien `fork()`-ENOMEM-korjaus | Ei toteutettu tässä päivityksessä |

LeakSanitizerin prosessiseuranta ei toimi tässä ajoympäristössä
(`/proc/<pid>/task` ei ole käytettävissä). Lopullinen testi ajettiin
`detect_leaks=0`:lla; ASan/UBSan jäivät käyttöön. Vuodottomuutta ei siis ole
varmistettu LeakSanitizerilla. Tavallisella hostilla LSan voidaan ottaa käyttöön
asettamalla `ASAN_OPTIONS=detect_leaks=1:halt_on_error=1`.

## Toisto

```sh
python3 tests/run-v72263-navigation-budget.py /tmp/jtmos-v72263-host
sh tests/run-v72257-navigator-performance.sh
sh tools/check_public_version.sh
make -C libc/apps -f navigator.mak -j2 navigator.bin
```

Host-testit rakentavat omat ASan/UBSan-Lexbor-objektinsa erilliseen kansioon;
niitä ei linkitetä JTMOS-binääriin. Varsinainen selaimen käännös sisältää
Lexborin, QuickJS:n, WebP:n, BearSSL:n ja valinnaisen oman TLS 1.3 -toteutuksen.
Täyteen release-pakettiin rakennettiin myös kernel, kaikki julkaisun ohjelmat,
käynnistyslevykuvat, asennuspaketit, ISO ja DOSBOOT. Host-ASan/UBSan-objekteja ei
ole käytetty näissä binääreissä.

Tarkistusten lokit: `validation-v72.263/`.

## Provenienssi

- Pohjapaketti: `JTMOS-v72.259-FULL-SOURCE-RELEASE.zip`.
- Pohjapaketin SHA-256: `397b966abc15075bd6fab4c0cd42c2618597b8edee5411c483456dfab98833a2`.
- Uuden `libc/apps/navigator.bin`-tiedoston SHA-256: `8ebe7b8fd828111de164d6771857fd95699c0bf5e86b4857e7a412a0f046a10c`.
- Uusi kernel: `bc313397c19ddf2a93ca7bfc9a6db027e1c3b62592057676e6d93108829e024c`.
- Uusi utilities.iso: `c9c81439e0afeb88ac1ef0d026d8f01b37b4886d45cb033f126ae565b41ad8fe`.
- Mediatarkistus seuraa pakattua ketjua ISO -> SQA -> Navigator/GraOS/bootkuva
  sekä NZIP -> kernel. Myös DOSBOOTin ja ISO-aliasten sisällöt tarkistetaan.
- Kernelin koko: 974112 tavua, vapaata linkitysikkunassa 74464 tavua;
  vaadittu vähimmäismarginaali 65536 tavua. BSS ei mene binäärin päälle.
- Tässä haarassa ei ole erillisiä V72.260–V72.262 säie-/VM-/FD-patcheja.
- Jatkokehityksen seuraava vapaa lähdeversio tämän haaran jälkeen: V72.264.

## Täyden julkaisun rakentaminen

```sh
make -j2 full-build
```

Käännöksessä käytettiin GCC 13.3.0:aa ja NASM 2.16.01:tä. Boot-profiili on
`text`, SAFE=0, NOAPIC=0, NOGUI=1, sama kuin liitetyn pohjapaketin oletus.

Valmiit tiedostot:

- `jtm32.img` – BIOS/NZIP-käynnistyslevykuva.
- `root1440.img` – erillinen root/rescue-levykuva.
- `utilities.iso` ja `utils.iso` – ohjelmat ja asentimet.
- `boot32pm/dosboot/dosboot.com`, `kernel32.nz` ja `utils.iso` – täysi DOSBOOT.
- `libc/apps/navigator.bin` – päivitetty Navigator.

Katso myös `validation-v72.263/full-release-build.log`,
`validation-v72.263/release-media.json` ja `FULL-RELEASE-SHA256.txt`.

## QEMU-käynnistys

Uusi `jtm32.img` ajettiin QEMU 8.2.2:ssa (TCG, pc/PS2, 512 MiB RAM,
tekstitila, ei verkkokorttia). BIOS/NZIP, kernelin käynnistys, ajoitin ja
näppäimistöreitti, SMSH-kehote sekä RAM-levyn mkdir/cd/help-komennot läpäisivät
olemassa olevan käynnistystestin. Vieraan loki varmisti lähdeversioksi V72.263.

Käynnistystesti päivitettiin siirtymään ensin juurihakemistoon: SMSH aloittaa
nykyään käyttäjän kotihakemistosta, kun vanha testi oletti aloituspoluksi ram:/.
Tämä on testin polkuoletuksen muutos; tuotannon hakemistokäyttäytymistä ei muutettu.

```sh
python3 tests/v72109_qemu_boot.py "$PWD/jtm32.img" /tmp/jtmos-v72263-boot
```

Tulokset ja lokit: `validation-v72.263/qemu-boot/`. GraOS/Navigatorin graafista
sivunvaihtoa ei ajettu QEMUssa tässä tarkistuksessa; sen budjettipolkua ja
sivun säilymistä testattiin oikeaa UI-koodia käyttävillä host-testeillä.
