# JTMOS v72.152 – QA

Päiväys 26.10.2026. Pohjana on kokonainen v72.151-lähdepaketti (SHA-256 `01e88251…412fa6`).

| Tarkistus | Tulos |
|---|---|
| Natiivi koonti ja media | PASS |
| `inet static` kesken DHCP-kierroksen, v72.151 | FAIL (perustaso; T400:n oire) |
| `inet static` kesken DHCP-kierroksen, v72.152 | PASS: osoite pysyi 40 s, ping 3/3 ja ARP who-has 10.42.0.28 vastattu 3/3 |
| Myöhäinen OFFER 44 s ja tavallinen DHCP | PASS |
| QEMU-verkkoregressio | PASS 10/10 |
| ICH9E-ajurimallit v72.108, 111, 145, 146, 147 ja 152 | PASS; mutaatio `no_tdh_reclaim` hylätty |

Rajaus: QEMU:ssa ei ole ICH9 LAN -mallia, joten TDH-palautus on testattu vain ajurimallissa. Intel AMT:n DHCP-hypoteesia ei ole todennettu raudalla.
