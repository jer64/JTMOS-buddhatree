# JTMOS v72.248 — tested build status

Base: v72.247 full-source release. Three modified kernel sources: `kernel32/fs/jtmfs/jtmfsDb.c`,
`kernel32/fs/jtmfs/jtmfsAccess.c`, `kernel32/fs/jtmfs/jtmfs.c`.

## PASS on Linux development environment

- `make -f generated.mak fs/jtmfs/jtmfsDb.o fs/jtmfs/jtmfsAccess.o fs/jtmfs/jtmfs.o`:
  successfully builds 32-bit i386 ELF relocatable kernel objects.
- `tests/v72248_atomic_replace_reboot_host.py`: **224/224** isolated power
  cut/reboot/replay cases. Includes same- and cross-directory replacement,
  three disk persistence models, 12 interrupted recovery checkpoints,
  mirrored superblock corruption, and interrupted reclamation of a 3-block old FAT chain.
- `tests/v72247_atomic_move_reboot_host.py`: **90/90**.
- `tests/v72246_crash_recovery_host.py`: **69/69**.
- `tests/v72241_dirdb_writeback_host.py`: **792 cases PASS**.
- `tests/v72245_dirdb_failclosed_host.py`: PASS.
- `tests/v72245_jtmfs_commit_fault_host.py`: PASS (seven injected faults).
- `tests/v72245_jtmfs_watchdog_host.py`: PASS.
- `tests/v72244_mv_wildcards.py`: PASS with the existing Linux-host mv test binary; metadata-only wildcard moves and existing-target handling.

## Not demonstrated

- Complete kernel link and bootable media generation (NASM unavailable).
- On-device T400, QEMU boot path, real AHCI, simultaneous POSIX open handles and real production `jtmfs_atomic_replace()` integration.
- Durable resume of already interrupted FAT orphan reclamation. Safe namespace
  replay is implemented; an orphan tail may remain for offline fsck.

The ZIP is a complete SOURCE TREE, **not** a verified v72.248 bootable
release. Existing images/binaries may predate this source release.
