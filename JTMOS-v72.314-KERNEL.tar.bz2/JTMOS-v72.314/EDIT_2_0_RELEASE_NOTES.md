# Edit 2.0 core – incremental implementation, 2026-10-16

## Implemented
- Raised application memory request from 2048 KiB to 65536 KiB (the actual application ELF now contains `SQUIRREL VERIFY APPLICATION MEMORY CONFIGURATION=65536`).
- 10001 active rows maximum and 4096 bytes of text per row, with one 4097-byte heap allocation per active row instead of the former eager 512 KiB document allocation.
- Transactional file load: on allocation, parse or I/O error, previous buffer stays intact.
- Updated newline splitting, joining, insertion and deletion to move owned row pointers rather than copying 4097-byte rows indiscriminately.
- Fixed document insertion to parse into a temporary document and preflight the resulting dimensions before mutating the current buffer.
- Save writes a temporary file, verifies writes, flushes and closes, then promotes; JTMFS rename cannot replace existing destinations, so existing files are first renamed to `.edtbak` and restored on failed promotion where possible.

## Important limitations / next tasks
- JTMFS replacement is not a truly atomic transaction across power failures; retained `.edtbak` files can require recovery. Filename/component length constraints must be considered.
- 64 MiB is a process reservation request, not a guarantee that contiguous physical memory, kernel mappings and libc heap allocations succeed; verify on QEMU and real hardware.
- `Ctrl+K` still follows the previous cursor-to-end-of-line contract, rather than GNU Nano's complete-line default.
- No Ctrl+6 mark, Alt+6 copy, undo/redo or case-insensitive search yet. These items from the prior roadmap are not completed in this stage.
- Fixed cut buffer has 65535 bytes. Pasting respects document/line bounds.
- The maximum of 10001 rows is one extra to represent a trailing newline after 10000 full-width lines.
- The current loader converts tabs to spaces and does not support embedded NUL bytes.
- Tests performed: application compile/link and ELF32 header check; NOT an interactive runtime test.

## Memory budget
10000 * 4096 = 40,960,000 bytes = 39.0625 MiB of text;
10000 * 4097 = 40,970,000 bytes = 39.072 MiB of allocated line storage;
10001 pointers on ELF32 = 40004 bytes (~39.1 KiB); extra space for allocator overhead, code, runtime and cut buffer.
A 64 MiB request leaves nominal headroom, but is NOT proven sufficient in the kernel's runtime memory model.
