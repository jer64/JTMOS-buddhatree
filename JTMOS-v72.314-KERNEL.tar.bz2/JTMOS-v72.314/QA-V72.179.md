# QA — JTMOS v72.179 — Google DOM/web compatibility

- Native JTMOS i686 Navigator: PASS (`make -C libc/apps -f navigator.mak navigator.bin`).
- Host QuickJS UI integration: PASS (DOM classes, tagName, matches/closest, selector lists, dataset Proxy, history replaceState same origin, animationFrame). Host Navigator code built with ASan+UBSan; large vendored host QuickJS core was compiled without sanitizer for practical build time.
- Real user-provided Google Search HTML static snapshot: PASS; 4864 DOM nodes, 11509 CSS rules, 4251 paint operations, 2149 result-region draw items, no partial rendering.
- Whiteout regression: PASS; 3960 glyphs retained after JS/CSS whiteout; normal JS mutation preserved.
- Pending: real Google live response on JTMOS/T400; complete kernel rebuild; full History API; browser Web APIs; visual screenshot parity.
