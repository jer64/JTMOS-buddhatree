# JTMOS v72.165 – sovelluskaatumisten eristys

27.10.2026. Pohja: kokonainen v72.164-julkaisu. Todisteet:
`release/qa/v72.165/`.

Korjaus kattaa sovelluksen poikkeuksen, lopetuksen jälkeisen muistinsiivouksen,
ympäristötietojen eliniän ja kaatumisraportin tallentamisen. PID0:n, ydintehtävien
immortal-suojauksen, NMI-tehtävän sisäisen poikkeuksen, double faultin ja machine
checkin vakavien virheiden pysäytyspolku säilyy.

| Tarkistus | Tulos |
|---|---|
| Täysi natiivi koonti ja lopullisten medioiden koonti | PASS |
| ELF/raw, aloitusosoite, BSS ja ytimen kokomarginaali | PASS: 938780 tavua, 109796 vapaana; vähimmäismarginaali 65536 |
| ISO/SQA-paketit, NZIP, käynnistyslevykuva ja DOSBOOT-kopiot | PASS (`media-check.json`) |
| Tavalliset poikkeukset, 21 lapsen kaatumista, orvoksi jääneen lapsen ympäristö, komentotulkin jatkuminen ja demand paging | PASS 19/19 (`verified-basic/result.json`) |
| Sovelluksen page fault + jatkovika kaatumislokin kirjoittajassa + lokiprosessin uudelleenkäynnistys | PASS 4/4 (`verified-secondary/result.json`) |
| VESA: poikkeukset, 21 lapsen testi ja orvon lapsen ympäristö; ei hätätekstin tilanvaihtoa | PASS 7/7 (`verified-vesa/result.json`) |
| Oikea JTMFS-levy: kaatumisraportti tallentuu hda1:/logs/crash.log-tiedostoon | PASS 4/4 (`verified-persistence/result.json`) |
| Sovelluksen eristys myös vanhan kernel-worker-palautuskytkimen ollessa 0 | PASS 5/5 (`verified-containoff/result.json`) |
| Nutget HTTP/HTTPS, SQSH, Ctrl+C ja tulosteen ohjaus | PASS 5/5 (`acceptance-nutget/result.json`) |
| Verkon kolme peräkkäistä uudelleenkäynnistystä ja lataus; ei CPU-poikkeuksia | PASS 2/2 (`verified-network-lifecycle/result.json`) |
| Poikkeus-, ISR- ja NMI-lähdeauditoinnit | PASS |
| Julkaisunumero ja asennusskriptien ajantasaisuus | PASS |

Käyttäjätilan testit aiheuttavat oikean page faultin osoitteeseen 0x90000000,
NULL-kirjoituksen, kirjoituksen vain luettavaan sivuun, UD2:n, nollalla jaon,
CLI:n aiheuttaman GP-virheen ja virheellisen käyttäjäpinon. `wait` tarkistaa
21 lapsen signaalistatukset waitpid-kutsulla. `orphan` tarkistaa, että lapsen
ympäristömuuttuja säilyy vanhemman page faultin ja siivouksen jälkeen.
`mmdemand.bin` varmistaa, että korjattavissa oleva sivuvirhe edelleen palaa
alkuperäiseen käskyyn.

## Ennen–jälkeen-todiste

V72.164:n tavalliset käyttäjätilan poikkeukset eristyivät jo perustestissä.
Koko ytimen pysäyttävä jatkoketju toistettiin lisäämällä QEMU-vieraan
kaatumislokin kirjoittajaan hallittu UD2-vika. V72.164 pysähtyi CPU_IDLE:n
(PID1) poikkeukseen (`baseline-crashlog-enabled/result.json`). V72.165 sulkee
virheellisen KLOGGER-prosessin, komentotulkki jatkaa ja lokiprosessi käynnistyy
uudelleen eri prosessisukupolvella. Samankin PID-numeron kierrätys tunnistetaan
thread_magic-arvosta.

Lokitus on julkaisun aiempien laitetestiasetusten mukaisesti oletuksena pois
(`SYSTEMLOGGING=0`). Vikatestit ottivat sen käyttöön vain omassa QEMU-vieraassaan.
Kirjoittajan jatkovika ja vanhan palautuskytkimen muutos tehtiin GDB-protokollalla
vieraan muistissa; julkaistuja levytiedostoja ei muutettu testivioilla.
JTMFS-tallennustesti osioi ja alusti vain testin luoman 64 MiB:n levytiedoston.

Lopetus siirtää oman pinon vapauttamisen CPU_IDLE:n tekemään etäsiivoukseen.
Vanhaan, puuttuvaan dezombie-kerääjään ei enää jätetä prosesseja. Ympäristöjen
tietokannat ja merkkijonot vapautetaan niiden varsinaisen eliniän päättyessä;
luoneen vanhemman tai lokiprosessin muistipyyhkäisy ei saa tuhota niitä.

Verkon uudelleenkäynnistys varaa uudet työntekijäpinot. Pysyvä TCP-socket-taulukko
ei enää ole ensimmäisen uIP-prosessin muistinomistuksessa. Näin vanhan prosessin
siivous ei vapauta edelleen käytettäviä verkon tietorakenteita. Verkkotestissä
käytettiin NE2000-emulaatiota, QEMU:n käyttäjäverkkoa ja paikallisia HTTP/HTTPS-palvelimia.

Valinnainen `faultprobe.bin` sisältyy vain tests.sqa-pakettiin. Ilman argumentteja
se näyttää ohjeen. Esimerkiksi `faultprobe.bin pf` kaataa tarkoituksella vain
testiprosessin ja `faultprobe.bin wait` tarkistaa lapsiprosessien eristyksen.

## Rajaus

Testit käyttivät QEMU:n TCG-emulointia, 512 MiB muistia ja VESA-testissä
1024×768×32-tilaa. ThinkPad T400:lla ei tehty laitetestiä eikä alkuperäisen
käyttäjähavainnon tarkkaa panic-viestiä ollut käytettävissä. Grafiikkatesti
varmistaa ytimen VESA-tilan säilymisen; se ei kata kaikkia GraOS-sovelluksia.
