# JTMOS V71.124 – QA

Pohja: JTMOS V71.123:n nykyinen täysi julkaisu (alkuperäisen ZIPin SHA-256
`c808e644a0a406d67fac1e2e3f9fb8e2c9663146692f9de0ae2f4b606d5caff4`).

| Tarkistus | Tulos |
|---|---|
| `tests/v71124_jtmfs_overwrite.py --source-tree <alkuperäinen v71.123>` | 31 epäonnistuvaa käyttäytymistarkistusta: virheet toistuivat |
| Sama testi korjatulla koodilla, AddressSanitizer + UndefinedBehaviorSanitizer | PASS, 0 epäonnistumista |
| Muutettujen kernel-tiedostojen i686-käännöstarkistus | PASS, ei uusia varoituksia |
| Täysi päätason `make` | PASS |
| Lopullisen kernelin ja käynnistyskuvan uudelleenrakennus | PASS |
| Natiivi `fsregress.bin --overwrite-only`, RAM-JTMFS | PASS |
| Sama natiivi testi erillisellä 128 MiB:n virtuaalisella HDD:llä | PASS |
| `jtmfsck -n hda`, fyysisen virtuaalimedian luku | CLEAN |
| QEMU-reset ja saman HDD:n uusi mount + `jtmfsck -n hda` | CLEAN |
| Vanha atomisen ylikirjoituksen/jtmfsck:n regressio | PASS |
| Vanha atomisen allokoinnin/resize-polun regressio | PASS |
| JTMFS integrity -käännöstarkistus | PASS |
| JTMFS crash-safety-, single-writer-, small-file latency- ja V71.20-transaction-checkit | PASS |
| Syscall IRQ-, NMI- ja GDT/TSS-auditit | PASS |
| V71.123 Navigator cookie/DOM/HTTP-regressiot | PASS |

## Mitä oikeasti ajettiin

Host-testi poimii toimitettavista C-lähteistä `open`, `write`, `read`, `lseek`,
`close`, `jtmfs_atomic_replace`, puskurin flush/free-polut sekä asiaankuuluvat
`scs.c`-funktiot ja kääntää ne samaan testiohjelmaan. Se ei korvaa korjattavaa
algoritmia erillisellä mallilla. Levy-, hakemisto-, FD- ja scheduler-ympäristö
on pieni deterministinen testitausta, johon injektoidaan ENOSPC-, osittainen
kirjoitus-, sync- ja namespace-commit-virheitä.

Tapaukset kattavat 0/1/4096/131072/131073 tavun alkuperäiset tiedostot,
lyhyen ja tyhjän korvauksen, vanhan sisällön säilymisen ennen closea,
lykätyn EOF:n, seek-reiät, ftruncate-kasvun ja pienennyksen, EOF:n jälkeisen
luvun, fsyncin, puskuroidun closen ja sen virheen, jaetun fork-FD:n viimeisen
closen, vanhentuneen mountin, read-only-tilan, tiedostojärjestelmädispatchin
sekä kirjoitus- ja seek-offsetin ylivuodot.

Natiivi QEMU 8.2.2 -testi käyttää 256 MiB RAMia ja vain testin itse luomaa
128 MiB:n levytiedostoa. Se käynnistää toimitettavan kernelin ja ajaa oikean
Ring3-ohjelman oikean syscall- ja JTMFS-ketjun kautta. Kiintolevy alustetaan
vain tämän testin erillisessä virtuaalikoneessa. Testi tarkistaa myös
uudelleenkäynnistyksen jälkeisen median eheyden. Kernelin, boot-kuvan ja
natiivin testibinäärin tarkat SHA-256:t ovat `release/qa/v71.124/qemu-result.json`.

## Rajaukset

- Fyysistä eMachines-konetta tai sähkönkatkoa oikean ATA-laitteen kesken ei
  testattu. Virheinjektiot ja QEMU-reset eivät vastaa kaikkia mahdollisia
  laitteiston virtakatkotilanteita.
- Staging-korvaus pitää vanhan kohteen näkyvissä viimeiseen onnistuneeseen
  closeen asti. Fsync tallentaa stagingin sisällön ja pituuden; kohdenimen
  julkaisu tapahtuu edelleen closessa, kuten JTMFS:n aiemmassa staging-polussa.
- Tavallinen ilman O_TRUNC-lippua tehty satunnaiskirjoitus on edelleen in-place.
  Kirjoitusvirhe ei voi palauttaa jo fyysisesti ylikirjoitettuja tavuja tällöin.
- Vanhan make check -kokonaisketjun historiallisia, muiden osa-alueiden
  odotuksia ei sertifioitu vihreiksi. Yllä ovat tämän korjauksen ajetut tarkistukset.
- LeakSanitizer on host-ympäristön rajoituksen vuoksi pois käytöstä;
  AddressSanitizerin ja UndefinedBehaviorSanitizerin tarkistukset ovat käytössä.

`tools/check_jtmfs_crash_safety.sh` tarkistaa nyt argumenttisuojan oikeasta
`_jtmfs_ReadFileCursor`-toteutuksesta, ei pelkästä vanhasta välityswrapperista.
Tämä korjaa testin vanhentuneen kohdistuksen muuttamatta turvavaatimusta.

Pakkaus säilyttää koko lähdekoodin, testisyötteet ja nykyiset ajotiedostot.
Mediakaksoiskappaleet, välitulokset, vanhat release-binäärit ja vanhat QA-kuvat
suodatetaan pois. DOSBOOT-kopiot palautuvat `tools/restore_release_media.py`:llä.
Lopullinen ZIP CRC- ja SHA-256-manifestitarkistetaan ennen toimitusta.
