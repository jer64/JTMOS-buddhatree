# JTMOS V72.259 TCP receive-window optimization

## What changed

- TCP user sockets: the existing 256 KiB receive ring grows to 512 KiB. Each ring is allocated lazily on its first active/passive open, permanently owned by the kernel and cached for the lifetime of that socket slot. Memory allocation occurs outside the interrupt-disabled region. If 512 KiB cannot be allocated the driver retries with a 256 KiB ring and the older 172-MSS window. If both fail, the socket is rejected with ENOMEM rather than advertised with a nonexistent receive buffer.
- The advertised maximum window changes from 172 MSS (251,120 bytes) to 340 MSS (496,400 bytes), with 27,888 bytes of safety headroom in a 512 KiB ring. It also shrinks with occupancy and is capped at 172 MSS on the smaller fallback allocation. Legacy peers remain limited to 65,535 bytes.
- The uIP RFC7323 receive window shift changes from 2 to 4. The SYN window itself is never scaled; the shift is only used after successful negotiation.
- IP MTU remains 1500 bytes; TCP MSS stays 1460. The change does not require jumbo frames.
- libc socket refill staging grows from 2 KiB to 8 KiB; Navigator streaming body reads/callback spans from 4 KiB to 8 KiB.
- `inet` diagnostics state the actual configured windows rather than stale pre-v72.195 numbers.

## Limits and expected behavior

A wider receive window can reduce throughput limited by bandwidth-delay product, but **does not** ensure a particular speed-up. TLS, worker scheduling, CPU usage, packet loss, single-segment uIP transmit behavior, and remote server limits can remain bottlenecks. The minimal uIP stack does not provide modern SACK/out-of-order reassembly. Large windows should be stress-tested under packet loss before defaulting for all installations.

## Integration status

The code was compiled for JTMOS i386, with Navigator ELF32 linked. Tests and full-system status are recorded in the release message; boot media inherited from prior versions are not freshly built here.

## Runtime measurements

Collect paired baseline and v72.259 measurements with the same server/file, including LAN and WAN RTT, TCP retransmits and memory usage:

```
inet stats
uip fast
```

Test under QEMU first, then T400 with realistic packet loss. Before attributing gains to the window, compare TLS and HTML parsing CPU times as well.
