# JTMOS V72.169 — validointi 28.10.2026

Pohja on JTMOS-Navigator-v72.168-FULL-SOURCE-UPDATE.zip:n versio 2.
Sen käyttöjärjestelmän VERSION oli 72.166 ja Navigatorin 72.168.
Tämä julkaisu päivittää käyttöjärjestelmän lähdeversion 72.169:ään.

## Tehdyt korjaukset

- Bittikartan olemassaolo ja todellinen kapasiteetti tarkistetaan myös silloin,
  kun fyysiset muistialueet on jo rekisteröity. Virheellistä pituutta ei kerrota
  ylivuotavasti kahdeksalla eikä kartan ulkopuolelle lueta tai kirjoiteta.
- Päällekkäiset ja vierekkäiset fyysiset alueet yhdistetään järjestetyksi
  unioniksi. Vapaiden sivujen uudelleenlaskenta ei laske päällekkäisyyttä kahdesti.
  Sivuhaku ja laskenta tapahtuvat MM:n keskeytyssuojauksen sisällä.
- Sparse-kfree ja omistajan tarkistava vapautus eivät avaa keskeytysaukkoa
  kuvaajan tarkistuksen ja vapautuksen väliin. Irrotettu vapautettava kuvaaja
  ei jää prosessin siivouksen uudelleen löydettäväksi.
- Mmap hylkää tuntemattomat liput ja osoitteettomat/kohdistamattomat kiinteät
  varaukset. Kernelin mmap ei hyväksy tukematonta demand-lippua. Alarajan
  pyöristyksen ylivuoto hylätään. Kiinteä kernel-mmap säilyttää boot-omistajuuden.
- Munmapin kokotarkistus ja vapautus ovat atominen MM-operaatio. VMA:n ja
  sparse-varauksen laskenta julkaistaan yhdessä niiden tilan kanssa.
- CPU-poikkeukset käyttävät HandleThreadException-handleria. Tavallinen
  virheellinen tehtävä karanteenoidaan; CPU_IDLE vapauttaa resurssit myöhemmin
  KillThreadExillä. FATALEXCEPTION säilyy vanhojen moduulien ABI-kääreenä.
- Sisäkkäisen poikkeuksen omistaja validoidaan ennen eristystä. Virhe myös
  sisäkkäisen karanteenin aikana päätyy rajattuun järjestelmävirhepolkuun.
- Karanteenin kerääjä yrittää epäonnistunutta lopetusta uudelleen. PID:n
  sukupolvitarkistus estää uuden, samaa PID:tä käyttävän tehtävän muuttamisen.

## Läpäisseet tarkistukset

| Tarkistus | Tulos |
| --- | --- |
| Tuotannon mmBit.c, mmAlloc.c, mmEntry.c ja mmap.c, 32-bittinen ajotesti | 19 083 tarkistusta PASS |
| Poikkeuspolitiikan ja reaperin tuotannosta sellaisenaan poimitut C-funktiot | 1 566 tarkistusta PASS |
| CPU-vektorien 0–31 reititys ja sisäkkäisen poikkeuksen suojat | PASS |
| Kuusi muuttunutta tuotannon C-tiedostoa, i486/-m32/-Werror | PASS |
| make -C kernel32 syntax | PASS, kolme aiempaa varoitusta |
| tests/v709_cow.py | 20/20 PASS |
| tests/v7010_first_touch_sparse.py | 30/30 PASS |
| tests/v7140_mm_safety.py, v7141_mm_safety.py, v7142_cow_page_safety.py | PASS |
| tools/check_mm_reentry_safe.sh | PASS |
| tools/check_v68209_exception_if0_recovery.sh | PASS |
| tests/v7066_interrupt_isr_audit.py | PASS |
| tools/audit_nmi_safety.py | PASS |

Ajotesti kääntää oikeat tuotannon MM-tiedostot freestanding i486/ELF32-
ohjelmaksi. Vain laitteisto-, sivutus-, ajastus- ja valinnaisen buddy/slab-
kerroksen rajat simuloidaan. Isäntä ei käynnistä i386-ohjelmaa suoraan, joten
se suoritettiin Unicorn 2.1.4:n i386-emulaatiossa. Testi tarkistaa muun muassa
callocin nollauksen, reallocin sisällön säilymisen, OOM- ja map-virheiden
palautukset, keskeytystilan säilymisen sekä julkaisu/vapautusrajojen uudelleentulon.

Kun yksi tiedosto kerrallaan palautettiin alkuperäiseksi, testi tunnisti
virheen kaikissa kolmessa muokatussa MM-C-tiedostossa: mmBit.c aiheutti
virheellisen muistiluvun, mmAlloc.c paljasti sparse-vapautuksen keskeytysaukon
ja mmap.c hyväksyi tukemattoman lipun. Tämä vertailu ei muuta toimitettua koodia.

Poikkeus-/reaper-testissä tuotannon funktiorungot käännetään sellaisinaan
kontrolloidulla ajastinrajalla. Testi tarkistaa virheelliset PID:t ja vektorit,
PID0:n ja immortal-tehtävien suojauksen, vapautusyrityksen epäonnistumisen ja
uudelleenyrityksen, PID:n uudelleenkäytön sekä IF=0/IF=1-tilat.

## Pohjassa jo olleet rajoitteet

- Kernelin syntaksitarkistuksessa oli ennen korjausta samat kolme varoitusta:
  core/random/secure_random.c ja drivers/tcpip/jt_sntp.c käyttävät SchedulerWaitPausea
  ilman näkyvää prototyyppiä; drivers/mouse/ps2mouse.c sisältää harhaanjohtavan
  sisennyksen. Muokatut kuusi C-tiedostoa kääntyvät -Werrorilla.
- tests/mm_v70_architecture.py ja tests/mm_multitask_mutex_v691.py epäonnistuvat
  vanhoihin alimerkkijonohakuihin myös alkuperäisestä ZIPistä palautettuna.
- tools/check_release_layout.sh odottaa vanhaa yksirivistä `linkit: image`
  -sääntöä. Pohjapaketissa on jo profiilin säilyttävä monirivinen linkit-sääntö.
- tests/v7166_nmi_exception_stack.py:n kolme NMI-watchdog-väitettä eivät vastaa
  nykyistä muuttamatonta NMI-toteutusta. Poikkeuspinoon liittyvät väitteet
  menevät läpi. ISR- ja nykyinen NMI-safety-auditointi menevät läpi.
- Täyttä `make check` -kokonaisuutta ei väitetä läpäistyksi.

## Mitä ei ole testattu

NASM ja QEMU-järjestelmäemulointi eivät ole käytettävissä. Täyttä kernelin
linkitystä, image-buildia, JTMOS-käynnistystä, oikeaa IRQ/IRET/TLB-käytöstä,
fyysisten aliasten koherenssia, COW-kopiointia tai laitteistoa ei testattu.
SMP-turvallisuutta ei lisätty: MM-suojaus on edelleen yhden CPU:n IRQ-save-malli.
Kernelin yhteisen tilan rikkoutumiset, PID0/immortal sekä NMI/#DF/#MC säilyttävät
järjestelmävirheen käsittelyn. Osittainen munmap ja tiedostommap eivät kuulu
nykyiseen rajapintaan.

Paketin vanhat binaarit ja mediat eivät sisällä tämän lähdekorjauksen muutoksia.
