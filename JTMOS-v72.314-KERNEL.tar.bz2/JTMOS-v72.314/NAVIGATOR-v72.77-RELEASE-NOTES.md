# JTMOS Navigator v72.77 – hiiren käyttöliittymäkorjaus

Pohja: v72.76 FULL SOURCE RELEASE. Tämä on kokonainen lähdekoodijulkaisu, ei patch/overlay.

## Korjaukset

- HTML5/CSS- ja F6-tekstinäkymän oikean reunan pystysuora vierityspalkki reagoi klikkaukseen ja hiirellä vetämiseen.
- Vierityspalkin liukusäädin piirretään samalla geometriamallilla, jota hiiritapahtumissa käytetään.
- Hiiren rullalla tehtävän osittaisen ruudunpäivityksen jälkeen myös vierityspalkin alue päivitetään GraOS:iin.
- Hiiren oikea klikkaus avaa selaimen kontekstivalikon; linkillä valinnat ovat Open link, Download link, Copy link URL ja Reload page.
- Muualla sivulla kontekstivalinnat ovat Reload page ja Copy page URL.
- Latausvalinta tukee myös HTTP(S)-linkkejä, joiden polku ei pääty tunnettuun tiedostopäätteeseen. Tiedostonimi suodatetaan turvalliseksi.
- Tiedostot ladataan nykyisen O_EXCL/.part-latauspolun kautta. Keskeneräiset tiedostot eivät korvaa valmiita tiedostoja.
- Sama toiminta kattaa selainikkunan koon muuttamisen ja vanhan tekstinäkymän.
- SDL2-yhteensopivuus-GraOS:n oikean hiiripainikkeen edelleenlähetys lisätty; natiivin GraOS:n oikean painikkeen lähetys oli jo toteutettu.

## Testit

- `python3 tests/v7277_interaction_regression.py`: PASS, AddressSanitizer + UndefinedBehaviorSanitizer, 8 000 skenaariota sekä rajatapaukset.
- `python3 libc/apps/navigator/tests/test_navigator_http.py`: PASS, 12 HTTP-latauksen integraatiotestiä.
- `make -C libc/apps -f navigator.mak navigator.bin`: PASS. `navigator.bin` = ELF32/i386.
- `sqarc --compare-member release/packages/navigator-v72.77.sqa navigator.bin libc/apps/navigator.bin`: PASS.
- GraOS-palvelimen natiivikoodin v72.76:ssa jo toteutettu oikean painikkeen välitys tarkistettu lähdekoodista.

## Käyttö

1. Asenna uusi `navigator.bin` esimerkiksi `hda1:/bin/navigator.bin`-polkuun.
2. Käynnistä Navigator GraOS:ssa ja avaa pitkä HTML-sivu.
3. Tartu oikean reunan harmaaseen liukusäätimeen vasemmalla hiirinapilla ja vedä; vaihtoehtoisesti klikkaa tyhjää vieritysrataa.
4. Klikkaa artikkelin tai MP3-linkin päällä oikeaa hiirinappia, valitse `Download link`.
5. Lataukset tallentuvat `ram:/download-...`-nimiin. RAM-levyn sisältö ei ole pysyvä; siirrä tiedosto haluttuun pysyvään tallennuspaikkaan erikseen.

## Rajoitukset

- Lataus tapahtuu vielä synkronisesti, joten suuret tiedostot voivat estää käyttöliittymän päivittämistä latauksen ajan.
- Uutta käyttöliittymää ei ole testattu QEMU:ssa eikä fyysisellä eMachines-koneella.
- Kokonaisjulkaisussa säilyy v72.76:n alkuperäinen `utilities.iso` eikä se välttämättä sisällä v72.77 Navigatoria. Päivitetty binaari ja erillinen `.sqa` ovat mukana. ISO:n rakennus vaatii erillisen mediatyökaluketjun.
- Julkaisua ei ole hyväksytty tuotantokäyttöön ilman laitetestausta.
