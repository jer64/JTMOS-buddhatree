# JTMOS v72.109 — kernel build/size correction

Date: 24 October 2026. Base: full v72.108 source/release.

The user reported `.data` ending at `0x00200bfc`, 3,068 bytes beyond the
fixed 1 MiB image window, overlapping BSS at `0x00200000`. V72.108's release
build left only 5,796 bytes spare. This was inadequate variation margin.
The exact user compiler/options are not inferred from this log: our isolated
v72.108 GCC 14.2 baseline also fitted, leaving 6,372 bytes, so it does not
reproduce the user's exact binary footprint.

The memory boundary checks correctly prevented a corrupt image. They remain
in place; no load/BSS/stack addresses or boot-storage limits have been raised.

## Change

The kernel now uses `-ffunction-sections -fdata-sections`, a proper ELF32/i386
link with `--gc-sections`, followed by `objcopy -O binary`. Using collection
with the old direct raw-binary output did not materially reduce the kernel.
The script explicitly places split `.text.*`, `.data.*` and `.bss.*`, retains
the bootstrap and build-identity record, and marks BSS NOLOAD.

The checker reconstructs every allocated file-backed ELF section and compares
it with the raw image. It also checks entry, section bounds, BSS/early stack,
embedded build version and a default **64 KiB free-space margin**. Its JSON
report records the actual compiler and ELF/raw SHA-256 values.

| Compiler | Raw bytes | Free bytes within 1 MiB |
|---|---:|---:|
| GCC 13.3 | 955,004 | 93,572 |
| GCC 14.2 | 954,460 | 94,116 |

Kernel objects depend on the compiler/options profile and generator/settings.
The profile includes the real compiler identity and expanded options; it is
written without shell re-quoting CFLAGS. An unchanged profile preserves its
header timestamp. Compiler or option changes trigger rebuilds. Module and boot
definitions participate in the fingerprint. Direct kernel32 builds preserve
the selected boot profile unless an explicit override is provided.

`imgsrc/img.c` now checks configuration reads, image size/allocation and
offsets. It rejects truncated/malformed input instead of reusing stale tokens.
Valid image bytes are unchanged. The outer-package guard now reports any
unexpected member's exact path instead of a generic message.
The installer verifies each packed compressed member against its source and
compares the enclosed boot image byte-for-byte before publishing. A media test
follows ISO -> boot.sqa -> A-image -> NZIP -> raw kernel, preventing a stale
embedded boot image from surviving a successful kernel rebuild.

## Validation

- Real kernel ELF/raw comparison and both compiler builds; see JSON reports.
- Actual kernel objects relinked with injected unused 1 MiB data: collection
  removes it and raw bytes remain identical.
- Retained 40 KiB padding: link fits physically, but the reserve checker rejects it.
- Retained 128 KiB padding: physical text/data assertion rejects overlap.
- Retained 128 KiB BSS: early-stack assertion rejects it.
- Truncated raw image: ELF/raw comparison rejects it.
- Native `ich9e_init`, `ich9e_restart`, relative mouse queue and syscall roots
  remain in the final kernel ELF, together with bootstrap and initialization.
- Compiler-profile stability and option invalidation tests.
- `imgsrc/img.c` built with GCC, `-D_FORTIFY_SOURCE=2 -Wall -Wextra -Werror`:
  no diagnostics; valid output byte comparison and 10 malformed inputs.
- GCC 14.2 BIOS/NZIP image boots in QEMU; scheduler/keyboard, SMSH, RAM mkdir/cd
  and help tested through real keyboard events. This is a kernel boot test,
  separate from the final release-media tests.
- Final default full release build, PS/2 and USB OHCI GraOS tests, cursor/menu
  regression checks, actual media bytes and final archive audit are recorded
  under `release/qa/v72.109/`; the archive audit is delivered separately.

The V72.108 behavior remains: pointer Start is classic; Windows/Ctrl+Esc/Win+Tab
open Overview; relative mouse data avoids invisible edges; menu cursor motion
within one row does not recompose the desktop. Private GUI ABI stays 108;
public release/version is 72.109. Native T400 reset/PHY/Kumeran support stays.

Final default full-system PS/2 and USB runs: **PASS**. Both used the final
kernel and packages. Each measured 24 cursor-only presents, zero desktop
recompositions and no rebuilt menu surface while moving within one menu row.
All 112 application targets and boot32pm/DOSBOOT/install media were built.

The final QEMU results are bound to these exact shipping artifacts:

```text
kernel32.bin  1f925d786e5a3d9b5dda67ea954217f1c7c4e5ade7d51aa74528fa61d6ee7e1c
utilities.iso 0c6997e65490e3eb67783ff2d8050c9c982a884884e5dd8502c35a73375675b8
graos.bin     caa8751d8de74729684b588d093b53e0ff7b111be25a55dda17a94a914b86ad5
```

The unchanged-build log records zero C compilations while preserving the
selected root boot profile. GCC 14 boot evidence comes from its separate final
image; the shipped default kernel uses GCC 13.3.

## Limits

GCC 13.3 and 14.2 were tested. The user compiler and enabled-module differences
are unknown. Builds now fail explicitly before releasing an image with the
inadequate default reserve. Custom profiles still have the physical image and
stack linker protections.

The inherited optional legacy `boot32/nonsysdisk.bin` is absent; packaging
zero-fills that reserved area. Supported boot32pm/DOSBOOT artifacts are built.
Pre-existing warnings in unrelated kernel modules remain; this is not a claim
that the entire historical source tree has zero warnings. The old global
warning gate also has the unchanged historical scheduler-pattern failure
described in v72.108 QA. The image-tool warnings shown in the user's log are fixed.

Physical T400 Ethernet transmission, reception, TrackPoint feel and display
timing remain hardware acceptance items. Emulation does not establish those.

## Installation

Use a new v72.109 source directory or rebuild from this complete tree with
`make`. Do not alter the 1 MiB memory boundary. For FreeDOS, replace the
DOSBOOT directory's **KERNEL32.NZ**, loader and utilities medium together;
copying an isolated `kernel32.bin` does not update that boot path.

Linker behavior was checked against the primary GNU Binutils documentation:
[section garbage collection and entry roots](https://sourceware.org/binutils/docs/ld/Options.html).
