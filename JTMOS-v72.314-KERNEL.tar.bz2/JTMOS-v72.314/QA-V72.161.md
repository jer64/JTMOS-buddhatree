# JTMOS v72.161 – QA

Päiväys 27.10.2026. Pohjana on kokonainen v72.160-lähdepaketti (SHA-256 `51aa82a0…dbc83fb7`).

| Tarkistus | Tulos |
|---|---|
| Natiivi koonti ja media (`check_release_media.py`) | PASS |
| Ohjelmien pakettiomistus (V70.31, V70.29), myös hakemistopuupaketit | PASS (124 ohjelmaa, 9 ulointa pakettia) |
| SQARC521 isäntätesti: puu, tyhjät hakemistot, `-o`, `--list`, `--extract-member`, 4 vihamielistä polkua, litteä SQARC520 | PASS |
| SMSH ajaa nimellä `angbandinstall.sh`, `bitchxfullinstall.sh`, `bitchxinstall.sh`, `irciiinstall.sh`, `fhsinstall.sh` (#!/bin/sqsh ytimen lataajassa) | PASS |
| Asennettu GNU/FHS-rakenne: /usr/bin, /usr/share/&lt;paketti&gt;, /usr/share/doc, /var/games/angband, /var/www/html | PASS (11/11 polkua) |
| `--help` asennusskriptissä | PASS |
| Skripti nimellä: `$#` `$1` `${0##*/}` `${0%/*}` `${X:-oletus}`, if/then/else, `exit` | PASS |
| `sqsh TIEDOSTO ARG` ajaa ja poistuu | PASS |
| `#!/bin/sh` → sh.bin, `*.sh` ilman #!-riviä → sqsh | PASS |
| Ytimen `sqarc -r` + `sqa -o` (SQSH:sta) | PASS |
| WWW: tiedosto vain /var/www/html:ssa palvellaan | PASS |
| Angband: "[Initialization complete]", data /usr/share/angband, .raw-tiedostot /var/games/angband/data | PASS |
| HDA QEMU ich9-intel-hda: duplex, micro ja 3 rinnakkaista ajoa, 4 s ääni ilman yli 1 ms:n katkoa | PASS (5/5) |
| GraOS-leikepöytä, kalenteri, SQSH Ctrl+V (V72.160) | PASS |
| QEMU-verkkoregressio | PASS 10/10 |
| SQSH:n Ctrl+C | PASS |
| Koko paketin manifesti (`check_full_release_manifest.py`) ja ZIP:stä uudelleenkoonti | PASS (kernel32.bin, graos.bin, sqsh.bin, sqa.bin, angband.bin, bitchxfull.bin, utilities.iso, levykuvat identtiset) |
| Muut: find/lainausmerkit, SQA-NZIP, jokerit, kopioeheys, Angband/BitchX/ircII-auditit | PASS |

Huomio: QEMU:n tekstikonsolissa Angband käynnistyy ja lukee datansa, mutta
sen näppäinsyötettä ei testattu (peli on tarkoitettu GraOS:n terminaaliin).
`tests/v7181_release_check.py` ja `tools/check_v7041_bitchx_network_package.sh`
vaativat kiinteän vanhan VERSION-arvon (71.81 / 70.41) ja epäonnistuvat jo
v72.160:ssa; `tests/v7165_irc_dcc_exec_plugins.py` epäonnistuu v72.160:n
tavoin vain kohdassa "scall_sockctl ends the table".
