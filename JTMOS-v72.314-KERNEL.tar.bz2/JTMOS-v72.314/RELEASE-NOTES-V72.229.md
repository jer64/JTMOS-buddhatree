# JTMOS v72.229 – Kernel SQA renamefile Link Fix

## Problem
Kernel linking in v72.228 failed with three undefined references to `rename`
in `kernel32/sh/sqa.c:sqa_publish_stage`. JTMOS kernel32 provides
`renamefile(oldpath,newpath)` in `fs/jtmfs/publicapi/directfileaccess.c`,
not POSIX `rename()`.

## Fix
- In `kernel32/sh/sqa.c`, include `directfileaccess.h` only for JTMOSKERNEL.
- Introduce a target-specific `SQA_RENAME(from,to)` macro:
  - `JTMOSKERNEL`: `renamefile(from,to)`;
  - host/user-space: `rename(from,to)`.
- Use the abstraction for backup, stage publication and rollback.
- Preserve v72.228's staged extraction, checksum verification and backup recovery.
- Update `VERSION` and `kernel32/include/jtmos_release.h` to v72.229.

## Verification
Run `tests/v72229_sqa_kernel_rename_link.sh` to compile the affected kernel
modules and check that `sqa.o` references `renamefile`, which is defined by
the compiled JTMFS module. It also runs the v72.228 host repeat-extraction
and corruption/fallback regression suite.

The kernel modules compile and their rename symbol is resolved through the
kernel JTMFS implementation. A whole-kernel ELF/binary link and hardware
boot are **not guaranteed by the module tests**. A full kernel build requires
the platform build tools including NASM (`sudo apt install nasm`).

## Build
`make clean && make -j$(nproc)` (on a configured development host)

The package is a **full-source release**, not a patch. Prior v72.227
Navigator/worker changes and v72.228 JTMFS/SQA changes are included.
