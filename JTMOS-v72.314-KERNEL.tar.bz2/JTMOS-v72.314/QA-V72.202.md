# QA — JTMOS v72.202

## Verified

- Native Navigator rebuilt using its canonical navigator.mak with default
  Lexbor/QuickJS/WebP/BearSSL features and normal -Werror flags: PASS.
- ELF32 i386 executable, entry 0x80004000, memory preference 524288 KiB: PASS.
- 19 UTF-8 vectors at every possible two-buffer split: PASS.
- All 1,112,064 Unicode scalar values round-trip through the existing encoder,
  new bounded decoder and DOM adapter; also tested one input byte per buffer:
  PASS. This includes ASCII, NUL, Nordic letters, BMP boundaries, U+FFFD and
  supplementary scalars up to U+10FFFF.
- 478,394 comparisons against Python's independent UTF-8 replacement decoder:
  PASS. Covers all 1-byte and 2-byte inputs plus 12,000 deterministic random
  buffers, delivered in whole buffers and chunks of 1, 2, 3, 4 and 7 bytes.
- ASan and UBSan codec tests, exact-length input allocations, malformed input,
  truncated EOF flush, document reset, invalid arguments and retry of an
  unconsumed HTML delimiter: PASS.
- Standalone C99 example compiles and runs without JTMOS libraries: PASS.
- Browser integration under ASan/UBSan with BOTH pinned Lexbor HTML5 and
  the native fallback: PASS. Six HTML RAWTEXT/RCDATA/text chunk boundaries;
  plain-text and legacy-HTML regressions; Unicode preserved into 10 layout
  glyphs and 573 modified framebuffer pixels via the actual shared painter.
- Existing DIV/table regressions with each parser: 43/43 and 18/18 PASS.
- Real kernel ELF identity, memory-window clamp, layout and truncation
  preflight checks against the new Navigator: PASS (host execution only).
  The inherited harness initially failed to link its missing
  mm_process_max_user_bytes helper; it now extracts that actual kernel
  function and its constants, then passes the existing checks.

## Reproduce

```sh
sh tests/run-v72202-utf8.sh /tmp/jtmos-utf8-core
sh tests/run-v72202-utf8-browser.sh /tmp/jtmos-utf8-fallback
python3 tools/build_navigator_lexbor_host.py /tmp/jtmos-lexbor-host
LEXBOR_HOST_ARCHIVE=/tmp/jtmos-lexbor-host/liblexbor_static.a \
  sh tests/run-v72202-utf8-browser.sh /tmp/jtmos-utf8-lexbor
make -C libc/apps -f navigator.mak -j2 navigator.bin
python3 tests/v7196_navigator_launch.py libc/apps/navigator.bin
```

Or run `make -C libc/apps -f navigator.mak navigator-utf8-ci` for core and
browser tests; LEXBOR_HOST_ARCHIVE is optional. Logs from this run are in
`release/qa/v72.202/`.

## Limits and artifact status

- LeakSanitizer cannot enumerate /proc tasks in this managed runtime.
  Leak detection is disabled; AddressSanitizer and UBSan remain active.
  The decoder itself performs no allocations.
- No QEMU, ThinkPad T400, eMachines or other real-hardware execution.
  Host framebuffer tests exercise shipping painter code, not VESA hardware.
- Kernel32, GraOS, DOSBOOT and installation media are inherited binaries.
  The ZIP is FULL-SOURCE-UNBUILT; only Navigator is newly rebuilt.
  The inherited utilities.iso does not install this new Navigator.
- Only stage 1 is implemented here. Streaming network-to-tokenizer plumbing
  belongs to stage 2; the current HTTP worker is not replaced.
- Decoding Unicode does not add missing font glyphs, complex text shaping,
  Unicode normalization or charset auto-detection.
