# JTMOS v72.188 — Unique 2.3 QA

## Source / host verification

- `python3 tests/v72188_unique23_host.py`: PASS (21 separate process invocations).
- `python3 tests/v72187_unique22_host.py`: PASS (Unique 2.2 regression).
- `sh tools/check_unique.sh`: PASS (old Unique scripts and lexical scoping).
- `make -C libc/apps -f unique.mak unique.bin`: PASS.
- `file libc/apps/unique.bin`: Intel i386 ELF 32-bit, statically linked.

## Distribution

- `MAKE=make sh tools/build_install_image.sh`: PASS, 115 applications.
- `sh tools/publish_utilities_iso.sh`: PASS.
- `python3 tools/check_release_media.py`: PASS, version 72.188.

## Not verified

- Live JTMOS CPU/process scheduling and waitpid behavior on ThinkPad T400.
- GraOS IPC window lifetime, labels and caption behavior on real hardware.
- JTMFS durability on sudden power loss or automatic atomic replacement.
- Full kernel and GraOS rebuild (old binaries are intentionally inherited).
