# V72.233 – varmennus

Ajo: `LEXBOR_HOST_ARCHIVE=…/liblexbor_static.a python3 tests/run-v72233.py OUT`
(loki: `release/qa/v72.233/host-gate.log`). Kaikki läpi, ASan/UBSan.

## Uudet testit

- `tests/v72233_ui.c` ajaa oikeaa `navigator.c`:tä host-valjaissa. Testi kattaa:
  - lykätyn navigoinnin, joka estää CSS-työt ja käynnistyy, kun worker
    vapautuu, sekä 20 s aikakatkaisun;
  - Ctrl+S-kehotteen, Esc-peruutuksen ja tallennuksen CSS- ja JS-tiedostoineen
    sekä tiedostojen ja HTML:n sisällön;
  - korvausvahvistuksen, Esc/Stop-keskeytyksen ja epäonnistuneen tiedoston,
    jonka viittaus jää verkkoon;
  - Ctrl+N:n;
  - käsikursorin linkin päällä ja nuolen muualla ja kontekstivalikon kanssa.
- `tests/run-v72233-save-page.sh` testaa resurssisuunnitelman
  (stylesheet, preload, protokollasta riippumaton `//cdn`, modulepreload,
  `&amp;`-dekoodaus, kaksoiskappaleet ja nimiristiriidat). Lisäksi se testaa
  ohitetut kommentit ja raw-text-elementit, `<style>`- ja `style=`-määreiden
  url():t, `<base>`-käsittelyn, srcsetin, tyhjän ja suhteellisen
  form-actionin, CSS:n `url()`/`@import`-muunnokset (data:, #fragmentti ja
  kommentit säilyvät), keskeneräisen merkinnän sekä polku- ja nimiehdotukset.
- `tests/run-v72233-cookie-store.sh` testaa evästeiden tallennuksen ja
  palautuksen sekä 21 vrk:n katon tiedostotasolla (Max-Age = vuosi lyhenee).
  Lisäksi se testaa, ettei workeri (fork, eri pid) kirjoita purkkia, että forget
  poistaa tiedoston, että vioittunut tiedosto hylätään kokonaan ja että
  vanhentuneita tietueita ei ladata.

## Päivitetyt ja ennallaan läpäisevät

- `tests/v72203_http_stream.c`: aiempi https→http-uudelleenohjauksen
  hylkäystesti muutettiin uuden linjauksen mukaiseksi. Ohjaus haetaan
  HTTPS:nä, ja vain http-silmukka estetään. Lisätty tyhjän vastauksen
  kertauudelleenyritys ja sen epäonnistuminen. 79 tarkistusta läpi.
- V72.232:n koko yhdistetty testisarja (`run-v72232-merge.py`): Yle/MTV-
  käyttöliittymä, CSS-testit, Google-haku ja -lomake, lomakkeet,
  `v72231_fork_capacity` (uusi luotaus-backoff mukana) sekä URL-vektorit.
- `v7274_cookie_session_host.py` (async-evästeet, 600 worker-elinkaarta) ja
  `v7275_js_cookie_host.py` (document.cookie).

## Natiivikäännös ja media

- `navigator.bin`, `downloadmgr.bin` ja `graos.bin`: ELF32, i386, entry
  0x80004000, `-Werror`. GraOS linked layout: PASS (36 moduulia, ABI 111).
- `network.sqa`:n `navigator.bin`, `core.sqa`:n `downloadmgr.bin` ja
  `graos.sqa`:n `graos.bin` vastaavat tavulleen uusia binäärejä. `boot.sqa`:n
  `jtm32.img` on peritty V72.231-kuva. ISO-peilit ovat identtiset.
  Tarkistussummat: `release/qa/v72.233/media-check.txt`.

## Ei ajettu

- QEMU-, T400- tai muuta laitteistokäynnistystä ei ajettu, eikä JTMOS TCP/TLS
  -päästä päähän -testiä. Käsikursori, Save As oikeaan JTMFS-hakemistoon ja
  evästetiedosto todellisella `$HOME`:lla on testattu vain host-valjailla.
- QuickJS-polkua (`nav_js_network_abort`) ei voi ajaa host-valjaissa, koska
  niissä ei ole QuickJS:ää. Polku käännetään natiivisti `-Werror`-lipulla.
