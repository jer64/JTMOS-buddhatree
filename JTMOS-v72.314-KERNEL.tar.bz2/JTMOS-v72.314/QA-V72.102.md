# JTMOS V72.102 QA – boot32pm source-check failure

## User-reported failure
- `kernel32.bin` linked and NZIP2-compressed successfully: **1,046,876 bytes raw**.
- BIOS loader stopped at `boot32pm/Makefile:135` in target `check-source`.
- This exact line checked that `version.generated.inc` matched `VERSION`.
- The examined V72.101 source tree contained `VERSION = 72.101` but an inherited
  `%define JTMOS_BOOT_VERSION_STRING "72.77"` in `boot32pm/version.generated.inc`.
- The supplied build log does not display the include contents on the user's
  machine; the exact failed rule and reproduced stale-source condition agree.

## Fix
- The generated boot version is synchronized by **content**, regardless of mtime.
- A rewritten include is replaced atomically using a temporary file; an
  already-correct include is not rewritten.
- Extracted source checks from silent individual grep commands into
  `boot32pm/check-source.sh` with labeled diagnostic failures.

## Tested on this host
- `make -C boot32pm check-source`: **PASS**, VERSION=72.102.
- Test: generated include future-dated to year 2033, value 72.77: **PASS**.
- Test: exact new include content: **PASS**.
- Test: repeated make does not modify include: **PASS**.
- Test: version change to 72.103 with `make -j4`: **PASS**.
- Test: intentionally corrupt boot candidate marker, meaningful diagnostic: **PASS**.
- Test: restore original boot source, check-source again: **PASS**.
- `sh -n boot32pm/check-source.sh`: **PASS**.
- `tests/v72101_kernel_image_budget.py`: **PASS**, compact help <= 4000 B.

## Limits
- Full kernel, boot.bin, DOSBOOT and hardware tests: **NOT RUN**, NASM unavailable
  and full linked kernel objects are not present in this execution environment.
- Bundled binaries remain inherited, not compiled v72.102 binaries.
- Do not infer ThinkPad T400/BIOS boot success from `check-source` passing.
