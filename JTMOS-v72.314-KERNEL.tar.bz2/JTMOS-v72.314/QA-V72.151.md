# JTMOS v72.151 – QA

Päiväys 26.10.2026. Pohjana on kokonainen v72.150-lähdepaketti (SHA-256 `c025ae47…b8625c`).

| Tarkistus | Tulos |
|---|---|
| Natiivi koonti, media ja kernelin kokobudjetti | PASS |
| Myöhäinen OFFER 33 s, v72.150 | FAIL (perustaso; sama oire kuin T400:lla: OFFERin jälkeen uusi xid) |
| Myöhäinen OFFER 33 s ja 44 s, v72.151 | PASS 34,4 s ja 45,4 s; tallennettu OFFER hyväksyttiin |
| Myöhäinen ACK 14 s, v72.151 | PASS 18,2 s |
| OFFER/ACK suoraan osoitteeseen 10.42.0.28 | PASS 4,7 s |
| Tavallinen dnsmasq-kaltainen palvelin | PASS 4,7 s |
| QEMU-verkkoregressio (slirp) | PASS 10/10 |
| DHCP-koodekki, DHCP-palautus ja rakennetestit | PASS |

Rajaus: T400:lla ei ole vielä ajettu V72.151:tä. QEMU käyttää NE2000-korttia, mutta korjattu kohta on JNetissä, kortin yläpuolella.
