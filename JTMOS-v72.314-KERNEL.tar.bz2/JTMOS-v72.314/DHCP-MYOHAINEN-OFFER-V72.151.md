# DHCP T400:lla, osa 2: myöhässä saapuva OFFER, V72.151

**Aineisto:** T400:n `tcpdump` V72.150:llä (`release/qa/v72.151/t400-tcpdump-v72.150.txt`).

## Mitä kaappaus näyttää

V72.150:ssä tilanne parani edellisestä: palvelin 10.42.0.1 lähettää nyt OFFERin, ja T400 vastaanottaa sen (`15:14:00.422 In … DHCP OFFER`). Heti perään, 1,1 s myöhemmin, JTMOS kuitenkin lähettää **uuden DISCOVERin** (`15:14:01.542`). REQUESTia ei lähde, joten JTMOS ei käyttänyt saamaansa tarjousta.

## Syy

V72.150:ssä DHCP-kierros (DISCOVER → OFFER → REQUEST → ACK) kesti enintään noin 29 sekuntia: kolme DISCOVERia, joiden odotusajat olivat 4, 8 ja 16 s. Seuraava kierros alkoi vasta 30 s viimeisen DISCOVERin jälkeen, ja sillä oli **uusi transaktiotunniste (xid)**. Kierrosten välissä uIP-säie käsitteli saapuvat kehykset, ja se ei tunne DHCP:tä.

T400:n dnsmasq vastasi noin 30 s myöhässä. OFFER osui kierrosten väliin ja hylättiin. Seuraava kierros alkoi uudella xid:llä, ja sen OFFER osui taas seuraavaan väliin. Sama toistui loputtomasti.

QEMUssa sama käyttäytyminen toistuu V72.150:llä palvelimella, joka vastaa 33 s myöhässä: OFFER saapuu 77,2 s:n kohdalla ja uusi DISCOVER uudella xid:llä lähtee 78,7 s:n kohdalla. Osoitetta ei saatu 115 sekunnissa.

Miksi NetworkManagerin dnsmasq vastaa näin hitaasti, ei selviä kaappauksesta. Ennen tarjousta dnsmasq tarkistaa pingillä, ettei osoite ole käytössä; kaappauksen ARP-kyselyt "who has 10.42.0.28" kuuluvat tähän tarkistukseen. Asiakkaan pitää joka tapauksessa toimia hitaankin palvelimen kanssa.

## Korjaus

1. **Sama xid koko hankinnan ajan.** Xid pysyy samana myös taustalla tehtävien uusintakierrosten yli, kunnes osoite saadaan. Uusi xid otetaan vain NAKin tai kantoaallon muutoksen jälkeen. Myöhäinen vastaus mihin tahansa aiempaan DISCOVERiin kelpaa siis edelleen.
2. **Myöhäinen OFFER tai ACK talteen.** Jos kierrosten välissä saapuu oikealla xid:llä ja omalla MAC-osoitteella varustettu OFFER, se otetaan talteen 60 sekunnin ajaksi, eikä sitä anneta uIP:lle. Taustasilmukka huomaa sen 250 ms:n sisällä ja lähettää heti REQUESTin. Samoin myöhässä tullut ACK hyväksytään, jos se vastaa lähetettyä REQUESTia. Kohdeosoitteella ei ole väliä: OFFER voi tulla myös suoraan osoitteeseen 10.42.0.28.
3. **Lyhyempi uusintaväli.** Ilman osoitetta uusi kierros alkaa 15 sekunnin välein, kun se ennen oli 30 s.
4. **`inet status`** näyttää uuden rivin `late offer/ack=… current xid=…`. Sen avulla tcpdumpin xid:t voi verrata JTMOSin omaan xid:hen.

## Tulokset QEMUssa

| Palvelimen käytös | V72.150 | V72.151 |
|---|---|---|
| OFFER 33 s myöhässä, vain kerran kullekin xid:lle | FAIL, ei osoitetta 115 s:ssa | PASS, 34,4 s |
| OFFER 44 s myöhässä, osuu kierrosten väliin | – | PASS, 45,4 s; lokissa `DHCP: late OFFER … accepted` |
| ACK 14 s myöhässä, REQUEST-ikkunan ulkopuolella | – | PASS, 18,2 s; lokissa `DHCP: late ACK … accepted` |
| OFFER/ACK suoraan osoitteeseen 10.42.0.28 ja omaan MAC-osoitteeseen | – | PASS, 4,7 s |
| Tavallinen dnsmasq, 3 s:n tarkistus | PASS | PASS, 4,7 s |

Kaikissa tapauksissa ping osoitteeseen 10.42.0.1 toimi. Lisäksi QEMU-verkkotesti meni läpi 10/10, ja DHCP-koodekin sekä DHCP:n palautustestit menivät läpi.

Kaappauksen rivi `15:14:08.422 In … DHCP ACK` on epäselvä. Ennen sitä ei näy REQUESTia, ja millisekunnit ovat täsmälleen samat kuin OFFERissa, joten rivi on ehkä kopioitu käsin väärin. V72.151 hyväksyy ACKin vain, jos se vastaa JTMOSin lähettämää REQUESTia.

## T400-ajo

```
ver                          (72.151)
inet restart
tcpdump -v -c 20 udp port 67
inet status                  (late offer/ack, current xid, IPv4)
ping -c 3 10.42.0.1
```

Toimivassa tilanteessa tcpdumpissa näkyy OFFERin jälkeen `Out … DHCP REQUEST` samalla xid:llä ja sen jälkeen `In … DHCP ACK`. Jos osoite ei vieläkään tule, kopioi xid-kentät kokonaan.
