# JTMOS V71.131 — validation

2026-10-21. Input: full `JTMOS-v71.130-FULL-SOURCE-RELEASE.zip`.

## Completed

- Native i686/ELF32 Navigator build, canonical `navigator.mak`, default Lexbor,
  WebP and BearSSL configuration; QuickJS disabled. The code is built with
  the existing `-Werror` configuration and existing warning exceptions.
- Kernel loader preflight accepts the executable: entry 0x80004000,
  startup reservation 102400 KiB, process window 131072 KiB. This is static
  ELF/loader validation, not a claim that GraOS executed the binary.
- `tests/run-v71131-html5.sh`: new query/image/disclosure/form/template/selector
  cases, using both the genuine Lexbor HTML parser and the conservative HTML
  fallback. AddressSanitizer and UndefinedBehaviorSanitizer enabled.
- 10,000 disclosure toggles after warm-up leave `NavDom.used` unchanged;
  1,000 same-value class writes reuse the existing allocation.
- Previous CSS/layout tests: 30 checks and 120 page lifetimes; 160 malformed
  CSS/HTML cases; V71.95 selectors/cascade/responsive/file-URL tests.
- Previous V71.122 form-state, cache-budget, radio, disabled-option, UTF-8
  maxlength and input-tail tests; V71.120 forms and selection/find tests.
- GraOS client's document-pointer reset test and V71.93 focus/UX tests
  (1,027 checks), linked against the updated focus manager.
- Saved Vunet/MV article/front-page fixtures through shipping HTML/CSS/layout,
  widths 1280, 810 and 390; all assertions passed. The original archived
  fixture HTML/CSS was used; no live-site result is implied.
- JPEG reference comparisons: 81 images, plus 388 truncation/corruption cases.
- V71.129 HTTP regression verifies that the worker's response limit remains
  compatible with the 6 MiB frontend buffer.
- Local `navhtml5.html` rendered at widths 900 and 390 through Navigator's
  shipping layout/painter. Desktop image inspected; this exposed the padded
  SELECT clipping bug, which was corrected and covered by a regression.

## Release media

- Kernel and modern BIOS/nzip boot image rebuilt for V71.131 with the existing
  text/nogui profile. Kernel source changes are release identification only.
- System/root floppy and utilities archive rebuilt from the current program
  inventory. Complete DOSBOOT package rebuilt against the same kernel/ISO.
- Standalone Navigator SQA built and extracted back; executable and test-page
  bytes compared with the originals. The network package's Navigator and
  test page also match the final standalone build.
- Loader preflight also passes for tlsseedctl and rngctl. Its old test assumed
  all tools request at least 16 MiB; corrected to preserve small reservations
  when checking the no-extension fallback. Kernel allocation code unchanged.
- Four existing Python test scripts had missing executable mode in the input
  archive; restored their modes along with the new test driver's executable bit.

## Reproduce

```sh
make -C libc/apps -f navigator.mak -j2 navigator.bin
python3 tests/v7196_navigator_launch.py libc/apps/navigator.bin
ASAN_OPTIONS=detect_leaks=0 sh tests/run-v71131-html5.sh
python3 tests/v71129_navigator_http_limit.py
```

`LEXBOR_HOST_ARCHIVE` and `NAV_TEST_DIR` optionally reuse an already-built
host test archive/output directory. Host archives must never be linked into
the native executable. The native makefile uses the separate JTMOS archive.

## Limits of the evidence

LeakSanitizer cannot inspect this environment's `/proc`, so leak detection
was disabled. ASan/UBSan and explicit arena-growth checks still ran. The
arena-growth test is not a whole-process RSS or system leak measurement.

No physical eMachines run, overnight stability run, live Internet-site test
or JavaScript/Web API compatibility test has been performed here. Existing
HTTPS/codec/kernel features are retained; their historical test reports do
not establish a new live-site acceptance result for this release.

The screenshots are host renders through the shipping painter, not GraOS
screenshots. `@supports`, media queries, responsive image parsing and HTML
interaction remain bounded subsets as described in the release notes.
