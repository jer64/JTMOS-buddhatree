# V72.239 – varmennus

Lokit ja vertailukuva ovat hakemistossa `release/qa/v72.239/`.

| Ajo | Tulos |
|---|---|
| `tests/v72239_jtmos_layout.c` (tallennettu jtmos.com, `tests/v72239_pages/jtmos/`) 810 ja 1260 px: kortit mahtuvat sivulle, aikajanan tekstisarake noin 27 %:n kohdalla (Chromium: 238/742), lasikortin reuna läpikuultava viiva eikä läpinäkymätöntä täytettä, 4 px:n `::before`-palkki, ↗ linkin oikeassa reunassa | PASS (sama testi V72.237:n koodilla: 28 FAIL) |
| `tests/v72239_http_offer.c`: uudelleenohjausvirheestä tulee selityssivu, verkkosivu ei voi myöntää poikkeusta, käyttäjän klikkaus sallii vain kyseisen palvelimen (myös CSS-osoitteet), sivu latautuu HTTP:llä, tunnuksia sisältävät osoitteet torjutaan | PASS |
| Elementtikohtainen vertailu Chromiumiin (`getBoundingClientRect` vs. Navigatorin piirtoalue): 810 px:ssä ei ylivuotoja, 1260 px:ssä erot alle 25 px | tarkistettu |
| v72.237-, v72.236- ja v72.233-portit (Navigator-UI, QuickJS, haku, tallennus, evästeet) | PASS |
| CSS/asettelusarjat: v71.83, v71.95, v72.203, CNN, media, MTV, Yle, css-basics, div/:has, grid 3L | PASS |
| QEMU-tallennustesti V72.239:n medialla | 15/15 PASS |

**Tunnetut erot Chromiumiin:**
- Lippuemojit näkyvät kirjaimina "FI" ja "GB".
- Otsikkopalkin oikea reuna on noin 10 px vasemmalla.
- `box-shadow` näkyy hieman jyrkempänä.
- Ilman JavaScriptiä laskuri näyttää 0 (sama Chromiumissa ilman JS:ää).

**Ei ajettu:** oikeaa jtmos.comia. Tästä ympäristöstä ei ole verkkoyhteyttä
sivustoon, joten kaikki ajot tehtiin tallennetulla sivulla ja Navigatorin
piirtokoodilla tietokoneella.
