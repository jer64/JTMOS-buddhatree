# JTMOS v72.177 – Navigator DIV/TABLE verification (2026-10-28)

Basis: v72.176 full source (boot/kernel not rebuilt here).

## Rebuilt
- Native i686 `libc/apps/navigator.bin` with `NAV_HAVE_LEXBOR=1`, `NAV_HAVE_QUICKJS=1`, BearSSL and WebP.
- New table CSS feature tests with host Lexbor HTML5; AddressSanitizer and UndefinedBehaviorSanitizer enabled.
- 18/18 passed with both Lexbor HTML5 and fallback parser.
- New Navigator package rebuilt from updated sources; binary validated after SQA extraction.

## Verified
- `tests/v72177_navigator_tables.c`: 18 / 18 passed with Lexbor HTML5 and fallback HTML, including nested CSS variable inheritance and ROWSPAN/COLSPAN collision avoidance.
- `tests/v72167_navigator_div.c`: 45 / 45 passed with Lexbor HTML5 after final table hardening changes.
- `tests/run-v72175-css-basics.sh`: passed.
- `v72172_google_serp`: saved Google JTMOS search rendered with 4864 nodes, 11509 CSS rules (including linked CSS), 4251 drawing operations, 2149 in results, no partial layout.
- `v72170_rko_probe`: float layout remained three columns (left 34–258, center 270–742, right 750–978) on the saved page.
- CNN 7 MB HTML: Lexbor parser succeeded (10342 DOM nodes); full sanitizer layout did not complete inside test timeout and is not certified.

- Added bounded multi-ancestor style computation for TRs nested inside DIV table wrappers; release CSS variable references inside-out.
- Skip occupied rowspan slots for colspan placement; fixed a potential overlap in malformed/complex table input.

## Limitations
- Grid/Flexbox is still a bounded subset; no claim of standards-complete layout.
- Table rendering has bounds (up to 64 columns, 512 rows and 1024 cells) and simplified border collapsing, intrinsic width, fixed column sizing and rowspan groups.
- No real-hardware GraOS/T400 or QEMU desktop test was carried out.
- v72.176 source contains experimental Ctrl-Z/fg job-control kernel changes; kernel binary inherited from an earlier release because full kernel link was not verified in this environment.

## Packaging
- `libc/apps/navigator/package.sh` built and verified its SQA contents by extraction and binary comparison.
- `tools/build_install_image.sh` assembled installable packages and `make publish-utilities-iso` published updated ISO aliases.
- `tools/check_release_media.py` PASS for new Navigator and inherited GraOS/boot/kernel images.
- Full operating-system rebuild remains **unverified**: this release must carry the UNBUILT label due to earlier kernel job-control modifications.
