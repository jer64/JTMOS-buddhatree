# JTMOS V71.108 validation

| Check | Result |
|---|---|
| Scalar i486 kernel build, link, compressed boot image | PASS |
| Kernel image below the 1 MiB loader limit (986,328 bytes) | PASS |
| BLAKE2s against Python hashlib: 52 key/length/boundary cases | PASS |
| ChaCha20 RFC 8439 vector and 100 independent cryptography comparisons | PASS |
| 180 independently derived outputs and persistent key transitions | PASS |
| No output before trusted initialization; 1,000 predictable writes cannot initialize | PASS |
| Actual coordinator: IRQ discipline, bounded work, EAGAIN, EINTR, blocking retry | PASS |
| Shared stream; 1,000 reads do not consume new file seeds | PASS |
| Hardware reseed, failed reseed continuity, metadata snapshots | PASS |
| Actual kernel seed code: 14 success/fault scenarios with ASan/UBSan | PASS |
| Local/global/root paths, malformed/exhausted pool, RAM/raw rejection | PASS |
| Exclusive lock, flush, short write, readback and unlock failure handling | PASS |
| libc bounds, short reads, wiping, EINTR/ENOSYS/EAGAIN and v71.107 fallback | PASS |
| Prior FAT12 O_EXCL/stat/physical-flush and fsync routing regressions | PASS |
| Navigator/tlsseedctl/rngctl ELF32 i486 build and loader preflight | PASS |
| Existing seed setup, TLS, DNS, URL, IPC and package regression chain | PASS |
| Current syscall IRQ policy and NMI safety audits | PASS |
| Native QEMU CPU max: devices, poll, getentropy, large reads, fork and TLS 1.2 | PASS |
| Native QEMU Pentium III: unseeded EAGAIN, writes cannot make POLLIN ready | PASS |
| Two native blocking readers, one per device, wake after pool installation | PASS |
| Native old CPU: same kernel stream serves devices, fork and verified TLS | PASS |
| Raw FAT12 image after shutdown: one consumed record, remaining 31 intact | PASS |
| Clean source rebuild: three apps, libc archives, both kernels, compressed stream and boot image byte-identical | PASS |
| Physical machine / live external Navigator website | Not run |

Run the host checks after building the native apps:

```
NAV_TEST_LEAKS=0 sh tests/run-v71108-rng-ci.sh
```

The test runtime cannot inspect `/proc/<pid>/task` for LeakSanitizer. Only
leak detection is disabled by this setting; address and undefined-behavior
sanitizers remain enabled. The RNG core comparison also uses independent
Python hashlib and cryptography implementations, not a statistical randomness
test as a security claim.

For the native tests, build the image and BearSSL's host tools first:

```
make image
make -C third_party/bearssl CONF=HostPortable -j2 lib tools
python3 tests/v71108_native_rng_tls.py
python3 tests/v71108_native_rng_tls.py --legacy
```

Set JTMOS_QEMU_PREFIX to an extracted QEMU filesystem if necessary. Native
tests boot the production kernel and use actual Ring3 libc, RNG syscalls,
TCP/NE2000, BearSSL and entropy objects. Their temporary TLS client alone
overrides the CA and localhost resolver to reach an independent local
Python/OpenSSL server. The production Navigator trust roots and resolver
are unchanged. Test keys and seed bytes are temporary and are not packaged.

The old CPU test installs a fresh 32-record pool onto an IDE FAT12 volume.
It first checks both unseeded devices and poll, forks two blocking readers,
then installs the pool. Both readers complete. Larger device reads, access
mode errors, another fork, getentropy and certificate-verified TLS 1.2 then
use the central generator. The raw disk check proves exactly one record
was consumed across all these operations.

This release carries forward the v71.107 storage and TLS fixes. Historical
v71.50 popen/system and v71.66 string-audit limitations recorded in
QA-V71.107.md have not been claimed fixed or rerun as passing checks here.
QEMU's existing low-DMA floppy reservation issue means the persistent test
uses IDE FAT12; physical floppy access is not asserted. Existing unrelated
floppy/cache/shell and image-builder warnings are outside these RNG changes.

The old v71107_native_tls.py targets the historical hardware-only behavior;
use the new v71108 native script for this release. Source references, exact
construction, trust assumptions, Linux differences and snapshot limitations
are documented in DESIGN-RNG-V71.108.md.
