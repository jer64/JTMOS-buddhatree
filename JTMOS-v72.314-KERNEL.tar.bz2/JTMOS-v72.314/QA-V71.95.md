# JTMOS v71.95 — HTML/CSS-tuen tarkistus

Testidata on täsmälleen käyttäjän toimittama Vunetin etusivu ja artikkeli sekä
MV-lehden etusivu resurssihakemistoineen. Alkuperäiset ZIP:t ovat hakemistossa
`tests/fixtures/v7195`; testit purkavat ne erilliseen väliaikaishakemistoon.

Tarkistuskohteet:

- Lexbor 3.0.0, sama DOM/CSS/layout/kuvakoodi kuin natiivissa sovelluksessa.
- Jokainen kolmesta sivusta: 1280, 810 ja 390 CSS-pikseliä.
- Ulkoiset CSS:t mukaan lukien media-attribuutit, muuttujat ja tyylien järjestys.
- DOM:n ja näyttölistan rajat, lähdebudjetti, asettelun uudelleenlaskenta.
- Selektorit, sisäkkäinen media, lyhyiden/pitkien ominaisuuksien etusija,
  oletusgrid, viisi saraketta, flexin suora teksti ja paikallisten URL:ien eristys.
- 77 liitteen JPEG-kuvaa ja neljä synteettistä progressiivista/restart-kuvaa:
  vertailu Pillow/libjpegin RGB-tulokseen sekä katkaisut ja bittivirheet.
  Synteettisten kuvien progressiivinen ja samoilla asetuksilla koodattu
  peräkkäinen JPEG tarkistetaan lisäksi pikseli pikseliltä samoiksi.
  Korkeataajuisissa väritestikuvissa sallitaan suurempi ero Pillow'n fancy-
  värialinäytteistyssuodattimeen; oma dekooderi käyttää lähintä näytettä.
- Aiempi v71.94:n koko offline-testiketju, natiivi ELF32/i386-käännös ja SQA:n
  purku takaisin täsmälleen samaksi binääriksi.

Katso toteutuneet lukemat jakelun `validation`-hakemistosta. Testit käyttävät
AddressSanitizeria ja UndefinedBehaviorSanitizeria. Tämän ajon Linux-
hiekkalaatikko estää LeakSanitizerin prosessi-/säiekartan lukemisen; siksi
muistivuotojen tunnistus on tässä ajossa erikseen pois päältä
(`NAV_TEST_LEAKS=0`). Normaalissa Ubuntu-ajossa testiskriptien oletus on 1.

Testi ei mittaa koko käyttöjärjestelmäprosessin RSS:ää eikä todista pitkän
GraOS-laiteajon vakautta. Renderöintikuvia käytettiin kehityksen tarkistamiseen;
niitä ei ole otettu fyysisestä JTMOS-laitteesta.

JPEG-toteutuksen normatiivinen viite: ITU-T T.81, liite G,
https://www.w3.org/Graphics/JPEG/itu-t81.pdf .

## Toteutuneet tulokset 17.10.2026

| Sivutapaus | CSS-tiedostoja | Tallennettuja CSS-sääntöjä | CSS-lähde tavua |
|---|---:|---:|---:|
| Vunetin artikkeli | 3 | 1422 | 138755 |
| Vunetin etusivu | 4 | 1851 | 175195 |
| MV-lehden etusivu | 10 | 2536 | 363497 |

Kaikki kolme sivua: PASS leveyksillä 1280, 810 ja 390. Ei CSS-/DOM-/näyttölistan
budjetin katkaisua. Lisäksi 81 JPEG-pikselivertailua, neljän synteettisen kuvan
progressiivinen/peräkkäinen-bittikarttojen identtisyys ja 388 vaurioituneen tai
katkaistun JPEG-syötteen koetta: PASS. v71.94:n aiempi regressioketju: PASS.
Paikallisen tiedoston taustalataus, fragmentti-/välilyönti-URL:t ja etäisen
HTML:n file-aliresurssien esto: PASS.

ELF32/i386, aloitusosoite 0x80004000. SQA:n purku palautti saman binäärin
(bittikohtainen vertailu). Diff-patch soveltuu tarkistetusti v71.94-pohjaan.
