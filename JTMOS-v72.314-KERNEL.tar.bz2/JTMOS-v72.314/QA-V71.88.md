# JTMOS v71.88 – QA and security statement

Automated Ubuntu-host tests:

1. `tests/run-v7188-plugins.sh`: 67 checks and 1200 malformed manifest
   inputs under AddressSanitizer + UndefinedBehaviorSanitizer.
2. `tools/test_navigator_v7187.sh`: inherited rendering, lifecycle,
   CSS/DOM, HTTP/1.1 and shared-library regressions.
3. `make -f navigator.mak navigator.bin`: GNU C17, i486 ELF32 with configured
   `-Werror` (pre-existing warning suppressions). Verified `readelf` ELF header.
4. `sqarc --compare-member` verifies the Navigator binary in the SQA release.

Security constraints: limits on manifest size/add-on count/selectors,
operation budget and DOM mutation count. No ELF loader or arbitrary
third-party callback registration from the manifest. Not a kernel sandbox.
Known risks include native process memory unsafety, exceptions or infinite
loops in TRUSTED callback implementations, absent on-device watchdog, and
hardware behavior untested. Runtime resource accounting is not measured on
physical JTMOS hardware.
