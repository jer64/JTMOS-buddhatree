# JTMOS v71.89 — QA & Acceptance Matrix

| Test / requirement | Result | What was actually verified |
|---|---|---|
| i486 ELF32 JTMOS navigator build | PASS | Static application links; `readelf`: ELF32 Intel 80386, entry `0x80004000` |
| Profiler component accounting and peaks | PASS | 10,032 C assertions with synthetic DOM/CSS/layout/media structures and 10,000 allocation/deallocation snapshots, ASan + UBSan |
| `NAV_PROFILE_ENABLE=0` | PASS | 4 assertions in compiled-out mode; zero reported counters |
| Render damage / framebuffer | PASS | 41 host assertions under sanitizers |
| Malformed HTML smoke parser | PASS | 650 cases under sanitizers, default *fallback* HTML parser |
| Page lifecycle / WordPress-like mockups | PASS | 3,150 assertions: 300 full document lifecycles plus 150 malformed fixtures under sanitizers |
| HTTP/1.1 localhost integration | PASS | 13 checks: redirects, gzip, deflate, chunked, cookies, caching, invalid response and HTTPS must reject without TLS |
| Async HTTP worker host integration | PASS | Persistent cookies, non-blocking polling, cancellation |
| Plugin sandbox rules regressions | PASS | 67 assertions + 1,200 hostile declarative manifest samples under sanitizers |
| TLS certificate validity checks | NOT EXECUTED | Secure native BearSSL backend and CA/entropy are unavailable; fail-closed HTTPS check only |
| Real public WordPress HTTPS end-to-end | NOT EXECUTED | Native HTTPS unavailable |
| GraOS visual overlay and F12 interactions | UNVERIFIED ON DEVICE | GUI compiled and linked only; no runtime test |
| Physical eMachines or alternate JTMOS test PC | NOT EXECUTED | No direct access to user hardware |
| Memory true peak RSS / heap fragmentation | NOT MEASURED | Snapshot accounting is NOT OS process RAM/RSS; worker memory excluded |
| Guaranteed resilience against arbitrary hostile code | NOT PROVEN | No kernel isolation/fault injection certification |

CI entry point: `sh tests/run-v7189-navigator-ci.sh`.

Acceptance status: profiling of known allocations and repeatable Ubuntu-host CI: **implemented/tested**. Diagnostics reporting: **implemented/host-tested**, target GUI unverified. Security/performance acceptance for live HTTPS and real JTMOS hardware: **open**.
