# JTMOS v72.220 FTP upload client

Build: `make -C libc/apps ftp.bin`

Use: `ftp 192.168.1.100 21 username password put /var/log/kern.log kern.log`
Or: `ftp 192.168.1.100 21 username password putlogs`
Interactive: `ftp 192.168.1.100` then `put /var/log/kern.log`, `putlogs`, `quit`.

Passive EPSV with PASV fallback; binary uploads. IPv4 literal only.
WARNING: credentials and data are sent in cleartext. Use on trusted LAN only.
Limitations: no TLS, DNS, download, directory listing or resume.
Network and on-device tests remain required.
