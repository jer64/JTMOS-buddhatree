# QA – JTMOS v72.96, ThinkPad T400 Intel 82567LM TX/MAC stage 2

| Check | Result |
|---|---|
| Complete v72.95 source preserved as base | PASS |
| Source version and kernel release metadata | PASS – v72.96 |
| `ich9e.c` 32-bit kernel GCC build | PASS – ELF32 Intel 80386 object |
| `networkapp.c` 32-bit kernel GCC build | PASS – ELF32 Intel 80386 object |
| `tests/v7296_ich9e_dma_stage2.py` real MAC routines + simulated MMIO | PASS |
| Quiesce acknowledgement and ring reset order | PASS (simulation) |
| Stuck GIO master -> no descriptor reuse | PASS (simulation) |
| GCR write rejection -> no TX/RX activation | PASS (simulation) |
| Coherent GCR setting preserves unrelated bits | PASS (simulation) |
| `tests/v7296_ich9e_hw_probe_compat.py` v72.95 TX probe regression | PASS (simulation) |
| `tests/v7280_ich9e_source.py` PCI backend source check | PASS |
| Old v72.82–v72.84 tests | Their fixed version/print marker expectations fail on newer releases; no device regression established. |
| Complete kernel32.bin and DOSBOOT rebuild | NOT BUILT: NASM absent; most prerequisite kernel objects absent. |
| ThinkPad T400 actual TX, RX, DHCP | NOT TESTED. |
| ZIP archive CRC/integrity | PASS |

**Important:** the full-source archive contains older `kernel32.bin` and DOSBOOT binaries; do not claim those executables contain v72.96 fixes.
