# QA – JTMOS V71.114 (KTLS kernel TLS service)

Date: 2026-10-19. Host: Ubuntu 24.04, GCC 13.3 (+gcc-multilib for the 32-bit
harness), OpenSSL 3, curl 8, Apache 2.4.58, QEMU 8.2 (`qemu-system-i386`, TCG),
Chromium headless (visual check only).

## 1. Host suites

| Command | Result |
|---|---|
| `sh tests/run-v71114-ktls-ci.sh` | PASS – module build (ET_DYN, R_386_RELATIVE only), 28 unit checks, 400 corrupted module images, generated certificate parsed by OpenSSL, server vs curl/s_client (ChaCha20 preferred, AES-256-GCM, SHA-1 CBC and TLS-1.3-only refused, resumption, RSA-2048 PEM identity), client vs s_server (unknown issuer 62, host name 56, RSA-1024 60, TLS < 1.2 refused, `-k` session never resumed by a verifying caller) |
| `sh tests/run-v71113-https-front-ci.sh` | PASS – Apache front (15 checks) |
| `sh tests/run-v71111-ci.sh` | PASS – 46 PASS lines (needs free TCP 80/443 on the host) |
| `tools/check_tcpip_hardening.sh`, `check_qemu_inbound.sh`, `check_contabo_launcher.sh`, `check_v68201_linode_launcher.sh` | PASS |

`tools/check_jt_httpd_site.sh` and `tools/check_jnet_dhcp.sh` fail identically
on the unmodified V71.112 tree (stale text greps); not caused by this release.

## 2. Native build

Full `make` (kernel, apps, packages, images): PASS.
`kernel32.bin` 1 012 700 bytes (V71.113: 995 640; window 1 048 576).
`ktls.kmo` 183 564 bytes, 469 relocations, packaged in `network.sqa`.

## 3. Runtime in JTMOS (QEMU, `run_jtmos_contabo.sh`, hostfwd 8443 -> 443)

Boot, `sqa cdrom`, `sqa network.sqa`; KTLS found `ram:/ktls.kmo` by itself:

    KTLS: engine loaded from ram:/ktls.kmo (184 KiB, 469 relocations) ... 117 trusted roots.
    KTLS: server identity CN=jtmos.com (generated in memory (no persistent root device))
    HTTPS: JTMOS site listening on 10.0.2.15:443 (TLS 1.2, CN=jtmos.com).

| Check | Result |
|---|---|
| 8 routes over HTTPS vs plain HTTP | byte-identical; 404, HEAD, POST→405 correct |
| first page incl. full handshake | 0.19–0.22 s |
| parallel load | 6×24, 8×32, 12×12, 16×32, 6×60, 6×18: all 200, all bodies identical |
| resumption (`openssl s_client -sess_in`) | Reused, ECDHE-ECDSA-CHACHA20-POLY1305 |
| Chromium `https://jtmos.com:8443/` | renders (screenshot) |
| `tls test -k 10.0.2.2 4433` / without `-k` | handshake OK / refused: issuer not trusted (62) |
| `nutget https://…` without `-k` | refused (62) |
| `nutget -k https://10.0.2.2:4433/big.bin` (300 KiB) | saved 307 200 bytes; served back by JTMOS HTTPS: SHA-256 identical |
| persistent identity (`mkfs hda`, `TLS_SEED_DIR=hda:/cfg`, `tls regen`, `tls reload`) | saved, reloaded with the same fingerprint |
| CA-signed PEM `server.crt`/`server.key` in `hda:/cfg/tls` | loaded; `curl --cacert ca.pem` verify 0 for jtmos.com and www.jtmos.com; other name refused |
| Apache `https://jtmos.com/` → JTMOS (HTTP backend) | 200, HTTP/2, same page |
| Apache → JTMOS KTLS over HTTPS (`SSLProxyEngine`, pinned JTMOS cert) | 200, same page |

## 4. Defects found by the runtime test and fixed

1. Every HTTPS handshake was dropped as "timeout": `now` was read before the
   crypto work and `last_tick` after it, so `now - last_tick` wrapped.  All
   elapsed-time checks now use `elapsed_ms()`.
2. 6+ simultaneous connections got RST: the JtUserSocket listen backlog (4)
   filled before the KTLS thread could accept.  Backlog 16, streams 24; KTLS
   leaves connections queued while all sessions are busy instead of closing.
3. Security: a session established with `-k` (issuer not verified) was cached
   and later resumed by a verifying `tls test`, which then reported
   "verified".  Unverified sessions are never cached or offered now
   (regression test in the CI script).

## 5. Not tested

Physical eMachines EL1352, a real Let's Encrypt certificate and live
internet servers from inside JTMOS (no outbound access from the sandbox
guest), long-running stability.

## 6. Release archive check (fresh extract of the zip)

- `MANIFEST-SHA256.txt` and `release/SHA256SUMS.txt`: OK.
- `sh tests/run-v71114-ktls-ci.sh`: PASS.
- `sh kmod/ktls/build.sh`: bit-identical to `release/bin/ktls.kmo`.
- `make` + `make purelinkit` in `kernel32/` alone: links, same size as
  `release/kernel/kernel32.bin` (1 012 700 bytes); 218 bytes differ as small
  address shifts with no string differences.  The release kernel and images
  come from the top-level `make`, which passes its own build options.
