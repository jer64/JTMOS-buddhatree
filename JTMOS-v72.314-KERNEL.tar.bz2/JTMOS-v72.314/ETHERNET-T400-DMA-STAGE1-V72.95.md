# JTMOS v72.95 – ThinkPad T400 Intel 82567LM DMA diagnosis (stage 1)

**Source release / NOT a new bootable kernel.** Based on complete JTMOS v72.94 source.

## Scope

- Exact PCI match 8086:10F5, ICH9M + 82567LM. No changes to other NIC backends, VESA EGA text terminal, GraOS, filesystem or PHY firmware.
- `inet hw` now includes PCI command/status, PCI PMCSR, optional PCIe capability readbacks, PBA, TIPG, Tx FIFO head/tail, descriptor and DMA information in addition to older CTRL/TCTL/TXDCTL/RX/PHY observations.
- Explicit `inet hw test tx` single-frame experiment (one broadcast, 60-byte Ethernet frame, EtherType 0x88B5, marker `JTMOS-v72.95 ICH9E TX TEST`). **Use only on a controlled/isolated test LAN.** No automatic test traffic.
- Test runs through the `ethdev` mutex that already serializes normal send/receive and restart. Refuses when no link, no PCI bus master, no ring verification, non-idle TX ring or another probe is active. No MAC global reset, PHY/NVM/ME programming, forced DMA completion or descriptor recycling.
- Captures TX descriptor dwords, ring head/tail before/after and DD observation, bounded by 50 scheduler waits of nominal 10 ms. A DD indicates NIC descriptor processing, NOT proof of cable-level reception.
- Probe session is generation-tagged using driver TX submission sequence; an overwritten descriptor is reported **inconclusive**. A finished probe cannot close another probe started later.

## Quick test (after rebuilding the REAL kernel)

On Lenovo T400 boot the NEW kernel (the ZIP contains OLD kernel32.bin; this is not a ready-to-boot 72.95).

```
inet stop
inet hw
inet hw test tx
inet hw
```

Expected code paths:
- result `TX DMA: DD observed`: descriptor processed. Capture the physical packet on another Linux machine on the *same controlled segment* using `sudo tcpdump -ni <interface> -e 'ether proto 0x88b5'`. This does not assert it reached the wire without independent capture.
- result `no DD within probe window`: TX may be stalled; compare PCI command, link, TXDCTL0/1, TDH/TDT, FIFO head/tail and PBA.
- result `test refused`: check diagnostic state, background network traffic, link and ring-check. Do not reset/retry continuously.
- result `descriptor reused concurrently`: diagnostic inconclusive; stop other network traffic and retry.

The test frame is only intended for a locally administered test LAN. IEEE 802 standard identifies 0x88B5 as *local experimental EtherType*; it is **not suitable as a globally deployed protocol**.

## Build status

- `kernel32/drivers/tcpip/ich9e.o`: 32-bit GCC build PASS.
- `kernel32/drivers/tcpip/ethdev.o`: 32-bit GCC build PASS.
- `kernel32/sh/networkapp.o`: 32-bit GCC build PASS.
- `tests/v7295_ich9e_hw_probe.py`: actual TX / probe functions compiled into an instrumented MMIO simulation with ASan+UBSan and PASS.
- Full kernel32.bin / DOSBOOT: NOT BUILT. System lacks NASM and v72.94 inherited source contains too few object files for relinking. Existing kernel32.bin is older and DOES NOT contain this patch.
- Hardware verification on T400: NOT RUN.

## Next stage

v72.96: Based on actual captured TDH/DD/MMIO results, implement a targeted MAC/TX-DMA correction; do not guess missing PHY/firmware initialization.
