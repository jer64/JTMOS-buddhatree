# JTMOS v72.164 – nutget-mittarin tarkistukset

Päiväys 27.10.2026. Pohjana kokonainen v72.163-julkaisu.
Muutokset koskevat nutgetin tilanäyttöä, sen SQSH-ohjeita, SMSH-työsäikeen
tulostusreitin periytymistä ja julkaisunumeroa.
Todisteet ovat hakemistossa `release/qa/v72.164/`.

| Tarkistus | Tulos |
|---|---|
| Koko natiivi koonti (`make full-build`) | PASS |
| Ytimen ELF/raw-kartoitus, aloitusosoite, BSS ja kokomarginaali | PASS: 938428 tavua, 110148 vapaana (vaatimus 65536) |
| Käynnistyslevykuvat, NZIP-ydin, ISO-paketit ja DOSBOOT-kopiot | PASS (`media-check.json`) |
| Mittarin 18 laskenta- ja muotoilutarkistusta, mukana 3000 satunnaista 32 bitin tapausta | PASS (`progress-unit.json`) |
| `check_nutget.sh`, `check_public_version.sh`, asennusskriptien ajantasaisuus | PASS |
| HTTP/HTTPS-lataukset ja mittarin todellinen päätenäyttö QEMU:ssa | PASS 14/14 (`qemu-summary.json`) |

Laskentatestit kattavat prosentin, tasatun nopeuden ja ylöspäin sekunteihin
pyöristetyn ETA:n, päivitystahdin, tuntemattoman koon, tyhjän ja lyhyen
latauksen, pysähtymisen ja jatkamisen, kellon 32 bitin ympäri menon sekä
lähes 4 GiB:n arvot. Mittari ei käytä liukulukua eikä ytimestä puuttuvaa
64 bitin jakolaskun ajonaikaista apurutiinia.

QEMU-yhteenveto yhdistää ensimmäisen ajon hyväksytyt SMSH-tapaukset ja
lopullisen ytimen uusinta-ajon. Jälkimmäinen varmisti HTTP:n, HTTPS:n, SQSH:n
mittarin, SQSH:n Ctrl+C:n ja tulostusreitin korjauksen (`qemu-final/result.json`).
Muut SMSH-tapaukset ajettiin ennen viimeistä tulostusreitin periytymiskorjausta;
lataussilmukka ja mittarin laskenta säilyivät samoina.

QEMU-testi käynnistää oikeat julkaisutiedostot ja paikalliset HTTP- ja
HTTPS-testipalvelimet. Se tarkistaa etenemisen ja ETA:n lisäksi uudelleenohjauksen,
tuntemattoman koon, tyhjän ja lyhyen tiedoston, valmiin vastauksen pitämisen
auki, viiden sekunnin tauon, katkeavan latauksen, Ctrl+C:n SMSH:ssa ja SQSH:ssa sekä SQSH:n
pääte- ja tiedostotulostuksen. HTTPS-testipalvelimen itse allekirjoitettua
varmennetta käytetään vain testin `-k`-valinnalla.

Tuntemattomalle koolle ei lasketa prosenttia tai ETA:ta. Vähintään kolmen
sekunnin tauolla ETA on `--:--`; yhteyden aiempi 60 sekunnin aikakatkaisu
säilyy. Lopullinen 100 % / done edellyttää onnistunutta tarkistusta ja
tiedoston sulkemista. Katkennut tai keskeytetty lataus ei saa valmistumisriviä.

Testit ajettiin QEMU:n TCG-emuloinnilla, NE2000-verkkolaitteella. ThinkPad
T400:lla tai GraOSin erillisessä pääteikkunassa ei tehty laitetestiä.
Ytimen vanhoja, muutokseen liittymättömiä kääntäjävaroituksia on koontilokissa.
