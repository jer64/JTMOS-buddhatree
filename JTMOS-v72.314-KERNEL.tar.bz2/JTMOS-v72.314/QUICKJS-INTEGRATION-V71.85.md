# QuickJS native integration checklist

1. Obtain official `quickjs-2026-06-04.tar.xz` from https://bellard.org/quickjs/; verify publisher provenance and review MIT LICENSE.
2. Extract only its own sources into `third_party/quickjs/` and run `tools/build_navigator_quickjs.sh`. This script intentionally fails when the upstream sources are absent.
3. Review QuickJS's QuickJS 2026 APIs, i486 libc compatibility and compiler flags; verify `quickjs.c`, `cutils.c`, `libregexp.c`, `libunicode.c` and `dtoa.c` compile and link against JTMOS. Port missing math/locale/time APIs rather than linking host libraries into JTMOS.
4. Test DOM event callbacks, classList mutation and stylesheet reflow, timer callbacks, pending promise jobs, script loading order, same-origin fetch JSON/text and cancellation.
5. Stress-test 12 MiB engine memory, 30 ms interrupt budget and page navigation JS runtime teardown with ASan/UBSan and actual JTMOS memory allocator.
6. SECURITY GATE: QuickJS uses process memory shared with Navigator UI. To guarantee a hung/hostile script cannot freeze GraOS, introduce separate JavaScript worker/process + request/reply DOM bridge, not only time checks. Check crash isolation and timeout on actual eMachines hardware.
7. Native HTTPS is still blocked pending verified TLS; this independently prevents reading most real WordPress sites even if QuickJS succeeds.

Current state: the source files contain a QuickJS adapter but NOT an operational native engine. Build defaults to JS=OFF to avoid overpromising.
