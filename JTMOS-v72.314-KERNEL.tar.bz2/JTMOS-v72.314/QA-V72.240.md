# V72.240 – varmennus

Lokit ovat hakemistossa `release/qa/v72.240/`. Ajot tehtiin lopullisella V72.240-lähdekoodilla. Testikomentoja tarvitsevat ajot
(`dirdbtest`, `free --vafrag`) tehtiin QA-ytimellä (`make KERNEL_SELFTEST=1`).

| Ajo | Tulos |
|---|---|
| `tests/v72240_dirdb_lazy_bench.smsh`: sama kuorma ensin `jtmfsdelay 0`:lla ja sitten 1000 ms:lla. Kuorma: 300 pientä tiedostoa, 300 appendia, 100 mkdiriä ja 300 poistoa. Lopuksi `jtmfsck` (`bench_summary.txt`) | 19/19 PASS, CLEAN |
| `tests/v72240_lazy_crash.smsh`: 40 tiedostoa ja `sync`. Sitten ilman syncia 23 uutta tiedostoa ja 10 poistoa, minkä jälkeen heti **hard reset** (uusi `!reset` tiedostossa `tests/qemu_smsh_script.py`) | 11/11 PASS |
| V72.237:n mkfs stale cache -testi (`v72237_mkfs_stale_cache.smsh`) | 14/14 PASS |
| `tests/v72237_qemu_mkfs_640g.py` (T400:n levykoko, sqa-asennus) | 11/11 PASS |
| V72.234:n tallennustesti, koko levy / hda1 | 15/15 ja 14/14 PASS |
| V71.124 päällekirjoitusregressio (ring3 `fsregress.bin`, fsync/ftruncate, reset) | PASS |
| `free --vafrag legacy` / `new` (`tests/v72240_vafrag_*.smsh`): 4 mallinnettua Navigator-istuntoa (512 MiB image + 512 MiB alias + pienet varaukset) | vanha: suurin aukko 960 → 512 MiB; uusi: 960 MiB säilyy; molemmilla fork mahtuu vielä |
| `tests/v72240_nav_log.c` (osa run-v72240.py:tä): rivin alku `[DD.MM.YYYY HH:MM:SS] [DEBUG] pid=… t=…`, URL-suodatin (userinfo pois, query/fragment → `<N bytes>`, `@` polussa säilyy), tekstin rivinvaihdot pois | PASS |
| `tests/v72212_logging/run.sh` (vanha lokitesti, nav_log.c muuttui) | PASS |
| `tests/run-v72240.py` (host, ASan/UBSan): uusi `v72240_fork_starved` (fork aina ENOMEM → starved, inline GET/POST palauttaa dokumentin) + v72.231 fork capacity + v72.239/237/236-portit | PASS |

Reset-testi tuotti seuraavat tulokset:

- Kaikki ennen `sync`ia kirjoitettu säilyi.
- Viimeisen avoimen ryhmän 4 poistoa katosi. Tiedostot ovat siis edelleen
  olemassa, mikä on odotettu tulos.
- `jtmfsck -n`: bad_entries, bad_chains, crosslinks ja size_mismatch olivat
  kaikki 0, orphan=0, tila CLEAN.
- Uudet kirjoitukset ja `sync` onnistuivat resetin jälkeen.

## Kehityksen aikana löytyneet viat

Molemmat viat löytyivät regressiotesteistä ja on korjattu tähän julkaisuun.

1. **Jumi 640 GB -testissä `sqa`-purun aikana.** KJTMFSC odotti
   DAPI-välimuistin lukkoa, ja Kyber-este oli sillä itsellään. Komentotulkki
   piti DAPI-lukkoa ja odotti esteen takana. Korjauksena lukkojärjestys on nyt
   DAPI → Kyber (`driver_FlushDrive` ja mount/unmount).
2. **Ytimen #PF KJTMFSC:ssä `fsregress.bin`:n päätyttyä.** Vapaan tilan
   kartta oli ring3-prosessin muistissa, joka vapautui ohjelman päättyessä.
   Korjauksena kartta ja infolohko varataan nyt pysyvästi
   (`mm_kernel_persistent_owner`).

Testien sarjalokeissa ei ole poikkeuksia, paniikkeja eikä lukkojen
DEADLINE-varoituksia.

Uudet lokirivit ja `console.*`-sidonta käännettiin myös oikeaa QuickJS:ää vasten
(v72.237-portti, sisältyy run-v72240.py:hyn).

## Sivusto, uIP, HOSTNAME ja ytimen koko

| Ajo | Tulos |
|---|---|
| Julkaisuydin (`KERNEL_SELFTEST=0`): `image-budget-release.json` | 940864 tavua, vapaata 107712 tavua (vaatimus 65536) |
| `tools/check_jt_httpd_site.sh` + `tests/jt_httpd_stream_test.c` (host) | PASS. Kaikki sivut ja reitit (`/`, `/fi`, `/en`, `/invest`, `/en/invest`, css, js) luettiin `/var/www/html`:stä tavu tavulta oikein. Puuttuva tiedosto antoi 404-sivun, jossa mainitaan jtmoswww.sqa. 300 KB:n tiedosto luettiin 10 kertaa (32 KiB:n ikkunat), index.html kerran. Lisäksi multi-MSS-, uudelleenlähetys- ja fbclid-tapaukset. |
| `tests/v72161_qemu_install_scripts.py` (QEMU, verkko hostfwd :8080): `docsinstall.sh` asentaa jtmoswww.sqa:n; `www start` palvelee `/`, `/en`, `/invest`, `/jtmos.css`, `/jtmos.js` ja `/shots/jtmos-navigator-jtmos.jpg` tavu tavulta samoina kuin `www/`. `rm /var/www/html/jtmos.css` → 404. | 24/24 PASS |
| `tests/v72240_hostname.smsh`: `set` | `HOSTNAME=jtmos.com`, PASS |
| QA-ydin (`make KERNEL_SELFTEST=1`): stale cache 14/14, lazy bench 19/19, lazy crash 11/11, vafrag legacy/new | PASS |
| Julkaisuydin: tallennustesti 15/15 ja 14/14 (hda1), päällekirjoitus PASS, 640 GB 11/11 | PASS |

`tests/v72161_qemu_install_scripts.py` oli vanhentunut: se purki paketit
hakemistoon `/home/vai/bin`, jolloin `/bin/sqsh.bin` puuttui ja asentimien
käynnistys epäonnistui. Nyt testi purkaa paketit hakemistoon `ram:/bin`
(`cd /`).

`tools/check_env_path_keropt.sh` epäonnistuu PATH-merkkijonon kohdalla
(`/bin:/usr/bin:ram:/bin:...`), joka ei liity tähän julkaisuun. HOSTNAME-rivi
on päivitetty kyseiseen testiin.

## Ei ajettu

- Oikea T400. Flush-määrien vähenemä on mitattu, mutta sen vaikutusta
  oikean kiintolevyn aikoihin ei ole mitattu.
- Navigatorin GUI-testi QEMU:ssa (`tests/v72111_qemu_navigator.py`) on
  vanhentunut: se etsii `labeldemo.bin`- ja `navigator.bin`-ohjelmia, joita
  nykyisellä medialla ei ole oletuspolussa. Sitä ei siksi voitu käyttää. Inline-
  varakeino on testattu vain host-testillä.
- T400:n fork-ENOMEM-tilannetta ei toistettu tarkasti. Korjaus perustuu lokien
  analyysiin ja QEMU:n fragmentaatiomittaukseen.
- navigator.log:in uusia rivejä ei ole nähty oikealla JTMOS-koneella eikä
  GraOS-Navigatorissa QEMU:ssa, koska GUI-testi on vanhentunut. Rivien muoto
  ja suodattimet on testattu hostilla.
