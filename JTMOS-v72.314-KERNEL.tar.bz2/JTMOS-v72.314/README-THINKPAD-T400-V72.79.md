# JTMOS v72.79 development source — ThinkPad T400 bring-up

Base: supplied `JTMOS-v72.78-dev-FULL-SOURCE.zip` (its internal version was 72.77).
The following are **source-level changes**, not proof that the laptop has been tested.

## Implemented

- Read-only PCI inventory of GM45, Intel GMA 4500MHD (2a42), Mobility Radeon
  HD 3400 series, ICH9M IDE/AHCI, Intel 82567LM (10f5) and HD Audio (293e).
- Distinguish Compatibility (IDE subclass) and AHCI modes in the boot log.
- Identify 82567LM's BAR0 but **do not initialize its DMA engine or claim
  network connectivity**; proper e1000e implementation is still outstanding.
- Preserve BIOS-provided VESA framebuffer for GraOS. Neither GPU is
  reprogrammed, and runtime Intel/ATI switching is not attempted.
- Prefer Intel 293e HDA controller and Conexant CX20561 (14f1:5051) analog
  codec over HDMI audio codecs; reuse existing generic HDA output parser.
- Preserve the DOSBOOT menu/`gui` behavior and mouse changes.

## Existing features, not new additions

- AHCI controller driver already present at `kernel32/drivers/sata/ahci.c`.
- ATA/ATAPI are used with BIOS SATA Compatibility.
- Generic HDA output, including EAPD, already present; CX20561 *playback
  remains unverified on actual hardware*.

## Current status and build caveat

This is a **development full-source archive**. The pre-existing binaries and
images inside the original tree are unchanged until rebuilt using the full
JTMOS toolchain (notably NASM and 32-bit GCC). They should NOT be described
with the new version number or flashed as v72.79 binaries. No on-device
ThinkPad tests have been performed. Run a clean full build and verify boot
with both `gui` and `safe` before using on real hardware.

## Testing sequence on T400

1. Set SATA=Compatibility and graphics=Integrated in BIOS.
2. Boot from the FreeDOS USB stick using `DOSBOOT.COM` with `gui`.
3. Capture serial boot log; look for `T400/GM45` diagnostic records.
4. Confirm the IDE HDD and ATAPI DVD are still enumerated; no writes.
5. Run `audio probe` / `audio status` if those commands are available.
6. Only then test ATI Discrete mode, VESA framebuffer and mouse input.
7. Switch SATA=AHCI only when booting a separate test configuration and
   never write to a disk containing valuable data.

## Future work

- 82567LM Ethernet e1000e DMA rings, EEPROM/MAC initialization, PHY link,
  interrupts or bounded polling, error recovery and uIP/ethdev integration.
- Conexant-specific pin routing/automute corrections only after obtaining
  actual codec NID/pin dump from the T400.
- Intel i915 / ATI accelerated framebuffer drivers and power-safe switching.
- AHCI fallback testing, ATAPI over AHCI and laptop ACPI power management.
