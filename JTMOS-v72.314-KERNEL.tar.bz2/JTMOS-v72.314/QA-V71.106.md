# v71.106 validation

| Check | Result |
|---|---|
| Actual JTMOS path branch: unformatted hda1 returns EIO, /cfg on another root succeeds | PASS |
| Root-relative path ignores current subdirectory; same binary works on prepared hda1 | PASS |
| Explicit directory/device, global defaults and local precedence | PASS |
| Known RAM aliases rejected before file writes, including uppercase RAM | PASS |
| Invalid/overlong paths and explicit EIO fail without fallback to another disk | PASS |
| Existing pool kept; exact seed consumption, locks and injected fsync failures | PASS |
| Real BearSSL peer: TLS 1.2, SNI, RSA/ECDSA, gzip/chunking, EOF and timeout | PASS |
| Invalid CA/hostname/dates/weak RSA and disallowed TLS policies rejected | PASS |
| DNS RCODE, URL normalization, IPC and canonical package inventory regressions | PASS |
| Native ELF32 i486 Navigator and tlsseedctl builds, application -Werror | PASS |
| Actual kernel ELF startup-layout/identity preflight for both final binaries | PASS |
| General two-file SQA and private three-file SQA extraction and byte comparison | PASS |
| Source archive extracted and both binaries rebuilt byte-identically | PASS |
| Native JTMOS boot, physical hardware, live sites in Navigator | PENDING |

Commands:

```sh
NAV_TEST_LEAKS=0 sh tests/run-v71106-navigator-ci.sh
make -C libc/apps -f navigator.mak -j2 navigator.bin
make -C libc/apps -f tlsseedctl.mak tlsseedctl.bin
sh libc/apps/navigator/package.sh
```

The new test compiles the actual `#ifdef JTMOS` path and global-setting code
against host filesystem operations mapped to simulated device roots. hda1
returns errno 5 until explicitly made available. Only the unused ELF memory
marker is shimmed; admin/env declarations are the real JTMOS headers. This
checks path selection and failure behavior, not physical filesystem execution.
ASan/UBSan are enabled. LeakSanitizer is disabled because this environment
blocks /proc task inspection; leak-freedom is not claimed.

The final package build also rebuilds the startup add-on path change and
checks both final ELF files against the actual kernel preflight. Strings in
Navigator confirm `/cfg/navigator.addons`, `/cfg/navigator-maint.log` and
`/cfg/navigator-lts.log`, with no `hda1:/cfg` path remaining in these modules.

No kernel ABI, TLS algorithms, CA roots or certificate validation were changed.
The crypto/HTTP tests use an independent local Python/OpenSSL server; success
there does not establish that mvlehti.net or vunet.net has been opened by a
native JTMOS instance. The native boot and live-site checks remain pending.

Final native binaries:

- `navigator.bin`: 1,231,228 bytes; SHA-256 `477721b6b02413357956575de85039b03d2287fa4f6e85ebc414a88d3b8607a4`.
- `tlsseedctl.bin`: 82,008 bytes; SHA-256 `ef22caf944f94dca1f5c41c084aa3cd126133e94f01ec7b1a0a597752e9fd99c`.
