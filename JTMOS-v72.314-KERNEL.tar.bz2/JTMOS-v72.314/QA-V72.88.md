# JTMOS v72.88 – QA

## PASS (host/source/build checks)

- JTMOS 32-bit `calendar.bin` compiled/linked successfully, ELF32 i386, entry point 0x80004000.
- GraOS `graos.bin` rebuilt/linked successfully, ELF32 i386, entry point 0x80004000.
- v72.88 persistence test: v1 legacy import, **actual v2 dual-slot migration**, multiple events/day, time order, stable IDs on edits, deleting by ID, corrupt latest generation fallback, invalid dates/times, 128-event capacity.
- v72.86 persistence regression: legacy import, checksums, repeated edits, delete, valid dates.
- v72.88 GUI source integration: staged event/day/editor windows, integrated clock launcher, no duplicate taskbar in `calendar.bin`, package manifest.
- DOSBOOT v72.78 prompt-parity regression.
- GraOS v70.70 mouse/hourglass regression.
- v70.61 setup/installation flow regression (updated version header).
- v72.88 SQA packaging: `calendar.bin`, `graos.bin`, README member presence + byte-for-byte comparisons.
- ZIP integrity and checksums (post-pack validation).

## Not tested or out of scope

- Runtime in actual T400 or GraOS emulation. Keyboard / mouse interaction has only been statically inspected.
- Power failure while JTMFS writes or fsync. Existing two-generation store minimizes exposure but depends on filesystem correctness.
- Full kernel/DOSBOOT/ISO rebuild (no NASM executable in build environment).
- GUI taskbar clock only guards against second **window**; manually launching two calendar processes can cause competing writes.
