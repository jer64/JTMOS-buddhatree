# V72.235 – varmennus

Lopullisilla julkaisutavuilla (ydin `V72.235`, `jtm32.img`, `root1440.img`,
`utilities.iso`) ajettiin QEMU 8.x, `qemu-system-i386`. Lokit ovat hakemistossa
`release/qa/v72.235/`.

| Ajo | Tulos |
|---|---|
| **LBA48, 500 Gt:n IDE-levy** (`tests/v72235_qemu_lba48.py`): IDE ilmoittaa LBA48:n ja koko 500 Gt:n. `blocktest` kirjoittaa ja lukee LBA:t 1000, 2^28−1, 2^28+12345 ja levyn viimeisen sektorin, ja ne tarkistettiin myös isäntäkoneen levykuvasta. Levyn ulkopuolinen LBA hylätään. `partition hda auto` kattaa koko levyn, `mkfs hda1` > 400 GiB, `sqa cdrom` hda1:lle, `jtmfsck` CLEAN | 16/16 PASS |
| V72.234:n tallennustesti (ram: 128 MiB, mount/umount -f, kaikki paketit) | 15/15 PASS |
| Sama hda1-osiolla | 14/14 PASS |
| V71.124 päällekirjoitusregressio (fsregress ram: + hda:, jtmfsck ennen ja jälkeen resetin): ajettu hakemistotarkistuksen kanssa | PASS |
| Navigatorin osoiterivi (`tests/v72235_ui_address.c`, ASan/UBSan): klikkaus siirtää kursorin, nuolet/Home/End myös E0-koodeina, Ctrl+A, valinnan purku, poisto, historiatäydennys, pudotusvalikko ja klikkaus valikkoon | PASS |
| Historiatietokanta (`tests/v72235_history.c`, ASan/UBSan): tallennus, fragmentin poisto, hylätyt osoitteet, täydennys, järjestys, tallennus ja lataus, poisto, vioittunut tiedosto, kapasiteetti | PASS |
| V72.233:n host-portti (Navigator, Save As, evästeet, GraOS ABI) | 53/53 PASS |

## TCP-ikkunan skaalaus ja FTP QEMU:ssa – tunnettu rajoitus

`tests/v72235_qemu_ftp_wscale.py` siirtää 4 MiB:n tiedoston pyftpdlib-palvelimelta
QEMU:n user-verkon (slirp) yli. Pakettikaappauksessa JTMOS tarjoaa SYN-paketissa
oikein window scale -option (`02 04 05 b4 01 03 03 02`). Slirpin SYN-ACK sisältää
kuitenkin vain MSS:n (`02 04 05 b4`), joten skaalaus ei aktivoidu, ja ikkuna pysyy
standardin mukaisesti 65 535 tavussa. Tämä on oikeaa toimintaa.

Siirto pysähtyy noin 2 Mt:n kohdalla (toistuvat ACK:t, pudonneita segmenttejä,
todennäköisesti NE2000:n vastaanottopuskurin ylivuoto). **Sama pysähdys toistuu
täsmälleen samoin V72.234:n medialla**, joten se ei johdu tämän julkaisun
muutoksista. Loki: `qemu_ftp_wscale_known_issue.log`. Ikkunan kasvu näkyy
oikeassa verkossa sellaista palvelinta vastaan, joka hyväksyy skaalauksen
(Linux, Windows ja useimmat FTP- ja HTTP-palvelimet).

## Ei ajettu

- Oikea rauta (T400, eMachines) ja oikea 500 Gt:n levy. LBA48-polku on testattu
  QEMU:n IDE-emuloinnilla.
- Erillistä testiä, joka tahallaan tuottaisi nollatun hakemiston kirjoitettavaksi,
  ei ole. Tarkistus (virheet 310 ja 311) on mukana kaikissa yllä olevissa
  tiedostojärjestelmäajoissa, eikä se hylännyt yhtään ehjää hakemistoa.
