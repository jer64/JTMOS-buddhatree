# JTMOS v72.89 – QA

## PASS

- Stage 4 host test: v4 CRC32 store persistence, daily/weekly/monthly/yearly occurrence handling, reminder due-time logic, repeated saves, stable IDs, ICS export, ICS import, rejection of unsupported RRULE, v3-to-v4 migration without modifying v3.
- Stage 3 v72.88 host persistence regression.
- Stage 1 v72.86 host persistence regression.
- DOSBOOT v72.78 prompt parity regression.
- `calendar.bin`: ELF32 i386 static JTMOS app compiled and linked.
- `calremind.bin`: ELF32 i386 static JTMOS app compiled and linked.
- `graos.bin`: ELF32 i386 static JTMOS app compiled and linked.
- `graos-v72.89.sqa` includes byte-for-byte identical copies of all three apps.

## NOT VERIFIED

- Actual GUI interaction / popup delivery on ThinkPad T400; not asserted working until on-device validation.
- Physical power-loss/fault-injection test of JTMFS dual-slot durability.
- Full kernel32, DOSBOOT, utilities.iso, installer rebuilding (NASM unavailable). Their old files in the full tree are unchanged.
- Complex timezone/DST and iCalendar RRULE rules intentionally unsupported.

## USER INSTALL NOTES

- Install all three programs from `graos.sqa` into the live `/bin` filesystem; an old graos.bin will not start reminder agent.
- ICS import: place `/calendar-import.ics` in the active JTMOS root and click `ICS Import`. The root may be RAM-backed on USB DOSBOOT; confirm persistence if saving matters.
- ICS export writes `/calendar-export.ics` to the active JTMOS root.
- Keep backups of `/calendar3.a`, `/calendar3.b`, `/calendar.a`, `/calendar.b`, `/calendar.txt`; v72.89 does not delete or replace them.
