# JTMOS v72.293 — Navigator async network/performance

## Verified source-level bottlenecks

- The previous Navigator network worker processed only one request, closed its command pipe, then exited. HTML pages with many CSS/image resources incurred new `fork()` and process startup for each subsequent job; an HTTPS worker's transient TLS context could not persist.
- After `fork()` failure, a last-resort inline fetch is performed in the GraOS event loop and can block rendering. The safety fallback is kept, but reusable workers reduce the circumstances that trigger it.
- The GUI's fixed `Sleep(10)` made asynchronous completions wait up to a 10ms poll cycle regardless of outstanding work.
- The TCP userspace send path could wait on readiness before attempting an immediate nonblocking write; kernel TCP-ring hot paths copied bytes one at a time.

## Changes

1. One completed, cookie-neutral network worker can remain idle for 5 seconds to receive the next request, preserving worker process state. A cookie-jar change or an unsuccessful worker request invalidates reuse. IPC writes remain nonblocking and bounded in the GUI. Active workers are still separate isolated **processes**, not POSIX pthread network threads.
2. Active GUI polling 2ms when loading, 4ms on pending events/repaints, 10ms idle. This reduces scheduler sleeps while asynchronous jobs run, at the cost of potential extra CPU time.
3. `jt_net_transport` attempts `send(MSG_DONTWAIT)` before select/poll waits, still respecting existing timeouts.
4. `kernel32/drivers/tcpip/jt_usersock.c` replaces TX ring byte-loop copies with one/two bounded `memcpy` segments. This requires building/booting a fresh kernel to take effect.
5. Added host regressions in `tools/check_navigator_v72293.sh` for adaptive pacing, localhost TCP transfer, worker reuse / cookie invalidation, the earlier download and CSS tests, and 14 HTTP integration cases.

## Safety/limitations

- JTMOS's experimental Ring3 pthread child forbids modifying FDs, memory allocation, fork, and other operations needed for HTTP/TLS. **No unverified POSIX pthread network thread has been enabled.** Async work remains in bounded child processes using pipes.
- Persistent worker reuse is limited to **one** idle worker and guarded by cookie generation + serial and successful complete reply, with expiry. A different worker's independent cookie snapshot cannot safely be reused after a cookie mutation.
- Full `make KERNEL_RING3_TEST=1` did not complete in the build container: missing `nasm` (`nasm -f elf core/asm/aslib.asm`). The changed TCP kernel module compiles separately and `navigator.bin` links as ELF32/i386.
- QEMU and real JTMOS website-load tests were not run in this environment. No measured speedup or complete Yle/MTV/Google compatibility is claimed. A shell/binary package can update Navigator on the installed v72.292 kernel, but the optimized kernel TCP-ring code is not active until the user rebuilds the kernel.
- Previous `pthread` and release code is otherwise preserved.

## Validation

```
make clean
make KERNEL_RING3_TEST=1 -j2   # full build requires NASM; failed here at missing executable
make -C libc/apps -f navigator.mak -j2 navigator.bin
make -C kernel32 -f generated.mak drivers/tcpip/jt_usersock.o
sh tools/check_navigator_v72293.sh
```

Host checks: adaptive event-loop, nonblocking localhost TX/RX (32KiB upload, 256KiB download), 66 sequential requests in one worker with cookie invalidation, download cancellation/progress, CSS rollback, 14 HTTP integration scenarios.

## Suggested verification on JTMOS

Run `navigator.bin https://yle.fi/`, `navigator.bin https://mtvuutiset.fi/`, `navigator.bin https://google.com/search?q=jtmos` and monitor `/var/log/navigator.log` for `worker reused pid=...` and `worker fork unavailable`; compare time-to-render and HTTP throughput before/after under identical QEMU config and network connectivity. A browser's partial render or console `PASS` is not proof that all JS/CSS is supported.
