# QA: JTMOS v72.197 - CNN Navigator

## Verified in this run

- HTML source provided by user, 7,049,850 bytes, offline fixture.
- Unpatched conservative parser returned -1 at offset 7,047,967 after 15,663 nodes (near final oversized iframe URL); DOM arena had used ~9 MiB, not a 512 MiB shortage.
- Patched parser: 15,673 nodes, 9,244,947 reserved DOM bytes, 1 oversized attribute skipped.
- CSS parsed 16,929 rules from 2,669,469 CSS bytes, ~15,017,888 owned CSS bytes, no truncation.
- Unpatched styled layout (same patched HTML): 227 paint items, partial flag=1, 532 px height; nested layout stack reached 128 KiB safety guard at depth 25.
- Increasing layout guard to 192 KiB caused test to exceed 20 seconds; **not accepted** as the solution. Original 128 KiB guard is retained.
- Patched `nav_page_build`: 5,421 paint items, 8,441 px height, partial flag=0, reader mode selected by bounded fallback.
- `tests/v72197_cnn_large_attributes.c`: PASS, 12,000-byte iframe attribute skipped, headline/link preserved.
- `tests/v72197_cnn_snapshot.c` on supplied CNN HTML with Linux host and sanitizer-instrumented modules: PASS.
- Existing host regression logs: alignment bitmap 69/69, alignment vector 69/69, position 48/48, DIV 45/45, page lifecycle 3,150 checks, HTML CSS and CSS fuzz all PASS.
- `libc/apps/navigator.bin`: fully recompiled/relinked as i686 ELF32 with Lexbor/QuickJS/WebP/TLS build switches enabled.

## Not validated

- Real JTMOS kernel/boot image, live CNN site, exact native Lexbor runtime HTML tree, mouse/scroll GUI response, interactive CNN JavaScript, live multimedia and performance on ThinkPad T400.
- Original 512 MiB memory question: 256 MiB is the source request, not 512 MiB. The available process budget may be lower; no proof increasing it improves the real CNN page.
- FULL-SOURCE-UNBUILT because kernel, GraOS executable and ISO media are inherited from v72.196.
