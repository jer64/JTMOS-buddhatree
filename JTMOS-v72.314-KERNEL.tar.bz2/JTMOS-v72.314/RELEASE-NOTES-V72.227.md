# JTMOS v72.227 – Navigator Worker Lifecycle / fork errno recovery

Base: JTMOS-v72.226-FULL-SOURCE-WORKER-RECOVERY.zip. This is a full source tree, not a patch archive.

## Root-cause finding

The old i686 `fork()` wrapper in `libc/libc/modern/syscall_app.S` returned raw negative kernel results, without setting `errno`. The kernel's `scall_fork()` often returned a generic `-1` on failures. Consequently `worker fork failed errno=3` from older Navigator logs may have been *stale*; it cannot be diagnosed as ESRCH solely on that observation. This release fixes both sides of the ABI.

## Changes

1. `kernel32/core/cp/fork.c`: return specific negative POSIX errors on parent validation, bad fork context, missing VM backing, COW cloning failure, process table exhaustion, and VM setup failure. Normal successful forks no longer spam the kernel log.
2. `libc/libc/modern/syscall_app.S`: i686 fork assembly sets the userspace `errno` variable and returns -1 on negative syscall results; success returns a positive child PID. The child still resumes at its original return address with EAX=0.
3. `libc/apps/navigator/nav_async.c`: preserve v72.226 bounded fork retry, gracefully reap completed workers without sending SIGTERM to them; cancel/timeout paths still terminate workers. Track completed/cancelled/reaped/reap-failure counters for `/var/log/navigator.log`.
4. `libc/apps/navigator/nav_async.[ch]`: expose `nav_async_transient_blocked()` to distinguish temporary worker/reaper pressure from permanent resource errors.
5. `libc/apps/navigator.c`: retry CSS loads deferred by fork/reaper pressure instead of discarding all CSS; retry image loads instead of permanently failing them due to temporary worker unavailability. Avoid creating work repeatedly while backoff is active.
6. Version markers: `/VERSION` and `libc/apps/navigator/VERSION` set to `72.227`.

The TLS transport already closes its socket/crypto state through `jt_net_close()` on the surveyed failure and success paths. No speculative TLS protocol behavior is changed here.

## Validation in this build environment

- PASS: `kernel32/core/cp/fork.c` compiled to i686 object with native JTMOS make recipe.
- PASS: `libc/libc/modern/syscall_app.S` compiled to 32-bit object; inspected `errno` relocation in fork failure path.
- PASS: `libc/apps/navigator/nav_async.c` and `libc/apps/navigator.c` compiled under native JTMOS flags and `-Werror`.
- PASS: Full `libc/apps/navigator.bin` i686 ELF32 link; entry point `0x80004000`.
- NOT TESTED: QEMU, ThinkPad T400 real hardware, TLS stability / runtime process exhaustion.
- BLOCKED: full kernel32 linker/build because `nasm` is not available in the build environment. A new bootable kernel image/media was NOT verified.

## Suggested hardware test

Boot a freshly built JTMOS kernel (the kernel fork error returns are required for accurate errno) and the matching navigator.bin. Visit a large CSS/image-heavy site repeatedly, monitor `/var/log/navigator.log` for `worker resources` and `worker fork failed errno=...` lines, and compare pending_reap, reaped, failures and HTTP failures. Verify no missing stylesheets appear after transient fork pressure. If `errno=12` or `11` persists with pending_reap=0, investigate COW VM memory and process-table capacity in kernel32.
