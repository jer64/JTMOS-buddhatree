# JTMOS v72.244 - build/test status

Based on JTMOS v72.243 FULL SOURCE RELEASE.  This release fixes `mv *.mp3 mp3/`
and other filename wildcard moves in both the external utility and SQSH.

## Built
- `libc/apps/mv.bin`: statically linked ELF32/i386, v72.244.
- `libc/apps/sqsh.bin`: statically linked ELF32/i386, v72.244.
- JTMOS GCC/i686 application builds completed with zero C compiler warnings.

## Tested
- Host regression: `python3 tests/v72244_mv_wildcards.py /mnt/data/mv_host_v72244`: PASS.
  Includes 150 MP3s, case-insensitive wildcards, mixed operands, metadata-only
  inode-preserving moves, existing target replacement, no-match, invalid target,
  4096-match safety bound, and cross-device rejection.
- Legacy metadata-only regression: `python3 tests/v72211_mv_cli.py /mnt/data/mv_host_v72244`: PASS.
- The `mv.c` and `sqsh.c` 32-bit JTMOS builds both compile and link.

## Limitations
- QEMU and real hardware runtime tests of SQSH/mv have not been performed here.
- Boot media (`jtm32.img`, `root1440.img`, `utilities.iso`, `boot32pm/dosboot/`)
  are inherited from v72.243's source package; they have NOT been regenerated
  with v72.244 applications. The build environment is missing NASM, preventing
  a complete kernel/media rebuild. Do not assume the old ISO contains new mv.
- Most other bundled binaries are inherited from v72.243 and may print their
  earlier version numbers until they are rebuilt.
- Wildcards in intermediate directory components are deliberately rejected;
  only the last filename component is expanded. At most 4096 matches per pattern.

## How to use
On an existing JTMOS installation, install both `libc/apps/mv.bin` (external
utility, usually on PATH) and `libc/apps/sqsh.bin` (SQSH builtin implementation)
into their respective application locations, or rebuild media on your development
machine (`make`, NASM required). Then run:

    mkdir mp3
    mv *.mp3 mp3/

No file byte-by-byte copy is performed by `mv`.
