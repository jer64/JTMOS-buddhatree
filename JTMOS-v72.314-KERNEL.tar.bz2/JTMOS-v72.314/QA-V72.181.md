# QA v72.181

PASS  23 HDA simulation assertions (including 50% gain, mute and unmute)
PASS  Four kernel C objects compile for i686
PASS  libc application archive rebuilt
PASS  volumemixer.bin / sound.bin / controlpanel.bin / launcher.bin i686 builds
PASS  Navigator i686 binary with Lexbor, QuickJS, WebP and BearSSL
PASS  graos.sqa contains current volumemixer.bin, launcher.bin and controlpanel.bin
PASS  `tools/build_install_image.sh`
PASS  `tools/check_release_media.py` with corrected DOS boot ISO copy
UNTESTED  Re-linked kernel32.bin; full hardware codec / GraOS runtime
UNTESTED  Full Fetch CORS, ES module graph and Google dynamic search end-to-end
