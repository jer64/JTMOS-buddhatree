# JTMOS v72.288 experimental pthread test release

## Highlights

- Added `pthreadrace.bin`: 8 children × 3 rounds, mutex-contention validation
  and 24,576 protected shared-counter increments.
- Added `pthreadlifecycle.bin`: 64 create/join cycles, 32 detach/collect cases,
  stale-handle guards and fail-closed POSIX default.
- Both in `tests.sqa` and complete utilities media, NOT the B: rescue disk.
- New release contract validates ELF32 + SQA byte equality, leaving production
  pthread feature bits off.

## Build status

Source tests, user applications, packaging and media check: PASS.
Kernel build: **BLOCKED** on missing NASM; included kernel/boot are inherited
from v72.287 and must be rebuilt using `make KERNEL_RING3_TEST=1` on a machine
with build dependencies. QEMU/T400 guest execution of the two new test binaries
has NOT been performed in this environment.

See `RELEASE-V72.288-PTHREAD-RACE-LIFECYCLE.md` for exact commands and limitations.
