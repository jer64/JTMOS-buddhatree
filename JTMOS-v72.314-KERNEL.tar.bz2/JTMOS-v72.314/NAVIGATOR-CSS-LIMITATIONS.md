# CSS subset (v71.112)

Since v71.112 text uses the JTMOS vector font engine (JT Sans / JT Serif /
JT Mono, proportional metrics, bold, synthetic italic, Unicode Latin, Greek,
Cyrillic, punctuation and arrows). CSS font-family lists map to these three
families; web fonts are not downloaded. Ctrl-T selects the old 8x16 font.

Supported in addition to the list below: rem relative to <html>, sibling and
first-child margin collapsing, inline-block/inline-flex/inline-grid, inline
margins/padding/background (single line), ::before/::after content and small
decorative boxes, grid auto/min-content/max-content tracks, shrink-to-fit
floats, align-items/place-items center/end, letter-spacing, text-transform,
text-indent, vertical-align, color-mix(), hsl(), percentage border-radius,
per-side border colours/widths, list-style none/decimal, form controls.

Still missing: absolute/fixed/sticky positioning (laid out in flow),
z-index stacking, transforms, shadows, gradients, CSS background images,
@import, @supports, animations, web fonts and icon fonts, bidirectional text,
CJK glyphs, JavaScript-dependent content.

---- historical v71.83 notes ----

# CSS subset and WordPress compatibility notes

CSS grammar: Lexbor 3.0.0 parses; bounded JTMOS rule extractor computes only
supported properties. Descendant/child, tag, class, ID and :root selectors,
maximum width media conditions, and simple @layer groups. Unsupported
pseudoselectors are safely nonmatching. The app loads eight external CSS
resources at most, sequentially and asynchronously; @import is not followed.

Supported box model and typography are approximations using the 8x16 EGA
font, with 2x bitmap-scale headings. The renderer does not have proportional
font glyph metrics, full inline formatting, text shaping, pseudo-elements,
flex sizing, auto-fit grid, floats, sticky/fixed positioning, floats,
background images, box shadows, full z-index, or animation.

Desktop F7 mode lays out at 810px, Mobile F7 mode at 520px. For two/three
columns, the renderer uses equal width columns only when each would have
at least 230px. Narrow pages use a readable single column instead.

WordPress reading target: HTML5 Gutenberg headings, text, links, alt text,
styles, simple columns. WordPress JS plugins, complicated ecommerce, logged-in
admin, remote fonts, encrypted WordPress sites and image-rich themes are
still outside the usable v71.83 compatibility level.
