# JTMOS 72.86 QA

| Check | Result |
|---|---|
| Full-source continuity from v72.85 | PASS |
| Calendar store module JTMOS 32-bit syntax | PASS |
| New `taskbar.bin` ELF32 link | PASS |
| Storage host test suite | PASS |
| JTMFS no-rename-over-existing workaround | PASS: alternating verified slots |
| Native DOSBOOT regression | PASS |
| GraOS mouse / VESA regression | PASS |
| Old Ethernet 72.84 source-only regression | PASS except hard-coded version check |
| Full kernel/DOSBOOT build | NOT RUN; previous binaries retained |
| Real hardware / power-cut integrity | NOT VERIFIED |

See `CALENDAR_STAGE1_V72.86.md` for known constraints and migration details.
