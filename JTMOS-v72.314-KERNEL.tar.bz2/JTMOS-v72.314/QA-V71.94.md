# JTMOS Navigator v71.94 – QA and release gate

Date: 2026-10-17. Ubuntu-host checks do not equal real JTMOS/GraOS certification.

## Evidence

- Native ELF32/i386 target linked with static Lexbor 3.0.0.
- `-Werror` on Navigator targets using existing warning policy; successful
  supported-default build (not a claim for every compiler/toolchain).
- Host browser-runtime lifecycle test: **14 assertions PASS**.
- GPU hook disabled/enabled host tests: **both PASS**.
- Actual i486 rebuild when switching `NAV_HW_ACCEL_ENABLE=1` then `0` without
  manually running clean: **PASS**.
- Parent host regressions: v71.93 accessibility; DOM/CSS/WordPress lifecycle;
  SHA-256 community manifests; image; cache; HTTP 17 assertions; LTS; plus
  malformed HTML and add-on inputs: **PASS**.
- Packaging with SQA unpack/ELF32 comparison and SHA256: see release log.

## Certification gate

| Check | State |
|---|---|
| Source integration and supported binary link | PASS |
| Automated host regression suite | PASS |
| Cross-module teardown partial initialization audit | Improved; physical runtime untested |
| Verified HTTPS certificate verification | BLOCKED |
| Real WordPress HTTPS rendering tests | BLOCKED |
| QuickJS/WebP/TTF native backends | BLOCKED |
| OS-enforced native extension sandbox | BLOCKED |
| Real hardware long-running validation | BLOCKED |
| Full process-level RAM metrics and leak-free claim | BLOCKED |

**Release classification: Master integration preview, NOT production certified.**
