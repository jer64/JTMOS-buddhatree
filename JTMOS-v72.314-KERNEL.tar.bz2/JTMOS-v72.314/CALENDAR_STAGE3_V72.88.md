# JTMOS v72.88 – GraOS Calendar stage 3

## Functional changes

- Standalone `calendar.bin` (opened by the GraOS built-in taskbar clock) supports **multiple events on the same date** (up to 128 events overall).
- Each event has a stable unique ID, local start time (`HH:MM`), duration (1..1440 minutes) and title (1..95 bytes).
- Selecting a date opens a **paged, chronologically sorted day-event list**. Select an event to edit/delete, or choose `Uusi` to add another entry. 8 entries are shown per page.
- The month overview marks a day with `*` if one or more events exist; today's date retains its `[dd]` marker.
- Calender GUI creates no separate taskbar; native GraOS tray clock opens `/bin/calendar.bin`, and normally raises an existing calendar window.

## Persistent storage and backward compatibility

- **New format:** text `JTCAL3` using `/calendar3.a` and `/calendar3.b`, CRC32 per generation with incrementing generation number, readback verification, `fflush()` and `fsync()`. The older storage `/calendar.a`, `/calendar.b` (`JTCAL2`) and `/calendar.txt` is **read but never overwritten** by the new calendar.
- On first launch without a v3 slot, import events from v2 (or v2's legacy text fallback), preserving stable IDs; the old entries default to **09:00** local time and **60 min**. After the first save, v3 slots become authoritative; old files remain as recovery copies.
- Failed/corrupt newest v3 slot falls back to the last verified older slot. If the only v3 slot exists but is corrupt, calendar remains read-only to prevent silent data loss.
- Storage capacity: 128 events total, titles of max 95 bytes. No recurring events, reminders, timezone conversion, ICS, or cross-process locking in this stage.
- **Safety limitation:** Power-loss durability depends on working JTMFS `fsync`, and the root `/` needs persistent writable storage. RAM roots lose events on reboot. Do not run old `taskbar.bin` simultaneously; it can still modify the v2 files, which the new calendar only imports initially. Only the built-in GraOS clock launcher avoids a duplicate by checking for the existing window. Manual parallel starts remain unsupported.

## Deployment

1. Replace **both** `/bin/calendar.bin` and `/bin/graos.bin` with binaries included in this release, OR unpack `graos-v72.88.sqa` into the active GraOS application installation.
2. **Do not assume the old `utilities.iso` was rebuilt**: the v72.88 SQA is the updated client bundle, but boot floppies, kernel32, DOSBOOT and utilities.iso are preserved from previous releases. Build the full boot media separately on your development machine if needed.
3. Click the GraOS taskbar clock, select a date, press **Uusi** or select an event, enter `HH:MM`, duration and title, and save.
4. Keep a copy of old `/calendar.a`, `/calendar.b`, `/calendar.txt` before testing on valuable data. The new calendar itself doesn't overwrite them.

## Build/test commands

```
make -C libc/apps -f calendar.mak calendar.bin
make -C libc/apps/gui -f graos.mak graos.bin
tests/calendar/run_v7286_store_test.sh
tests/calendar/run_v7288_store_test.sh
python3 tests/calendar/v7288_integration.py
```

## Limitations

- Physical JTMOS/GraOS on ThinkPad T400 has **not** yet been tested.
- Mouse click ergonomics, small-screen positioning, multi-window focus and filesystem power-loss recovery need on-device verification.
- No kernel/DOSBOOT image rebuild was performed; those artifacts retain their previous versions.
