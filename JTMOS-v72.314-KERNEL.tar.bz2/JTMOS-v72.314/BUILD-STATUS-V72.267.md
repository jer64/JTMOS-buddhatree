# JTMOS V72.267 full release

Canonical full-build PASS; kernel 934656 bytes, 113920 free.
64 KiB kernel pipes, Navigator 384 MiB window + 2 MiB/turn worker IPC, batched navigator.log, JS globals.
See LOKIANALYYSI-V72.267.md, QA-V72.267.md and RELEASE-V72.267.txt.
