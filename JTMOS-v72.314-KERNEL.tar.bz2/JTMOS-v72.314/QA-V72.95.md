# QA – JTMOS v72.95 Intel 82567LM stage 1

| Check | Result |
|---|---|
| v72.94 complete source preserved as base | PASS |
| Source version + release header updated to v72.95 | PASS |
| 32-bit JTMOS GCC build – ich9e.c | PASS |
| 32-bit JTMOS GCC build – ethdev.c | PASS |
| 32-bit JTMOS GCC build – networkapp.c | PASS |
| v7280 Intel PCI source contract | PASS |
| v7295 test: static constraints + actual probe routines in simulated MMIO (ASan/UBSan) | PASS |
| v7282 / v7283 / v7284 historical tests | Some version assertions fixed to 72.82–72.84 and fail for 72.95; previous source invariants preserved. |
| Full kernel/DOSBOOT build | NOT RUN: NASM absent and most `.o` prerequisites missing |
| ThinkPad T400 Ethernet link and wire capture | NOT RUN – requires user hardware |
| ZIP archive CRC/every-entry integrity | PASS (unzip -tqq; 10,963 archive entries) |

**Critical distinction:** `ich9e.o` is built, but `kernel32.bin` inherited from v72.94 does not include v72.95 code. It must be rebuilt before testing `inet hw test tx` on T400.
