# JTMOS v72.87 – GraOS calendar phase 2

## Behaviour
- The **built-in** GraOS taskbar tray clock launches `/bin/calendar.bin`.
- `calendar.bin` creates a normal GraOS calendar window and event editor; **no taskbar**.
- Clicking again brings the existing calendar window to the front instead of launching a duplicate.
- The calendar maintains the v72.86 `/calendar.a` and `/calendar.b` verified dual-slot store and legacy `/calendar.txt` import.
- The application remains usable from the command line: `calendar.bin`.
- The historical `taskbar.bin` remains available for compatibility **but should not be launched together** with the built-in taskbar (it would create a second panel and concurrent writers).
- The new client is part of GraOS packaging (`graos.sqa`); install or copy `calendar.bin` to `/bin` in the active root filesystem. DOSBOOT GUI users must ensure this binary is present in their GraOS application package.
- Mouse press over the integrated tray clock triggers the launcher. No startup auto-launch.
- Editing still restricts one event per day (phase 1 behavior retained).

## Limits
- Only the built-in taskbar click path prevents two instances. Manually starting multiple `calendar.bin` processes is not yet prevented by an interprocess lock.
- Files are saved under root. RAM root loses data at reboot; `/calendar.a`/`/calendar.b` must be on persistent writable storage.
- A popup may briefly be recreated when navigating months or after saving an edit.
- Physical GraOS runtime and USB/DOSBOOT package install are not hardware-tested.

## Build
```
make -C libc/apps -f calendar.mak calendar.bin
make -C libc/apps/gui -f graos.mak graos.bin
```
These two binaries must BOTH be deployed for taskbar click integration.
