# Navigator v71.127 — image memory safety

Hardened decoded-image cache against dimension overflow, invalid decoder output,
underflow of cache accounting, and stale dimensions following eviction/replacement.
The existing 6 MiB cache cap and LRU eviction policy remain in force.

Limitations: peak temporary decoder allocations are not fully covered by the cache
budget; hardware boot and live CNN/Fox News tests have not been performed.
