# v71.105 validation

| Check | Result |
|---|---|
| Missing cfg reproduced; automatic mkdir and missing-pool message | PASS |
| mkdir failure EROFS and cfg-is-a-file failure | PASS |
| Actual existing lock retained and reported as EEXIST | PASS |
| Simulated lock-create EACCES, ENOSPC, EROFS distinguished from a lock | PASS |
| Fresh installation, read-only record counts, one-record consumption | PASS |
| Reinstall does not replace or reset a consumed existing pool | PASS |
| Used/zero-record input rejected | PASS |
| Failed install fsync retains lock; no successful entropy output | PASS |
| Existing TLS/entropy integration: real Python/OpenSSL peer, cert failures, policies, HTTP upgrade | PASS |
| Native Navigator and tlsseedctl ELF32 build with application -Werror | PASS |
| Both binaries: real kernel launch layout/identity preflight | PASS |
| Canonical application inventory and network.sqa classification | PASS |
| General SQA and private setup SQA extraction round-trip | PASS |
| Full source extracted into a separate directory and rebuilt | PASS |
| Physical JTMOS/eMachines execution and user's errno/filesystem state | PENDING |

Commands:

```sh
make -C libc/apps -f navigator.mak -j2 navigator.bin
make -C libc/apps -f tlsseedctl.mak tlsseedctl.bin
NAV_TEST_LEAKS=0 python3 tests/v71105_seed_setup.py
NAV_TEST_LEAKS=0 python3 tests/v71104_tls.py
python3 tests/v7196_navigator_launch.py libc/apps/navigator.bin libc/apps/tlsseedctl.bin
python3 tests/v71103_dns_rcode.py
python3 tests/v7199_navigator_package.py
sh tests/run-v7197-navigator-ci.sh
sh libc/apps/navigator/package.sh
```

The setup CLI/provider tests use ASan/UBSan and deterministic host filesystem
failure injection. LeakSanitizer remains disabled for the known /proc inspection
restriction; this is not a leak-freedom claim. Existing HTTPS tests compile the
same modified entropy provider. HTML/CSS/rendering code was not changed in this
release; v71.104's completed regressions are retained as earlier evidence.

Direct site probe: `http://vunet.net/` returned 301 with
`Location: https://vunet.net/`; the HTTPS request returned HTTP 200 through the
host environment. This probe is separate from native Navigator on JTMOS.

Final binaries:

- `navigator.bin`: 1,226,956 bytes; SHA-256 `d4051cfc6c18368e42736eac43e8891172f0bdcb6c2e86a20a639472265b4e17`.
- `tlsseedctl.bin`: 77,736 bytes; SHA-256 `0ab1644dac0e014221a12d19e27c2ab5992ebec1ed69ab958fc3537c107b346c`.
