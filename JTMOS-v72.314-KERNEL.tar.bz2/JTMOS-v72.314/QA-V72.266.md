# JTMOS V72.266 – tarkistukset

| Tarkistus | Tulos |
| --- | --- |
| `make -j8 full-build` (GCC 13.3.0) | PASS |
| Kernelin kuvabudjetti: 934528 tavua, 114048 vapaana (kernelin lähdekoodi ennallaan) | PASS |
| GraOS-palvelimen layout-tietue (`check_graos_layout.py`, 37 moduulia) | PASS |
| GraOS + asiakkaat ELF32 (`make -C libc/apps/gui check`) | PASS |
| `tests/v72266_graos_button_looks.py` (oikea GraOS-renderöijä, isäntäesikatselu) | 11/11 PASS |
| `tests/v72266_qemu_buttondemo.py` (QEMU, lopullinen media) | 4/4 PASS |
| QEMU-käynnistys `tests/v72109_qemu_boot.py` (lopullinen media) | PASS |
| GraOS-kalenteri `tests/v72160_qemu_graos_calendar.py` (lopullinen media) | 3/3 PASS |
| `tests/v7138_nutedit_graos.py`, `tests/v72107_build_layout.py`, `tests/v7291_busy_integration.py` | PASS |
| `tools/check_graos_accessories_v7155.sh`, `tools/check_v690_filer_mouse_input.sh` | PASS |
| T400 / EL1352 | Ei ajettu |

QEMU-testi buttondemo: GraOS käynnistettiin, `buttondemo.bin` avattiin
Activities-haulla (Windows-näppäin), ja kehyspuskurista tarkistettiin:
oletusnappi (Close) on reunaton vaaleansininen (koko reunakehä täsmälleen
väriä 178,214,245), SMOOTH-napin kulmassa on antialiasoituja välisävyjä, ja
Antialiasing-nappi kytkee smoothauksen pois (kulmat kovareunaisiksi).
Käsin ajettuna myös oletustyypin vaihto edge/blurry/smooth päivitti ikkunan
muut napit heti. Kuvakaappaukset: `validation-v72.266/qemu-buttondemo/`.

`/cfg/graos-appearance.txt`: tallennus onnistuu vain, jos `/cfg` on
olemassa (asennettu järjestelmä). Pelkällä RAM-juurella tallennus
epäonnistuu ilmoituksella, mutta asetus tulee silti voimaan GraOS:n ajon
ajaksi.

Valmiiksi rikki olleet testit (sama tulos muuttamattomalla V72.265:llä,
ei regressioita): `v7027_graos_gui_clients`, `v7056_graos_hybrid_preview`,
`v7146_graos_start_menu`, `v7149_graos_activities_path`,
`v72104_graos_mouse_diag`, `v7071_graos_ansi256_font`,
`check_graos_win98_ui.sh` sekä `tools/graos_preview` -työkalun `test`- ja
`zrank`-ohjelmat (kaatuvat ajossa). `v7057_graos_app_icons_alttab` puuttuvat
kuvakkeet olivat jo listalla; buttondemo sai oman kuvakkeen.

Lokit ja kuvat: `validation-v72.266/`.
