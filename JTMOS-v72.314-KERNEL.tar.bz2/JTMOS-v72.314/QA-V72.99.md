# JTMOS v72.99 QA — calremind application inventory

| Check | Result |
|---|---|
| Canonical application release inventory includes `calremind.bin` | PASS |
| All 112 expected root-level application executables present | PASS |
| No unclassified root-level `*.bin` | PASS |
| GraOS package classification contains calendar and calremind | PASS |
| Real `tools/build_install_image.sh` execution, v72.99 | PASS |
| `calremind.bin` staged into `graos.sqa` | PASS |
| Independent SQA checker: 122 executables each in exactly one package | PASS |
| v72.94 minimal-compatibility patch applies and packages | PASS |
| Published `utilities.iso` and `utils.iso` | PASS |
| Full kernel32.bin/DOSBOOT rebuild | NOT RUN (NASM unavailable) |
| ThinkPad T400 hardware boot/Ethernet test | NOT RUN |
| Archive integrity and SHA256 | Verified after ZIP creation |

Packaging reports repeated `sqarc` warning: missing `boot32/nonsysdisk.bin`, optional safe area zero-filled. This is distinct from the fixed error.
