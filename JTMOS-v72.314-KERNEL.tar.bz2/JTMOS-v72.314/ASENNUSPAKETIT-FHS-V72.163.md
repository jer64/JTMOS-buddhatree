# V72.163: kaikkien pakettien asennus POSIX/FHS-hakemistoihin

Jokaiselle utilities.iso:n aihepaketille on asennusskripti. Skriptit tulevat
`core.sqa`:n mukana, ja ne asentavat paketin laitteen juureen:

| Skripti | Paketti | Minne |
|---|---|---|
| coreinstall.sh | core.sqa | /usr/bin, /etc (tcp.cfg, slip.cfg, boot.uni), /usr/lib/jtmos/drivers, /usr/share/doc/core, /usr ja /var -rakenne (fhs.sqa) |
| bootinstall.sh | boot.sqa | /boot/jtm32.img, /usr/share/doc/boot |
| demosinstall.sh | demos.sqa | /usr/bin, /usr/share/demos, /usr/share/doc/demos, Angband (/usr/share/angband, /var/games/angband) |
| docsinstall.sh | docs.sqa | /usr/share/doc/jtmos, www-sivut /var/www/html |
| graosinstall.sh | graos.sqa | /usr/bin, /usr/share/graos, /usr/share/doc/graos |
| interpretersinstall.sh | interpreters.sqa | /usr/bin, esimerkit /usr/share/doc/interpreters/examples |
| mediainstall.sh | media.sqa | /usr/bin, /usr/share/doc/media |
| networkinstall.sh | network.sqa | /usr/bin, /usr/lib/modules/ktls.kmo, /usr/share/doc/navigator/examples, BitchX, ircII |

Käyttö (esimerkiksi kiintolevylle hda1:):

    sqa cdrom
    sqa core.sqa
    coreinstall.sh hda1:/
    graosinstall.sh hda1:/
    networkinstall.sh hda1:/

Ilman argumenttia kohde on `/`. Jokainen skripti hyväksyy `--help` ja
`--version`. Paketti etsitään skriptin vierestä ja sitten nykyisestä
hakemistosta.

Komennot löytyvät /usr/bin:stä automaattisesti (PATH ja ohjelmanlataaja).
GraOS löytää kuvansa /usr/share/graos:sta, KTLS moduulinsa
/usr/lib/modules:sta ja picture.bin sqfam.raw:n /usr/share/demos:sta.

Paketit itse ovat ennallaan litteitä, joten `sqa graos.sqa` /bin:iin ja
`pkg install` toimivat kuten ennenkin.

## Uutta sqa-komennossa

    sqa paketti.sqa -u '*.bin' -o /usr/bin

`-u` hyväksyy nyt jokerimerkit `*` ja `?`, ja `-o`-hakemisto luodaan
tarvittaessa (myös välihakemistot).

## Leikepöytä

Jaettu leikepöytä on nyt juuritiedostojärjestelmän `/tmp/clipboard.txt`.
Se toimii ilman ram:-levyä. Jos juurilaitteelle ei voi kirjoittaa, käytetään
varalla `ram:/clipboard.txt`:tä.
