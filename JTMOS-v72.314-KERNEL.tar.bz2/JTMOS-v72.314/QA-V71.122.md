# QA – JTMOS v71.122

Testattu 20.10.2026. Pohja on käyttäjän täydellinen v71.121-ZIP.

| Tarkistus | Tulos | Kattavuus |
|---|---|---|
| Uusi v71.122 Navigator-CI | PASS | Kymmenen korjausaluetta; DOM, lomakkeet, renderöinti, muistirajat, oikea GraOS-cleanup ja localhost-HTTP. |
| HTTP 204/205:n IPC | PASS | Edellisen sivun HTML säilyy taustatyöntekijän vastauksen yli. |
| GraOS-näyttötilan malli | PASS | Aito C-käyttöönottopolku: prepared ei ole active; BIOS-tila, BGA-muutos ja kartoitusvirhe erikseen. |
| v71.120 Navigator-CI | PASS | WebP, Adam7/16-bit PNG, 8000 SVG-muunnosta, layout, valinta/haku, lomakkeet, POST/303/307. |
| v71.116 renderöinti | PASS | Taulukot, asemointi, varjot, gradientit ja PNG. |
| v71.112 vanha ketju | PASS | 1611 fontti/CSS-tarkistusta, JPEG-referenssit ja vanhemmat Navigator-sarjat. |
| Navigator ELF32 / kernel launch preflight | PASS | Oikeat kernelin tunniste- ja käynnistysikkunan validaattorit; 8192 KiB alkuvaraus mahtuu 16 MiB ikkunaan. |
| Kernel syscall/NMI/ISR/GDT/TSS | PASS | Olemassa olevat staattiset tarkistukset. |
| Kernelin 343 C-yksikön syntaksi | PASS, varoituksia | Kaksi ennestään olevaa puuttuvan SchedulerWaitPause-prototyypin varoitusta. |
| Päätason make | PASS | Tuottaa jtm32.img, root1440.img, utilities.iso ja DOSBOOT. |
| QEMU 8.2 / 512 MiB / OHCI / NE2000 | PASS | Oikea v71.122-kernel, pakettien purku, 1024×768 GraOS, Navigatorin käynnistys ja HTTP 103/200 -lomakesivun näkyminen, myös inline-SVG. |
| Koko make check | FAIL, ennestään vanhentuneet testiodotukset | Ei ilmoiteta vihreäksi; katso auditointiraportti. |

ASan ja UBSan olivat käytössä host-korjaustesteissä. LeakSanitizer oli pois
käytöstä ympäristön prosessitietorajoituksen vuoksi. Fyysistä eMachines- tai
muuta laitteistokoetta ei tehty.

Täysi make ei ole varoitukseton. Alkuperäisiä varoituksia on myös esimerkiksi
floppy-ajurissa, JTMFS:n dirdbFind-koodissa ja vanhemmissa host-/GUI-lähteissä.
Ne eivät estäneet ensimmäistä täydellistä rakennusta. Yksi uusinta-ajo pysähtyi
rsyncin tilapäishakemiston tiedoston päädyttyä SQA-keräilyyn; keräilijä ohittaa
nyt nimenomaisesti .rsync-tmp:n ja sama koko rakennus onnistui sen jälkeen uudelleen.

Lokit ovat hakemistossa release/qa/v71.122. Alkuperäisen ZIPin manifestivirheet
on dokumentoitu AUDIT-V71.121-NAVIGATOR.md:ssä. Uuden ZIPin SHA-256-manifesti
varmennetaan arkiston omista tavuista.

## QEMU-koe

Ajettiin toimitettavilla jtm32.img-, root1440.img- ja utilities.iso-tiedostoilla
sekä erillisellä 128 MiB:n tyhjällä testilevyllä. OHCI-näppäimistöä käytettiin
pakettien asennukseen ja Ctrl+Shift+N:n kautta avattuun GraOS-terminaaliin.
Navigator käynnistettiin oikeana Ring3-sovelluksena. Paikallinen HTTP-palvelin
lähetti ensin 103 Early Hintsin ja sitten 200-vastauksen. Kuvasta tarkistettiin
otsikko, tekstikentät, readonly-kenttä, select, radionapit ja inline-SVG.

Tämä smoke-koe ei korvaa kaikkien lomake-eleiden manuaalista laitekoetta.
Niiden säännöt ja rajatapaukset tarkistettiin erillisissä ASan/UBSan-
regressiotesteissä. Kokeessa ei käytetty ulkoista verkkosivustoa.

Ohjelmabinaari, asennusmedian network.sqa-paketti ja toimitettava kopio
varmennetaan samoiksi lopullisessa paketointitarkistuksessa.

Lopullinen Navigator SHA-256: `c4ce55dddaa6253f39648fcae42cdf7ffa83bb155509ac44501be85ee524ef47`.
Lopullinen utilities.iso SHA-256: `cd4320bebc819d2529cdc97b2958b897551924b091425c9f867cc6150005c1da`.
QEMU-smoke tehtiin näillä täsmälleen samoilla toimitettavilla tavuilla.
