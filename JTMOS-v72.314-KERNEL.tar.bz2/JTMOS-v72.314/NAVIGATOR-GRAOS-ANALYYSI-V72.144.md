# Navigator GraOSissa – analyysi ja toteutetut uudistukset

**Versio:** JTMOS 72.144. **Päiväys:** 26.10.2026. **Pohja:** kokonainen v72.143 FULL SOURCE RELEASE -paketti.

v72.143 korjasi historian, ankkurit ja dokumentin elinkaaren. Sen analyysin toinen ja kolmas jatkotyö koskivat pitkiä sivuja: piirtolistaa käydään läpi lineaarisesti, ja rajoihin törmännyt sivu jää käyttäjälle huomaamatta osittaiseksi. Tämä julkaisu toteuttaa näistä rajatun, testattavan osan: piirtolistan alueindeksin, stacking-järjestyksen lajittelun lineaarisena ja pysyvän ilmoituksen osittaisesta sivusta. Sivun ulkoasu ja piirtojärjestys eivät muutu.

## Tutkimuksen rajaus ja menetelmä

Tarkastelu kohdistui siihen, kuinka usein ja millä hinnalla Navigator käy läpi `NavLayout`-piirtolistan: `nav_render_visit`, napsautuksen ja kontekstivalikon osumatestit, kuvien latausajastus, `nav_layout_build`-funktion z-järjestys sekä `truncated`-lippujen käyttö. Jokaisen kutsukohdan suoritustiheys selvitettiin lähdekoodista (vieritys, damage-alueet, UI-tick, hiiren painallus).

Uusi koodi verrattiin vanhaan toteutukseen suoraan: testi suorittaa saman kyselyn sekä indeksillä että v72.143:n lineaarisella silmukalla ja vaatii täsmälleen saman tuloksen samassa järjestyksessä. Vanha z-lajittelu on testissä sellaisenaan vertailukohtana. Ajoitukset ovat Ubuntu-isännän mittauksia (-O2). Ne kuvaavat algoritmien välistä eroa, eivät JTMOSin laitteistolla mitattua nopeutta.

## Havainnot v72.143:ssa

| Prioriteetti | Havainto | Vaikutus |
|---|---|---|
| Korkea | `nav_render_visit` kävi koko piirtolistan läpi jokaisella piirrolla. Vieritys, damage-alueiden uudelleenpiirto ja täysi piirto kutsuvat sitä kerran jokaista aluetta kohden. | 100 000 kohteen sivulla jokainen vieritysaskel testasi 100 000 kohdetta, vaikka näkyvissä on muutama tuhat. |
| Korkea | Napsautuksen ja kontekstivalikon osumatesti kävi listan läpi lopusta alkuun. | Linkin painallus pitkän sivun alussa tarkisti lähes koko listan. |
| Keskitaso | `image_schedule` kävi koko listan läpi jokaisella UI-kierroksella, kun kuvia odotti latausta. | Joutilaskierroksen kustannus kasvoi sivun pituuden mukana. |
| Keskitaso | Stacking-järjestys lajiteltiin toistuvalla haulla: O(kohteet × eri z-arvot). | Sadat `z-index`-arvot 100 000 kohteen listassa tarkoittivat kymmeniä miljoonia vertailuja jokaisessa reflow'ssa. |
| Keskitaso | `layout->truncated`, DOM-virhe ja tekstitilan rivikatto eivät näkyneet käyttöliittymässä. CSS-katto näkyi vain hetkellisessä tilarivin viestissä. | Pitkä uutisarkisto saattoi loppua kesken ilman mitään merkkiä. Reader-tilaa ei tarjottu. |

Lineaarisia läpikäyntejä on muitakin: haku (Find), valinta, saavutettavuuspuu, `control_rect` ja `image_placed`. Ne suoritetaan kerran käyttäjän toimintoa tai valmistunutta kuvaa kohden, eivät jokaisella piirrolla. Niitä ei muutettu.

## Toteutus

### Piirtolistan alueindeksi

`nav_layout_build` rakentaa valmiille listalle indeksin lajittelun, 200 %:n zoomauksen ja muistin tiivistyksen jälkeen. Sivun rivit jaetaan 128 pikselin kaistoihin. Jokaiselle kaistalle tallennetaan sitä koskettavien kohteiden indeksit nousevassa eli piirtojärjestyksessä. Yli neljän kaistan korkuiset kohteet, kuten sivun taustakangas, tallennetaan erilliseen `tall`-listaan, joka tarkistetaan jokaisessa kyselyssä. Kaistoja on enintään 4 096; sitä alemmat rivit yhdistetään viimeiseen kaistaan.

Kysely yhdistää kaistojen ja `tall`-listan nousevat indeksijonot k-tie-yhdistämisellä. Usean kaistan kohde tuotetaan vain ensimmäisestä kyselyn kaistasta, jota se koskettaa. Tulos on siis vanhan silmukan kohdejoukon ylijoukko samassa järjestyksessä. Kutsujat säilyttävät oman tarkan geometriatestinsä. Piirtojärjestys ja z-kerrokset pysyvät tavu tavulta samoina.

| Kutsukohta | v72.143 | v72.144 |
|---|---|---|
| `nav_render_visit` (vieritys, damage, täysi piirto) | koko lista | näkyvän alueen kaistat + `tall` |
| Napsautus | koko lista lopusta alkuun | ylin osuma: binäärihaku kaistassa ja `tall`-listassa |
| Kontekstivalikko | koko lista | sama osumaiteraattori, alaspäin osuma kerrallaan |
| Kuvien ajastus | koko lista jokaisella UI-kierroksella | ikkuna −½…+2 näkymää; pysähtyy ensimmäiseen ladattavaan kuvaan |

Indeksiin luotetaan vain, jos sen tallentama `items`-osoitin ja `count` vastaavat listaa. Muussa tapauksessa, samoin kuin muistinvarauksen epäonnistuessa, kaikki kyselyt käyttävät vanhaa lineaarista polkua. Testien pinossa rakentamat `NavLayout`-rakenteet nollataan, joten niiden indeksi on `NULL`. Kuvan valmistuminen muuttaa paikallaan vain kohteen tyyppiä ja leveyttä. Se ei siirrä kohteen kaistaa.

### Stacking-järjestys

`nav_layout_sort_z` korvaa toistuvan haun vakaalla laskentalajittelulla, O(kohteet + avainväli). Z-avain on `short`, joten laskuritaulukko on enintään 65 537 alkiota (256 KiB) ja vain lajittelun ajan. Testi vertaa tulosta vanhaan algoritmiin 200 satunnaisella listalla, joissa on 1–65 536 eri avainta. Tulokset ovat identtiset.

### Osittaisen sivun ilmoitus

`nav_page_partial` palauttaa syyt: layout-katto (100 000 kohdetta, 200 000 px tai sisäkkäisyysraja), CSS-budjetti, DOM-budjetti tai tekstitilan rivikatto. Tilarivin oikeaan reunaan piirretään pysyvä merkki, kuten `Partial page: layout limit | F8 Reader`. Se säilyy vierityksen ja tilaviestien vaihtuessa ja poistuu, kun näytetty sivu on kokonainen. Merkin napsautus avaa Reader-tilan, jos artikkelijuuri löytyy. Muuten tilariville tulee selitys rajasta. Find-tila varaa tilarivin, joten merkkiä ei piirretä hakukentän päälle. Reader-tieto lasketaan kerran layout-sukupolvea kohden, ei jokaisella piirrolla.

## Mittaukset

Isäntä -O2, kaksi ajoa, generoitu 2 400 kappaleen artikkeli ja 600 sijoiteltua laatikkoa (100 000 kohdetta, katto saavutettu):

| Toiminto | v72.143-polku | v72.144 | Ero |
|---|---|---|---|
| Näkymän (616 px) kohdejoukko, 1 650 vieritysaskelta | 0,22 ms | 0,013 ms | ×17–18 |
| Napsautuksen osumatesti | 175–179 µs | 0,55 µs | ×320 |
| Stacking-lajittelu, 301 avainta | 69 ms | 4,4–7,8 ms | ×9–16 |
| Indeksin rakentaminen | – | 1,1 ms / layout | uusi kustannus |

Ajat kuvaavat vain listan läpikäyntiä. Pikselien piirto (`nav_paint_*`, glyfit) on ennallaan ja hallitsee näkyvän alueen todellista piirtoaikaa. Laitteistolla erot ovat todennäköisesti suuruusluokaltaan samat, mutta absoluuttisia aikoja ei ole mitattu T400:lla eikä eMachinesilla.

Muisti: 100 000 kohteen listalle indeksi vie noin 0,5 MB (126 455 kaistamerkintää, 1 281 kaistaa). Itse lista vie i686:lla 5,2 MB (52 tavua kohdetta kohden). Pahin tapaus on rajattu: enintään 4 merkintää kohdetta kohden ja 4 096 kaistaa, eli noin 1,6 MB. Indeksi lasketaan muistiprofiilin CSS + layout -komponenttiin. Reflow pitää vanhan ja uuden layoutin hetken yhtä aikaa muistissa, kuten ennenkin; nyt molemmilla on oma indeksinsä.

## Rajoitukset ja seuraavat työt

1. **Merkkikohtainen piirtolista.** Jokainen glyfi on yhä oma 52 tavun kohteensa. Tekstijaksot pienentäisivät sekä muistia että 100 000 kohteen kattoon törmäämistä. Indeksi nopeuttaa kohteiden löytämistä, mutta ei pienennä listaa.
2. **Koko dokumentin reflow.** Lomakkeen kirjoitus, kuvan koon muutos ja JS-muutos rakentavat yhä koko layoutin ja indeksin uudelleen. Rajattu invalidointi on erillinen työ.
3. **Verkkotilan omistajuus.** v72.143:ssa nimetty pysyvä HTTP-välimuisti, TLS-istunnot ja HSTS-tila jäävät ennalleen.
4. **Osoiterivin kirjoitus raskaalla sivulla.** Jokainen osoiterivin näppäily piirtää koko ikkunan uudelleen. QEMU:n TCG-emulaatiossa 100 000 kohteen Reader-sivulla 28 merkin osoitteesta vastaanotettiin 17, kun merkit lähetettiin 0,08 s välein. Indeksi pienentää piirron listakustannusta, mutta glyfien piirto jää. Pelkän työkalurivin uudelleenpiirto osoitetta muokattaessa on seuraava selvä korjaus. Fyysisellä koneella tätä ei mitattu.
5. **Katon nostaminen.** Rajoja ei nostettu. Ilmoitus kertoo, milloin sivu on osittainen, ja tarjoaa Reader-tilan. Se ei näytä puuttuvaa sisältöä.

## Toistettavat tarkistukset

```sh
make BOOT_DISPLAY=vesa BOOT_NOGUI=0
python3 tools/check_release_media.py
python3 tests/v7196_navigator_launch.py libc/apps/navigator.bin
NAV_TEST_LEAKS=0 sh tests/run-v72144-paint-index.sh
python3 tests/v72144_ui_host.py
python3 tests/v72143_navigation_host.py --quickjs
NAV_TEST_LEAKS=0 sh tests/run-v7274-navigator-sanitizers.sh
python3 tests/v72111_qemu_navigator.py ../qemu144-ps2 --navigator-only --navigator143 --navigator144
python3 tests/v72111_qemu_navigator.py ../qemu144-usb --navigator-only --usb --navigator143 --navigator144
```

Tulokset, lokit ja tarkistussummat ovat `QA-V72.144.md`:ssä ja hakemistossa `release/qa/v72.144/`.
