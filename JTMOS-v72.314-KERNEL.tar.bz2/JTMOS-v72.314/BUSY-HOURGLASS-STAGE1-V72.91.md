# JTMOS v72.91 – GraOS busy/hourglass, phase 1 (window-scoped manager)

## Scope

GraOS's existing animated 32x32 hourglass remains the only GUI busy cursor.
The transparent VESA/EGA terminal overlay removed in v72.90 remains removed.
This stage introduces per-window busy operation ownership without changing the
animation geometry. The 150 ms debounce and 220 ms frame period remain unchanged.

### API

```c
int token=GraOS_BusyBegin(window_id,"Loading directory");
if(token>0) {
    /* Work in application process, not GraOS's window-server event loop. */
    (void)GraOS_BusyEnd(token);
}
int active=GraOS_BusyIsActive(window_id); /* 1 busy / 0 idle / negative error */
```

The new APIs are available through both modern and legacy JTMOS GraOS client
libraries. `GraOS_BusyBegin` returns a positive token or a negative error.
`GraOS_BusyEnd` requires the original sender's PID and returns 0 or a negative
error. Descriptions are stored truncated to 63 bytes for future diagnostics.

Legacy `JtmosGraOSSetBusy(1/0)` remains global and reference counted per
process to retain old binary compatibility. Legacy requests coexist with new
window-specific requests. `JtmosGraOSGetBusy()` reports aggregate active state;
its owners field is the legacy owner count plus outstanding window operations.

### IPC and ownership

- New GSIDs: BUSYBEGIN=57, BUSYEND=58, BUSYISACTIVE=59.
- The server validates `m->sndPID` equals the live window's owning PID.
- Only the PID that created a token can release it.
- 32 concurrent window-scoped operations, in addition to the 16 legacy owner
  slots. Overflow returns an error rather than corrupting memory.
- Token allocation is monotonic and collision-checked for active slots.
- Operations remember window ID **and generation** so recycled window slots
  cannot inherit an earlier operation.
- `guiCloseWindow()` releases operations for the closing window generation.
- The 250 ms dead-client reaper clears both legacy and new requests.
- The cursor is an hourglass only when the pointer is over a busy window, unless
  a legacy global request is active; other windows keep their normal cursor.

### Diagnostics

```text
graosctl busy
graosctl busy window 7
```

### Packaging and limitations

`libc/apps/gui/graos.bin` and `libc/apps/gui/graosctl.bin` were compiled and
linked as static ELF32 Intel 80386 executables. The packaged `graos.sqa` and
`tools/install_payload/graos.sqa` include these built programs, plus the prior
calendar and reminder agent. The bulk `utilities.iso` file was NOT rebuilt and
may still contain older GraOS binaries. The full kernel and DOSBOOT were NOT
rebuilt; a NASM compiler is missing from this environment, so retained legacy
boot/kernel binaries do not contain v72.90's VESA console modification.

This is a source+GraOS application release, NOT a fully rebuilt bootable kernel.
The new window-scoped API is opt-in; existing Filer and media-browser calls
still use the compatibility global busy mode until phase 3.

No real ThinkPad T400 hardware rendering/IPC test has been performed yet.
Phase 2 will address cursor graphics and animation timing.
