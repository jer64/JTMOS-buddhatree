# Navigator v72.170 – RKO CSS/HTML regressio

28.10.2026. Liitetty RKO-sivu käyttää CSS:ssä kolmea float-palstaa
(`23% / 48% / 23%`), `div.banner`-taustakuvaa, `position:absolute`
-mainosta, `display:flex`-ikonisoluja, taulukon `colspan`-määrittelyjä
ja `tbody tr:nth-of-type(odd/even)`-valitsimia.

Aiemmassa Navigatorissa valitsimet, float-rakenne, position, table ja flex
olivat jo tuettuja, mutta taustakuvien `url(...)` jätettiin huomiotta.
Lisäksi float-palstan prosenttileveys laskettiin toisen kerran sen omasta
kapeasta Flow-alueesta: esimerkiksi 23 % tarkoitti käytännössä 23 % × 23 %.

Tässä versiossa CSS-taustakuvat sidotaan saman rajatun media-cache-asynkronisen
latauksen kautta kuin `<img>`-kuvat. Kuville on oma `NAV_PAINT_BG_IMAGE`
-piirtokomento, jotta ne piirretään tekstin alle ja sama klippaus toimii
GraOSissa sekä host-testeissä. Toistot, no-repeat ja reunasijoittelu
käyttävät kuvan luontaista kokoa. Myös lajittelulinkkien oikean reunan
nuolet voidaan nyt näyttää.

Float-elementin leveys ratkaistaan nyt kerran sisältävän lohkon mukaan.
RKO:n palstojen todelliset maalatut leveydet 1050 px näkymällä ovat
noin 224 / 472 / 228 px, jolloin vasen ja oikea sivupalsta sekä
keskimmäinen musiikkitaulukko ovat vierekkäin.

Regressioiden syöte: `tests/navigator/rko_saved_original.html`,
`tests/navigator/rko.css`. Alkuperäinen .html oli Firefoxin view-source
-sivu; testin tiedosto on sen rakenteesta palautettu oikea HTML, ei
Firefoxin lähdekoodin esityssivu.

Puutteet: vain ensimmäinen URL-kuvataso, ei `background-size`-skaalausta eikä
kaikkia position-syntakseja; CSS-tiedoston hakemistosta riippuvat
suhteelliset kuvat eivät ole vielä täysin standardin mukaisia.
