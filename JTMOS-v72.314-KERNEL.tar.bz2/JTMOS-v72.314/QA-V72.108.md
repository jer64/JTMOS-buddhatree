# JTMOS v72.108 — hiiri, Start ja T400 Ethernet

24.10.2026. Pohja: v72.107 FULL-SOURCE-RELEASE. Kokonainen käännetty julkaisu.

## Korjaukset ja niiden syyt

**Hiiren näkymätön seinä.** Ydin rajasi absoluuttisen hiiripaikan, josta GraOS
laski erikseen kiihdytetyn siirtymän. Ytimen paikka saattoi saavuttaa reunansa,
vaikka GraOSin kursori oli vielä keskellä ruutua. Silloin seuraavista saman
suunnan liikkeistä saatiin nollan suuruinen muutos. Uusi subcommand 10 välittää
rajaamattomat suhteelliset liikelaskurit ja niiden arvot jokaisella nappireunalla.
PS/2, Synaptics/TrackPoint, USB ja sarjahiiri päivittävät laskureita ennen
vanhan koordinaatin rajausta. GraOS rajaa ainoastaan lopullisen kursorin paikan.
Ylivuoto on määritelty modulo-2^32-laskenta; lähteen vaihto ja jonon ylivuoto
asettavat uuden perustason ilman hyppyä tai tekaistua klikkausta.

Vanha 32-tavuinen snapshot, 40-tavuinen nappitapahtuma ja 696-tavuinen
subcommand-9-vastaus säilyvät ennallaan. Uusi vastaus on i686:lla 832 tavua.
Vanhan ytimen kanssa käytetään sen absoluuttista paikkaa ilman toista
kiihdytystä. Olemassa olevat sovellukset eivät tarvitse uutta hiiri-ABI:a.

**Startin vaihtuva toimintatapa.** Näkymä valittiin aiemmin teeman ja ulkoisen
tehtäväpalkin saatavuuden kautta. Nyt hiiren Start-painike käyttää aina
perinteistä valikkoa; Windows/Ctrl+Esc/Win+Tab käyttävät Overview-näkymää
kaikilla teemoilla. Näkymästä toiseen vaihtaminen sulkee aiemmat valikot ja
vapauttaa mahdollisen pointer capturen. Sama avauspainike myös sulkee oman
näkymänsä. Ulkoinen tehtäväpalkki ei valitse Startin esitystapaa.

**Valikon aikainen töksähtely.** Jokainen hiiren koordinaatin muutos merkitsi
aiemmin koko ruudun uudelleenpiirrettäväksi valikon ollessa auki. Nyt
korostusrivin muuttuminen ohjaa piirron invalidointia. Saman rivin sisällä
käytetään kursorin erillistä aluepäivitystä. Kolmen valikkotason neutraalit
pinnat välimuistitetaan; vain aktiiviset rivit piirretään niiden päälle.
Teema, valikkolista ja koko kuuluvat välimuistin avaimiin. Muistipulassa
käytetään samaa suoraa piirtoa, eikä valikko lakkaa toimimasta.

**T400 Ethernet.** BIOS-tilaan luottava alustava ajuri on korvattu kohdelaitteen
natiivilla alustusketjulla: PCI D0, DMA-pysäytyskuittaus, firmware-SWFLAG,
MAC/PHY-resetti, Kumeran-yhteyden alustus, BM PHY:n tunnistus/sivutus,
virransäästöstä palautus, MDI/MDI-X/downshift sekä linkkineuvottelu.
Resetin jälkeen DMA pysäytetään uudelleen ennen descriptorien kirjoittamista.
`inet restart` käyttää samaa ketjua. `inet hw` näyttää sen tulokset.
Toteutus ja virhekoodit on kuvattu tiedostossa `docs/ICH9E-V72.108.md`.

## Todennukset

| Tarkistus | Tulos ja rajaus |
|---|---|
| Kokonainen `make` | Ydin, kaikki 112 sovelluskohdetta, GraOS/asiakkaat, käynnistys- ja asennusmediat sekä DOSBOOT käännetty |
| `v72108_pointer_runtime.py` | Todelliset i686-otsakkeet, ytimen jono, libc ja GraOSin kuluttaja; 30 000 reunanylityssarjaa kolmella laskentageometrialla, välitön paluuliike, laskurin ylivuoto sekä vanha ABI |
| `v72108_shell_runtime.py` | Todellinen desktop/input/shell-koodi; 2 500 toistettua avaus-/vaihtosarjaa kaikilla teemoilla ja aktiivisella ulkoisella tehtäväpalkilla; 10 000 saman rivin liikettä ilman scene damagea |
| Valikon välimuisti | Välimuistitetun ja suoran piirron pikselivertailu kaikilla teemoilla, valinnoilla ja kolmella valikkotasolla; sama ulkoasu myös epäonnistuneella allokoinnilla. Fonttirasterointi on tässä testissä hallittu fixture; lopullinen ulkoasu tarkistetaan QEMUssa. |
| `v72108_ich9e_runtime.py` | Kokonainen tuotantoajuri ja oikeat otsakkeet; mallinnettu MMIO/MDIC/Kumeran/DMA; resetin lukujärjestys, firmware-lukitus/esto, MAC-autoload ilman BIOS-MACia, 14 virhetilannetta, 100 000 TX-kierrosta, RX ja linkin katkeaminen. ASan/UBSan käytössä. |
| Aiemmat regressiot | Nappijono/hold/overflow/source change, capture/resize/omistajasukupolvet, käynnistyksen layout-vahti, lopullisen ELFin 36 layout-tietuetta, otsakkeen riippuvuudet, kursoripinnan säilyminen, busy-watchdog ja DMA-quiesce |
| QEMU PS/2 | Koko järjestelmä käynnistetty tämän julkaisun medialta ja GraOS asennettu sen paketista; animoitu kursori |
| QEMU USB OHCI | Sama käyttötesti USB-hiirellä ja -näppäimistöllä; `--no-animation` tarkistettu ajonaikaisesta lokista |
| Paketit | ISO → NZIP → SQA → GraOS/asiakas tarkistettu tavutasolla; suorat paketit, DOSBOOT-kopiot ja purettu pakattu ydin vastaavat tämän julkaisun binäärejä |
| ZIP | Manifestin hashit, symlinkit ja niiden kohteet, yksilölliset/turvalliset polut sekä asennusmedioiden kopiot tarkistetaan lopullisesta ZIPistä |

QEMU-käyttötestit kattavat kaikki ruudun reunat ja heti vastakkaiseen suuntaan
tehdyn liikkeen, hiiren Startin, Windows-näppäimen ja Ctrl+Esc:n, perinteisen
Startin uudelleenavaamisen Overview'n jälkeen, saman valikkorivin sisäisen
liikkeen, kontekstivalikon, pidetyn hiirinapin, uuden terminaalin sekä
jatkuvan näppäimistötoiminnan. Käynnistys käyttää uutta `queue=2`-rajapintaa.
Molempien lopullisten ajojen mittaus: **24 kursoripäivitystä, 0 työpöydän
uudelleenpiirtoa ja 0 uutta valikkopinnan muodostusta** saman rivin sisällä.

Sarjalokin `scene`- ja `fast-cursor`-laskurit erottavat työpöydän koostamisen
pelkän kursorin esittämisestä; kokonais-frame-laskuri sisältää molemmat.

Tarkat ajotulokset ja binäärien SHA-256:t ovat hakemistossa
`release/qa/v72.108/`. QEMU JSON -tulokset sidotaan pakettitarkistuksessa
täsmälleen lopullisiin kernel-, GraOS- ja ISO-tavuihin.

Raaka ydin on **1 042 780 tavua**; sen 1 MiB:n kuvarajaan jää **5 796 tavua**.
Linkkerin muistialuerajaukset läpäisevät tarkistuksen.

## Testauksen käytännön rajat

Fyysistä ThinkPad T400:aa ei ole tässä suoritusympäristössä. Ethernetin
rekisteri-/DMA-mallit eivät todista oikean kortin TX/RX:ää, ja QEMU ei emuloi
82567LM-kohdetta. Laitteella on vielä vahvistettava linkki, TX DD/TDH -eteneminen,
ARP/DHCP/RX sekä `inet restart`. Myös TrackPointin/touchpadin todellinen tuntuma
ja näytön ajoitus tarvitsevat T400-testin.

Intel ME:n aktiivista PHY-resetin estoa ei ohiteta firmwarea rikkomalla.
Ajuri ilmoittaa eston ja tukee MAC-only-resettiä jo toimivalla linkillä;
ilman käyttökelpoista linkkiä se palauttaa -22. NVM/flash-kirjoituksia ei tehdä.

Täysi käännös onnistuu, mutta vanhan lähdepuun varoituksia on edelleen
esimerkiksi levykuvatyökalussa sekä muissa muuttamattomissa moduuleissa.
Uusissa hiiri-/valikko-/ICH9E-muutoksissa ei havaittu GCC-varoituksia.
Vanha laaja `check_gcc_warning_clean.sh` pysähtyy muuttamattomaan
v68.175-lähdekuviotarkistukseen, joka odottaa aiempaa HLT-burst-vakiota.
Sen tarkistusskripti ja scheduler-otsake vastaavat tavulleen v72.107-pohjaa.
Tätä vanhaa koontitarkistusta ei ole ilmoitettu läpäistyksi; tämän muutoksen
ajonaikaiset testit sekä käännös-/paketointitarkistukset ajetaan erikseen.

Peritty valinnainen `boot32/nonsysdisk.bin` puuttuu; kuvatyökalu nollatäyttää
sen varatun alueen. Käytössä oleva boot32pm/DOSBOOT-polku on käännetty ja
QEMUssa testattu. Oletusbootin text/nogui-valinta säilyy.

## Julkaisupuun tarkistus

Kaikki 21 suhteellista symbolista linkkiä säilytetään. Eriävät host/Filer-
lähdevariantit säilyvät erillisinä. DOSBOOT:n tarvitsemat asennusmedia- ja
kernel-kopiot ovat fyysisiä ja tavulleen samat kuin kanoniset tiedostot.
Vanhoja erillisiä GraOS-asennuspaketteja ja tyhjää generoituvaa
`libc/libc/build/`-hakemistoa ei pakata uuteen julkaisuun. Viimeksi mainittu
poistaa aiemmin havaitun `BUILD`/`build`-ristiriidan kirjainkokoa
erottelemattomassa purussa; ohjetiedosto `BUILD` säilytetään.

## Asennuksen tarkistus

Päivitä FreeDOS-medialta käytettävä `KERNEL32.NZ` ja tämän saman julkaisun
GraOS-asennus. Koko DOSBOOT-hakemiston tiedostot ovat julkaisussa valmiina.
`graosctl input` näyttää uudella kokoonpanolla **ABI=108, queue=2**.
T400-verkkotesti aloitetaan komennoilla `inet start`, `inet hw`, `inet status`.
Niiden HW reset / Native PHY / KMRN / DMA-laskurit kertovat täsmällisesti,
mihin alustus tai tiedonsiirto etenee. `inet restart` tekee uuden laiteresetin.
