# JTMOS v72.80 – Intel 82567LM first Ethernet draft (2026-10-23)

**Full development source, UNBUILT. Not a tested bootable v72.80 release.**

## Base and preservation

This full-source tree derives from JTMOS v72.79 development source and retains the existing DOSBOOT.COM `gui` option, GraOS/mouse updates, JTMFS, AHCI/IDE and previous userspace code. The previous v72.79 T400 readme is historical; the Intel NIC comment there is superseded by this file and `docs/V72.80-T400-INTEL-82567LM-DRAFT.md`.

## Implemented in the source

* 8086:10F5 PCI probe; first call initializes PCI database (needed with DOSBOOT).
* MMIO mapped ICH9M integrated NIC with PCI D0 and bus mastering; INTx disabled, NIC interrupts masked.
* MAC address read from RAL/RAH, fallback to read-only EERD if needed.
* Coherent low-memory DMA using 64 RX / 32 TX 16-byte legacy descriptors, polling RX/TX and link status, 1518-byte Ethernet frame maximum.
* Integrated with generic `ethdev` (`ETHDEV_ICH9E`) and existing uIP/JNet DHCP/ping path; nForce and NE2000 retained.
* Limited initialization: no unreviewed PHY, flash firmware or global MAC resets.
* Source test `tests/v7280_ich9e_source.py`; adjusted previous T400 inventory regression to acknowledge draft packet driver.

## Verified in the build environment

* `kernel32/drivers/tcpip/ich9e.c` and changed `ethdev.c` compiled with the project's `-m32 -march=i686 -nostdinc -nostdlib` flags.
* `tests/v7280_ich9e_source.py`: PASS
* `tests/v7279_t400_probe.sh`: PASS
* `tests/v7278_dosboot_prompt_parity.py`: PASS
* `tests/v7277_interaction_regression.py`: PASS
* `tests/vesa_autostart_mouse_union_regression.sh`: PASS

## Not tested / NOT supported yet

* Cannot confirm ThinkPad T400 Ethernet carrier, DHCP, ARP, ping or TX/RX on hardware.
* Full kernel and DOSBOOT link/rebuild not performed (NASM missing in build environment); older included images/binaries are from the parent source archive and **do not have this driver**.
* The hardware may need additional ICH9LAN PHY/firmware initialization, link-workarounds, non-volatile memory handling and error recovery. If so, this first draft will report link-down or no MAC.

## Build and first hardware test

With the JTMOS build toolchain installed (GCC x86 32-bit, NASM, GNU binutils):

    cd kernel32
    make
    cd ..
    make [appropriate full release target]

Rebuild all DOSBOOT kernel payloads and images from source; **do not put the old `KERNEL32.BIN` from this source archive on the USB and expect the new NIC**. On the ThinkPad T400, leave BIOS SATA in Compatibility mode for the initial tests; use the existing FreeDOS USB and `DOSBOOT.COM gui` only after fully rebuilding its kernel payload. Connect an Ethernet cable, inspect boot diagnostics, `inet start`, `inet status`, `inet stats`, and `ping -c 3 gateway`. If there is no carrier, collect a serial log.

No disk formatting is required for a network-only test.
