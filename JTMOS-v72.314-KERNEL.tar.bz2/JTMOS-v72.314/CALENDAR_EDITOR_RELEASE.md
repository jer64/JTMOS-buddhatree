# GraOS Taskbar Calendar Editor (2026-10-16)

The taskbar clock opens a six-row month popup. Click a valid day to open the native GraOS event editor. Save (or Enter in text field) creates/updates one 95-character event per date; Delete removes it; Esc and Close cancel. Event dates with saved titles are marked with `*`. Month arrows navigate. The current day is bracketed.

Storage is `/calendar.txt` (one `YYYY-MM-DD TITLE` line per event); the editor writes `/calendar.tmp` then renames to the destination. Maximum 128 events. The filesystem containing `/` must permit writes, and SYS_rename must support overwriting the target. If persistence fails, a status error is displayed. No timed notifications/alarms or concurrent writer locking. A malformed source is ignored line-by-line; an unavailable source loads as empty. Do not run multiple taskbars modifying this file concurrently.

Modified: `libc/apps/taskbar.c`, `graos-host/apps/taskbar.c`. The supported ELF32 binary in `libc/apps/taskbar.bin` was rebuilt with `make -f taskbar.mak default`; actual GraOS and hardware runtime tests have not been performed.
