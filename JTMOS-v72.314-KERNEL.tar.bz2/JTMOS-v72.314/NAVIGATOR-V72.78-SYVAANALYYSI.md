# Navigator (navigator.bin) – syväanalyysi ja merkittävät parannusehdotukset

**Pohja:** JTMOS v72.77 FULL SOURCE RELEASE · **Päiväys:** 23.10.2026
**Laajuus:** `libc/apps/navigator*.c`, `libc/apps/navigator/*` (~600 kt C:tä), sekä Navigatorin käyttämät
`libc/libc/network/jt_net_transport.c`, `libc/libc/process/process.c`, `libc/libc/media/jpegdec.c` ja
ytimen DNS-resolveri (`kernel32/drivers/tcpip/jnet.c`).

**Menetelmä:** lähdekoodin luku, `navigator.bin`-käännös (onnistui, 32-bit ELF), olemassa olevat
host-testit (v72.77 interaction, 12 HTTP-testiä, memory/DOM-pressure – kaikki PASS) sekä uusi
host-mittaus (`navbench`), joka linkittää Navigatorin oikean parser-, CSS-, style-, layout- ja
render-koodin ja ajaa synteettisen uutisportaalisivun.

> Mittaukset on tehty nykyaikaisella x86-64-isännällä (-O2). eMachines-luokan koneella ajat ovat
> arviolta 10–30 kertaa pidempiä. Suhteelliset havainnot (mikä skaalautuu ja miten) pätevät silti.

---

## 1. Yhteenveto

Navigatorin turvallisuusajattelu (rajatut puskurit, IPC:n validointi, TLS fail-closed, O_EXCL-lataukset)
on hyvällä tasolla, ja testikattavuus on laaja. Suurimmat puutteet eivät ole yksittäisiä bugeja vaan
**arkkitehtuuriin liittyviä**. Ne selittävät suurimman osan hitaudesta ja epäluotettavuudesta oikeilla
sivuilla:

| # | Havainto | Vaikutus | Työmäärä |
|---|---|---|---|
| 1 | Jokainen HTTP-pyyntö forkkaa uuden worker-prosessin, joka tapetaan vastauksen jälkeen. | HTTP-välimuisti, TLS-istuntojen jatko ja HSTS **eivät käytännössä toimi**. Jokainen kuva tekee oman DNS-kyselyn, TCP-yhteyden ja TLS-kättelyn. | keskisuuri |
| 2 | HSTS-tieto jää lapsiprosessiin. Samalla HTTPS→HTTP-fallback sallii "handshake"-virheillä plaintext-latauksen. | **Tietoturva:** aktiivinen hyökkääjä voi pakottaa paljaan osoitteen HTTP:ksi, myös HSTS-sivuilla. | pieni |
| 3 | Ytimen DNS-resolverissa on vain yksi paikka eikä välimuistia. Rinnakkainen kysely palauttaa heti `-16 EBUSY`. | Rinnakkaiset CSS-, kuva- ja JS-haut epäonnistuvat satunnaisesti ("DNS resolver busy"). | pieni |
| 4 | libc:n `Sleep()` pyörii `SwitchToThread()`-silmukassa. Navigatorin pääsilmukka kutsuu `Sleep(10)`. | Joutilaskin Navigator vie prosessoriajan. Workerit ja GraOS kilpailevat siitä. | pieni |
| 5 | IPC lukee enintään 16 KiB kierrosta kohti, ja kierroksen päätteeksi on `Sleep(10)`. | Workerilta käyttöliittymään siirtyy **enintään noin 1,6 Mt/s** työtä kohti. 8 Mt:n sivun siirto vie vähintään 5 s pelkkää IPC:tä. | pieni |
| 6 | Layout katkeaa 100 000 piirto-objektiin (yksi objekti per merkki), eikä katkaisusta ilmoiteta. | Pitkät sivut **loppuvat kesken huomaamatta** (mittauksessa näkyi noin 40 % sivusta). | keskisuuri |
| 7 | Linkkejä tallennetaan enintään 1 024. | Portaaleissa loput linkit eivät ole klikattavia. | pieni |
| 8 | Jokainen reflow laskee kaikkien solmujen tyylit ja koko layoutin alusta. Lomakekentän jokainen näppäily tekee reflow'n. | Kirjoittaminen hakukenttään isolla sivulla on hidasta (eMachinesilla arviolta 0,5–3 s per merkki). | suuri |
| 9 | Täysi uudelleenpiirto (koko ikkuna, a11y-rakenne, ikkunan otsikon IPC) laukeaa jokaisesta tilarivin muutoksesta. | Jokainen kuvalataus piirtää koko sivun 1–2 kertaa. | pieni |
| 10 | Piirtäminen käy koko piirtolistan läpi lineaarisesti jokaisella vieritysaskeleella. | Vieritys hidastuu sivun pituuden mukana. | pieni |
| 11 | Kuvat ladataan yksi kerrallaan, tyylitiedostot peräkkäin. | Kuvarikas sivu latautuu hitaasti, vaikka workereita saisi olla 4. | pieni (1:n jälkeen) |
| 12 | JPEG-dekooderin raja on 1600 × 1600 / 1,92 Mpx, eikä DCT-skaalausta ole. | Suuri osa uutissivujen pääkuvista epäonnistuu. | keskisuuri |
| 13 | JS: `addEventListener` tukee vain `click`-tapahtumaa elementillä. `document`/`window`-delegointia ei ole, eikä `removeEventListener`ia. `fetch()` sallii vain yhden pyynnön kerrallaan. | Tavallisin JS-malli (event delegation) ei toimi. | keskisuuri |
| 14 | QuickJS ajetaan samassa prosessissa kuin käyttöliittymä ja evästevarasto. | JS-moottorin muistivirhe vaarantaa koko selaimen istunnot. | suuri |

Ehdotettu järjestys: **2 → 3 → 4/5 → 1 → 6/7 → 9/10/11 → 12 → 8 → 13 → 14**. Kohdat 2–5 ja 7, 9–11 ovat pieniä
muutoksia, mutta niiden vaikutus on suuri.

---

## 2. Havainnot yksityiskohtaisesti

### 2.1 Worker per pyyntö kumoaa välimuistit (kriittinen suorituskyvylle)

`nav_async_begin_post()` (`navigator/nav_async.c`) forkkaa jokaiselle pyynnölle uuden lapsen.
`nav_async_release()` (rivi 308) kutsuu `worker_stop()`-funktiota, joka lähettää SIGTERMin. Lapsen
`for(;;)`-silmukka osaisi käsitellä useita komentoja, mutta toista komentoa ei koskaan lähetetä.

Seuraukset:

- `nav_cache_get/put` (`nav_network.c` rivit 602 ja 727) toimii **lapsen** muistissa, joten välimuisti
  katoaa jokaisen pyynnön jälkeen. Vanhemman välimuisti pysyy tyhjänä, ja jokainen fork perii tyhjän välimuistin.
- `jt_net_transport.c`:n TLS-istuntovälimuisti (kommentti: *"Navigator's persistent worker keeps…"*)
  on samoin kertakäyttöinen. Jokainen kuva tekee siis täyden ECDHE-kättelyn, ja vanhalla CPU:lla se
  vie satoja millisekunteja.
- Jokainen pyyntö tekee DNS-kyselyn uudelleen.
- `Connection: close` on kovakoodattu (rivit 626 ja 628), joten keep-alivea ei ole.
- Jokainen fork kopioi (COW) jopa 128 MiB:n prosessi-ikkunan sivutaulut, ja lapsi varaa 8 MiB:n
  `NAV_BODY_MAX`-puskurin sekä pakatuille ja chunked-vastauksille toisen samankokoisen.

**Ehdotus:** pysyvä worker-pooli, esimerkiksi 2–3 workeria, jotka elävät koko selainistunnon ajan.
`nav_async_release()` palauttaa workerin pooliin eikä tapa sitä. Vain `cancel` ja aikakatkaisu
käynnistävät workerin uudelleen. Lisäksi:

- HTTP/1.1 keep-alive saman originin pyynnöille workerin sisällä: yhteyspooli, jossa on enintään 2
  yhteyttä per host ja 15 s:n joutoaika.
- Kun välimuisti on per-worker, saman URL:n pyynnöt kannattaa reitittää samalle workerille
  (hash(origin) % N). Vaihtoehtoisesti välimuisti siirretään vanhempaan, ja vanhempi vastaa
  välimuistiosumista ennen forkkia tai pyyntöä.
- Tämä on edellytys kohtien 3 ja 11 täydelle hyödylle.

### 2.2 HSTS ei säily, ja HTTPS-fallback on alttiina alennushyökkäykselle (tietoturva)

- `hsts_note()` (`nav_network.c` rivi 667) päivittää taulukkoa **lapsiprosessissa**.
  `NavCookieDelta`-IPC välittää vain evästeet. Vanhemman HSTS-taulukko on siksi aina tyhjä, ja jokainen
  uusi worker aloittaa ilman HSTS-tietoa. `hsts_upgrade()` (rivi 620) ei koskaan löydä aiempaa merkintää.
- `https_fallback_allowed()` (`navigator.c` rivit 106–110) hyväksyy HTTP-fallbackin, kun virheteksti
  sisältää sanan "handshake", "TCP connection failed" tai "Network timeout". Verkossa oleva hyökkääjä voi
  aiheuttaa nämä virheet helposti (RST tai pudotetut paketit), jolloin selain lataa sivun plaintextinä.
  Käyttäjälle näytetään vain tilarivin viesti.

**Ehdotus:**
1. Laajenna IPC-delta: `NavHstsDelta {host, max_age, include_subdomains}` samaan validoituun kehykseen
   kuin evästeet. Tallenna HSTS lisäksi tiedostoon `/cfg/navigator-hsts` atomisesti.
2. Estä fallback kokonaan, jos host (tai sen yläverkkotunnus `includeSubDomains`-ehdolla) on HSTS-listalla.
3. Älä tee fallbackia automaattisesti. Näytä HTTPS-First-tyylinen välisivu, jossa on painike
   "Jatka suojaamattomana", kuten nykyselaimet tekevät.
4. Valinnainen: pieni sisäänrakennettu HSTS preload -lista (esim. 200 yleisintä verkkotunnusta).

### 2.3 DNS: yksi paikka, ei välimuistia, EBUSY ilman uutta yritystä

`jnet_host_request()` (`kernel32/drivers/tcpip/jnet.c` rivi 1030) palauttaa `JNET_EBUSY`, jos toinen
kysely on käynnissä. `gethostbyname()` ja `jt_net_transport.c` muuttavat sen virheeksi
"DNS resolver busy (rc=-16)". Navigator ajaa samanaikaisesti sivua, CSS:ää, kuvaa ja JS:n `fetch`iä
omissa workereissaan, joten ehto toteutuu säännöllisesti. Kuva epäonnistuu, ja kuvalle tehdään vain
yksi uusi yritys 1,5 s:n kuluttua.

**Ehdotus:**
- Ytimeen pieni DNS-välimuisti, esim. 32 merkintää, TTL vastauksesta (min 30 s, max 1 h), sekä
  negatiivinen välimuisti 10 s:ksi. Tämä hyödyttää kaikkia sovelluksia.
- Jono tai odotus EBUSY-tilanteessa: `jnet_host_request` odottaa (aikakatkaisun puitteissa), kunnes
  aiempi kysely valmistuu, eikä palauta heti virhettä. Vähintään `gethostbyname()` voi yrittää uudelleen
  `-16`-virheellä, esim. 5 × 50 ms.

### 2.4 `Sleep()` on aktiivinen odotus

`libc/libc/process/process.c` rivi 474:

```c
for(; GetTickCount()<(i4+cMilliseconds); ) SwitchToThread();
```

Navigatorin pääsilmukka (`navigator.c` rivi 1686) kutsuu `SwitchToThread();Sleep(10);`. Jos muita
ajettavia säikeitä ei ole, prosessori pyörii jatkuvasti. Ytimessä on jo oikea nukkumismekanismi
(`UsecSleep` → `SchedulerSleepCurrentUsec`, syscall `SYS_usleep`).

**Ehdotus:**
- libc:n `Sleep(ms)` toteutetaan `usleep(ms*1000)`-kutsulla. Muutos hyödyttää kaikkia sovelluksia;
  testaa GraOS-sovellusten responsiivisuus.
- Navigatorissa odotusaika valitaan dynaamisesti: jos jokin `nav_async_poll` kulutti koko budjettinsa,
  käytetään 0 ms (vain `SwitchToThread`). Jos ajastimia tai töitä on odottamassa, odotetaan noin 10 ms.
  Muuten, kun selain on joutilaana, odotetaan 30–50 ms tai käytetään GraOS-tapahtuman blokkaavaa odotusta
  aikakatkaisulla, jos sellainen API lisätään.

### 2.5 IPC:n läpäisykatto

`NAV_IPC_POLL_BUDGET = 16 KiB` (`nav_async.c` rivi 26). Budjetti luetaan kerran pääsilmukan kierrosta
kohti, ja kierroksen päätteeksi on vähintään `Sleep(10)`. Teoreettinen maksimi on siis
100 × 16 KiB ≈ **1,6 Mt/s per työ**. Kun JTMOS:n putki on 4 KiB, lapsi blokkaa kirjoitukseen, kunnes
käyttöliittymä lukee.

**Ehdotus:** (a) kohdan 2.4 dynaaminen odotus; (b) budjetti aikaperusteiseksi, esim. "lue kunnes
4 ms kulunut" eikä tavumäärään sidottuna; (c) pidemmällä aikavälillä jaettu muistialue
(mmap/shm) runko-osalle, jolloin putkea käytetään vain ilmoituksiin.

### 2.6 Layoutin hiljainen katkaisu ja 1 024 linkin raja

Mittaus (`navbench`, 810 px leveys):

| Sivu | HTML | CSS-sääntöjä | Piirto-objekteja | Linkkejä | Layoutin korkeus |
|---|---:|---:|---:|---:|---:|
| 300 korttia | 90 KiB | 503 | 48 874 | 300 | 39 543 px |
| 1 500 korttia | 530 KiB | 4 003 | **100 000 (katto)** | **1 024 (katto)** | 80 714 px |
| 3 000 korttia | 1,4 MiB | 15 003 | **100 000 (katto)** | **1 024 (katto)** | 80 714 px |

Korttikorkeudesta (noin 132 px) laskettuna 1 500 kortin sivusta näkyy noin 610 korttia, eli **noin 40 %**.
`r->out->truncated` asetetaan (`nav_layout.c` rivi 45), mutta käyttöliittymä ei koskaan lue sitä.
Ilmoitus näytetään vain CSS-katkaisusta (`navigator.c` rivi 688).

Syy on rakenteessa: **jokainen merkki on oma 56 tavun `NavPaintItem`** (`nav_layout.h` rivit 15–30).

**Ehdotus:**
1. Heti: näytä tilarivillä "Page truncated at N items" ja lisää F12-diagnostiikkaan laskuri.
2. Tekstiajot: uusi `NAV_PAINT_TEXT_RUN`-tyyppi (alku-offset + pituus jaetussa glyph-puskurissa,
   yhteinen fontti, väri, baseline ja linkki). Tämä pienentää objektimäärää tyypillisesti 10–30-kertaisesti
   ja muistia vastaavasti. Valinta, Find ja kopiointi voivat käyttää glyph-puskuria suoraan.
3. Linkit: korvaa `link_id()`-funktion lineaarinen `strcmp`-haku (`nav_layout.c` rivi 36, O(L²)) hajautuksella
   ja kasvata linkkitaulukkoa dynaamisesti (nykyisin kiinteä `NAV_LINKS × 512` tavua = 512 KiB).

### 2.7 Reflow ilman tyylivälimuistia

`nav_layout_build()` laskee jokaisen solmun tyylin `nav_style_compute()`-kutsulla alusta: `calloc(PCOUNT)`
ja sääntökandidaattien läpikäynti. Tämä tehdään jokaisessa reflow'ssa: lomakekentän näppäilyssä
(`form_changed()`, `navigator.c` rivi 1102), JS:n DOM-muutoksessa, mitoittamattoman kuvan saapuessa
(400 ms:n erissä), ikkunan koon muuttuessa, zoomissa ja Reader-tilassa.

Mittaus: **reflow kestää yhtä kauan kuin ensimmäinen rakennus** (53 ms / 57 ms ja 139 ms / 146 ms
isännällä). Toistuvista reflow'ista ei siis säästy mitään.

**Ehdotus:**
1. **Laskettujen tyylien välimuisti** per DOM-solmu (`NavStyle` + sukupolvinumero). Mitätöinti
   CSS-muutoksessa (kaikki), DOM- tai attribuuttimuutoksessa (alipuu) ja viewportin leveyden muuttuessa
   (vain jos media query -tulos muuttuu).
2. Lomakekentät: jos kentän sisäinen koko ei muutu (tavallinen tekstikenttä), piirrä uudelleen vain
   kentän suorakulmio. Tällöin reflow'ta ei tarvita lainkaan.
3. JS: kasaa DOM-muutokset ja tee reflow enintään 1–2 kertaa sekunnissa tai seuraavan kuvan kohdalla.

### 2.8 Turhat täydet uudelleenpiirrot

`paint()` (`navigator.c` rivi 853) piirtää valikot, työkalurivin, koko sivun ja tilarivin, rakentaa
a11y-rakenteen, lähettää `setWindowCaption`-IPC:n ja kopioi koko framebufferin (`refreshWindow`,
840 × 594 × 4 ≈ 2 MiB). Toisaalta `dirty=1` asetetaan pelkästä tilarivin tekstimuutoksesta, esim.
`image_schedule()`: "Loading image N" ja `image_poll()`: `if(!repaint_damage.count)dirty=1;`.

**Ehdotus:** erota likaisuus kolmeen tasoon: `chrome_dirty` (työkalurivi ja osoite), `status_dirty`
(vain alarivi, jolle on jo `refreshWindowRect`) ja `page_dirty`. Lähetä `setWindowCaption` vain, kun
otsikko muuttuu. Rakenna a11y-rakenne vain layoutin muuttuessa.

### 2.9 Vierityksen piirto O(koko sivu)

`nav_render_visit()` (`nav_render.c`) käy jokaisella kutsulla läpi kaikki piirto-objektit.
Mittaus: 48 px:n kaistale vierityksessä vei 136–287 µs isännällä ja kävi läpi 48 874–100 000 objektia,
joista vain 64–78 oli näkyvissä.

**Ehdotus:** layoutin rakennuksen yhteydessä kaistaindeksi (esim. 256 px:n kaistat → objekti-indeksien
lista) tai y-lajiteltu indeksi ja binäärihaku. Lisäksi `z`-järjestyksen lajittelu (`nav_layout_build`,
O(n·k) erillisten z-arvojen määrällä) vaihdetaan vakaaseen merge-sorttiin.

### 2.10 Alirajattu rinnakkaisuus

Workereita saa olla 4 (`NAV_MAX_WORKERS`), mutta `image_schedule()` aloittaa vain yhden kuvan kerrallaan
eikä aloita ollenkaan, kun `active_job` on käynnissä. `next_stylesheet()` lataa tyylit peräkkäin.

**Ehdotus:** pysyvän poolin jälkeen 2 samanaikaista kuvaa ja kaikki tyylit rinnakkain (enintään 2).
Ensimmäinen tyylitelty layout tehdään, kun kaikki head-osan CSS:t ovat saapuneet tai 1,5 s on kulunut.
Tämä vähentää myös nykyistä tyylittömän sivun välähdystä.

### 2.11 Kuvat: JPEG-raja ja vanhentunut muistibudjetti

- `jpegdec.c`: `JD_MAX_W/H 1600`, `JD_MAX_PIXELS 1600×1200`. Esim. 1920×1080- tai 2048×1152-hero-kuvat
  hylätään. `srcset` auttaa vain, jos sivu tarjoaa pienemmän vaihtoehdon.
- `NAV_IMAGE_MEMORY 6 MiB` ja kommentti "16 MiB process window" ovat ajalta ennen v71.128:n 100 MiB:n
  ikkunaa.

**Ehdotus:** JPEG-dekoodaus DCT-alueessa skaalaten (1/2, 1/4, 1/8: vain DC tai matalat taajuudet),
jolloin 8000 px leveäkin kuva puretaan suoraan näyttökokoon pienellä muistilla. Kuvabudjetti määräytyy
`nav_memory_plan()`-funktiosta (esim. 15 % budjetista, min 6 MiB).

### 2.12 JavaScript-yhteensopivuus

- `js_event_listener()` (`nav_js.c` rivi 255) rekisteröi vain `click`-tapahtuman. `document.addEventListener`
  hyväksyy vain `DOMContentLoaded`in. Delegointi `document.addEventListener('click', …)`,
  `input`/`change`/`submit`/`keydown`, `removeEventListener` ja `window`-kohde puuttuvat. Kuuntelijoita
  ei koskaan vapauteta (128:n katto täyttyy SPA-sivuilla).
- `fetch()` sallii vain yhden pyynnön kerrallaan (`!s->fetch_job`). Toinen samanaikainen kutsu ei käynnisty.
- Ajastimia on 32, ja jokaisella pollilla ajetaan vain yksi erääntynyt ajastin.

**Ehdotus:** yleinen EventTarget: tyyppi, capture/bubble, `once`, `removeEventListener`, `document` ja
`window` kohteina sekä kuuntelijoiden vapautus dokumentin vaihtuessa. `fetch`-jono (esim. 4) ja
erääntyneiden ajastimien ajo samalla kierroksella aikabudjetin puitteissa.

### 2.13 JS:n eristys (pidemmän aikavälin tietoturva)

`nav_js.c` toteaa itse: *"NOT a security sandbox"*. QuickJS ajetaan käyttöliittymäprosessissa, jossa ovat
evästeet (myös HttpOnly), DOM ja lomakedata. JS on oletuksena pois päältä (F9), mikä on oikea valinta.
Ennen kuin JS:stä tehdään oletus, se kannattaa siirtää omaan prosessiinsa. DOM-mutaatiot välitetään
validoituina IPC-viesteinä samaan tapaan kuin evästedeltat nyt. Tämä on myös ROADMAP_v0.3:n kohta 3.

---

## 3. Muita havaintoja (pienempiä)

- **Historia:** paluu ja eteenpäin hakevat sivun aina verkosta, eivätkä ne palauta vierityskohtaa.
  POST-tuloksen historiamerkintä haetaan GETillä. Tallenna `scroll_pixel` historiaan ja pidä viimeiset
  2–3 vastausta muistissa (back/forward-välimuisti).
- **Lataukset** ovat synkronisia ja jäädyttävät käyttöliittymän (tunnettu v72.77:ssä). Kun pysyvä
  worker-pooli on käytössä, latauksen voi ajaa workerissa ja raportoida edistymisen IPC:llä.
- **Koko sivu jäsennetään ja asetellaan käyttöliittymäsäikeessä** vasta, kun koko vastaus on saapunut.
  8 Mt:n sivulla käyttöliittymä on lyhyen aikaa jäässä. Inkrementaalinen jäsennys (Lexbor tukee
  chunk-syötettä) ja ensimmäisen ruudullisen layout ennen loppua parantaisivat koettua nopeutta paljon.
- **Hiiren keskinappi (nappi 3):** GraOS välittää sen nyt (v72.78-muutos). Navigatorissa sille sopisi
  esim. "avaa linkki uuteen Navigator-ikkunaan" tai automaattivieritys.
- **v72.77:n oikean napin kontekstivalikko ei toiminut natiivisti fyysisellä hiirellä**, koska
  `mouse_union=1` muutti oikean napin napiksi 1. Korjattu tässä versiossa (ks. RELEASE-V72.78-KEHITYS.md).
- `NAV_IMAGE_MEMORY`-, `NAV_LINES`- ja `NAV_LINKS`-kommenteissa viitataan 16 MiB:n ikkunaan, mikä on vanhentunut tieto.

---

## 4. Toistettava mittaus

`navbench.c` ei ole osa julkaisua. Se on tehty analyysia varten seuraavilla tiedostoilla, samoilla
lähteillä kuin `tests/build-v7195-host.sh`:

```
cc -std=gnu17 -O2 -w -idirafter libc/libc/include -Ilibc/apps navbench.c \
  libc/apps/navigator_html.c libc/apps/navigator_url.c libc/apps/navigator/nav_{dom,html5,lexbor,css,css_lexbor,stylesheets,style,text,layout,image,svg,select,form,paint,wordpress,inflate,render}.c \
  libc/libc/media/{jt_image,jt_inflate,jpegdec}.c libc/libc/font/{jt_font,jt_ttf,jt_fonts_builtin}.c -lm
./navbench <kortteja> <css-sääntöjä>
```

Sivu: `<div class='card cN'><a><h3>…</h3></a><p>…</p></div>` × N sekä N kappaletta muotoa
`.cN .tM{…}` olevia CSS-sääntöjä.
