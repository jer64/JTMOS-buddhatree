# Navigator v72.68 – phase 1 (partial implementation)

Source: v72.67 full release. Change: `libc/apps/navigator/nav_js.c`.

- Delay the 6 MiB JavaScript network/script scratch buffer allocation until the first use.
- Handle allocation failure without passing a null buffer into asynchronous polling or inline script copying.
- Update `nav_js_memory_bytes()` to count the scratch buffer only when allocated.

This is a focused first increment, NOT completion of the entire five-part phase-1 memory/stability specification. Remaining: unified budget across processes, fault isolation, DOM cap handling, and target-device soak tests.

No native JTMOS boot or physical hardware verification has been performed.
