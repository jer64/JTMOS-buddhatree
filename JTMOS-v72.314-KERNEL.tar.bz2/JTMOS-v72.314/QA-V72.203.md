# QA — JTMOS v72.203

## Memory core

- 40,000 deterministic allocation/free/realloc operations, content preservation,
  16-byte alignment, split/coalesce, OOM, size overflow, invalid/interior/double
  frees, corrupted-list/header rejection and arena checkpoints: PASS, ASan/UBSan.
- Freestanding i686 C99 example object: PASS; nm -u has no output.
- Standalone C example: compiled and executed successfully.
- DOM document with 400 DIVs and text nodes allocated from a caller-owned
  NavMemory region: PASS; document destruction leaves zero live bytes and
  zero allocations. Both parser/layout test builds include this test.

## Layout and painting

- New box/painter integration under ASan/UBSan with BOTH Lexbor and fallback:
  PASS. Content-/border-box and min/max dimensions, padding/margin coordinates,
  percentage child widths and CSS-triggered reflow, all four clip edges,
  image/gradient sampling preservation, partial glyphs, TrueType/EGA alpha,
  padded-stride buffer guards, hit testing and damage invalidation.
- Existing regressions with BOTH parsers: DIV/table 43/43, tables 18/18,
  DIV sizing/overflow 45/45 PASS. One old assertion now checks an empty
  clip rectangle rather than destructive mutation of the child's width.
- Previous UTF-8 browser integration with BOTH parsers: PASS; 6 chunk
  boundaries, legacy text/HTML, 10 glyphs and 573 modified pixels.

## Networking

- 72 deterministic shipping-code fixtures: PASS under ASan/UBSan. Split
  reads, partial writes, length/chunked/close framing, truncation/limits,
  duplicate/invalid headers, redirects, TLS routing/no downgrade, callback
  cancellation, UTF-8 EOF behavior and 2 MiB data in <=4096-byte spans.
- 4 real localhost streaming cases: PASS. Server waits for the first consumer
  callback before sending the rest, proving delivery before whole-body completion.
  Tested both byte and scalar callbacks with Content-Length and chunked.
- Existing real HTTP regression: 17/17 PASS (gzip/deflate, redirects, cookies,
  images/cache, corruption and body limits). Legacy async-cookie gate was
  explicitly skipped by the existing NAV_HOST_HTTP_ONLY test switch.
- Existing HTTP cache end-to-end regression: 8 scenarios/14 requests PASS.
- Host TCP tests do not verify TLS certificates or native hardware networking.
  Fixture tests check TLS routing/failure and downgrade refusal; native
  Navigator retains and links the existing BearSSL backend.

## Native build and scope

- Canonical native Navigator build with default backends and -Werror: PASS.
- ELF32 i386, entry 0x80004000, preferred window 524288 KiB: PASS.
- Actual kernel launch validators/layout/clamp/truncation preflight: PASS
  in the host harness. This is not an OS boot test.
- Public version, full ZIP CRC/root/manifest and original 21 symlinks are
  checked by the release packaging tools.
- No QEMU, VESA/GOP hardware or ThinkPad/eMachines execution.
- Kernel32, GraOS, DOSBOOT and installation media are inherited binaries.
  utilities.iso does not contain the rebuilt browser; ZIP is UNBUILT.
- LeakSanitizer is disabled because this runtime cannot enumerate /proc
  tasks. ASan/UBSan remain enabled; allocator live-count checks also run.
- Full isolated CSS group-opacity compositing, complete modern CSS,
  custom TLS 1.3, a replacement JS VM and total removal of Navigator's
  old dependencies are outside this stage.

## Reproduce

```sh
sh tests/run-v72203-memory.sh /tmp/nav-memory
sh tests/run-v72203-http-stream.sh /tmp/nav-stream
python3 tests/v72203_http_live.py /tmp/nav-live
sh tests/run-v72203-layout-paint.sh /tmp/nav-layout
python3 tools/build_navigator_lexbor_host.py /tmp/nav-lexbor
LEXBOR_HOST_ARCHIVE=/tmp/nav-lexbor/liblexbor_static.a \
  sh tests/run-v72203-layout-paint.sh /tmp/nav-layout-lexbor
NAV_HOST_HTTP_ONLY=1 python3 tests/v7181_network_host.py
python3 libc/apps/navigator/tests/test_http_cache_v72196.py
make -C libc/apps -f navigator.mak -j2 navigator.bin
python3 tests/v7196_navigator_launch.py libc/apps/navigator.bin
```

`make -C libc/apps -f navigator.mak navigator-core-ci` runs the new core
checks (optional LEXBOR_HOST_ARCHIVE for the shipping parser).
Logs from this run are included in release/qa/v72.203/.
