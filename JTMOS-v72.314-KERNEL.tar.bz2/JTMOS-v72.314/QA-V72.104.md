# QA – JTMOS V72.104

| Verification | Result |
|---|---|
| Modern libc `graos_compat.c` ELF32 build | PASS |
| GraOS `graos.bin` ELF32 link | PASS |
| `graosctl.bin` ELF32 link | PASS |
| Kernel `core/int/scs.c` and `sh/sh.c` ELF32 compilation | PASS |
| 20-field mouse diagnostics ABI/header/wire consistency test | PASS |
| Kernel GUI phase tracing/pid generation protection source test | PASS |
| V72.103 safe cursor framebuffer runtime test (5000 moves) | PASS |
| V72.94 busy-owner watchdog stress (100,000 operations) | PASS |
| T400 PS/2 recovery source regression | PASS |
| `boot32pm check-source` VERSION=72.104 | PASS |
| GraOS/install SQA package creation | PASS |
| Updated GraOS/GUI control binaries included in SQA | PASS |
| Full kernel link | NOT RUN; NASM and most objects unavailable |
| T400 hardware GUI freeze test | NOT RUN; no hardware access |

Note: Programmatic source and simulation tests cannot certify that a graphics freeze is fixed. V72.104 diagnoses the freeze; it does not change the kcursor compositing strategy. Old kernel binaries in the source archive do NOT contain the new kernel diagnostics.
