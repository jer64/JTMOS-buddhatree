# QA — JTMOS v72.171

- Navigator CSS: 16,934 rules in 2,669,479 CSS bytes, no truncation: PASS.
- Lexbor HTML5 parses CNN saved 7,049,850-byte document: PASS.
- Full 1024px layout: 10,342 DOM nodes, 7,656 paint items, partial=0: PASS.
- ASan + UBSan host test for the above: PASS.
- Synthetic long variable name, 180 tokens, media queries and aspect ratio: PASS.
- v72.168 align/position + prior DIV/CSS and lifecycle regressions: PASS.
- Native ELF32 Navigator build and SQA archive round-trip: PASS.
- Real hardware/Graphical GraOS render and live CNN network: NOT TESTED.
- CNN JavaScript and dynamic media interactions: NOT CERTIFIED.
