# v71.87 QA record

Environment: Ubuntu host, GCC, GNU binutils. Target: i486 ELF32 statically
linked JTMOS application. Reproduce with:

```sh
cd libc/apps
make -f navigator.mak clean
make -f navigator.mak navigator.bin
make -f iview.mak iview.bin
readelf -h navigator.bin
cd ../..
./tools/test_navigator_v7187.sh
./tests/run-v7184-tests.sh
```

Target-link PASS does not imply successful boot, safe TLS, or correct WordPress
rendering. Compilation uses `-Werror` and selected exclusions for legacy code.

| Acceptance criterion | Status and evidence |
|---|---|
| shared libc codec/transport/font archives | PASS: libs linked into navigator ELF32 |
| iView links moved shared JPEG | PASS: `iview.bin` cross-link |
| C17 mode for Navigator | PASS: `-std=gnu17` active |
| no compile warnings for this target's configured build | PASS with existing legacy warning suppressions |
| lifecycle/memory regression | PASS host; hardware memory not measured |
| Native HTTPS X.509 verification | NOT IMPLEMENTED |
| Native TrueType rasterization | NOT IMPLEMENTED (EGA fallback) |
| Native WebP decoding | NOT IMPLEMENTED; host libwebp test only |
| Native QuickJS JavaScript execution | NOT IMPLEMENTED |
| Real physical JTMOS/GraOS testing | NOT PERFORMED |
| Live WordPress pages over HTTPS | BLOCKED by HTTPS gap |
| third-party codec/renderer security audit | NOT PERFORMED |

Static libraries facilitate sharing across apps but are not independent
runtime-loaded plugins. Public headers describe ownership and constraints.

## Executed checks on 2026-10-17

- `make -f navigator.mak navigator.bin`: PASS, ELF32 i386, entry 0x80004000.
- `make -f iview.mak iview.bin`: PASS, JPEG object shared.
- `tools/test_navigator_v7187.sh`: PASS host regressions and shared API tests.
- `tests/run-v7184-tests.sh`: PASS media fuzz/pixel comparisons/localhost HTTP.
- New shared API checks: 7 PASS (font clipping, malformed image, inflate, TLS block, compiled capabilities).
- JPEG host fidelity tests allow baseline JPEG approximation; native WebP absent.
- `sqarc --compare-member`: PASS `navigator.bin` matches package.
- `readelf`: ELF32 Intel 80386 / entry 0x80004000.
- Link audit: `jt_image_decode`, `jt_font_draw_glyph`, `jt_net_connect` symbols present.
- No `warning:` or `error:` in recorded Navigator compiler output with configured
  warning suppressions. One image-test Python Pillow deprecation warning is
  non-compiler and harmless for this release.
- No real hardware, HTTPS, TrueType, QuickJS or native WebP validation.
