# Navigator: ten workstreams, v72.185 audit and staged roadmap

| Workstream | Available in v72.184 baseline | Added in v72.185 | Next needed |
|---|---|---|---|
| 1 Render performance | Indexed paint query, lazy image loads, budgeted CSS/DOM | Preserve and regression-check | Paint invalidation profiles / parallel decode |
| 2 Security and privacy | BearSSL TLS, HTTPS-first, HSTS, data-only add-on pins | Third-party tracker shield + basic mixed-content policy | Initiator-bound redirect checks, CSP, threat intelligence |
| 3 HTML5/CSS/JS | Lexbor HTML5, CSS selector/layout subset, QuickJS subset | No new web syntax | Cross-browser conformance harness; CSS Grid/Flex edge cases |
| 4 Add-ons | Bounded declarative NAVP1, reviewed SHA256 manifest | Existing controls preserved | Capability-based permission UI, isolated process model |
| 5 Device sync | Local single bookmark and navigation history only | Not implemented | Encrypted vault, pairing, account/key management, conflicts |
| 6 UI themes | GraOS toolbar, mobile/reader, zoom and high contrast | View-menu shield control and local counters | Theme palette, persistent settings |
| 7 DevTools | F12 diagnostics and opt-in console log, no telemetry | Privacy statistics and focused form DOM metadata | DOM inspector, request timeline, source map |
| 8 Accessibility | Tab/focus, zoom, contrast, form controls | Preserved | Semantics tree, screen reader protocol, ARIA |
| 9 Memory/tabs | Memory reservation and pressure eviction | No tabs implementation | Process-isolated tabs, freeze/resume state snapshot |
| 10 Media/downloads | Bounded image decode and async safe .part download | Preserved | Verified resume with Range/ETag, media formats and AV sync |

Security architecture note: a full browser must mediate URL redirects,
credentials, CORS, mixed content and CSP in a central Fetch layer. Navigator's
current network worker has only a URL-focused interface. Adding browser-wide
permissions before centralizing request origins would create false confidence.

Primary external references (2026-10-28):
- WHATWG Fetch Living Standard: https://fetch.spec.whatwg.org/
- W3C Mixed Content: https://www.w3.org/TR/mixed-content/
- MDN HSTS: https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Strict-Transport-Security
