# JTMOS v72.277 — Ring3 shared-VM view and protected lifecycle

Base: complete v72.276 source release (both parts).

- Generation-checked VM owner resolution wired into actual paging/PTE/VMA
  lookup and selected memory operations, not just the standalone group model.
- Group root teardown deferred until the last member is reaped; members do
  not release the root's user mappings or primary sparse backing.
- Group closing prevents new attachments; shared-VM fork is fail-closed.
- `threadctl` read-only VM owner/refcount introspection; Ring3 start-frame
  validator integrated with the existing preflight syscall.
- `pthreadprobe.bin` rebuilt with v72.277 ABI; new host-model tests.
- **FEATURES=0 / CREATE=ENOSYS**: not a working pthread or Ring3 clone.
- Bundled kernel boot image is inherited; full kernel build/runtime was NOT
  performed without NASM. See JTMOS-v72.277-PTHREAD-VM-INTEGRATION.md.
