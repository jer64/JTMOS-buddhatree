# JTMOS v72.184 – source cleanup quality assurance

## Scope

- Source base: JTMOS v72.183, binaries inherited unchanged.
- Cleanup is conservative: deletes only regenerable staging and build objects, historical versioned package copies. Required installer, DOS and boot images are kept as distinct paths.
- Restores 21 **real Unix symlinks**, not text files and not dereferenced copies.

## Verification requirements

- `sh tools/check_duplicate_layout.sh` must PASS with all 21 directory aliases.
- `python3 tools/clean_full_source_release.py --check` must report zero candidates.
- `python3 tools/test_release_cleanup.py` must PASS.
- `python3 tools/gen_pkg_installers.py --check` must PASS for v72.184 scripts.
- `python3 tools/check_release_media.py` must PASS, with inherited media hashes.
- ZIP test must return no CRC errors; `tools/check_full_release_manifest.py` checks full manifest, 21 symlink targets and unchanged media hashes.

## Explicitly not validated

- Kernel or GraOS fully rebuilt; real-hardware boot; network, audio or video performance.
- Historical versioned packages removed from this ZIP remain available in earlier full release archives.

## Mitatut tulokset

- Lähdepuun duplikaattiryhmiä siivouksen jälkeen 716, määrä oli ennen siivousta 750. Lisää poistokohteita ei hyväksytty pelkän sisällön samankaltaisuuden perusteella.
- 21/21 vaadittua symbolista linkkiä palautettu ja todennettu sekä lähdepuussa että ZIP-muodossa.
- `check_full_release_manifest.py`: PASS, 10 829 SHA256-manifestin tavallista tiedostoa sekä 21 linkkiä.
- `check_release_media.py`: PASS; peritty kernel, Navigator, GraOS ja ISO täsmäävät.
- Paketin ZIP-pakkaus on validoitu; käyttäjälaitteistolla toimintaa ei ole testattu.
