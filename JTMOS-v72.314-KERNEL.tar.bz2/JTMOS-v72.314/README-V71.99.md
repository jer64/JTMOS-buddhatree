# JTMOS v71.99 — Navigator packaging fix

`make packages` in v71.98 stopped with:

    build_install_image: unclassified built application: navipctest.bin

`navipctest` existed as a makefile/source/binary but was absent from the
canonical release inventory, so the strict packaging gate correctly rejected
it. v71.99 registers `navipctest` in `UTILITIES_ONLY_APPS` and moves it into
`tests.sqa` during packaging. It must not be installed into the smaller
`sys:/B:` rescue disk. Navigator itself remains in `network.sqa`.

Test with:

    python3 tests/v7199_navigator_package.py
    make packages

The first command ran successfully in the authoring environment. Full
`make packages` requires your development toolchain (including NASM and ISO
creation dependencies) and has not been run end-to-end here.

The supplied ELF32 `navigator.bin` and `navipctest.bin` are rebuilt for
v71.99. HTTPS is not yet enabled. Please send the `[NAVDBG]` serial log
from your eMachines test after extracting `tests.sqa` and `network.sqa`.
