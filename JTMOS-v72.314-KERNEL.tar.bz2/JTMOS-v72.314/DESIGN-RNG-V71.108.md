# JTMOS V71.108 – /dev/random ja /dev/urandom

## Tavoite ja Linux-vertailu

V71.107 palautti jokaisella lukukerralla suoraan laitteiston RNG:n dataa.
Vanhoilla prosessoreilla molemmat satunnaislaitteet jäivät ilman lähdettä,
vaikka Navigator pystyi käyttämään omaa levypooliaan. Uusi toteutus alustaa
yhden kernelin CSPRNG:n, jota kaikki prosessit ja rajapinnat käyttävät.

Vertailussa luettiin Linux v6.12:n `drivers/char/random.c`, erityisesti
`crng_fast_key_erasure`, `crng_make_state`, `extract_entropy`, `getrandom`,
`random_poll` ja `write_pool_user`. Lähde:
https://github.com/torvalds/linux/blob/v6.12/drivers/char/random.c

Luetun tiedoston SHA-256:
`395bb854da12bb40d491dbc129063218b3f45f65bacaa8e21b17a4584bea4d3c`.
Linuxin C-koodia ei kopioitu. Skalaariset ChaCha20- ja BLAKE2s-primitiivit
toteutettiin RFC 8439:n ja RFC 7693:n määrittelyistä ja testattiin erillisiä
toteutuksia vasten. Rakenteen taustaa:
https://www.zx2c4.com/projects/linux-rng-5.17-5.18/

## Rakenne

- `rng_core.c/.h`: OS-riippumattomat 32-bittiset primitiivit, 32 tavun
  sekoitustila, 32 tavun generaattoriavain ja valmius/metatiedot.
- `secure_random.c`: yhteinen kerneltila, lähteiden valinta, IRQ-suojaus,
  alustuksen odotus ja tilannekuva.
- `rng_seed.c`: olemassa olevan yksityisen levypoolin pysyvä kulutus.
- `linuxabi.c`: molemmat laitteet, käyttötilat, osittaiset luvut ja poll.
- `scs.c` ja libc: sama `SYS_getrandom=175`; uusi syscall-numero ei ole tarpeen.

Sekoittaminen käyttää avaimellista BLAKE2s-256:ta. Pooliin lisätään enintään
64 tavua kerrallaan domainilla `MIX1`. Jo alustetun generaattorin avain
sekoitetaan samalla uudelleen domainilla `WRT1`; valmius tai luotettujen
siemennysten laskuri ei muutu. Luotettu 64 tavun siemen sekoitetaan pooliin,
uusi avain johdetaan poolista ja vanhasta avaimesta domainilla `RNG1`, ja
poolin tila vaihdetaan erillisellä `POL1`-johdannalla.

Jokaisessa enintään 256 tavun generoinnissa ChaCha20:n nollannen lohkon
ensimmäinen puolikas korvaa pysyvän avaimen ennen tulosteen luovuttamista.
Toinen puolikas aloittaa tulosteen; mahdollinen loppu tulee saman paikallisen
vanhan avaimen lohkoista 1–4. Paikalliset avaimet, työtilat ja lohkot
nollataan eksplisiittisillä volatile-kirjoituksilla. Avaimen vaihtaminen joka
pyynnöllä estää nykyisen generaattoriavaimen suoran käytön aiempaan virtaan.
Fork ei kopioi generaattoria käyttäjätilaan.

Nykyinen kernel ajaa yhdellä CPU:lla. Yhteinen tila suojataan lyhyesti
`irq_save/irq_restore`-parilla; enintään viisi ChaCha-lohkoa käsitellään
kerralla. Levykäsittely, laitteiston lähteen haku ja odotus tapahtuvat
keskeytysten ollessa käytössä. SMP-tuki vaatisi oikean lukon ennen useamman
CPU:n käyttöönottoa.

## Alustus ja uudelleensiementäminen

Ensimmäinen luku yrittää CPUID-portitettua RDSEED/RDRAND-lähdettä. Jos sitä
ei ole, kernel kuluttaa yhden 64 tavun tietueen nykyisestä
`TLS_SEED_DIR/tlsseed.bin`-poolista. Asetus haetaan prosessin ympäristöstä,
sitten globaalista ympäristöstä; oletus on aktiivisen laitteen `/cfg`.
Liian pitkä tai virheellinen asetus hylätään. RAM-laite hylätään.

Poolin sisältö on luotetussa järjestelmässä valmisteltua yksityistä
siemenmateriaalia. JTMOS:n nykyinen tiedosto-/käyttäjäeristys ei suojaa sitä
haitallisilta paikallisilta sovelluksilta. Tämä muutos ei luo uutta
käyttöoikeusrajaa eikä tarjoa sovelluksille mielivaltaista entropy-credit-API:a.

Sama `tlsseed.lck` ja O_EXCL-protokolla sarjoittaa käytön vanhojen TLS-
asiakkaiden ja asennustyökalun kanssa. Tietue nollataan, tiedostojärjestelmä
ja fyysinen laite synkronoidaan, nollaus luetaan takaisin, tiedosto suljetaan
ja lukko poistetaan ennen alustamista. Epävarman nollaus-/sync-/close-tilan
jälkeen lukko säilytetään eikä siementä julkaista. Julkisiin paketteihin ei
sisälly siementä.

Alustettu generaattori jatkaa ilman uutta tietuetta jokaiselle lukukerralle
tai TLS-yhteydelle. Hardware-uudelleensiementämistä yritetään aktiivisten
lukujen yhteydessä minuutin välein. Epäonnistuminen ei poista valmiutta.
Vanhan CPU:n levypoolista kulutetaan yksi tietue per kernelin käynnistys;
ajonaikaista automaattista levypoolin lisäkulutusta ei tehdä. Kylmän alustuksen
epäonnistuneita yrityksiä rajoitetaan yhteen sekunnissa.

## Rajapintojen sopimus

| Rajapinta | Ennen alustusta | Alustuksen jälkeen |
|---|---|---|
| `/dev/random`, `/dev/urandom` | Odottaa; O_NONBLOCK antaa EAGAIN | Sama CSPRNG, ei ehtyvää lukukiintiötä |
| `getrandom(..., 0/GRND_RANDOM)` | Odottaa | Enintään 256 tavun lyhyt luku |
| `getrandom(..., GRND_NONBLOCK)` | EAGAIN | Sama generaattori |
| `getentropy` | EAGAIN, tulospuskuri pyyhitään virheessä | Enintään 256 tavua kokonaan |
| Laitteeseen kirjoitus | Sekoittaa, ei alusta | Sekoittaa, ei kasvata entropy-luottoa |
| `poll(POLLIN)` | Ei valmis | Valmis lukukelpoisella fd:llä |
| `poll(POLLOUT)` | Valmis kirjoituskelpoisella fd:llä | Valmis |

Odotus palauttaa EINTR:n, kun kernelin nykyinen pending-signal-rajapinta
ilmoittaa signaalin. Suurissa laiteluvuissa valmiiksi tuotettu osa voidaan
palauttaa signaalin kohdalla. Käyttötilan vastainen luku/kirjoitus antaa EBADF.
Syscall-välitys säilyttää RNG:n negatiiviset POSIX-virheet odotuksen yli.
Libc osaa uusia yli 64 tavun pyynnön pienempänä v71.107-kernelin kanssa.

Linux v6.12:n urandom voi palauttaa dataa ennen alustusta. JTMOS tekee
tietoisesti tiukemman valinnan: kumpikaan laite ei julkaise alustamatonta
dataa. GRND_INSECURE ei ole tuettu. Ajastimia, PID:tä, kellonaikaa tai
näppäimistötapahtumia ei väitetä mitatuksi entropiaksi.

`/proc/random` ja `rngctl.bin status` näyttävät vain metatietoja.
`entropy_avail` on 0 tai 256: se kuvaa valmiutta/avaimen kokoa, ei tarkasti
mitattua jäljellä olevaa fyysisen entropian määrää. `rngctl.bin init` odottaa
alustusta; `rngctl.bin test` tarkistaa kolme julkista rajapintaa tulostamatta
satunnaisdataa. VM:n tai siemenlevyn vanhan snapshotin palautus ei ole
tuettu tapa säilyttää virran yksikäsitteisyyttä.

Testitulokset ja rajaukset: [QA-V71.108.md](QA-V71.108.md).
