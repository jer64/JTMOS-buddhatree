# Navigator v72.76 – viiden tallennetun verkkosivun lähdekoodiauditointi

**Perusta:** JTMOS v72.75 FULL SOURCE RELEASE. **Kohteet:** käyttäjän 23.10.2026 toimittamat CNN-, Fox News-, Remix.Kwed.Org-, Yle- ja YouTube-sivujen ZIP-tallenteet. ZIP sisältää myös tiedostokohtaisen SHA-256- ja koko-inventaarion `analysis/NAVIGATOR-SAVED-SITES-MANIFEST-v72.76.json.gz` (1 288 tiedostoa ja seitsemän hakemistomerkintää). Sivujen alkuperäiset tiedostot eivät sisälly releaseen, koska niiden sisältö on kolmansien osapuolten materiaalia. Testit voidaan ajaa syöttämällä samat ZIPit testiohjelmalle.

## Viiden sivun mitatut ominaisuudet

| ZIP | Tiedostomerkintöjä | Pää-HTML | Tärkeitä havaintoja |
|---|---:|---:|---|
| CNN | 460 | 6 718 360 tavua | 4 321 HTML/SVG-elementtiä, 233 `srcset`-attribuuttia, 77 skriptiä, 2 293 004 tavun sisäinen CSS; paljon WebP-tiedostoja ja JS-koodeja. |
| Fox News | 252 | 886 337 tavua | 136 skriptiä, 213 `picture`-elementtiä, 718 `data-srcset`- ja 188 `data-src`-attribuuttia. |
| Remix.Kwed.Org | 15 | 108 650 tavua | 375 linkkiä, 286 taulukkosolua, 179 `img`-elementtiä, SVG-kuvia ja MP3-latauslinkkejä. |
| Yle | 520 | 657 192 tavua | 496 AVIF-tiedostoa, 14 `type=module`-skriptiä, 239 `srcset`-attribuuttia. |
| YouTube | 48 | 2 786 349 tavua | 9 791 elementtiä, 193 `template`-elementtiä; 3 430 109 tavun ulkoinen CSS, 9 811 555 tavun `.es`-skripti ja mukautetut web-komponentit. |

## Vian syyt ja toteutettu korjaussuunnitelma

**1. HTML-vastaanotto (tehty):** CNN:n 6,7 Mt:n HTML ylitti `NAV_BODY_MAX`/`NAV_HTTP_MAX_BODY`-rajat (6 MiB). Nostettu **8 MiB:iin**. HTTP-lapsiprosessi ja käyttöliittymän vastauspuskuri käyttävät samaa rajaa. CSS:n ja kuvan erilliset vastaanottopuskurit rajattu **4 MiB:iin kumpikin**, jotta HTTP-muistia ei kasvateta kolminkertaisesti. Raja on edelleen tarkka; sitä suuremmasta vastauksesta näytetään hallittu virhe, ei rajoittamatonta varausta.

**2. HTML5/DOM (tehty):** Dokumentin DOM-areenan yläraja nostettu 12 -> **20 MiB** ja aloitusbudjetin suhde 1/8 -> **1/5** käytettävissä olevasta selainsuunnitelman muistista. Yksittäistä DOM:ia ei kasvateta rajatta. Kaikki viisi toimitettua pääsivua jäsentyivät sekä itse tehdyllä varajäsentimellä että varsinaisella Lexbor 3.0.0 HTML5-jäsentimellä ASan/UBSan-instrumentoidussa Ubuntu-isäntätestissä.

**3. CSS (tehty):** CSS-syötekatto 2 -> **6 MiB**, sääntökatto 8 192 -> **32 768**, CSS-areena 6 -> **36 MiB**. CNN:n 2,29 Mt sisäinen CSS jäsentyi **14 936 sääntöön** (~9,0 Mt), YouTuben 3,43 Mt CSS **21 108 sääntöön** (~27,1 Mt) ilman katkaisua. Tämä ei yksin takaa kaikkien CSS-ominaisuuksien oikeaa visuaalista laskentaa. CSS-muistin F12-profiiliraja päivitetty (38 MiB CSS + layout).

**4. JavaScript ja kuvat (tehty rajatusti):** Dokumentin JS-lähdekoodin enimmäismäärä 256 KiB -> **4 MiB** sekä käsiteltävien `script`-elementtien katto 128 -> **192**. Sisäisten skriptien koko tarkistetaan ennen muistivarausta. JS:n ulkoisten skriptien vastaanottopuskuria ei enää varata 8 MiB:n kokoisena vaan enintään 4 MiB:n lähdekoodirajan mukaisesti; pienet `fetch`-vastaukset käyttävät 128 KiB:n rajaa. Tämä EI tee suurista ES-moduuliriippuvuuksista tai YouTuben soittimesta täysin yhteensopivia. Mediametadatan enimmäispaikkamäärä 256 -> **512**, mutta dekoodattujen pikselien katto säilyy 6 MiB:ssä. AVIF:n dekooderia ei ole vielä lisätty: jos JPEG/WebP-vaihtoehto löytyy, se voidaan valita; muutoin kuva voi puuttua.

**5. Testit ja jakelu (tehty osittain):** `tools/run_navigator_v7276_sites.py` lukee käyttäjän ZIP-tallenteet ilman verkkoa ja suorittaa kummankin HTML-jäsentimen, suuret CSS:t ja kuvavalinnan host-regressiot. Mukaan on lisätty C-testit `v7276_site_dom.c`, `v7276_css_capacity.c`, `v7276_media_sources.c`. Navigator/GraOS 32-bittinen käännös, v72.74-sanitizer-sarja, v72.75 DOM/evästetestit, 12 HTTP-lataustestiä ja 17 verkkotestiä läpäisty. `release/packages/navigator-v72.76.sqa` sisältää uudelleen käännetyn `navigator.bin`-tiedoston ja sen purkutulos vertautuu tavutasolla alkuperäiseen.

## Testaustulokset ja rajoitukset

- Offline-HTML-testit (Lexbor + native) **5/5 + 5/5 PASS**.
- Offline-CSS-testit: suurimmat ulkoiset ja sisäiset CSS-tiedostot **PASS**, mukana erityisesti CNN ja YouTube.
- Media-paikkarajat ja AVIF/JPEG varavalinta **PASS (380 eri media-ID:tä)**.
- ASan/UBSan, 300 DOM/elinkaaritestiä, 1 800 muistipainetestiä ja 1 800 damage-testiä **PASS**.
- HTTP-integraatioiden 12 ja vanhojen verkkotestien 17 skenaariota **PASS**.
- **EI TESTATTU:** verkkosivujen elävä HTTP/HTTPS-selainkäyttö, JavaScriptin kaikkien frameworkien toiminta, AVIF-dekoodaus, täydellinen HTMLMediaElement/MSE/EME/video- ja audiosoittimet, QEMU-GraOS-käynnistys ja fyysinen eMachines.
- **Asennusmedian rajoitus:** juuren `utilities.iso` on arkistossa entisenä. Uusi `navigator.bin` ja `navigator-v72.76.sqa` ovat ajantasaisia. Asennusmedia pitää rakentaa erikseen ennen sen käyttöä uuden selaimen asentamiseen.

## Seuraavien kehitysvaiheiden prioriteetti

1. ES-moduulien riippuvuusgraafi, `import()` ja async/defer-skriptien oikea tapahtumajärjestys (Yle/YouTube).
2. CSS:n Grid/Flexbox/positioning sekä Web Components ja Shadow DOM (CNN/Fox/YouTube).
3. AVIF:n rajattu natiivi decoder tai palvelimen formaattineuvottelu (Yle).
4. HTMLMediaElement/MSE ja ääni/video, erikseen YouTuben DRM- ja formaattirajoitukset (YouTube).
5. QEMU + fyysinen kone: sivulataukset, ~100 navigointia, F12-profiili ja 24h vakavuus.

## Toistettavat testit

```
python3 tools/run_navigator_v7276_sites.py --assets-dir /polku/zippeihin --report-dir /tmp/nav7276
sh tests/run-v7274-navigator-sanitizers.sh
sh tests/run-v7275-dynamic-host.sh
sh libc/apps/navigator/tests/run_v7272_host_tests.sh
make -C libc/apps -f navigator.mak -j2 navigator.bin
```

Host-Lexbor-testit voi ottaa käyttöön lisävalinnalla `--lexbor-archive /polku/liblexbor_static.a` (hostille käännetty ASan/UBSan-arkisto, ei JTMOS:n ELF32-arkisto). JTMOS:n omat 32-bittiset kirjastot ja ohjelmat on käännettävä erikseen. Pelkkää localhost- tai host-sanitizer-tulosta ei pidä tulkita oikean verkkosivun hyväksymistestiksi.
