# JTMOS v72.194 QA

- Kernel sh/sh.o and core/int/scs.o GCC i686 compile: PASS, no errors.
- libc with GraOS session request helper: PASS.
- GraOS server with ownership-checked IPC request and privileged syscall: PASS, layout test 36 modules.
- smshgui.bin 32-bit static ELF link: PASS.
- Full kernel link / boot: NOT TESTED (NASM absent).
- Real GraOS session creation, keyboard routing and cleanup: NOT TESTED; requires rebuilt kernel and GUI image.
- UI uses existing v72.193 SMSH Root desktop shortcut and Start menu launch handlers.
- Kernel session interactive editor is initially basic (no full VT3 shell history/pipelines or expansions).
