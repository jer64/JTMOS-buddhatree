# Navigator v72.231: Google-haku osoiteriviltä ja Googlen hakukentästä

Päivämäärä 2.11.2026. Pohjana v72.230 FULL-SOURCE. Muutokset koskevat vain Navigatoria.

## Miksi haku ei toiminut

1. **Osoiterivi ei tehnyt hakua ollenkaan.** `nav_address_url()` hyväksyi vain
   verkkotunnuksen tai http(s)://-osoitteen. Kun osoiteriville kirjoitti esimerkiksi `jtmos`,
   `jtmos kernel` tai `sää helsinki`, tuloksena oli virhe "Invalid address". Näppäinkoodit
   ≥ 127 (ä, ö, å) hylättiin jo kirjoitettaessa.
2. **Googlen etusivun hakukentässä Enter lisäsi rivinvaihdon.** Google käyttää hakukenttänä
   elementtiä `<textarea name="q" role="combobox" rows="1">`. Navigator käsitteli sitä
   monirivisenä tekstialueena, joten Enter lisäsi `\n`:n eikä lähettänyt lomaketta. Oikea
   selain lähettää tämän lomakkeen Googlen omalla JavaScriptillä.
3. **Google ei näytä hakutuloksia selaimelle ilman täyttä JavaScriptiä.** Tammikuusta 2025
   lähtien `/search` palauttaa tällaiselle selaimelle vain kuoren, jonka `<noscript>`
   ohjaa osoitteeseen `/httpservice/retry/enablejs`. Navigatorin QuickJS-osajoukko ei läpäise
   Googlen bottitarkistusta, joten sivu jäi tyhjäksi.

## Korjaukset

- `nav_address_or_search()` (navigator_url.c): kelvollinen osoite toimii kuten ennenkin
  (HTTPS ensin). Muu teksti muuttuu osoitteeksi `https://www.google.com/search?q=…`
  (lomakekoodaus: välilyönti on `+`, peräkkäiset välilyönnit yhdistetään, UTF-8
  prosenttikoodataan). Etuliitteet `? sana` ja `g sana` tekevät aina haun, myös silloin kun
  teksti näyttää verkkotunnukselta (`? vunet.net`). Virheellinen eksplisiittinen URL
  (`ftp://`, `javascript:`, `data:`, `file:`) pysyy virheenä eikä muutu hauksi.
- Osoiterivi hyväksyy Latin-1-näppäinkoodit (ä ö å Ä Ö Å é ü …). Ne piirretään CP437-glyfeinä
  ja koodataan hakuun UTF-8:na. Komentorivi `navigator jtmos kernel` hakee kaikilla sanoilla.
- `nav_form_single_line()` (nav_form.c): tekstialue, jolla on `role=combobox` tai `searchbox`
  tai `enterkeyhint=search|go|send`, on yksirivinen hakukenttä. Siinä Enter lähettää
  lomakkeen, eikä liitetty teksti tuo rivinvaihtoja. Tavallinen `<textarea>` toimii kuten
  ennenkin.
- Googlen JS-muuri (navigator.c `finish_navigation`): jos Google-haun (`google.com`,
  `google.fi`, `google.co.uk`, `google.com.au` …, polku `/search`) vastauksessa ei ole
  tuloselementtiä `#rso` tai `#search` ja se sisältää `enablejs`- tai `/sorry/`-ohjauksen,
  sama `q` haetaan heti osoitteesta `NAV_SEARCH_FALLBACK`
  (oletus `https://html.duckduckgo.com/html/?q=`). Tilarivillä lukee silloin
  "Google requires full JavaScript - same search via DuckDuckGo HTML". Muihin sivustoihin
  sääntöä ei sovelleta. Varahaun saa pois käytöstä käännöksessä:
  `APP_CFLAGS+=-DNAV_SEARCH_FALLBACK=\"\"`.

## Testit

- `tests/v72231_google_search.c` (ASan/UBSan, vain navigator_url.c): osoite- ja hakusäännöt,
  Latin-1/UTF-8, Google-isäntien tunnistus (`google.evil.com` hylätään), q-parametri,
  JS-muuri ja varahaun URL: **PASS**.
- `tests/v72231_google_form.c` + `tests/v72231_pages/google-home.html` (Lexbor-isäntäobjektit,
  ASan/UBSan): Googlen textarea on yksirivinen, Enter-lähetys tuottaa
  `…/search?sca_esv=1&source=hp&q=s%C3%A4%C3%A4+jtmos&btnK=Google-haku`: **PASS**.
- Regressiot: `v71120_forms` (moniriviset textarea-rivinvaihdot säilyvät) PASS,
  `v72143_url` PASS.
- `navigator.bin` käännetty JTMOS i686 -kohteelle `-Werror`-asetuksella:
  SHA-256 `7c9c516eabdb599399db75f049bd4b34fb845d7dfd4c80b66f7fd68935e20704`.

## Rajoitukset

- Live-yhteyttä Googleen ei testattu: rakennusympäristöstä ei ollut verkkoyhteyttä
  google.comiin. JS-muurin tunnistus perustuu julkisesti raportoituun enablejs-kuoreen.
- Googlen oikeita tulossivuja saadaan vain, jos Google palvelee ne tälle selaimelle.
  Muussa tapauksessa tulokset tulevat varahakukoneesta. Täyttä Google-yhteensopivuutta
  JavaScriptin kanssa ei väitetä.
- Ytimen ja GraOS-levykuvia ei rakennettu uudelleen. `navigator.bin` pitää kopioida
  utilities-mediaan tai järjestelmään tavalliseen tapaan.
- `tests/v7180_navigator_port.py` epäonnistuu jo v72.230:ssä ("memory req mismatch").
  Tämä muutos ei aiheuta sitä.
