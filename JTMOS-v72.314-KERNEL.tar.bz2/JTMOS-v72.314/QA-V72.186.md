# QA JTMOS v72.186

## Host-side functional tests

- 2,187 PASS assertions in the first host sanitizer run for IPv4 filtering,
  256-node RB-tree randomized insertion/deletion, 4KiB page cache, quota
  accounting, safe builtin registry, and rejected eBPF load.
- Final regression rerun required before release; see logged results.

## JTMOS compiler

- Cross-compiled seven native i686 objects using the real kernel flags
  (`gcc -m32`, `-nostdinc`, `-nostdlib`): five new C modules, modified
  `uipMain.c`, and modified `vfs_mount.c`.
- No kernel linking, interrupt-context validation, emulator boot or hardware
  network test was performed. These are NOT PASS states.

## Release scope

- Inherited v72.185 boot/kernel binaries, old installation media and GraOS
  binaries. This is FULL-SOURCE-UNBUILT, not a bootable updated kernel release.
- All 21 critical Unix symlinks must be preserved and audited inside ZIP.
- ZIP checksums, manifest and archive structure are validated separately.
