# V72.234 – varmennus

Lopullisilla julkaisutavuilla (ydin `V72.234`, `jtm32.img`, `root1440.img`,
`utilities.iso`) ajettiin QEMU 8.x, `qemu-system-i386`. Lokit ovat hakemistossa
`release/qa/v72.234/`.

| Ajo | Tulos |
|---|---|
| 1024 MiB: ram: 128 MiB; mkfs hda; `bootroot` hylkää tyhjän hda:n; `root`/`mount` hylkäävät, `mount -f` hyväksyy; juuri valitaan, kun hakemistossa on sisältöä; `umount` busy → `umount -f` siirtää / ram:-levylle; `mkfs hda` toimii; `sqa cdrom` + kaikki 8 pakettia ram:-levyllä, 82 MiB vapaana, ENOSPC=0 | 15/15 PASS |
| 1024 MiB, hda1-osio (raportoitu tapaus): `partition hda auto`, `mkfs hda1`, `root hda1` hylätään, `root -f hda1`, `umount`/`mkfs` busy, `umount -f hda1`, `mkfs hda1`, `mount hda1` hylätään, `mount -f`, juuri valitaan, kun sisältöä on | 14/14 PASS |
| 256 MiB, sama hda1-skenaario, ram: 127 MiB | 14/14 PASS |
| V71.124 päällekirjoitusregressio: fsregress ram: + hda:, jtmfsck CLEAN ennen ja jälkeen resetin | PASS |
| Käynnistysmatriisi 128/160/192/256/1024 MiB (`ramdisk-memory-matrix.txt`) | kaikki käynnistyivät; 192 MiB kaatui ennen puolen RAM:in rajaa |

V72.233:n host-testit (Navigator, Save As, evästeet, GraOS layout ABI 111)
koskevat samoja sovelluslähteitä. Sovelluskoodiin ei tehty muutoksia, vain
versionumeroon.

Ei ajettu: oikea rauta (T400, eMachines) eikä käynnistys hda:lta (BIOS 0x80).
hda1:n käynnistyshaara käyttää samaa `jtmfs_root_has_entries()`-tarkistusta kuin
QEMU-testattu `bootroot`/hda-haara.
