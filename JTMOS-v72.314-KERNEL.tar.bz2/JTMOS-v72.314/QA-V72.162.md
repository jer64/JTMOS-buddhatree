# JTMOS v72.162 – QA

Päiväys 27.10.2026. Pohjana on kokonainen v72.161-lähdepaketti (SHA-256 `9a2713e9…0c519be13`).

| Tarkistus | Tulos |
|---|---|
| Natiivi koonti ja media | PASS |
| Ytimen kokoraja (`check_kernel_image.py`, vaatimus 65536 vapaata) | PASS: 936220 tavua, 112356 vapaata (v72.161: 69700) |
| Upotettu sivusto: LZSS-pakkaus + purku, hosted stream -testi vertaa alkuperäisiin (`check_jt_httpd_site.sh`) | PASS |
| QEMU: asennusskriptit, #!-skriptit, puupaketit, /var/www/html, upotettu jtmos.css ehjänä, Angband | PASS 16/16 |
| HDA ich9-intel-hda duplex / micro, 4 s ilman katkoja | PASS |
| GraOS-leikepöytä, kalenteri, SQSH Ctrl+V | PASS |
| QEMU-verkkoregressio | PASS 10/10 |
| SQSH:n Ctrl+C | PASS |
| SQA-, puu-, find-, HDA-, Angband-, BitchX- ja ircII-isäntätestit | PASS |
| Koko paketin manifesti ja ZIP:stä uudelleenkoonti | PASS (kernel32.bin, graos.bin, sqsh.bin, utilities.iso, levykuvat identtiset) |

Huomio: kun neljä QEMU-ajoa pyöri samanaikaisesti, kolme testiä epäonnistui
kerran (tulokset kansiossa `release/qa/v72.162/parallel-load-run/`):
asennusskriptitestissä `sqa` palautti virheen 11, koska lopullinen `sync()`
epäonnistui jollakin toisella laitteella (kaikki 94 tiedostoa oli purettu);
HDA-testissä yksi 2,3 ms:n katko (alivuoto kuormituksessa); verkkotestissä
kaikki 10 osatestiä onnistuivat mutta isäntäpuolen kuuntelutarkistus ei.
Peräkkäin ajettuina kaikki kolme menivät läpi. `sqa`:n sync-käytös on
ennallaan versiosta 69.x.
