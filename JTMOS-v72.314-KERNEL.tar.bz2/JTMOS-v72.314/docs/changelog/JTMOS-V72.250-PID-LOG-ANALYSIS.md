# JTMOS v72.250 — PID and systemlog corrections

Input: `pslist.txt` and `systemlogs2.zip`, 2026-11-03 to 2026-11-04.

## Source-backed observations

- Snapshot: PID 5 CP, PID 11 KJTMFSC, PID 17 KLOGGER, PID 18 guiserver, PID 20 navigator.bin, PID 26 volumemixer.bin.
- PID 21, 22, 24 are also earlier Navigator network workers; the snapshot shows them as SQSH. PID reuse prevents assigning old log records using a later `ps` snapshot.
- `navigator.log` reports Navigator **v72.233**, two launches, an IPC timeout of a large Bloomberg response, and fork ENOMEM concurrency fallback. Those observations are not v72.249/v72.250 regressions without new runtime tests.
- `kern-5.log` contains contention for the per-volume JTMFS mutex, often with PID 14. Mutex waits alone do not establish deadlock; no measured wait duration was present in the old logs.
- PID 26 repeatedly sends GraOS command 17 = SETLABELTEXT. `kern-18.log` is dominated by successful IPC message debug logs.
- `kern-11.log` and `kern-17.log` show repeated successful ATA flush diagnostics and DIRDB writeback reports. Printing successful I/O can cause KLOGGER self-amplifying writes.
- `crash.log` is empty. `diskspace.log` shows no ENOSPC errors; absence of crash logs is not proof of absence of faults.
- CPU ticks in `ps` are cumulative since process start, not instantaneous CPU utilization. The snapshot alone cannot prove a runaway process.

## Corrections in v72.250

1. `mutex.c`: log PID generation (thread_magic), process name, owner identity and held duration at contention; log elapsed wait on slow acquisition >=100 ms.
2. `WriteChain.c`, `jtmfsAccess.c`, `dirdb_writeDir.c`: successful JTMFS write/dir flush reports are optional (`-DJTMFS_TRACE_SUCCESS_IO=1`); errors remain.
3. `jtmfat.c`, `fsfind.c`, `dirdbFind.c`, `jtmfsAccess.c`: routine path lookup chatter optional (`-DJTMFS_TRACE_LOOKUPS=1`).
4. `ahci.c`: flush-success logs sampled on first 16 operations and every 1024th. Every failed flush still logs, and AHCI diagnostic counters remain.
5. `guiServer.c`: successful SETLABELTEXT no longer logs for every request. Failed IPC commands are still logged.
6. `volumemixer.c`: send label updates only if text changed, redraw only on changes, poll every 50 ms instead of 20 ms.
7. Host `tools/analyze_pid_logs.py` correlates snapshots and logs with PID-reuse warnings.

These changes aim to reduce unnecessary logging and GUI work, not to alter JTMFS journal durability or skip ATA flush commands. NASM boot image rebuild and real-hardware verification remain separate acceptance steps.

## Reproduce on host

```sh
python3 tools/analyze_pid_logs.py /path/to/pslist.txt /path/to/systemlogs2.zip
python3 tests/v72250_pid_logs_host.py
make release-check-source
```
