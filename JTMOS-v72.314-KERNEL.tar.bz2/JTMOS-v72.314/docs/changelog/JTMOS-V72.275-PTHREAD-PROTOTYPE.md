# JTMOS v72.275 — turvallinen pthread_create-prototyyppi (i686/Ring3)

## Lähde ja johtopäätökset

Käyttäjän toimittama `pthread_create.c` on GNU libc:n NPTL-toteutus (LGPL-2.1+).
Se käyttää sisäisiä `pthreadP.h`-säierakenteita, `allocatestack.c`-pinohallintaa,
`createthread.c`-kernel-sovitinta, TLS:ää, futexeja ja tarkkaa muistinomistajuutta.
Sitä ei voi kääntää JTMOSiin sellaisenaan. JTMOS-koodi on kirjoitettu itsenäisesti;
GNU:n ohjelmakoodia ei ole kopioitu. Tärkein sovellettu *periaate* on:
säiekuvaajan/pinon omistajuuden ja lapsen käynnistymisen täytyy olla atomisia
suhteessa `pthread_create`-kutsun paluuseen ja `pthread_join`-vapautukseen.

## Tässä julkaisussa toteutettu

- Varattu syscall **181**, `SYS_threadctl`, ja päivitetty sekä kernelin että libc:n koodit.
- `OP_VERSION=1` ja `OP_FEATURES=0`: kernel ilmoittaa ABI-version, mutta ei väitä
  tukevansa vielä aitoa käyttäjätilan säiettä. CREATE/JOIN/EXIT/SELF -> `-ENOSYS`.
- `jtmos/threadctl.h`: versionoitu, 32-bittinen create-kutsu ja vaadittavat
  ominaisuusbitit sekä kernelissä että libc:ssä.
- `modern/pthread_create_proto.c`: attribuuttien tarkistus, pinomuistin varaus
  ja kohdistus, kuvauksen omistajuus, aloituskäsittelijä, aloituksen portitus,
  epäonnistuneen luonnin siivous ja join-operaation jälkeinen vapautus.
- Olemassa oleva `pthread_create` ja `pthread_join` kutsuvat prototyyppikerrosta.
  `pthread_self` käyttää uutta SELF-operaatiota vain, jos täydellinen tuki joskus
  aktivoidaan. `pthread_detach`, cancellation ja condition wait pysyvät ENOSYS
  / ENOTSUP -rajattuina kuten aiemmassa toteutuksessa.
- Nykyinen käyttäjälle näkyvä tulos `pthread_create` -> **ENOSYS** on
  tarkoituksellinen. Emme käytä `fork()`-kopiota emmekä CPL0 `create_thread()`-säiettä.
- Testit varmistavat vanhan API-käyttäytymisen, ABI:n yhtenäisyyden ja i686-
  käännöksen. Tämä ei ole vielä suorittava pthread-toteutus.

## Kernelin toteutussuunnitelma (seuraavat vaiheet)

1. **Thread-group ja jaettu muisti:** viitteiden laskenta kaikkien Ring3-säikeiden
   page table -rakenteisiin ja `mmap`-alueisiin; *ei COW-kopiointia*. Vanhan
   `thread_base[pid]`-omistajuuden vapautus vain viimeisen viitteen jälkeen.
   Kaikkien säikeiden osoiteavaruusidentiteetin pitää pysyä samana.
2. **Ring3 TSS + yksilöllinen pino:** uusi child käyttää USER_CS/USER_DS,
   validia käyttäjästackia, oman FPU-tilan, oman kernel stackin ja
   säietunnisteen generaatiosuojaa. Luo lapsi pysäytettynä ja julkaise vasta
   kaikkien resurssien onnistuneen valmistelun jälkeen. Estä EIP:n/ESP:n
   käytön kernel- ja unmapped-osoitteisiin. Merkitse guard page ei-läsnäolevaksi.
3. **Jaettu prosessi-identiteetti:** fd-taulu, sockets, cwd, ympäristö,
   signaalit ja prosessin poistuminen käsiteltävä thread-group-tasolla;
   nykyinen PID-kohtainen `LinuxProcessCreated/Discard` ei yksin riitä.
   `fork` moni­säikeisestä prosessista tulee määritellä/estää kunnes turvallinen.
4. **Elinkaari, join, synkronointi:** `OP_CREATE`, `OP_SELF`, `OP_EXIT`,
   `OP_JOIN` + wait/wake; kerralla yksi joiner. JOIN palautuu vasta kun
   lopettava säie ei enää käytä käyttäjäpinoa. Tarkka ownership detached-
   säikeelle ja peruutukselle ennen kuin ne voidaan aktivoida.
5. **Libc:n säieturvallisuus:** `errno`/TLS per-säie, `malloc`- ja stdio-
   lukitus, resolver/timer/socket-koodin reentranssi, futex/condvar,
   schedulerin starvation- ja NMI-poistumispolut. Älä nosta FEATURES-bittejä
   ennen näitä. Kehitä ensin kernelin oma säietesti, vasta sitten Navigator.

## Esimerkki (nyt palauttaa ENOSYS)

```c
#include <pthread.h>
#include <errno.h>
static void *worker(void *p) { return p; }
int start(void) {
    pthread_t tid = 0;
    int rc = pthread_create(&tid, 0, worker, 0);
    if (rc == ENOSYS) return 0; /* ominaisuus ei vielä ole käytössä */
    if (rc != 0) return rc;
    return pthread_join(tid, 0);
}
```

POSIX-pthread-funktiot palauttavat virhenumeron suoraan eivätkä aseta `errno`:a.
Todellinen säikeen luonti ei vielä toimi JTMOS-laitteella v72.275:ssä.
