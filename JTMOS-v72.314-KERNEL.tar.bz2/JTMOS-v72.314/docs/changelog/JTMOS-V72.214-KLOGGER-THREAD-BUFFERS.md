# JTMOS v72.214 – KLOGGER: 64 viestiä säiettä kohti

Pohja: v72.213 FULL SOURCE UNBUILT. KLOGGERin aktiivisten säikeiden määrä pysyy enintään 64:ssa, mutta **jonon enimmäiskoko per säie on 64 viestiä (ennen 8)**.

## Toteutus

- Kunkin säikeen FIFO saa nyt pitää 64 odottavaa viestiä.
- Yhteispooli on enintään 4096 viestiä (64 säiettä × 64 viestiä). Viestin enimmäispituus on 512 tavua.
- Enintään 63 lisälohkoa (64 tietuetta/lohko) varataan kernelin heapista kerran `initSystemLog()`-alustuksessa käyttäen `malloc1`-toimintoa; vakiovarauksena säilyy ensimmäinen 64 tietueen lohko (~33 KiB). **Debug/ISR-polku ei varaa muistia eikä kirjoita levylle.**
- Täysi kapasiteetti tarvitsee noin 2,1 MiB heap-muistia. Jos varaukset epäonnistuvat, käytettävissä on onnistuneiden varausten mukainen pienempi pooli; jokaisella säikeellä on silti 64 viestin *enimmäisraja*, kun vapaata poolia riittää. Jono voi pudottaa viestejä yhteispoolin täyttyessä.
- KLOGGERin 4 viestin purkuvuoro ja enintään 32 viestin purkuerä pysyvät ennallaan. FIFO säilyttää säiekohtaisen järjestyksen; levyvirhe ei poista jonossa olevaa viestiä.
- Kun yhteispooli ylittää 75 % todellisesta käytettävissä olevasta kapasiteetista, KLOGGER yrittää purkaa sen aiemmin kuin normaalin ajastetun flushin.

## Testattu

`sh tests/v72214_thread_logging/run.sh` → PASS: 64 viestiä/säie, 64 säiettä × 64 viestiä, 4096 tietuetta, FIFO, vuorottelu, epäonnistuneen muistivarauksen fallback ja 20 000 operaation stressitesti. GCC C99 + UndefinedBehaviorSanitizer läpäisty. Kernelin `logging.c` läpäisi 32-bittisen GCC-syntaksitarkistuksen JTMOS-otsakkeilla.

## Rajoitukset

- Kernelin täyttä linkitystä, QEMU-käynnistystä tai oikean raudan testausta ei ole suoritettu. **Kyseessä on täysi lähdekoodipaketti, mutta edelleen UNBUILT.** Mukana olevat vanhat boot-binäärit eivät sisällä muutosta.
- Moniydinympäristö vaatii IRQ-safe SMP-lukituksen; nykyinen suojaus on paikallisten keskeytysten poisto.
- JTMFS/IDE:n tunnetut levyvirheet voivat vaikuttaa lokin kestotallennukseen; testaa erillisellä levykuvalla.
- KLOGGERin dprintk/ReportMessage-tiedostot käyttävät nykyisen toteutuksen mukaisia `kern-<TID>.log`-polkuja. Yhteinen `kern.log` säilyy ennallaan.
