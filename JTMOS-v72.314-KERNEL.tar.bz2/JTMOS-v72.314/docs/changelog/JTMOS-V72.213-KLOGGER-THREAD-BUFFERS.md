# JTMOS v72.213 – KLOGGER: säienumerokohtaiset puskurit

Pohja: v72.212 FULL SOURCE. Muutokset kohdistuvat
`kernel32/core/int/logging.c`- ja `thread_debug_queue.inc`-tiedostoihin.

## Muutokset

- `ReportMessage`/`dprintk` käyttävät ennestään `WritePIDDebugLog`-reittiä;
  viestin alkuperä otetaan `GetCurrentThread()`-kutsusta, joka palauttaa
  JTMOS:n säietunnuksen. Lokitiedoston nimi säilyy `/var/log/kern-<TID>.log`.
- Aiempi yhteinen 64 merkinnän FIFO korvattiin 64 merkinnän poolilla ja
  enintään 64 säiekohtaisella FIFO-listalla. Kullakin säikeellä saa olla
  enintään 8 odottavaa viestiä. Tämä estää yhden meluisan säikeen yksin
  täyttämästä koko puskuria.
- KLOGGER käsittelee enintään 32 merkintää purkukerralla ja vaihtaa säiettä
  viimeistään neljän merkinnän jälkeen. Säiekohtainen järjestys säilyy,
  mutta eri säikeiden välinen globaali aikajärjestys ei ole taattu.
- Tuottaja ei tee muistivarausta tai levykirjoitusta; kirjataan vain
  rajattuun RAM-puskuriin. Purku tapahtuu KLOGGER-säikeessä, ja epäonnistunut
  levykirjoitus ei vapauta viestiä ennen seuraavaa yritystä.
- Viestikoko pysyy 512 tavussa. Ylivuodon yhteydessä viestejä voidaan pudottaa;
  `dropped`-laskuri seuraa menetettyjen viestien lukumäärää RAM:ssa.

## Testit

`sh tests/v72213_thread_logging/run.sh`

Host-GCC/UBSan: FIFO-järjestys, säikeiden erottelu, 8 viestin yläraja,
64 aktiivista säiettä, uudelleenyritys, vapautuneen paikan käyttö,
20 000 operaation stressitesti. Kernelin `logging.c`-tiedosto kääntyi
32-bittisillä JTMOS-käännösvalitsimilla (`make -f generated.mak core/int/logging.o`).

## Rajoitukset

- **Kernelin kokonaislinkitystä, QEMU-käynnistystä eikä fyysisten levyjen
  pitkäaikaistestausta ei suoritettu.** Aiemmat kernel-binäärit eivät sisällä
  tätä muutosta. Käännä kernel ja päivitä käynnistysmedia ennen käyttöönottoa.
- Jono perustuu nykyiseen yhden CPU:n malliin, jossa `disable()` estää
  paikallisen keskeytyksen. Moniydinympäristö vaatisi lisäksi SMP-turvallisen
  IRQ-spinlockin.
- TID voi kierrättyä, jolloin myöhemmin luotu säie käyttää samaa
  `kern-<TID>.log`-tiedostoa. Erillinen säiegeneraatiotunnus puuttuu.
- Lyhyen osittaisen levykirjoituksen epäonnistumisen jälkeen viestin
  uudelleenyritys voi tuottaa osittaisen duplikaatin. JTMFS:n ja IDE:n
  tunnettujen kirjoitusongelmien vuoksi testaa erillisellä levykuvalla.
