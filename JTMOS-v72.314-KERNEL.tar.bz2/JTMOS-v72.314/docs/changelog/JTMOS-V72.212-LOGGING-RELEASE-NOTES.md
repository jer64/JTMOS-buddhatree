# JTMOS v72.212 – lokien erottelu

**Navigator:** `NAVDBG` ja `NAVREPORT` kirjoittavat `/var/log/navigator.log`.
Lokiriveissä näkyy taso ja alkuperäinen PID. `nav_log.c` käyttää `O_APPEND`-
kirjoitusta ja avaa tiedoston uudelleen prosessin vaihtuessa (`fork`).
Se yrittää luoda `/var` ja `/var/log` tarvittaessa. Lokiin ei kirjoiteta URL:eja,
evästeitä tai HTTP-otsakkeita automaattisesti.

**Kernel:** `dprintk` ja `ReportMessage` tallentuvat KLOGGERin kautta
`kern-<PID>.log`-tiedostoihin saman `/var/log`-hakemiston alle kuin muu
järjestelmäloki. Varhaiset kernelviestit käyttävät PID-arvoa 0. Kerneliin
lisätty 64 tietueen, 512 tavun rajattu RAM-jono muodostaa viestit ilman
filesystem-kutsuja tuottajakontekstissa. KLOGGER tallentaa enintään 32 viestiä
kerrallaan ja purkaa jonon ennen kaikkea 48 tietueen kuormituksella tai
normaalilla jaksolla. Ylivuotavat viestit pudotetaan; laskuri säilyttää
häviöiden määrän. Tulostus sarjaporttiin säilyy asetuksien mukaan.

**Tärkeät rajat:** yksittäinen kernel-debugviesti katkaistaan 510 tavun
jälkeen; debugviestien säilymistä ei taata, jos RAM-jono täyttyy tai
kirjoitukset epäonnistuvat. KLOGGERin oletuskohde voi olla `hda1:/var/log`
siihen asti, kunnes `klogger start` asetetaan seuraamaan aktiivista juurta.
Lokitiedostoja ei vielä kierrätetä eikä niiden kokoa rajoiteta automaattisesti.

## Testit

`sh tests/v72212_logging/run.sh`: erilliset host-GCC/UBSan-testit
Navigatorin prosessikohtaiselle append-kirjoitukselle ja kernelin jonon
PID-erottelulle, ylivuodolle ja erissä purulle.

Tässä lähdekoodijulkaisussa uusi `navigator.bin` on käännetty ELF32/i386-muotoon
ja kolme muutettua kernelin C-moduulia kääntyvät. **Uutta kernel-binääriä ei
ole linkitetty; asennusmediassa on edellisen julkaisun kernel.**
Navigator-binääri ei myöskään ole päivittynyt vanhaan `utilities.iso`-mediaan.
Tarvitaan uusi kernel- ja mediakäännös ennen kuin molemmat muutokset ovat
käytössä normaalin JTMOS-käynnistyksen jälkeen.

Uutta tallennuspolkua ei ole testattu QEMU:ssa eikä fyysisellä laitteistolla.
Koska IDE/JTMFS-kirjoitukset ovat aiemmin oireilleet, testaa ensin erillisellä
levykuvalla ja pidä varmuuskopio ennen asennusta.
