JTMOS V71.124 – täysi lähdekoodi- ja asennusjulkaisu
=================================================
Lue RELEASE-V71.124.txt ja QA-V71.124.md.

Käännös: make
Tarvitaan GCC/binutils (i686/-m32), make, Perl ja NASM. Vendoroidut lähteet
ja Lexborin nykyisen rakennuspolun tarvitsema staattinen kirjasto ovat mukana.

QEMU: ./run_jtmos_qemu.sh
Käyttää suoraan jtm32.img-, root1440.img- ja utilities.iso-tiedostoja.

Ennen DOSBOOTin siirtämistä DOS/FreeDOS-koneelle:
  python3 tools/restore_release_media.py
Kopioi sen jälkeen boot32pm/dosboot/-hakemiston kaikki kolme tiedostoa:
dosboot.com, kernel32.nz ja utils.iso. Sama komento palauttaa vanhojen
työkalujen utils.iso- ja kernel32/utilities.iso-polut. Make luo ne myös uudelleen.

Host-regressio: python3 tests/v71124_jtmfs_overwrite.py --sanitize
Natiivi testi: asenna tests.sqa ja aja fsregress.bin.
Oletus käyttää vain ram:/fsreg-alkuisia testitiedostoja.
Vain ylikirjoitustestit: fsregress.bin ram:/fsreg --overwrite-only
Omaa tyhjää JTMFS-testihakemistoa voi käyttää antamalla erillisen etuliitteen:
  fsregress.bin hda1:/testi/fsreg
Testiohjelma kirjoittaa etuliitteen mukaisia tiedostoja ja poistaa ne lopuksi.

Tiiviin julkaisun uudelleenpakkaus (Python 3.9+):
  python3 tools/package_full_release.py /absoluuttinen/tuloshakemisto
Paketti on täysi lähdekoodijulkaisu, ei overlay. Manifesteissa ovat lopullisen
julkaisun tiedostojen SHA-256-summat. Vanhoja julkaistuja binäärikopioita ja
vanhoja QA-kuvia ei toimiteta uudelleen.
