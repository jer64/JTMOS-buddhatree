# QA — JTMOS v72.97 / Intel 82567LM stage 3

| Check | Result |
|---|---|
| Complete JTMOS v72.96 source tree preserved as base | PASS |
| Modified `ich9e.c`, `ethdev.c`, `networkapp.c` compiled with real generated JTMOS make rules (-m32, -Os, -nostdlib) | PASS |
| `tests/v7297_ich9e_rx_dma.py` actual RX C code + fake MMIO | PASS |
| ARP frames, IPv4 DHCP candidate counters | PASS in C runtime simulation |
| Split-frame drain through EOP without forwarding continuation | PASS in C runtime simulation |
| Bad descriptor error, incorrect destination buffer capacity, invalid DMA address | PASS in C runtime simulation |
| RX ring index wrap and RDT returns | PASS in C runtime simulation |
| RXDCTL0/RDTR/RADV/RXCSUM programming | PASS in C runtime simulation |
| DHCP DISCOVER/OFFER/REQUEST/NAK plus malformed reply codec tests | PASS (host native) |
| network_dhcp_ping_http_v681651.py | PASS |
| ethernet_dhcp_recovery_v681650.py | PASS |
| v7280_ich9e_source.py PCI backend regression | PASS |
| Old v72.95/v72.96 version-pinned tests | Not rerun as passing: strict VERSION expectations refer to old releases |
| Entire kernel32.bin or DOSBOOT fully rebuilt | NOT BUILT (NASM unavailable) |
| Actual T400 RX, DHCP, ARP, ping | NOT TESTED |
| Entire ZIP CRC integrity | PASS after packaging |
