# GraOS taskbar clock calendar — 2026-10-16

Based on the audit-fixed JTMOS v71.66-r2 source archive.

GraOS taskbar already included a month-calendar popup in its source. This update hardens and finishes the existing implementation in both libc/apps/taskbar.c and graos-host/apps/taskbar.c:

- The taskbar clock button or clock label opens/closes the popup.
- Previous/next arrows move between months; Monday-first weeks and today's date indicator remain intact.
- Calendar display updates after month navigation and on day change.
- Gregorian month/day validation rejects invalid RTC dates.
- Year navigation is bounded to 1900..9999.
- Taskbar exit closes owned popup windows.
- Clicking Start/power menus or receiving CLOSEMENUS closes the calendar; Escape closes it from the popup.

Validation: taskbar.mak syntax passed. Hardware and full GUI runtime testing not performed.
