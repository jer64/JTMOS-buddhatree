# V72.158: Ctrl+C SQSH:ssa ja nutgetin -111 HTTPS-latauksen lopussa

**Tausta:** V72.157:llä T400:n verkko toimii: DHCP 10.42.0.28, ping 10.42.0.1 (3/3) ja TLS 1.2 vunet.netiin varmennettuna. Kuvat ovat hakemistossa `release/qa/v72.158/`.

## 1. Ctrl+C ei pysäyttänyt pingiä SQSH:ssa

**Oire:** GraOS:n "JTMOS Command Prompt #2 - Squirrel Shell" -ikkunassa Ctrl+C `ping 195.74.0.47` -komennon aikana tulosti vain uuden rivin ja `^C`, ja ping jatkui.

**Syy:**
- SQSH ajaa `ping`in, kuten muutkin SMSH-komennot (`nutget`, `host`, …), ytimen **työsäikeessä** (`smsh_run_guarded_userspace_builtin`).
- SQSH:n säie odottaa työsäiettä funktiossa `WaitProcessTerminationInterruptible()`. Se tarkistaa päätteen Ctrl+C-lipun millisekunnin välein, kuluttaa sen ja tulostaa `^C`.
- Sen jälkeen se lähettää työsäikeelle SIGINT:n, jota ytimen säie ei käsittele, ja jatkaa odottamista.
- Ping tarkistaa lipun vasta pyyntöjen välissä, joten se ei koskaan nähnyt Ctrl+C:tä.
- Sama kilpailu oli tekstipäätteellä silloin, kun SQSH oli käynnistetty SMSH:sta: myös SMSH odotti SQSH:ta ja kulutti lipun.

**Korjaus (threads.c, sh.c):**
- `WaitProcessTerminationDelegated()` SMSH-komentojen työsäikeille: odottaja vain tarkkailee lippua kuluttamatta sitä. Komento käsittelee Ctrl+C:n itse, ja ping tulostaa tilaston. Jos komento ei reagoi 1,5 sekunnissa, odottaja toimii kuten ennen.
- `WaitProcessTerminationInterruptible()` kuluttaa Ctrl+C:n vain, kun sen oma lapsi on päätteen etualan prosessi, ja palauttaa lopuksi edellisen etualan prosessin. Kun SQSH antaa etualan työsäikeelle tai omalle lapselleen, ulompi odottaja ei enää sieppaa Ctrl+C:tä.

**Testi** (`tests/v72158_qemu_sqsh_ctrlc.py`):
- SMSH: `ping 10.0.2.2` + Ctrl+C → pysähtyy 0,2 s:ssa (molemmat versiot).
- SMSH → `sqsh` → `ping 10.0.2.2` + Ctrl+C: V72.157 FAIL; V72.158 pysähtyy 0,2 s:ssa, ja SQSH jatkaa (`ver` toimii).

## 2. `nutget https://vunet.net` → "TCP receive failed (-111)"

**Oire:** TLS ja varmennus onnistuivat, palvelin vastasi `HTTP 200` ilman Content-Lengthia, mutta lopussa tuli virhe -111.

**Syy:** -111 on `KTLS_ECONN`. Kättelyn jälkeen KTLS palauttaa sen vain yhdessä kohdassa: kun **TCP-kirjoitus** epäonnistuu. Palvelin lähettää TLS:n close_notify-viestin ja nollaa TCP-yhteyden (RST). BearSSL yrittää vastata omalla close_notify-viestillään suljettuun socketiin, ja onnistunut lataus muuttui virheeksi. Lukuvirhe oli jo ennestään käsitelty tiedoston loppuna.

**Korjaus:**
- `ktls.c`: kun TCP-kirjoitus epäonnistuu kättelyn jälkeen, virta päättyy (EOF) eikä yhteys epäonnistu. Puskurissa jäljellä oleva selväteksti luetaan ensin.
- `ktls_module.c` ja `ktls_abi.h`: uusi tilabitti `KTLS_ST_PEERCLOSE` (BearSSL:n `close_received`). Jos palvelin lähetti close_notify-viestin, data on täydellinen. Muuten nutget ilmoittaa kuten ennenkin: *"TLS stream ended without close_notify … (possible truncation)"*. Vanha moduuli ei aseta bittiä, jolloin ydin tulkitsee tilanteen varovaisesti (mahdollinen katkeaminen).
- `nutget`: 60 sekunnin aikakatkaisu, kun dataa ei tule eikä yhteys sulkeudu. Aiemmin hiljaa kuollut yhteys jäi odottamaan ikuisesti.

**Testi** (`tests/v72158_qemu_nutget_tls_rst.py`, isäntäkoneen Python-TLS-palvelin, `nutget -k`):

| Palvelin | Tulos |
|---|---|
| vastaus, close_notify, FIN | tallennettu 23 400 tavua |
| vastaus, close_notify, RST | tallennettu 23 400 tavua |
| vastaus, RST ilman close_notifyä | ei tallennettu, aikakatkaisu 60 s:n jälkeen |

Rajaus: QEMU:n slirp-verkko ei toimita isäntäpuolen RST:tä samassa järjestyksessä kuin T400:n verkko, joten tarkka -111-tilanne ei toistu QEMUssa. Korjaus kohdistuu ainoaan kättelyn jälkeiseen -111-lähteeseen, ja se vahvistetaan T400:lla.

## T400-ajo

```
ver                       (72.158)
ping 195.74.0.47          (Ctrl+C pysäyttää ja tulostaa tilaston)
nutget https://vunet.net  (nutget: saved N bytes to index.html)
```
