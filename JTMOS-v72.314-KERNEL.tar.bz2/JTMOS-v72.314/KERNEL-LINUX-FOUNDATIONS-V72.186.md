# JTMOS v72.186 – Linux-inspired kernel foundations

## Architecture and scope

This release is an **incremental compatibility experiment**, not a port of
Linux. JTMOS retains its Postman-based kernel architecture, its x86 TSS
scheduler and its native JTMFS/FAT12 VFS. Components are designed to be
incrementally adopted with explicit integration and safety gates.

| Requested feature | Current implementation and limits |
|---|---|
| 1. Modular kernel / dynamic modules | Built-in module **metadata registry** (`jt_subsystems.c`). Dynamic executable module loading is deliberately denied; relocations, signatures, ABI contracts, memory protection and safe unload are missing. |
| 2. VFS switch | Existing JTMFS/FAT12 mount registry retained. Added backend **capability registry** and registration in `vfs_mount_init()`. No ext4/btrfs/tmpfs driver was added. |
| 3. CFS with red-black tree | Implemented bounded intrusive red-black `vruntime` queue (`fairq.c`), 256 PID slots, O(log N) insert/remove; unit-tested. **Not connected** to `SchedulerPickNext` or TSS switch logic. No weights, min_vruntime clamping, deadlines, sleep credit or SMP. |
| 4. SLAB / memory | Existing buddy + SLAB caches retained. No SLUB replacement. Resource charging prototype introduced but **not enforced** by `kmalloc`/`mmap`. |
| 5. Everything is a file | Existing `FILEDES` path retained. A comprehensive unified VFS operations table for pipes/devices/sockets remains future work. |
| 6. eBPF | Explicitly disabled loader stub returns `JT_BPF_UNSUPPORTED`. Must first implement verifier, resource bounds, permission checks, BPF maps, safe contexts and JIT/interpreter rules. |
| 7. Namespace/cgroups | Memory quota accounting building block (`jt_group_*`) only; not a container or enforcement layer. Need per-process membership, credential isolation and accounting at **every allocation** and relevant I/O/syscall path. |
| 8. Netfilter/nftables | Bounded **IPv4 ingress-only** allow/drop filter before jnet and uIP. Rule install is kernel-owner API, default allow; no NAT, output firewall, user policy editor, stateful conntrack or nftables parser. Ethernet ARP remains allowed. Non-first IPv4 fragments cannot match L4 port rules. |
| 9. Page cache | 8x4096 byte read-only LRU prototype, with device/page invalidation and failed-read protection. Not yet used for JTMFS/FAT; existing block caches remain authoritative. Need write-through/coherency, device-generation validation and locking before integration. |
| 10. Syscalls / arch | New `kernel32/arch/x86/jt_arch_caps.h` declares the **supported** i686 capabilities; existing syscall dispatch unchanged. ARM/RISC-V are **not** supported. |

## Security and performance notes

- The ingress filter is intentionally allocation-free and does not execute
  arbitrary callbacks. ARP is left intact. The rule array is bounded at 16.
- The firewall handles only the Ethernet IPv4 ingress path; outbound packets,
  SLIP and IPv6 are **not** filtered by this new module. It also does not
  replace the full uIP packet validation.
- The rule manager has no user syscall and assumes network-owner serialization.
- The fair queue is a prototype; switching the scheduler to this structure
  without reliable wake/sleep bookkeeping would risk a non-booting system.
- The page-cache demonstration does not guarantee disk write coherence and
  must not be attached to JTMFS writes without invalidation and consistency tests.
- The BPF loader intentionally rejects all programs; dynamic kernel-code
  execution needs strong verification and is unsuitable as an early feature.
- In newer Linux kernels CFS has been transitioning to EEVDF. The historical
  CFS red-black queue is used here as a bounded, inspectable precursor.

## Test and build

Run on a Linux development host:

```sh
sh tests/run-v72186-foundations.sh
cd kernel32
perl autogen.pl > generated.mak
make -f generated.mak -j2 \
  core/compat/fairq.o core/compat/netfilter_lite.o \
  core/compat/jt_subsystems.o core/compat/jt_pagecache.o \
  core/compat/jt_bpf_gate.o drivers/tcpip/uipMain.o fs/vfs_mount.o
```

Do not install the inherited kernel media expecting v72.186 features.
A complete kernel link, boot under QEMU, T400 Ethernet test, filesystem stress
suite and syscall ABI review are mandatory before enabling new policies.

## Standards references

- https://www.kernel.org/doc/html/latest/scheduler/sched-design-CFS.html
- https://www.kernel.org/doc/html/latest/scheduler/sched-eevdf.html
- https://www.kernel.org/doc/html/latest/filesystems/vfs.html
- https://www.kernel.org/doc/html/latest/bpf/verifier.html
