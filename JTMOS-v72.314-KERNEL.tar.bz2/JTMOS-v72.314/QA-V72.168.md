# Navigator v72.168 – tasausten ja paikannuksen varmennus

28.10.2026. Selainpohja v72.167; käyttöjärjestelmä, ydin ja mediat v72.166.

| Tarkistus | Tulos |
|---|---|
| Tasaus, bitmap-teksti, Lexbor ja varajäsennin | PASS 69 + 69 |
| Tasaus, vektoriteksti, Lexbor ja varajäsennin | PASS 69 + 69 |
| Relative/absolute/fixed, Lexbor ja varajäsennin | PASS 48 + 48 |
| Aiemmat v72.167:n div/CSS-tarkistukset molemmilla jäsentimillä | PASS 45 + 45 |
| Yllä olevan käyttäytymismatriisin yhteismäärä | PASS 462/462 |
| Aiemmat valitsin/cascade/grid/pituus/URL-testit | PASS |
| Aiempi CSS/layout-testi | PASS 30 tarkistusta ja 120 sivun elinkaarta |
| Aiempi virheellisen CSS/HTML-syötteen testi | PASS 160 tapausta |
| Aiempi sivujen elinkaaritesti | PASS 3150 tarkistusta |
| Tallennettu Vunet-sivu, 1280/810/390 px | PASS, 1461 CSS-sääntöä |
| Tallennettu MV-sivu, 1280/810/390 px | PASS, 3867 CSS-sääntöä |
| Selaimen oma jäsennys–CSS–asettelu–piirto, testisivu 390/800 px | PASS, kuvat tarkastettu |
| Native staattinen i386/ELF32, Lexbor + QuickJS + WebP + BearSSL | PASS |
| Oikean ytimen ELF-tunnistus ja latausasettelun ennakkotarkistus | PASS, ei käyttöjärjestelmän käynnistysajo |

Muuttamaton v72.167 samoilla testeillä: tasaus bitmap-tilassa 26/69,
vektoritilassa 25/69 ja paikannus 20/48, kummallakin jäsentimellä.
Lopullisessa versiossa kaikki näistä läpäisevät. Lokeissa säilytetään
sekä pohjan epäonnistumiset että lopulliset tulokset.

Tasaustestit tarkistavat tekstin reunoja ja periytymistä, RTL:n loogista
tekstin reunaa, virheellisten ilmoitusten ohittamista, rivien tasapalstoitusta,
flexin pää-/poikkiakselia, käännettyä suuntaa, automarginaaleja, baselineja,
venytyksen rajoja, gridiä ja sen rakoja, lapsilaatikoiden omia tasauksia sekä
`place-*`-lyhytmuotojen cascadea. Inline-laatikoiden middle/top/bottom/last-line
baseline tarkistetaan todellisista piirtoalkioista.

Paikannustestit tarkistavat reunasiirtymät, prosentit ja `calc()`-lausekkeet,
padding-laatikon, automaattisen korkeuden, vastakkaisten reunojen venytyksen,
min/max-rajat, auto-marginaalit, negatiiviset ja suuret siirtymät, tekstirivin
relative-elementin ja sen absolute-lapsen sekä DOM-piirtojärjestyksen.
Fixed-testit kattavat näkymän korkeuden, vierityksen, tilahaun, osumatarkistuksen,
oikean piirtäjän pikselituloksen ja muistisuojat sekä kaksinkertaisen zoomin.
Myös transform-vanhempi, perityt muuttujat, nollakoot, opacity-värisekoitus,
100 jonotettua laatikkoa ja toistuvat uudelleenasettelut testataan.

Todisteet: `release/qa/v72.168/`. Host-ajossa ovat käytössä AddressSanitizer
ja UndefinedBehaviorSanitizer. LeakSanitizer on pois tämän ympäristön
prosessi-/säierajoituksen vuoksi; vuotovapautta ei päätellä tästä ajosta.
Tallennetut sivut ovat paikallisia HTML/CSS-fixtureja. Niiden kuvia tai
julkisia sivustoja ei ladattu eikä interaktiivista JavaScript-käytöstä
hyväksytty näillä testeillä.

GraOS-/QEMU-ajoa tai ThinkPad T400 -laitetestiä ei tehty. Koonti ja ytimen
ennakkotarkistus eivät todista selaimen käyttöliittymän toimivuutta laitteella.
Vanhoja käyttöjärjestelmän asennusmedioita ei rakennettu uudelleen.

## Toteutuksen rajat

Kyseessä on edelleen rajattu CSS-moottori. Täyttä flex/grid-algoritmia,
pystykirjoitustiloja, bidi-tekstijärjestystä tai koko RTL-laatikkomallia ei
väitetä toteutetuksi. `direction` ratkaisee tässä loogisen tekstin reunan.
Sticky-paikannus, kaikki monirivisen inline-vanhemman paikannustapaukset ja
täydelliset stacking context-/alpha-kompositointisäännöt jäävät rajojen
ulkopuolelle. Tekstin text-top/text-bottom käyttää aiempaa fonttiarviota.

Flex/grid-lasten keräys ja jonotetut out-of-flow-laatikot ovat enintään
256 kerrallaan; yhden rivin tasapalstoitus käsittelee enintään 512 väliä.
Jonon ja muistivarauksen epäonnistumiset ilmoitetaan osittaisena asetteluna.
Host-käyttäjälle asetetaan näkymä `nav_page_set_viewport`-kutsulla;
ilman sitä oletuskorkeus on 600 px. Korkeuden muutos vaatii reflow-kutsun.
Kuvien osittainen overflow-leikkaus ja elementtikohtaiset vierityspalkit
säilyvät aiemman moottorin rajoittamina.
