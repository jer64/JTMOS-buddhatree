# QA V72.206

QEMU 8086:2922 ICH9 AHCI (sama ajuripolku kuin T400:n 8086:2929). Testi: purku cdrom -> JTMFS hda1.

| Kokoonpano | sqa cdrom | core.sqa | graos.sqa |
|---|---|---|---|
| IDE hda + IDE CD (vanha polku, regressio) | 56.1 s | 16.8 s | – |
| AHCI hda (vanha ajuri, V72.205) | 35.8 s | 11.0 s | 3.9 s |
| AHCI hda (uusi ajuri) + IDE CD | 36.3 s | 13.8 s | 4.8 s |
| AHCI hda + AHCI CD (portti 1) | 28.1 s | 10.5 s | 3.4 s |
| q35 (ICH9 0:31.2, levy p0, CD p2) | 27.5 s | 9.5 s | – |

Kaikki purut onnistuivat (9 / 79 / 29 tiedostoa).

Lokit (q35):
    SATA: Intel AHCI 2922 PCS port enable 0x0 -> 0x3f.
    SATA: port 0 link up, signature=0x101.
    SATA: port 2 link up, signature=0xeb140101.
    SATA: cdrom = AHCI port 2 ATAPI 'QEMU DVD-ROM', 7219 blocks x 2048 (14 MiB), DMA read-only.
    SATA: hda registered AHCI/LBA48 model 'QEMU HARDDISK', 1048576 sectors of 512 bytes.

Profilointi (IDE): aika kuluu PIO-DRQ-pollaukseen (hd400ns/hdWaitDRQ ~31 %),
HLT/uni ~2 %. Hitaus ei johdu sleepeistä.

Ei testattu: fyysinen T400 (ALPM-herätys, staggered spin-up, PCS-bitit ovat
QEMUssa triviaaleja), DVD-levyn vaihto lennossa.
