# V72.230 – varmennus

Navigatorin natiivikäännös onnistui (ELF32/i386, entry 0x80004000,
512 MiB:n muistipyyntö). Kernel on pohjapaketista, eikä käynnistystestiä tehty.

Host-testeissä käytettiin selaimen varsinaista HTML5/Lexbor-jäsennintä,
CSS-järjestelmää, asettelua, piirtämistä ja GraOS-käyttöliittymän
navigointi-/tyylilatauslogiikkaa. Verkko- ja näyttörajat korvattiin hallituilla
syötteillä. ASan/UBSan, 256 KiB:n pino, ei havaittuja virheitä näissä ajoissa.

- Neljä 2.11.2026 verkosta haettua sivua: Yle ja MTV, etusivu ja uutisjuttu.
- Kuusi asettelua sivua kohti: 360/800/1024 px, bitmap-/vektorifontti.
- Maalatut otsikot, ei osittaisuuslippuja, piirtopuskurin suojasanat ehjät.
- Käyttöliittymän CSS-alkuperä ja uudelleenohjaukset, viimeinen estetty CSS,
  worker-paineen uudelleenyritys; Apollo/Flight ja Unicode; rikkinäinen JSON
  ja virheellinen surrogaatti; streamatut HTML-rajat/segmentit; lukutila.
- Kahdeksan säilytettyä CSS-/asettelutestiohjelmaa läpi, lisäksi web-testi
  ajettiin molemmilla fonteilla. Worker-lähdekoodisopimuksen testi läpi.
- Nykyisen Navigatorin tavut tarkistettiin ISO:n puretusta network.sqa:sta.
  Yhdeksän ulkopakettia, pakkausten purku ja peilien tavut tarkistettiin.

Tarkka toimitusidentiteetti: `release/qa/v72.230/delivery.json` ja
`release/qa/v72.230/media-check.json`. Sivuvastausten tarkistussummat:
`release/qa/v72.230/live-results.json`. Raakoja sivukopioita tai host-kuvia
 ei jaeta lähdekoodipaketissa.

Ei QEMU-/T400-käyttötestiä eikä JTMOSin oman TCP/TLS-yhteyden
päästä päähän -testiä. Host-renderöinti ei todista videotoiston,
kirjautumisen tai täyden React-toiminnallisuuden yhteensopivuutta.
