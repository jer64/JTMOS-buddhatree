# JTMOS v72.250 – kernel BSS/early-stack link fix

This is a source-level correction to v72.250; VERSION remains 72.250.

## Root cause

The canonical memory map puts kernel BSS at 0x00200000 and the 64 KiB
bootstrap stack at 0x002E0000–0x002EFFFF. The pre-existing BSS had only
~15 KiB of headroom. The v72.249 emergency flight recorder declared an
additional 64 KiB global array, overflowing into the early stack.
The linker guard correctly refused to generate an unsafe executable.

## Correction

* Preserve the full 64 KiB flight recorder; move it out of `.bss` into a
  dedicated `.flightlog` NOLOAD section at 0x00B00000–0x00B0FFFF.
* Reserve this area in canonical C, NASM and linker memory maps, and start
  the physical allocator at 0x00B10000 instead of 0x00B00000.
* Identity-map the reserved flight-log pages when enabling paging.
* Zero `.flightlog` explicitly in `_boot_up_c()` after verifying A20, before
  ordinary kernel initialization.
* Retain the original early stack, page table and BSS overlap checks.
* Verify `.flightlog` address/type/size in `check_kernel_image.py`.
* Add `tests/v72250_bss_flightlog_link.py` and keep the older flight recorder
  regression compatible with the new size constant.

This reserves another 64 KiB of physical memory; it does not move
existing page tables or modify the on-disk JTMFS format.

## Validation

* `make release-check-source`: PASS. Includes crash/atomic-move/replace
  recovery and the new two-linker-script BSS/flightlog test.
* C compilation with JTMOS i386 flags: `core/int/debug.o`, `init/start.o`,
  `mm/paging.o` PASS.
* A synthetic kernel with 860,000 B of live BSS links correctly with
  `.flightlog` mapped at 0x00B00000; a 930,000 B BSS is still rejected.
* The synthetic ELF-to-raw conversion does not emit the NOLOAD area.
* Full kernel linking, boot image rebuild and real-hardware validation:
  **NOT EXECUTED** in this environment (NASM unavailable).

The archive may still include inherited older boot media and cached ELF
files. These are **not** newly built v72.250 BSS-fix binaries.

## Build on your development host

```
make -C kernel32 clean
make -j2
```

Or, if your build system runs kernel assembly and link on a standalone target:

```
make -C kernel32 linkit
```

The full build requires NASM and the usual JTMOS toolchain. Run the first
boot against a disposable QEMU disk image before testing on T400 hardware.
