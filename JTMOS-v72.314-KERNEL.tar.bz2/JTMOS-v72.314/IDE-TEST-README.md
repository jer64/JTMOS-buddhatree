# JTMOS v72.209 — PIIX IDE corruption reproduction launcher

`run_jtmos_qemu_ide.sh` is an independent launcher for the QEMU emulated **IDE/ATA** disk path. It does not attach an AHCI device. It is intentionally separate from `run_jtmos_qemu.sh`, `run_jtmos_qemu_sata.sh`, and their disk images.

## Quick start

```sh
chmod +x run_jtmos_qemu_ide.sh
./run_jtmos_qemu_ide.sh                 # new 512 MiB sparse raw IDE test disk on first run
./run_jtmos_qemu_ide.sh --hash-disk     # record host-side SHA-256 before/after each run
./run_jtmos_qemu_ide.sh --snapshot      # throw away writes, useful for read-only comparisons
./run_jtmos_qemu_ide.sh --cache none    # compare QEMU host-cache behavior
./run_jtmos_qemu_ide.sh --cache directsync
./run_jtmos_qemu_ide.sh --reset --confirm-reset  # move old test image to a backup and start fresh
./run_jtmos_qemu_ide.sh --dry-run       # display the effective QEMU command
```

Requires `bash`, `qemu-system-i386`, and `truncate`. The last is normally in Ubuntu coreutils. The launcher checks for QEMU; this package does not install it.

The boot path is the original **floppy A** (`jtm32.img`); floppy B is `root1440.img`. The IDE **primary master** disk is `ide-test/hd_jtmos_ide_test.img` (raw) and IDE **secondary master** is the `utilities.iso` ATAPI medium. The HDD and optical drive share QEMU's built-in PIIX IDE controller (`-machine pc`); no `ich9-ahci` is present. Floppy and ISO are read-only. Guest network is disabled to reduce noise. Serial output goes to a unique directory under `ide-test/logs/` each time.

### Reproduce possible corruption safely

1. Start with a **new expendable** test image. In the JTMOS guest, `mkfs hda` creates an empty JTMFS filesystem on the test disk (destructive). Do this only on the dedicated test disk.
2. Find a known-good file on the boot/root media, then copy it to a new directory on `hda:`. For example, if `sys:/bin/tail.bin` exists on your installation, use:

   ```text
   mkdir hda:/ide-test
   cp sys:/bin/tail.bin hda:/ide-test/tail.bin
   cmp sys:/bin/tail.bin hda:/ide-test/tail.bin
   ```

   If `sys:/bin/tail.bin` is unavailable, choose another confirmed existing file using `ls`. `cmp` exits nonzero on mismatch; inspect stdout for details.
3. Repeat copy/compare **without reboot**, preferably with large and small files and repeated overwrite of the same target. Observe errors in `ide-test/logs/.../serial.log` and in JTMOS `/var/log/kern.log` if writable.
4. Shut down, then relaunch **without `--reset` or `--snapshot`** and rerun `cmp`. This distinguishes write/read errors from persistence/flush errors.
5. Repeat on the same test disk with `--cache none` (host page-cache bypass) and with `--cache writethrough` (default). This does not change JTMOS's own caches. Treat a cache-mode difference as a diagnostic clue, not proof of one faulty subsystem.
6. Save serial logs and the exact commands, disk mode, QEMU version, and checksum comparisons. Never format or modify a valuable host image.

### Important precautions

- `--snapshot` **discards guest writes on exit**. Do not use it to test persistence across reboots.
- The default disk is **persistent** so repeated corruption can be investigated.
- The launcher refuses `/dev/*` device nodes, boot/root images, symlinked images, and non-test existing disks unless explicitly allowed. Only launcher-created, marked disks can be reset, and reset keeps a renamed backup.
- The host-side SHA-256 from `--hash-disk` tells whether the *raw image changed*, not whether a guest file is valid. Use in-guest `cmp` for content validation.
- IDE firmware and JTMFS bugs remain unmodified. This release is a **test launcher**, not a fix for IDE corruption.
- The kernel and boot images bundled in v72.209 are carried over from v72.208; they are **not rebuilt** as part of this script-only release.

## Test coverage

`test_run_jtmos_qemu_ide.sh` invokes the launcher with a *fake QEMU executable* and checks argument formation, image isolation, snapshot mode, input guards, reset safety, caching variants, log output, and no-state dry-run. It does **not** prove that QEMU boots the OS or that the IDE guest driver works. A real QEMU integration test is still required.
