# Navigator v71.125 bounded-memory mitigation

Source review identified an eager 24 MiB DOM arena in nav_dom_create(), a 100000-node limit and 192-deep tree traversal. The DOM arena is now bounded to 12 MiB, the node limit to 40000 and nesting to 96. Existing allocation failure handling and the F6 legacy-text fallback remain intact.

This is a conservative memory-pressure mitigation, not a verified fix for every hang or crash. CNN and Fox News were not tested on physical JTMOS hardware; sysmemreq, image decoding, networking and Lexbor allocations may still require separate profiling. No compiled Navigator binary is claimed in this release.
