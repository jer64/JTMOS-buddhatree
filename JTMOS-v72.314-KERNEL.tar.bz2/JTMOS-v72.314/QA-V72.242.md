# JTMOS V72.242 — validation, 2026-11-03

The regression target is disappearing directory listings after a metadata
failure and FHS installation from an independent GraOS SMSH console.

| Check | Result |
|---|---|
| V72.241 injected write failure, then list existing root | Reproduced: empty listing and `?#` prompt |
| Before DAPI lifetime fix, second GUI FHS install | Reproduced: SQA header rejected, illegal memcpy from readblocks; physical source remained byte-exact |
| Final IDE write failure / write freeze | PASS — root/bin files readable, new mkdir rejected |
| Frozen volume raw physical inspection | PASS — no invalid entries/chains/crosslinks/size errors; CLEAN |
| Extract readable FHS source from frozen disk into healthy RAM | PASS — 14 entries, verified README, no extraction failure |
| AHCI, seriallog off, two complete outer SQA extracts | PASS — all 9 compressed packages each time; final physical fsck CLEAN |
| Hard reset with unsynced directory queue | PASS — synced keep directory remains; no bad entries/chains/crosslinks/size errors; conservative orphan repair and final scan CLEAN |
| Real chain I/O host checks | PASS — partial/direct/large-cluster/error/overflow |
| Real DIRDB writeback ASan/UBSan | PASS — 792 boundary/AfterFat/low-memory fallback cases |
| Repeated SQA replacement and corrupt input host checks | PASS |
| NZIP codec, package and independent publish contract | PASS |
| i686 kernel image / bootstrap / BSS gate | PASS — 945856 bytes; 102720 bytes free in 1 MiB budget |
| Final release media identity gate | PASS — BIOS/root/DOSBOOT/package copies consistent |
| Rebuilt sqa/nzip/unz/sqsh binaries in core.sqa | PASS — byte-for-byte identical to build outputs |

GUI final acceptance: PASS — five consecutive FHS installs in independent
SMSH terminal 10, root/bin and README remain visible after each; KLOGGER stop,
explicit sync, then raw physical scan CLEAN. Result JSON and transcripts saved.

Final QEMU checks use separate disposable 512 MiB IDE/AHCI disks (2 GiB for
the blkdebug failure fixture), 1024 MiB RAM and the text/nogui kernel. The GUI
check starts the real GraOS server, opens the real smshgui client using desktop
keyboard search, and runs the real fhsinstall.sh -> SQSH -> isolated kernel SQA
worker path. KLOGGER runs during installs; the test stops it and syncs before
its final raw physical scan. --raw intentionally omits sync, so inspection
while normal logging/preallocation is still active can show uncommitted blocks.
This must not be mistaken for a post-sync integrity result.

Source changes: all five long-lived DAPI allocations use persistent kernel
ownership; failed DB groups block mutations instead of reads; dirty DIRDB/FAT
writeback stays frozen; atime is skipped on failed volumes; missing committed
FAT pages may be read privately; allocator lock order is volume -> allocator
-> FAT cache; SQA only syncs its destination; rename reports useful errno.
The full ZIP also restores the 21 byte-equivalent source directory aliases as
Unix symlinks using the repository's validating restoration tool.

Limits: no physical T400/ASUS test, real power cut, or FreeDOS execution was
available. The initial T400 staged-rename error itself is not yet reproduced;
its serial log is needed to identify the first failing write/barrier. The
reproduced DAPI lifetime bug and metadata read lockout are real source defects,
but do not prove that the user's physical data remain intact. This kernel
cannot restore bytes already lost. Do not format or run repair on the original
disk merely because the listing is blank. --raw controls the checker, not
whole-system forensic write blocking or I/O already in flight.

Unchanged application binaries are retained from the previous full release;
sqa/nzip/unz/sqsh and libc were rebuilt. DOSBOOT and its kernel/media copies
were rebuilt and verified. Tests and text evidence are in release/qa/v72.242.
