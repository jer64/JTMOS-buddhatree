# JTMOS V72.263 – Navigatorin navigoinnin muistiraja

Päiväys: 5.11.2026. Pohjana on tähän keskusteluun liitetty
`JTMOS-v72.259-FULL-SOURCE-RELEASE.zip` ja havaintoaineistona
`denied_navigation_nav.log`.

## Korjattu vika

Versio 72.257 lisäsi toisen kuvien vastaanottopuskurin. HTTP-muistin
komponenttiraja jäi kuitenkin 24 MiB:uun. Ensimmäinen sivu käyttää valmista
vastaanottopuskuria. Seuraava sivu tarvitsee erillisen puskurin, jotta vanha
sivu säilyy luettavana latauksen tai virheen aikana.

| UI-prosessin varaus | Koko täysillä puskuriasetuksilla |
| --- | ---: |
| Näytettävän sivun lähde / ensimmäisen sivun vastaanottopuskuri | 8 MiB |
| CSS-vastaanottopuskuri | 4 MiB |
| Kuvan vastaanottopuskuri 1 | 4 MiB |
| Kuvan vastaanottopuskuri 2 | 4 MiB |
| Perusvaraukset yhteensä | 20 MiB |
| Seuraavan sivun erillinen vastaanottopuskuri | 8 MiB |
| Sivunvaihdon aikainen HTTP-varaus yhteensä | **28 MiB** |

`navigate_request()` tarkistaa seuraavan 8 MiB:n varauksen ennen verkkopyynnön
aloittamista. Vanhalla rajalla 20 + 8 > 24, joten tarkistus estää uuden
sivulatauksen riippumatta suuresta koko selaimen muistibudjetista. Virhe
koskee täysikokoisia puskureita; pienemmillä myönnetyillä muistialueilla
puskureiden koot voivat olla pienemmät. Saman dokumentin ankkurisiirtymä ei
varaa uutta sivupuskuria.

## Muutokset

- Kuvien siirtojonon koko määritellään yhdessä paikassa `navigator_core.h`:ssa.
- HTTP-raja lasketaan todellisista sivu- ja resurssipuskurien koista sekä
  kuvajonon koosta. Täysillä koilla raja on 28 MiB. Esimerkiksi 4/2 MiB:n
  sivu-/resurssipuskureilla se on 14 MiB ja 2/1 MiB:n puskureilla 7 MiB.
- HTTP-komponenttiraja rajataan koko selaimen budjettiin. Kokonaisbudjetin
  tarkistus ja epäonnistuneen latauksen aikana säilytettävä vanha sivu ovat
  käytössä. Rajan laskenta ei kasvata vastaanottopuskureita tai kernelin
  prosessialuetta eikä muuta TCP-paketteja.
- Budjettirajan ja allokoinnin aiheuttamat navigoinnin estot kirjataan lokiin
  numeerisilla muistitiedoilla. Uusissa merkinnöissä ei ole URL-osoitteita,
  lomaketietoja tai sivun sisältöä.

## Mitä liitetyssä lokissa havaitaan

Lokissa on useita istuntoja versioista 72.243 ja 72.259. Version 72.259
istunnossa 5.11. klo 11.20 toinen ikkuna saa 512 MiB:n virtuaalisen
muistialueen, ja järjestelmä ilmoittaa yli 2 GiB vapaata muistia. Sen
`fork()` epäonnistuu 25 kertaa virheellä `ENOMEM`, vaikka sen omia
verkkotyöprosesseja ei ole käynnissä. HTML saadaan ladattua saman prosessin
varareitillä, mutta CSS ja kuvat jäävät työprosessien varaan. Tämä on
**erillinen ongelma** yllä korjatusta 24 MiB:n budjettivirheestä.

Kernelin lähteessä dokumentoitu suurten prosessien COW-aliasalueen raja on
mahdollinen selitys työprosessien puutteelle. Fyysisen RAM-muistin määrä ei
itsessään varmista riittävää yhtenäistä kernelin virtuaalialuetta. Tässä
lokissa ei ole kernelin virtuaalialueen vapaan tilan mittausta, joten täsmällistä
`fork()`-epäonnistumisen syytä ei ole varmistettu tällä aineistolla.

Lokissa ei ole uutta `UI navigation denied` -merkintää, koska toimitetussa
versiossa juuri näitä paluita ei kirjata. 24/28 MiB:n virhe on varmistettu
lähdekoodista ja toistettu tuotannon navigointifunktiota käyttävällä testillä.
DuckDuckGo-kuvakkeen yksittäinen HTTP 404 ei ole koko navigoinnin eston syy.

## Paketin rajaus ja käyttö

Tämä on täydellinen lähdekoodipaketti liitetyn V72.259-paketin pohjalta,
sisältäen uuden `libc/apps/navigator.bin`-binäärin. Versiotunnus on V72.263,
koska erillisissä kehityshaaroissa on jo käytetty tunnuksia V72.260–V72.262.
**Näiden erillisten säie-, VM- ja FD-korjausten sisältöä ei ole yhdistetty tähän
haaraan.** Sovella tämän haaran Navigator-muutokset erikseen, jos käytät jo
niitä sisältävää uudempaa lähdepuuta.

Erikseen toimitettava `jtmos-navigator-v72.263.bin` on sama tiedosto kuin
paketin `libc/apps/navigator.bin`; sen voi asentaa käyttämäsi Navigator-binäärin
tilalle. Tämä korjaus ei vaadi kernelin muutosta.

Täyttä release-ZIPiä varten myös kernel, ohjelmat, asennuspaketit,
käynnistyslevykuvat ja DOSBOOT-paketti rakennettiin uudestaan. Julkaisumedioiden
sisäisten binäärien yhtäläisyys tarkistettiin käännöstuloksia vasten.
Uusi käynnistyslevykuva läpäisi QEMU-käynnistystestin: BIOS/NZIP, kernel,
SMSH sekä RAM-levyn mkdir/cd/help-komennot toimivat. Tarkistustulokset ovat
tiedostossa `QA-V72.263.md`. T400-ajotestiä ei tehty tässä ympäristössä.
