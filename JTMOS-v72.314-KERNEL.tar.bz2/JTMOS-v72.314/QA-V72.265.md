# JTMOS V72.265 – tarkistukset

| Tarkistus | Tulos |
| --- | --- |
| `make -j2 full-build` (GCC 13.3.0) | PASS |
| Kernelin kuvabudjetti GCC 13.3: 934528 tavua, 114048 vapaana (raja 65536) | PASS |
| Kernelin kuvabudjetti GCC 12.4 (vain kernel): 940448 tavua, 108128 vapaana | PASS |
| `tests/v72265_pit_clock_model.py` (C-kokonaislukuaritmetiikka vs. 3579545/3 Hz) | PASS |
| `tests/advanced_pit_model.py`, `tests/scheduler_policy_v67854.py` | PASS |
| QEMU-käynnistys (lopullinen media) | PASS |
| QEMU-verkko v72.145 (lopullinen media) | 10/10 PASS |
| QEMU-lataus 8 MiB (sama koodi, julkaisunimeä edeltävä build) | PASS, 1856 KiB/s |
| GraOS-kalenteri v72.160 (sama koodi, julkaisunimeä edeltävä build) | PASS |
| GraOS-leikepöytä v72.160 | 1/4. Täsmälleen sama tulos muuttamattomalla V72.263:lla, joten vika on vanha |
| T400 / EL1352 | Ei ajettu |

PIT: ajettu kernel ilmoittaa `divisor=4773, IRQ rate=250 Hz, exact clock ~= 4000 us/IRQ`.
Jakaja ei muuttunut. Tick- ja mikrosekuntimuunnos käyttää nyt tarkkaa
taajuutta 1 193 181,667 Hz. Vanhan vakion aiheuttama virhe oli 1,40 ppm
(0,121 s/vrk). Lyhyessä QEMU-ajossa näin pientä eroa ei voi mitata, joten
oikeellisuus on varmistettu mallitestillä.

Kokomarginaali: V72.264 kaatui GCC 12:lla (`kernel margin 64160 < 65536`).
`-mpreferred-stack-boundary=2` (i386-kernelin 4 tavun pinotasaus, kuten Linuxissa)
pienentää kerneliä noin 41 KiB, ja marginaali on nyt yli 100 KiB kummallakin GCC:llä.

Lokit: `validation-v72.265/`.
