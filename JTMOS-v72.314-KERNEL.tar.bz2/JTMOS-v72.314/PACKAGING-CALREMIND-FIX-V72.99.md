# JTMOS v72.99 — calremind.bin installation/package inventory fix

## Failure addressed
`make packages` stops with:
```
build_install_image: unclassified built application: calremind.bin
make: *** [Makefile:187: packages] Error 1
```
The `libc/apps/Makefile` explicit application inventory listed `calendar` but omitted `calremind`, although `libc/apps/calremind.mak` builds the reminder daemon and `tools/build_install_image.sh` expects it in `GRAOS_APPS`. Consequently, an independently built `calremind.bin` was rejected by the package inventory guard.

## Actual change
`libc/apps/Makefile`: add `calremind` immediately after `calendar` in `SIMPLE_APPS`. The canonical application inventory now contains 112 programs; the GraOS packaging whitelist was already correct. No kernel, Ethernet driver, application behavior, or GraOS cursor code changed.

## Verification performed
- `tests/v7299_calendar_package_inventory.py`: PASS, all 112 expected binaries present and no unclassified executable.
- Full `tools/build_install_image.sh` on v72.99 working tree: PASS; created `tools/install_payload/graos.sqa`, `tools/utilities.sqa`, and `tools/utilsdisk.img`.
- Independent complete SQA program check: PASS, 122 distributed program binaries, exactly one package each.
- Full `tools/build_install_image.sh` on patched v72.94 tree: PASS (same initial error reproduced in inventory, then cleared after patch).
- Published `utilities.iso`, `utils.iso`, `kernel32/utilities.iso` using the existing publishing script.
- Warning: `boot32/nonsysdisk.bin` missing, and sqarc zero-fills an optional safe area. Packaging succeeded; inspect if using the legacy boot32 path.

## Source-only warning
This is a *packaging repair*. The kernel and DOSBOOT were not rebuilt in the current environment, so binaries retained from previous source archives must not be mistaken for new v72.99 kernel/DOSBOOT builds. The pre-existing Ethernet fixes v72.95-v72.98 remain in source but have not been hardware validated.

## Apply directly to JTMOS v72.94 checkout
```
cd ~/JTMOS-v72.94
patch -p1 < /path/to/JTMOS-v72.94-calremind-build-fix.patch
make packages
```
Or edit `libc/apps/Makefile` manually to change `partition calendar pdump` into `partition calendar calremind pdump`.
