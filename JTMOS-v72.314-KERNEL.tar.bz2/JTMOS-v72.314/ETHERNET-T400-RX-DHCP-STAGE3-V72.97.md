# JTMOS v72.97 — ThinkPad T400 Intel 82567LM RX/DHCP stage 3

**Scope:** Complete JTMOS source release based on v72.96. Changes are limited to `kernel32/drivers/tcpip/ich9e.c`, `ich9e.h`, `ethdev.c`, `ethdev.h`, `kernel32/sh/networkapp.c`, the version metadata and tests.

## Changes

1. Programs RXDCTL0 with the Intel e1000e legacy receive DMA burst configuration (`0x01040420` in the threshold/granularity fields), with RDTR=0, RADV=0 and software RX checksum offload disabled in the polling driver. Queue 1 is left untouched. Reads back the programmed registers and refuses an incomplete MAC ring setup.
2. Asserts basic 2048-byte, single-buffer, CRC-stripped RX mode and checks the critical RCTL bits on startup.
3. Adds explicit RX descriptor lifecycle accounting, including DD ownership, CRC/frame-error drops, malformed DMA descriptor addresses, partial frames and ring wrapping. Incomplete multi-descriptor frames are discarded through EOP rather than passing a trailing fragment to ARP, DHCP or uIP as a new packet.
4. Adds RX counters and read-only descriptor snapshots (`inet hw`): DMA DD events, idle polls, errors, ARP, IPv4 and *candidate* DHCP replies, plus currently pending descriptor status. These counters do not validate the network payload.
5. Adds `inet hw test rx`, a passive 1-second status sampler that does not consume frames and does not touch PHY, NVM or MAC reset controls. It can run concurrently with the JNet/uIP receive owner.
6. Records RX mutex-contention polls separately in `ETHDEV_STATS.rx_busy_polls`, instead of implying the NIC had no frames. API continues to treat contention as a no-frame result for polling callers.
7. Preserves v72.95 TX probe, v72.96 coherent PCIe DMA and checked-master quiesce, plus all GraOS/Calendar/Navigator source.

## Safety/limits

- **This is an UNBUILT full-source release**. The updated kernel modules are ELF32 objects, but `kernel32.bin` and DOSBOOT have NOT been fully rebuilt (NASM absent). Binaries already present in the full archive may predate this change. Do **not** claim the included kernel executable exercises v72.97 RX code.
- A genuine 82567LM receive test requires rebuilding the kernel and testing on the ThinkPad T400. The RX simulation only validates software descriptor logic and simulated MMIO behavior; it does not confirm PCI DMA/PHY/link operation.
- v72.95/v72.96 TX progress must still be proven in hardware. This stage cannot guarantee DHCP if TX does not advance.
- `inet hw test rx` does not manufacture broadcast traffic; generate ARP from a second device on the same segment, and check RDH, hardware descriptors and RX counters. An idle network yielding no RX events is not enough to condemn the driver.
- Polling consumes frames on the normal owner path; the new command itself is passive. The `rx_dhcp_frames` counter is a non-authoritative diagnostic candidate, not a verified DHCP packet.
- Jumbo frames, VLAN-tagged frames, checksum offloads, fragmented receive packets and Intel NVM/PHY writes remain unsupported/disabled. This is intentional for legacy RX bring-up.

## Suggested T400 test

After a **full kernel rebuild** from this source, with the network on a controlled local LAN:

```
inet restart
inet hw
inet hw test rx
inet hw
inet status
inet stats
```

On another Linux machine attached to the same segment, generate an ARP broadcast/ordinary IPv4 traffic and check there is a packet the T400 should receive. A switch may not flood all unicast traffic to the T400; use broadcast traffic first. After confirming hardware RX, inspect DHCP DISCOVER/OFFER/REQUEST/ACK with tcpdump as needed.

## Linux reference

Linux e1000e: `drivers/net/ethernet/intel/e1000e/netdev.c` configure_rx path, and `drivers/net/ethernet/intel/e1000e/e1000.h` `E1000_RXDCTL_DMA_BURST_ENABLE`. Hardware settings are based on the legacy descriptor format only and are limited to PCI 8086:10f5.
