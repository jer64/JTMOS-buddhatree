# JTMOS v72.96 – ThinkPad T400 / Intel 82567LM MAC/TX-DMA stage 2

**FULL SOURCE, UNBUILT SYSTEM RELEASE.** Derived from the complete v72.95 source tree. This is not a bootable v72.96 kernel image: kernel32.bin and DOSBOOT binaries in the tree are older. Build them on the user's Linux development machine before testing. No T400 hardware validation has been performed.

## Scope and register reference

- Exact PCI device match 8086:10F5, Intel ICH9M LAN MAC / 82567LM PHY. No other Ethernet backend changed.
- `kernel32/drivers/tcpip/ich9e.c`: configure PCIe GCR at MMIO offset `0x5B00` so the six no-snoop request bits `[5:0]` are cleared. Preserve all other firmware-controlled GCR fields and verify readback. Source reference: Linux `e1000e/ich8lan.c` (`e1000_init_hw_ich8lan()`) and `e1000e/mac.c` (`e1000e_set_pcie_no_snoop()`). Intel ICH9LAN uses snoop-coherent DMA; this is not the ICH8 reversed-polarity configuration.
- Increase the page-aligned BAR0 MMIO mapping end from RAH0 at `0x5404` through GCR at `0x5B00`, with the same page rounding as the existing mapping.
- `hardware_setup()`: disable RX/TX and set MAC `CTRL.GIO_MASTER_DISABLE=1` before reinitializing DMA descriptors. Wait until `STATUS.GIO_MASTER_ENABLE=0` (max 800 * 100us = 80ms). Reference: Linux `e1000e/mac.c` `e1000e_disable_pcie_master()` and `MASTER_DISABLE_TIMEOUT=800`.
- **Fail closed** on timeout (`error=-13`): preserve descriptor buffers; do NOT invoke `ring_reset()`, change the PHY or force-complete TX descriptors. A device/firmware issue can still require a cold power cycle.
- **Fail closed** on GCR write/readback failure (`error=-14`) and on MAC CTRL master re-enable failure (`error=-15`). Enable TX/RX only after the PCIe master-disable bit is cleared, and verify RCTL/TCTL enable readback (`error=-16`).
- `inet hw` now prints `GCR`, `no-snoop` bits, DMA-quiesce attempts, success flag, failure count and last STATUS; these readings distinguish earlier silent MAC bring-up failures.
- Existing v72.84 TXDCTL/TARC/CTRL_EXT/RFCTL setup, v72.95 one-frame TX probe and PHY read-only policy are preserved. No interrupt-driven mode, PHY/NVM writes, flash access, ME reset, MSI, checksum offload or general MAC reset has been added.

## Test on ThinkPad T400 *only after kernel rebuild*

1. Connect T400's Intel 82567LM to an isolated/test LAN and power-cycle if firmware left DMA in a stalled state. Build v72.96 **kernel32.bin** and boot it with DOSBOOT; merely copying the source ZIP does not install a new NIC driver.
2. Start the NIC if necessary, then run `inet hw`. Confirm `ICH9E v72.96`, `ring-check=1`, `GCR ... no-snoop=0`, and `PCIe DMA quiesce: ok=1`.
3. To isolate from DHCP, stop normal networking before `inet hw test tx` (be aware that `inet stop` can deactivate your Ethernet backend; if this happens use the normal network initialization path). Run `inet hw test tx` **only on the controlled test LAN**. It submits one 60-byte broadcast with experimental EtherType `0x88B5` and the v72.95 marker.
4. Use a Linux host that can actually see T400's broadcasts on the same L2 segment: `sudo tcpdump -ni <iface> -e 'ether proto 0x88b5'`. A switch port not mirroring packets from another unicast destination will not see those packets; probe is broadcast.
5. Share `inet hw` diagnostics from before/after, and TX probe's `TDH`, `TDT`, `DD` and error codes. DD is NIC descriptor processing, not independent proof of transmission over the wire.

**No claim that DHCP, RX or the NIC TX engine already works on real hardware.** The stage-2 software fixes target a plausible MAC/PCIe DMA root cause and fail-safe restart, but hardware results remain necessary to select further changes. Stage 3 (RX/DHCP) remains separate.

## Reference sources

- Linux e1000e: https://codebrowser.dev/linux/linux/drivers/net/ethernet/intel/e1000e/mac.c.html
- Linux e1000e ICH8/9/10: https://linux.googlesource.com/linux/kernel/git/torvalds/linux/+/54ac9ff8f1196afc49d644a1625e0af1c9fcf7f5/drivers/net/ethernet/intel/e1000e/ich8lan.c
- Linux e1000e register offsets: https://codebrowser.dev/linux/linux/drivers/net/ethernet/intel/e1000e/regs.h.html
