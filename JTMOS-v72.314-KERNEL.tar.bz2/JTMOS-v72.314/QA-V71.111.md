# QA – JTMOS V71.111

Ympäristö: Ubuntu 24.04, GCC 13.3, NASM 2.16, QEMU 8.2 (TCG), 2026-10-19.
Lokit: `release/qa/v71.111/`.

## Käännös
| Kohde | Tulos |
|---|---|
| `make full-build` (kernel32, libc, sovellukset, jtm32.img, root1440.img, utilities.iso, DOS-paketti) | PASS, -march=i686 |
| BearSSL `build-jtmos/libbearssl.a`, Lexbor `liblexbor-jtmos.a` uudelleen i686:lle | PASS (CMOV-käskyjä mukana) |
| `tools/check_public_version.sh` | PASS (V71.111) |

## Host-testit (`tests/run-v71111-ci.sh`, ASan/UBSan)
| Testi | Tulos |
|---|---|
| v71111_rng_jitter: jumittunut/lineaarinen/neliöllinen laskuri ei saa hyvitystä, RCT+APT, 256 bittiä (TSC) / 1024 reunaa (PIT), deterministinen johdanto | PASS |
| v71111_nav_https: kaikki Set-Cookie-rivit + 400-tavuinen cookie, HSTS-päivitys, chunked ilman sulkua (50 ms), kehystetty vastaus ilman close_notifyta, kehystämätön hylätään, 404-sivu, TLS-istunnon uudelleenkäyttö | PASS |
| Sama testi alkuperäistä v71.110-koodia vastaan | 5 kohtaa FAIL (cookie, HSTS, chunked 6 s, 404, resumption): testit todentavat korjaukset |
| run-v71108-rng-ci.sh (v71.104–v71.108 ketju: BLAKE2s/ChaCha20, kernel-CRNG, seed-pooli, syscallit, TLS-politiikka, setup, DNS, IPC) | PASS |
| run-v7189 … v7196, v71104 Navigator-sarjat | PASS |

Tarkoitukselliset testimuutokset: v7197 (pelkkä domain -> https://), v71104 (CBC-SHA256 hyväksytään, SHA-1-CBC hylätään), v71108 native --legacy (CRNG on jo valmis ilman poolia).

## Native QEMU (`tests/v71111_native_auto_https.py`)
Pentium III (ei RDRAND), BIOS-kello 2001-01-01, ei seed-poolia, ei tlsseedctl/rngctl-komentoja; testi-NTP- ja TLS-palvelin isännässä.

| Tarkistus | Pentium III | -cpu max |
|---|---|---|
| i686-kernel bootaa | PASS | PASS |
| CRNG valmis | TSC-jitter 1104–1196 ms, 259 reunaa, 0 terveysvirhettä | laitteisto-RNG |
| KTIMED asettaa kellon (korjaus noin 814 000 000 s) | PASS | PASS |
| Varmennettu HTTPS (TLS 1.2 ECDHE-ECDSA-AES256-GCM) | PASS | PASS |
| rngseed.bin kirjoitettu (FAT12, 64 tavua) | PASS | PASS |
| 2. boot: siemen luettu (seed_loaded 1) ja HTTPS | PASS | PASS |

Lisäksi:
- v71108_native_rng_tls (modern ja legacy): PASS.
- JTMFS-levy (`mkfs hda`, root hda:): `hda:/cfg/rngseed.bin` kirjoitettu, `rngstat` seed_stage ok.
- QEMU `-cpu 486`: pysähtyy viestiin "requires an i686-class CPU".

## Ei testattu
- Fyysinen eMachines EL1352 (MCP61/nForce-verkko, todellinen TSC-jitter ja CMOS-kirjoitus).
- Julkiset verkkosivut ja julkiset NTP-palvelimet: tämän ympäristön verkko on rajattu, joten testit ajettiin paikallisia testipalvelimia vasten.
- Navigatorin graafinen käyttöliittymä GraOS:ssa: HTTP/TLS-koodi on testattu hostilla ja ELF-preflightillä, mutta ikkunaa ei klikattu.
- `tests/v71107_native_tls.py` on vanhentunut jo V71.108:sta lähtien (odottaa lähdenimeä "kernel hardware RNG"), eikä sitä ajeta missään CI-ketjussa.
