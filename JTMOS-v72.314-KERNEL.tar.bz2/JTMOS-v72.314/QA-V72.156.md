# JTMOS v72.156 – QA

Päiväys 26.10.2026. Pohjana on kokonainen v72.155-lähdepaketti (SHA-256 `c0dac6b8…dd89554`).

| Tarkistus | Tulos |
|---|---|
| Natiivi koonti ja media | PASS |
| ICH9E-ajurimallit v72.108–v72.156 | PASS; txmatrix kulkee nyt saman restart-polun kuin rauta |
| v72.156: PBA RX=8, PBS=16 ja palautus | PASS: PBA:n RX-kenttä 8, PBS 0x10, palautuksen jälkeen 0x18 ja 18 |
| Mutaatiot (inherit_pba, foreign_flag_clear, veto_phy_reset, inherit_wakeup, enable_at_init, no_tdh_reclaim) | kaikki hylätty |
| QEMU: kiinteä osoite, DHCP ja verkkoregressio | PASS, 10/10 |

Rajaus: PBA/PBS-hypoteesi mitataan T400:lla. Käsikirjaa ei ole mukana paketissa; viittaukset ovat tiedostossa `release/qa/v72.156/intel-sdm-references.txt`.
