# Navigator GraOSissa – analyysi ja toteutetut uudistukset

**Versio:** JTMOS 72.143. **Päiväys:** 25.10.2026. **Pohja:** kokonainen v72.142 FULL SOURCE DEVELOPMENT -paketti, jonka SHA-256 tarkistettiin ennen purkamista.

Navigatorin keskeinen kehitystarve on sivun, käyttöliittymän ja taustatöiden tilojen yhteensovitus. Selaimessa on jo huomattavasti toiminnallisuutta: Lexbor-parseri, oma CSS/layout/piirtopolku, kuvaformaatteja, BearSSL ja oikea QuickJS. Käytännön ongelmia aiheuttaa se, että sama toiminto kulkee eri elinkaarien ja eri muistirajojen läpi. Tässä julkaisussa korjataan konkreettisia toimintapolkuja ja lisätään niitä suorittavat testit.

## Tutkimuksen rajaus ja menetelmä

Tarkastelu kohdistui `libc/apps/navigator.c`:hen, Navigatorin URL-, DOM-, layout-, CSS-, JavaScript-, verkko-, asynkronisuus-, renderöinti- ja profilointimoduuleihin sekä GraOSin asiakasalueen, tapahtumien ja framebufferin käyttöön. Aiemman v72.111-analyysin ja v72.78-suunnitelman väitteitä verrattiin nykyiseen koodiin; niitä ei käsitelty tämän version testituloksina.

Lähdekoodin rinnalla suoritettiin todellinen parseri, layout ja käyttöliittymä isäntätesteissä ASan/UBSan-tarkistuksilla. Verkko- ja lataustesteissä käytettiin paikallisia HTTP-fixtureja. QuickJS-testissä suoritettiin vendoroitu oikea moottori Navigatorin F9-polun kautta. Natiiviversio käännettiin ELF32/i686-muotoon, ja koko järjestelmän media rakennettiin. Lopulliset QEMU-tulokset ja tarkistussummat ovat erillisessä `QA-V72.143.md`:ssä.

Isäntätestin OS/IPC-mallinnus ei ole fyysinen laitetesti. Se ei mittaa T400:n tai eMachinesin suorituskykyä. Tässä ei esitetä laskennallisia nopeutuksia laitteella mitattuina tuloksina.

## Nykyinen rakenne

| Kerros | Toteutus | Omistajuus ja raja |
|---|---|---|
| GraOS-asiakas | `navigator.c`, libc:n GraOS-rajapinta | Käyttöliittymä omistaa ikkunan, pikselipinnan, syötteen ja näkyvän dokumentin. |
| Dokumentti | `nav_html5`, `nav_dom`, `nav_lexbor` | DOM-arena omistaa solmut ja tekstin. HTML-lähde säilytetään erikseen uudelleenrakennusta varten. |
| Ulkoasu | `nav_stylesheets`, `nav_css`, `nav_style`, `nav_layout` | Layout rakennetaan uutena listana ennen vanhan listan vapauttamista. |
| Piirto | `nav_render`, `nav_paint`, `nav_text`, kuvat | GraOSille julkaistaan ohjelmallisesti tuotettu framebuffer tai sen alueita. |
| Verkkotyö | `nav_async`, `nav_network`, `jt_net_transport` | Forkattu lapsi hoitaa DNS/TCP/TLS/HTTP:n. UI pollaa rajattua pipe-liikennettä. |
| Tiedostolataus | `nav_download_job`, `nav_download_safe` | Lapsi streamaa väliaikaistiedostoon; UI julkaisee hyväksytyn tuloksen. |
| Skriptit | `nav_js`, `nav_js_dom`, QuickJS | Moottori toimii UI-prosessissa, rajatulla kasalla, pinolla ja suorituskvanteilla. |

GraOSin aiemmat asiakasalueen kysely, tapahtumabudjetti, refresh-virheen uudelleenyritys ja busy-tokenit säilyvät. Navigatorin sisäisen `NavDoc`-rakenteen layout-sukupolvi muuttuu; julkista GraOS-viestikehystä ei muuteta.

## Havainnot ja toteutus

| Prioriteetti | Todettu ongelma v72.142:ssa | Muutos v72.143:ssa |
|---|---|---|
| Korkea | Natiivitestissä Alt+vasen saapui Navigatoriin tavallisena vasempana nuolena; odotettu koodi puuttui yhteisestä dekooderista. | Alt+vasen/oikea koodataan ennen GraOS-jonotusta. Julkiset näppäinvakiot ovat samat kernelissä ja libc:ssä. AltGr ja tavalliset nuolet säilyvät. |
| Korkea | Back/Next muutti `hpos`-kohtaa jo työn alkaessa. Stop, 204 tai verkkovirhe saattoi jättää historian eri kohtaan kuin näkyvä sivu. | Odottava historiakohde erotetaan vahvistetusta. Sijainti vaihtuu vasta onnistuneessa sitoumuksessa. |
| Korkea | Uuden pyynnön virhe vapautti näkyvän dokumentin ja sulki sen JS:n. | Virhe säilyttää edellisen sivun, sen syötteet, vierityksen ja JS:n. Ensimmäisen latauksen virhe voi edelleen näyttää virhesivun. |
| Korkea | Linkkien ratkaisu käytti fragmentin poistavaa siirtokerroksen URL-funktiota. `#uutinen` hävisi ennen navigointia. | Uusi `nav_resolve_location` säilyttää selaimen fragmentin. Verkkopyyntö käyttää edelleen fragmentitonta URL:ia. |
| Keskitaso | Historia tallensi vain URL-osoitteita. Pitkän artikkelin lukukohta katosi palatessa. | Rajattu 32 kohdan historia tallentaa pikseli- ja tekstivierityksen. Uudelleenlataus palauttaa myös käyttäjän lukukohdan. |
| Korkea | URL:n hakemisto saatettiin ratkaista kyselyparametrissa olevan `/`-merkin perusteella. Polun `//` muutettiin `/`:ksi. | Polku erotetaan kyselystä, tyhjät segmentit säilytetään ja loppuun tulevat `/.` sekä `/..` käsitellään. |
| Keskitaso | Aiemmat CSS-lähteet saattoivat jäädä soveltamatta, jos viimeinen tyylivastaus oli tyhjä tai sen hyväksyminen epäonnistui. | Lopetus rakentaa tyylien yhdistelmän aina vastaanotetuista lähteistä ja tekee yhden lopullisen reflow'n. |
| Keskitaso | Pyynnön 35 s:n ja reapin 2 s:n ajat perustuivat UTC-kelloon; nolla-ajankohta ja kellon muutos olivat erityistapauksia. | Ne käyttävät monotonisia millisekunteja sekä ylivuodon kestävää erotusta. |
| Keskitaso | Reap-jonoa pollattiin pääasiassa aktiivisen verkkotyön yhteydessä. Viimeisen työn Stop saattoi jättää siivouksen odottamaan seuraavaa työtä. | `nav_async_maintenance` suoritetaan myös joutilaskierroksella. SIGKILL-porrastus ja nonblocking waitpid jatkuvat Stopin jälkeen. |
| Keskitaso | Find seurasi layoutin osoitetta ja objektimäärää. Allokaattori voi käyttää saman osoitteen uudelleen samalla määrällä. | `layout_generation` muuttuu onnistuneessa reflow'ssa; Find laskee osumat myös tällaisessa tapauksessa uudelleen. |
| Keskitaso | Peräkkäiset resize-tapahtumat saattoivat kukin varata pinnan ja tehdä reflow'n. | Vierekkäiset resize-tapahtumat yhdistetään nykyisen tapahtumaerän sisällä. Ennen seuraavaa muuta syötettä geometria vahvistetaan. |
| Keskitaso | JS:n profiloinnin alkuarvo oli 16 MiB, käynnistysvaraus 24 MiB ja käynnistyksen myöhempi ohitus 30 MiB. | Kaikki JS-komponentin varaukset käyttävät yhtä 32 MiB:n sopimusta. QuickJS:n kasakatto säilyy 24 MiB:ssa. |
| Keskitaso | Osoiterivin HTTPS-virhe saattoi käynnistää erillisen HTTP-varayrityksen. | UI ei tee automaattista HTTPS→HTTP-varayritystä. Nykyinen siirtokerroksen HTTPS-first-politiikka säilyy. |

JavaScript-havaintoa on tulkittava koko käynnistyspolun perusteella: 30 MiB:n myöhempi ohitus tarkoittaa, ettei alkuperäinen 16/24 MiB:n ero yksin osoita F9:n olleen estynyt natiivijärjestelmässä. Uudistus poistaa kolme erillistä arvoa ja varaa tilan myös enintään 4 MiB:n skriptipuskurille sekä moottorin oheistilalle. Testi suorittaa myös oikean `memory_startup_check`-polun.

### Historia ja dokumentin elinkaari

Osoite, historia ja näkyvä sivu vahvistetaan samassa onnistumispolussa. Historiarenkaan täyttyessä URL:t ja vieritystiedot siirtyvät yhdessä. Uusi haarautuminen poistaa Forward-kohteet vasta onnistuneessa navigoinnissa; epäonnistunut yritys ei katkaise historiaa. No-content-vastaus säilyttää nykyisen sivun ja historian.

HTML-siirron staging-puskuri säilyy erillään nykyisestä lähteestä. Vanhan dokumentin QuickJS suljetaan ennen lähteen ja DOM:n vapauttamista. Näkyvä sivu on käytettävissä siirron aikana. Tämä on siirron ja UI-tilan vahvistus, ei kokonaisen uuden DOM/CSS/layout-puun yhtäaikainen muistitransaktio: jos uuden sivun parseri tai layout ei mahdu budjettiin, nykyinen tekstitilan varapolku on edelleen käytössä.

### Ankkurit ja vierityspaikka

Tuettu osajoukko sisältää elementin `id`-tunnisteen, vanhan `<a name>`-ankkurin, prosenttikoodatun UTF-8-tunnisteen sekä tyhjän fragmentin ja `#top`-alkuun siirtymisen. ID:t ovat kirjainkoosta riippuvia; erikoistapaus `top` käsitellään vasta, jos vastaavaa ID:tä tai nimettyä ankkuria ei löydy. Piilotettuun tai puuttuvaan kohteeseen ei vieritetä. Tyhjälle nimetylle ankkurille lisätään näkymätön layout-merkki.

Saman dokumentin fragmentti ei forkkaa verkkotyötä eikä korvaa DOM:a. Uuteen dokumenttiin kohdistuva fragmentti säilytetään sivulatauksen yli. Palautusta voidaan yrittää uudelleen ulkoasun muuttuessa esimerkiksi CSS:n jälkeen, mutta käyttäjän syöte lopettaa automaattisen palautuksen.

Ankkurin kohteen haku edellyttää DOM/CSS-näkymää; vanhan F6-tekstitilan ID-paikannusta ei toteuteta. Tämä ei toteuta koko HTML-standardin fragmenttikoneistoa. `hashchange`-tapahtumat, CSS `:target`, kohteeseen liittyvä täydellinen fokus- ja ancestor-revealing-toiminta sekä HTTP-uudelleenohjauksen oman uuden fragmentin kaikki säännöt jäävät jatkokehitykseen. Historia ei sisällä BFCachea tai POST-datan turvallista uudelleenlähetysprotokollaa.

## Muisti ja suorituskyky

Selaimen SYSMEMREQ säilyy 100 MiB:ssa ja laajennetun prosessi-ikkunan koko 128 MiB:ssa. Budjettia pienennetään käynnistyksessä todellisen myönnön ja vapaan RAM:n perusteella. Kahden gigatavun suositus on koko koneelle; se ei tarkoita Navigatorille annettavaa kahden gigatavun osoiteavaruutta.

| Kohde | Nykyinen raja tai käytäntö |
|---|---|
| HTML-siirto | enintään 8 MiB; vanha ja odottava lähde voivat olla yhtä aikaa muistissa |
| CSS- ja kuvavastaanotto | erilliset 4 MiB:n puskurit |
| HTTP-komponentti | 24 MiB:n tunnetun omistuksen budjetti |
| Uuden dokumentin DOM-arena | budjetista johdettu, enintään 20 MiB |
| QuickJS | kasa 24 MiB, skriptilähteet enintään 4 MiB, komponenttivaraus 32 MiB |
| Tapahtumat | enintään 16 tapahtumaa ja yhteistoiminnallinen 4 ms:n tapahtumaerä |
| Sivuhistoria | 32 URL:ia vieritystietoineen; ei DOM-välimuistia |

Profilointi mittaa tunnettuja omistettuja varauksia. Se ei ole käyttöjärjestelmän mittaama RSS-kova raja: väliaikaiset parserivaraukset, allokaattorin metadata ja forkattujen lasten kokonaiskulutus eivät kaikki sisälly laskuriin. Suuret sivut tarvitsevat edelleen muistipainetestejä oikeassa järjestelmässä.

Uusien toimintojen mitattavissa oleva rakenteellinen hyöty on konkreettinen: saman sivun ankkuri tarvitsee nolla uutta verkkotyötä ja säilyttää DOM:n; testin kahdeksan vierekkäistä resize-tapahtumaa aiheuttaa yhden resize-pinnan rekisteröinnin. Tämä ei ole yleinen fps- tai sivulatauksen nopeutuslupaus. Suuri layout ja synkroninen OS-kutsu voivat ylittää tapahtumaerän 4 ms:n budjetin.

## Seuraavat tärkeimmät arkkitehtuurityöt

1. **Verkkotilan omistajuus.** `nav_async` luo yhä lapsen pyyntöä kohti, ja vapautus lopettaa sen. HTTP-välimuisti, TLS-istunnot ja lapsessa opittu HSTS eivät muodosta toimivaa pysyvää selainistunnon yhteistä varastoa. Seuraava vaihe on UI:n omistama validoitu tilaprotokolla tai hallittu pysyvä worker-pooli, jossa evästeiden ja HSTS:n rinnakkaisuus on suunniteltu yhdessä. Pelkkä lapsen jättäminen eloon olisi liian pieni korjaus.
2. **Rajattu layout-työ ja hakukentän päivitys.** Merkkikohtainen paint-lista ja koko dokumentin reflow ovat pitkän sivun pullonkauloja. `nav_render_visit` käy edelleen listaa lineaarisesti. Rivien spatiaalinen indeksi, tekstijaksot yksittäisten merkkien sijaan ja lomakkeen rajattu invalidointi ovat perustellumpia seuraavia töitä kuin uusien CSS-ominaisuuksien lisääminen sattumanvaraisesti.
3. **Selkeä osittaisen sivun tila.** DOM-, CSS- ja 100 000 piirto-objektin rajat suojaavat muistia, mutta pitkä sivu voi jäädä osittaiseksi. Käyttäjälle tarvitaan pysyvä ilmoitus ja Reader-/tekstitilaan ohjaava toiminto. Rajojen kasvattaminen ilman kokonaisbudjettia ei ratkaise asiaa.
4. **Moottorin eristys ja yhteensopivuus.** QuickJS ei merkitse Chromen kaltaista DOM-, selain-API-, Promise-, moduuli- tai sivustosovellusyhteensopivuutta. Saman prosessin kasa- ja aikarajat eivät muodosta erillistä turvallisuushiekkalaatikkoa. Google-kirjautuminen ja raskaat sovellussivut tarvitsevat omat hyväksyntätestinsä.

Kernelin näppäimistödekooderiin lisätään Alt+vasen/oikea ja julkaisubanneri päivitetään. T400:n Intel 82567LM -ajuria tai USB-massamuistin uutta kokeellista toteutusta ei muuteta tässä työssä. Täysi lähdepaketti säilyttää v72.142:n pohjan. QEMU-testin verkkolaite ja OHCI-testi eivät varmista Intel-ajurin, eMachinesin nForcen tai fyysisen T400:n toimintaa.

## Toistettavat tarkistukset

```sh
make BOOT_DISPLAY=vesa BOOT_NOGUI=0
python3 tools/check_release_media.py
python3 tests/v7196_navigator_launch.py libc/apps/navigator.bin
python3 tools/build_navigator_lexbor_host.py ../host111/lexbor
python3 tools/build_navigator_quickjs_host.py ../host143/quickjs
python3 tests/v72143_navigation_host.py --quickjs
python3 tests/v72143_alt_navigation.py
python3 tests/v72111_download_host.py
NAV_TEST_LEAKS=0 sh tests/run-v7274-navigator-sanitizers.sh
python3 tests/v72111_qemu_navigator.py ../qemu143-ps2 --navigator143
python3 tests/v72111_qemu_navigator.py ../qemu143-usb --navigator-only --usb --navigator143
```

LeakSanitizer ei kuulu tässä raportoituihin tuloksiin. ASan ja UBSan ovat käytössä. Natiivi- ja isäntämoottorit rakennetaan eri arkistoihin; isännälle rakennettua Lexboria tai QuickJS:ää ei linkitetä JTMOS-binääriin.

## Ulkoiset ensisijaiset lähteet

- [HTML Living Standard: Navigation and session history](https://html.spec.whatwg.org/multipage/browsing-the-web.html), erityisesti fragmenttinavigointi ja vieritystilan palautus. Toteutus kattaa yllä kuvatun osajoukon.
- [RFC 3986, kohta 5.2](https://www.rfc-editor.org/rfc/rfc3986#section-5.2), suhteelliset viittaukset, polku/kysely-erottelu ja dot-segmentit. Testit käyttävät standardin normaaleja ja poikkeavia HTTP-viittauksia; koko URL-standardin toteutusta ei väitetä.
- [Linux man-pages: clock_gettime](https://www.man7.org/linux/man-pages/man3/clock_gettime.3.html), monotonisen ajan ominaisuudet. Natiivipolku käyttää JTMOSin `GetTickCount`-aikaa, isäntäpolku `CLOCK_MONOTONIC`-kelloa.
- [RFC 6797, kohta 8](https://www.rfc-editor.org/rfc/rfc6797#section-8), HSTS-tilan elinikä ja turvallinen yhteys. Pysyvän HSTS-tilan korjaus on yllä nimetty jatkotyö.
