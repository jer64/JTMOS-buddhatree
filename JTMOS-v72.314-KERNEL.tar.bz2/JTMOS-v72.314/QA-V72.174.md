# JTMOS v72.174 QA — Navigator white screen / Google Search

| Check | Result |
| --- | --- |
| Native i686 Navigator (Lexbor, QuickJS, WebP, BearSSL) | PASS |
| Host ASan/UBSan QuickJS blank-page rollback | PASS |
| Host ASan/UBSan late stylesheet rollback | PASS |
| Host ASan/UBSan healthy DOM mutation (no false positive) | PASS |
| DOM load-event, createTextNode and tag query smoke test | PASS |
| Previously saved Google HTML and two CSS files, no CSS truncation | PASS |
| Search results `#rso` paint operations | 2461 |
| Complete fresh system kernel/GraOS build | NOT RUN; inherited from v72.173 |
| Real live Google search on JTMOS ThinkPad T400 | NOT VERIFIED |
| Complete Google JavaScript implementation | NOT CLAIMED |

The attached Google snapshot remains private and is not placed inside the ZIP.
