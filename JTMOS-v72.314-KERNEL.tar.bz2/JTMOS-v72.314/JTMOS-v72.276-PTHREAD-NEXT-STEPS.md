# JTMOS v72.276 — Ring3 shared-VM thread groundwork

## Scope

This phase extends v72.275's **non-executing pthread prototype**. It does **not**
claim that `pthread_create` works in Ring3. `SYS_threadctl FEATURES` remains `0`
(all required feature bits must be implemented before publication).

### Implemented

- `SYS_threadctl OP_VALIDATE=6`: Ring3-only preflight of
  `jtmos_thread_create_v1`. Checks ABI, flags, user-range arithmetic, entry
  mapping, per-page writable/user stack mappings, optional argument mapping.
  No PTE pinning, TSS allocation, runnable task publication, or child creation
  occurs. This is a *snapshot* only; successful validation must not be used
  as a substitute for atomic create-time validation under a VM lock.
- `kernel32/jtmos/thread_vm_group.h`: a small fixed-capacity VM lifetime model
  with root-PID identity, per-member generation cookie, reference counts,
  stale-PID rejection and root release refusal while other members exist.
- `kernel32/mm/thread_vm_group.c`: kernel-side entry points for reserving,
  querying and releasing *metadata*; this module is linked but intentionally
  **not invoked by CREATE**. It does not map or alias page tables. The actual
  shared VM binding and group teardown are still missing.
- `libc/libc/modern/pthread_create_proto.c`: future stack reservation now uses
  4-KiB alignment/size rounding and prefaults stack pages. This is only used
  if the complete kernel feature gate is eventually enabled. **No real stack
  guard page is provided yet**; this must be added before enabling CREATE.
- `libc/apps/pthreadprobe.bin`: ELF32 probe that checks the fail-closed
  `pthread_create()` behavior, allocates/touches a sample user stack and asks
  the rebuilt kernel to validate it.
- Host model tests for VM group lifetime and the Ring3 request validator.

### Still required for working pthreads

1. **Shared VM publish:** Point every member to the same actual PTE pages,
   extended PDEs, VMA registry and sparse backing; serialize map/unmap/fault
   changes with scheduler page-directory replacement. Existing `fork()` stays
   copy-on-write and must not silently join the group.
2. **Owner-independent memory lifetime:** Keep VM objects (including aliases,
   page tables and mmap reservations) alive until the final member has stopped
   executing; do not reuse the original leader PID while any member depends
   on its VM metadata. Integrate with KillThreadEx and fault quarantine.
3. **Ring3 task context:** Create TSS with USER_CS/USER_DS, user argument stack,
   private Ring0 stack, unique generation-safe handle and FPU state. Publish
   runnable priority only after every allocation and VM binding succeeds.
4. **Process-wide resources:** Shared FD/socket tables, cwd, signals, heap,
   environment and process exit, including accurate close/teardown semantics.
5. **Join and TLS:** Join waits for completed scheduler handoff before stack
   deallocation, implement detach policy, `errno`/TLS, libc locks, futex-like
   blocking and thread-aware allocator. Only then advertise FEATURES.

## Verification performed

- `gcc -std=c99 -Wall -Wextra -Werror -I kernel32 tests/v7276_threadctl_validate_test.c ...` — PASS (6 cases)
- `gcc -std=c99 -Wall -Wextra -Werror -I kernel32 tests/v7276_vm_group_test.c ...` — PASS (17 cases)
- Both test programs under AddressSanitizer + UBSan — PASS.
- `kernel32/core/int/scs.o` and `kernel32/mm/thread_vm_group.o` i686 kernel compilation — PASS.
- `make -C libc/libc check` — PASS (application + kernel libc and smoke links).
- `make -C libc/libc app SRC=../apps/pthreadprobe.c ...` — PASS (ELF32).
- `python3 tools/audit_syscall_irq_policy.py --root .` — PASS.
- `python3 tests/v72275_pthread_prototype.py` — PASS.
- Whole kernel boot image and real Ring3 runtime not tested here (NASM missing).

## How to test after rebuilding with a full JTMOS toolchain

Run `pthreadprobe` in JTMOS. A rebuilt v72.276 kernel should return
VERSION=1, FEATURES=0, `pthread_create=ENOSYS` and `OP_VALIDATE=0` for
present writable sample stack pages. The last result may identify MM issues;
**it does not demonstrate that a user thread can execute.**

For regression testing, run the existing Navigator and `fork()`-based worker
cases; the new code must not change normal process exit or COW behavior.
