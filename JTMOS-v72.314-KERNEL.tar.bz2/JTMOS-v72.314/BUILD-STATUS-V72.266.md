# JTMOS V72.266 full release

Canonical full-build PASS; kernel 934528 bytes, 114048 free (kernel source unchanged).
GraOS antialiasing/smoothing (guiSmooth.c), button looks smooth/edge/blurry/borderless,
light blue borderless buttons by default, buttondemo.bin.
See QA-V72.266.md and RELEASE-V72.266.txt.
