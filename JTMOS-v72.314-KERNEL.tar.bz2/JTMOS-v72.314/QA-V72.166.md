# JTMOS v72.166 – varmennus

28.10.2026. Pohja on v72.165. Lopullinen koonti sisältää ohjelmat, ytimen,
käynnistyslevykuvat, utilities.iso:n ja DOSBOOT-kopiot. Pakettien koostumus ja
medioiden identiteetti tarkistetaan erikseen. Todisteet: release/qa/v72.166/.
Erillisissä hyväksyntäajoissa läpäisi 158 käyttäytymistarkistusta ja 8
pakattujen ohjelmien tavutarkistusta. Tunnetut rajoitukset ja epäonnistuneet
rinnakkaisajot on lueteltu erikseen myös validation-summary.json-tiedostossa.

| Tarkistus | Tulos ja todiste |
|---|---|
| Editin moottori ja näppäinkäyttöliittymä, ASan + UBSan | PASS 46/46, edit-host/result.json |
| grep/tail/cat/head/wc/mv ja saman tiedoston tunnistus isäntäajossa | PASS 25/25, programs-host/result.json |
| Nutgetin oikea julkaisufunktio: onnistuminen, peruutus, nimeämisvirhe, palautusvirhe, nimikolarit ja hakemistosuoja | PASS 7/7, nutget-files/result.json |
| Oikeat ELF32-apuohjelmat JTMFS:ssä, binääritavuvertailut ja polkualiakset | PASS 14/14, final-utilities/result.json |
| Edit tekstikonsolissa ja GraOSin pääteikkunassa | PASS 7/7, final-editor/result.json |
| MP3:n komentorivitila ilman GraOSia, virhepaluuarvot, Ctrl+C ja oikea HDA-ääni | PASS 8/8, final-mp3/result.json |
| HTTP/HTTPS, kaksi verkon uudelleenkäynnistystä, vanhan tiedoston säilyminen, SQSH, keskeytys ja tulosteen ohjaus | PASS 12/12, network-regression/result.json |
| Sovelluspoikkeukset, 21 lasta, orvon lapsen ympäristö ja demand paging | PASS 19/19, isolated-faults/result.json |
| Kaatumislokin kirjoittajan jatkovika ja uudelleenkäynnistys | PASS 4/4, final-secondary/result.json |
| Kaatumislokin oikea tallennus JTMFS-levylle | PASS 4/4, final-persistence/result.json |
| VESA-tilan säilyminen ja lapsiprosessien kaatumiset | PASS 7/7, isolated-vesa/result.json |
| Eristys vanhan worker-palautuskytkimen ollessa pois | PASS 5/5, isolated-containoff/result.json |
| Apuohjelmien yhteiset sopimukset, poikkeus-/ISR-/NMI-auditit | PASS, utility-contract.log, exception-contract.log, isr-audit.log, nmi-audit.log |
| ELF/raw, latausosoite, BSS ja kokomarginaali | PASS: ydin 940736 tavua, 107840 tavua vapaana; alaraja 65536 |
| Medioiden ja pakattujen ohjelmien identiteetti | PASS 8/8 ohjelmaa sekä mediat, media-check.json ja packaged-apps.json |
| Julkaisunumero ja asennusskriptit | PASS, version-check.log ja gen_pkg_installers.py --check |

MP3-testi käynnisti soittimen tekstikonsolista ilman GraOS-palvelinta. WAV:ksi
kaapatusta HDA-ulostulosta mitattiin 9,96 sekuntia aktiivista ääntä ja 439,45 Hz:n
huippu 440 Hz:n MP3-testisignaalista. Myös toinen peräkkäinen toisto, puuttuva
syöte, puuttuva tiedosto ja Ctrl+C:n palautusarvo 130 tarkistettiin.

Host-testeissä v72.165 epäonnistui 11 käyttäytymistarkistuksessa.
Muuttamattoman v72.165:n katkennut nutget-lataus poisti vanhan kohdetiedoston.
Vertailuajon tulokset ovat baseline-programs/ ja baseline-nutget/.

Rinnakkaisissa rasitusajoissa sekä teksti- että VESA-tilassa havaittiin
ajoittainen fork-luonnin virhe, kun _createAppThread-lukko oli varattu
keskeytyksettömässä julkaisukohdassa. Tekstiajon kolmannella kierroksella
luonti epäonnistui 18. lapsen kohdalla; käyttöjärjestelmä ja komentotulkki
jatkoivat toimintaansa. Tämä on tunnettu rajoitus, ei korjatuksi väitetty vika.
Epäonnistuneet ajot säilytetään hakemistoissa parallel-fork-contention/ ja
parallel-vesa-contention/. Muuttamattoman lopullisen ytimen erillinen
tekstiajo läpäisi 21 lasta ja 19 tarkistusta. Taulukon tulokset eivät sisällä
rinnakkaisajojen epäonnistumisia, eikä niiden perusteella väitetä fork-kutsun
toimivan virheettä kaikissa kuormituksissa. Testiin ei lisätty lasten luontia
uudelleen yrittävää silmukkaa.

Vanha apps audit -koontitesti pysähtyy v71.80:n vanhentuneeseen täsmällisen
version ja Makefile-rivityksen vaatimukseen. Se kirjattiin apps-audit.logiin.
Sen kokonaisläpäisyä ei väitetä. Muutettujen lähteiden koonnit ja yllä olevat
käyttäytymistestit on tehty erikseen.

ASan ja UBSan olivat käytössä editorin host-testissä. LeakSanitizer jätettiin
pois, koska ajoalustan /proc-rajoitus estää sen säietarkastuksen. QEMU-ajot
käyttivät TCG:tä, 512 MiB muistia, std-VGA:ta ja äänitestissä ICH9-HDA:ta.
Oikealla ThinkPad T400:lla ei tehty laitetestiä.
