# JTMOS V72.265 full release

Canonical make -j2 full-build PASS; kernel 934528 bytes, 114048 free.
Exact PIT input clock 3579545/3 Hz; -mpreferred-stack-boundary=2 restores the size margin on GCC 12.
See QA-V72.265.md and RELEASE-V72.265.txt.
