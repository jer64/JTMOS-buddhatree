# JTMOS v72.297 — bounded pthread reaper stress and BSD socket lifetime

## Summary

This is a **source and targeted application test release**, not a fully
rebuilt or QEMU-boot-tested kernel image. Based on v72.296 and incorporates
the DOSBOOT publication directory fix from the prior hotfix.

### 1. BSD sockets (`libc/libc/modern/bsd_socket.c`)

* The descriptor state plus active reference count now live in **one atomic
  CAS word** (`js_socket_slot.h`), preventing a close/acquire race that could
  recycle or zero a descriptor with a live user.
* `close()` changes LIVE -> CLOSING and defers kernel-handle teardown and
  clearing the JS structure until the **last pinned operation** returns.
  Further acquisitions reject CLOSING. Last release finalizes exactly once.
* Read and write paths use independent per-socket atomic direction locks:
  concurrent writers cannot race each other in the send path and concurrent
  readers cannot race in the receive buffer. One send and one recv may
  progress concurrently while the descriptor remains pinned.
* `send`, `recv`, `sendto`, `recvfrom`, `connect`, `bind`, `listen`, `accept`,
  `shutdown`, `getpeername`, `getsockname`, `getsockopt` and `setsockopt`
  acquire a pinned descriptor. `select()` pins while inspecting sockets,
  `fcntl` also pins; `read`/`write` socket glue routes through the public
  guarded send/recv implementation rather than bypassing it.
* Closing a socket during `recv`/`send` causes polling loops to stop with
  `EBADF` (or return already-sent bytes); `accept` and `connect` loops now
  notice CLOSING. `accept()` also atomically reserves a free descriptor.
* Repeated `close()` while the original close is in flight returns `EBADF`.

**Limits:** This does **not** make socket connect/send/recv/shutdown/select
fully POSIX-thread-safe or solve all concurrency interactions (including
concurrent connect vs send, UDP auto-binding, DNS's static hostent state,
TLS library state, cancellation, or full shutdown semantics). Experimental
Ring3 pthread worker restrictions remain. Never use Navigator's socket,
TLS, malloc, or I/O routines from experimental child threads yet.

### 2. `pthreadreapstress.bin` (`libc/apps/pthreadreapstress.c`)

* Default: 2,048 created child threads; `--extended`: 8,192; `--smoke`: 256.
* Waves of 8 (never more than eight simultaneously); alternating joined and
  detached waves; checks result tokens, completion counts, stale generation
  handles (ESRCH), collect return values and successful experimental opt-out.
* Progress every 256 threads reports physical free KiB (`sysinfo`), including
  start/min/end for **diagnostic trending**. These figures are not a proof
  that all physical memory/pages are reclaimed; cache growth is possible.
* The test does not call libc malloc/stdio/socket functions from children.
* Included in the app Makefile and install-image `tests.sqa` generation list.

### 3. DOSBOOT ISO publication

`tools/publish_utilities_iso.sh` creates `boot32pm/dosboot` automatically
before copying `utils.iso` because `make clean` legitimately removes it.

## Verification actually performed

* `make clean`: PASS.
* `make KERNEL_RING3_TEST=1 -j2`: BLOCKED in kernel32 by **missing nasm**.
  No full kernel link, boot or QEMU run was performed in this environment.
* `make -C libc/libc application -j2`: PASS.
* `navigator.bin`, `navnetd.bin`, `pthreadreapstress.bin`, and seven existing
  pthread test apps: ELF32/i386 compilation/link succeeded.
* Host socket packed-ref state machine test: 4,000 closing transitions and
  more than 350,000 concurrent ref acquisitions; errors=0. This is NOT a
  test of JTMOS's actual network hardware/kernel.
* Targeted SQA files: members match rebuilt application binaries. Both
  SQA/NZIP pairs unpack to exact byte-for-byte matching archives.
* Archive integrity and SHA256 verification included separately.

## Build after extracting all three archives in same parent folder

```bash
cd JTMOS-v72.297
make clean
make KERNEL_RING3_TEST=1 -j$(nproc)
```

Keep JTMOS's internal `.sqa`, `.sqa.nz`, `.nz` formats unchanged. Release
archives are separately distributed as `.tar.bz2`.

## Suggested QEMU test order

```text
pthreadreapstress.bin --smoke
pthreadreapstress.bin
pthreadreapstress.bin --extended
pthreadreap.bin
pthreadlifecycle.bin
pthreadonce.bin
pthreadrace.bin
pthreadchurn.bin
navigator.bin https://yle.fi/
```

Run the extended test only when the default test repeatedly passes. Monitor
memory trends, kernel logs, JTMOS console, and possible scheduling stalls.
Until QEMU and T400 evidence is available, the new close/send/recv path is
**experimental** and Navigator should continue using its isolated navnetd
network workers, not new general pthread network workers.
