# JTMOS v72.98 — ThinkPad T400 Ethernet, stage 4: carrier, watchdog and safe recovery

**Status:** Complete source tree release, **UNBUILT** as a bootable kernel. Only the affected ELF32 kernel object files were rebuilt. Testing below is with *simulated MMIO*, not a physical ThinkPad T400.

## Scope / changes

- `ich9e.c` / `ich9e.h`: lightweight link-edge tracking for 8086:10F5, including rise/fall counters and the last transition tick. The driver never attempts a PHY/NVM write or MAC-global reset in response to link flaps.
- `ich9e_send()` refuses a direct transmit while `STATUS.LU` is clear and counts such refusals. The normal `ethdev_send()` path already checks carrier; this closes the lower-level gap.
- A read-only TX watchdog records live pending descriptors, those over the **2 s observational warning threshold**, the oldest outstanding age, and how many checks were performed. DD/TDH must advance before hardware TX can be considered proven. The warning **does not** reuse DMA descriptors, automatically reset the card or kill a network job.
- Restart success/failure/attempt counters survive `ring_reset()` and help distinguish a refused DMA quiesce from successful recovery. `restart_last_error` is the nonnegative internal failure code, or zero on success.
- `inet hw` now prints carrier transitions, cable-down send refusals, pending/stalled TX, and safe restart history. Existing `inet hw test tx` and passive `inet hw test rx` continue to work.
- Existing `quiesce_dma_for_ring_reset()` is deliberately preserved: a PCIe GIO master-disable acknowledgement is required **before** recycling descriptors. No automatic retry/reset with unacknowledged DMA is introduced.
- DHCP already has carrier-loss/recovery handling in `jnet_maintenance()` (invalidate prior DHCP lease and fresh DORA). It is preserved instead of duplicated in the Ethernet driver.

## Testing performed

1. Target `ich9e.o`, `ethdev.o`, `networkapp.o` compiled with original generated Makefile GCC flags (`-m32 -Os -nostdinc -nostdlib`), ELF 32-bit relocatable objects.
2. `tests/v7298_ich9e_link_watchdog.py` runs the actual new C link/watchdog/send functions with an injected fake MMIO map and a wrapping 32-bit timer; includes 100,000 back-to-back simulated TX submissions and completions, cable flaps, and a deliberately uncompleted descriptor.
3. `tests/v7298_dma_quiesce.py` runs the actual quiesce and `ring_reset()` C functions against a fake MMIO controller: 50 failed acknowledgements do not touch the ring, and a subsequent successful acknowledgement permits reset.
4. `tests/v7298_ich9e_rx_compat.py` runs actual v72.97 RX C logic against fake MMIO (byte-identical logic except for the version check in the test).
5. Existing Ethernet carrier/DHCP-recovery, owner-loop/ping/HTTP source invariants and native DHCP codec tests pass.
6. Full archive CRC check and SHA-256 output at packaging.

## Safety and limitations

**Do not boot the included old `kernel32.bin` expecting v72.98 behavior:** the executable has not been relinked. This environment has no NASM, and a complete kernel/DOSBOOT build has not been performed. Only rebuildable kernel objects contain the new diagnostics. No T400 hardware test has been performed. An MMIO simulator cannot prove the PCIe DMA bus, PHY autonegotiation, ping, DHCP, or Navigator connectivity on a real laptop.

The latest user-provided T400 `inet hw` report was v72.83 and indicated `TX enqueued=3`, `TX DD=0`, `TX head=0`; no *built-and-booted* 72.84–72.98 hardware result has been supplied. Thus TX/RX hardware bring-up is **still unverified**. Stage 4 is intentionally conservative and does not claim to fix that unknown hardware fault.

## T400 bring-up and stress checklist

**Only after a complete v72.98 kernel rebuild:** on an isolated test Ethernet segment:

```text
inet restart
inet hw
inet hw test tx
inet hw test rx
inet status
inet stats
ping -c 1000 gateway
```

Test carefully: switch cable disconnected and reconnected, inspect `inet hw` link rises/falls and DHCP re-lease. For actual transmission validation on a second Linux host in the same broadcast domain, capture `sudo tcpdump -ni <interface> -e 'arp or ether proto 0x88b5'`. Expect the frame to be visible only when real hardware TX works. Avoid physical cable changes during a write to persistent media.

Once basic TX and RX have been independently observed, repeat a bounded set of `inet restart` operations with `inet hw` snapshots between them. If a restart reports a DMA-quiesce failure, **stop** and collect the serial output; do not force descriptor reuse. Consider 24 h soak/long ping only after normal link, ARP, DHCP and TX DD completion have been verified.

## Reference

Intel e1000e Linux driver: `drivers/net/ethernet/intel/e1000e/ich8lan.c` and `mac.c` for PCIe master-disable and link management patterns. Hardware-specific changes remain strictly limited to Intel PCI `8086:10F5`.
