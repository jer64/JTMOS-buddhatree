# Navigator v72.168 – CSS-tasaus ja paikannus

28.10.2026. Selain jatkaa v72.167:n div-korjauksista. Käyttöjärjestelmäpohja
on v72.166; ytimen ja käynnistys-/asennusmedioiden versio säilyy ennallaan.

Tekstin `left`, `right`, `center`, `start` ja `end` sekä periytyminen toimivat
omana tasauksenaan. `justify` jakaa välit käärittyjen rivien sanojen väliin
ja jättää viimeisen rivin alkuun. `vertical-align:middle`, `top`, `bottom`
ja `baseline` tasaavat inline-laatikoita. `middle` ei ole `text-align`-arvo;
virheellinen ilmoitus säilyttää aiemman kelvollisen ilmoituksen.

Flex ja grid siirtävät lapsilaatikoita tekstin tasauksesta riippumatta.
`align-self`, `justify-self`, `place-self`, `align-content`, `place-content`,
`space-between`, `space-around` ja `space-evenly` täydentävät moottorin
rajattua asettelumallia. `place-items` laajenee samoihin cascade-paikkoihin
kuin pitkämuodot. Rivin ja sarakkeen akselit, auto-marginaalien etusija,
venytyksen min/max-rajat sekä ensimmäisten tekstibaselinejen tasaus korjattiin.

`relative` siirtää piirtoa muuttamatta seuraavien elementtien virtaa.
`absolute` lasketaan lähimmän paikannetun vanhemman padding-laatikosta.
Prosentit, `calc()`, vastakkaisten reunojen venytys, auto-marginaalit ja
negatiiviset siirtymät on testattu. Siirrettyjen laatikoiden DOM-piirtojärjestys
ja staattiselta esi-isältä perityt CSS-muuttujat säilyvät.

`fixed` käyttää näkymän korkeutta ja seuraa vieritystä piirto- ja
osumatarkistuksissa. Transformoitu esi-isä muodostaa sille oman laatikon.
Selaimen käyttöliittymä välittää näkymän korkeuden moottorille; muut käyttäjät
voivat kutsua `nav_page_set_viewport(doc,height,scroll)` ennen asettelua ja
vierityksen yhteydessä. Ilman asetettua korkeutta host-ajon oletus on 600 px.
Korkeuden muuttamisen jälkeen tarvitaan uudelleenasettelu.

Asenna `navigator-v72.168.sqa` tai korvaa `/bin/navigator.bin` uudella
binäärillä. Avaa `navigator.bin file:///bin/navcss168.html`. Täydessä
lähdepäivityksessä ovat kaikki pohjan lähteet, uusi binääri, erillinen
selainpaketti ja varmennusaineisto. Perityt v72.166-asennusmediat sisältävät
aiemman selaimen; ne eivät itsessään asenna tätä päivitystä.

```sh
make -C libc/apps -f navigator.mak -j2 navigator.bin
python3 tools/build_navigator_lexbor_host.py /tmp/nav168-lexbor
LEXBOR_HOST_ARCHIVE=/tmp/nav168-lexbor/liblexbor_static.a \
  sh tests/run-v72168-navigator-css.sh /tmp/nav168-tests
sh tests/run-v72168-navigator-css.sh /tmp/nav168-subset-tests
NAV_HAVE_QUICKJS=1 DIST_DIR=/tmp/navigator-v72.168 \
  sh libc/apps/navigator/package.sh
```

Katso testitulokset ja toteutuksen rajat tiedostosta `QA-V72.168.md`.
