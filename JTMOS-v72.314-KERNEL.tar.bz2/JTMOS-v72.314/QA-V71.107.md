# v71.107 validation

| Check | Result |
|---|---|
| Native full i486 kernel compile/link; kernel below 1 MiB | PASS |
| Updated boot32pm image bound to exact compressed kernel | PASS |
| Native Navigator/tlsseedctl ELF32 build and actual loader preflight | PASS |
| Source ZIP clean rebuild: both apps, both kernels, NZIP stream and boot image byte-identical | PASS |
| Kernel random output bounds, flags, user mapping and missing-source errors | PASS |
| libc random short reads, EINTR, ENOSYS, EAGAIN, failure wipe and limits | PASS |
| CPUID-gated hardware source on host; no seed bytes logged | PASS |
| Actual FAT12 bodies: directory/file stat, O_EXCL, clean-FAT physical flush, failed-barrier retry | PASS |
| Actual fsync/VFS bodies: FAT12/JTMFS routing, I/O errors, stale mounts and ownership | PASS |
| Root-device /cfg and absolute /bin/tlsfresh.dat default; no hda1 dependency | PASS |
| Existing-pool preservation, per-record erasure/fsync, lock and I/O failure tests | PASS |
| Real BearSSL against local Python/OpenSSL: TLS1.2, SNI, RSA/ECDSA, chunk/gzip, EOF, timeout | PASS |
| Invalid CA, hostname, dates, weak keys and disallowed TLS policies rejected | PASS |
| DNS/URL/IPC/HTML/CSS and package inventory regressions in v71.106 chain | PASS |
| Syscall IRQ policy (176 registered services) and current NMI safety audit | PASS |
| QEMU TCG boot on a CPU without RDRAND/RDSEED (Pentium III), SMSH reached | PASS |
| Native QEMU Ring3 tlsseedctl -> getentropy -> SYS_getrandom -> hardware RNG | PASS |
| Native QEMU TLS1.2 + certificate verification + HTTP over actual JTMOS TCP/NE2000 | PASS |
| Native Pentium III with no hardware RNG: FAT12 installation + TLS via private seed pool | PASS |
| Native seed erasure durable in raw disk image after QEMU exit; next record intact | PASS |
| Physical eMachines, Navigator GUI and public live sites | PENDING |

The kernel host tests compile the actual changed function bodies with simulated
filesystem and memory-map services, under ASan/UBSan. They check API behavior,
not physical disk durability. The TLS tests use real BearSSL and an independent
local TLS server. LeakSanitizer is disabled because the environment does not
support its process inspection; leak-freedom is not asserted.

Commands:

```sh
NAV_TEST_LEAKS=0 sh tests/run-v71107-navigator-ci.sh
make image
make -C libc/apps -f navigator.mak -j2 navigator.bin
make -C libc/apps -f tlsseedctl.mak tlsseedctl.bin
sh libc/apps/navigator/package.sh
# Optional full native checks (QEMU installed or JTMOS_QEMU_PREFIX set):
python3 tests/v71107_native_tls.py
python3 tests/v71107_native_tls.py --legacy
```

The validation environment has no native 32-bit execution. The older V71.50
freestanding tests were also run with QEMU user emulation. The actual kernel
pipe suite passed 67 checks. Its separate old libc popen/system harness failed
25 of 88 checks identically against unmodified v71.106 and this release. This
is not reported as a passing check. Likewise the old V71.66 string-based audit
reports the same two existing watchdog/probe expectation failures on baseline
and v71.107; the current NMI safety and syscall IRQ-policy audits pass.

Existing build warnings in unrelated floppy, directory cache and shell code
remain; no warnings were reported from the changed kernel C modules. Navigator
application builds retain their existing -Werror policy.

A native boot does not prove that an external website opened in Navigator.
Legacy machines without hardware random still require a private seed pool on
persistent writable storage. Importing the TLS pool does not make the kernel
random devices ready. Seed files are deliberately absent from the public
source release and ordinary Navigator package. The separate private setup
package has one newly generated pool input and must be used on one machine.

The native TLS checks boot the release kernel image with a NE2000 adapter,
obtain DHCP, extract and launch a test ELF32 client, and contact an independent
Python/OpenSSL server on the local QEMU host. They use the actual production
transport/entropy objects and native libc/BearSSL. Only that temporary test
client substitutes the trust anchor and maps localhost to 10.0.2.2. Production
CA roots, resolver and Navigator binary are not modified. The legacy test
uses a formatted FAT12 IDE volume and a fresh 32-record pool. After QEMU exits,
it checks the raw backing disk: the consumed first record is gone and the
second record remains. No test seed or private CA key is packaged.

QEMU's floppy controller was unavailable in this configuration because the
existing low-DMA reservation failed. The legacy storage check therefore uses
an IDE FAT12 volume; physical floppy I/O is not asserted. Both native CPU paths
complete a verified TLS1.2 handshake and receive HTTP 200.

The libc archive is recreated in source-list order so incremental builds and
clean builds link identically; adding an object no longer leaves it appended
at a different location in an existing archive.
