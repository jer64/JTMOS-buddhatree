# JTMOS v72.189 – MP3/HDA DMA-ring replay investigation

## Report

On v72.178, `mp3.bin` plays normally initially, then audio seems to repeat the contents of its buffer. No captured ThinkPad T400 serial log or audio trace was available with this report, so the underlying hardware fault is not proven.

## Source audit findings

- v72.178 `kernel32/drivers/hda/hda.c` can promote the controller's DMA position buffer to its playback cursor, but previously did not fall back to LPIB if that source subsequently stopped advancing while LPIB continued to move.
- The v72.178 position reader rejects *every* DMA position delta greater than half of the 128-KiB ring, even when a long scheduling gap makes the delta physically plausible. The DMA descriptor wraps every ~683 ms at 48-kHz stereo 16-bit. Rejecting a legitimate update means the software write cursor can get out of sync with the device cursor.
- HDA hardware will continue cycling through its BDL ring when the service callback is absent. A lost callback longer than one revolution is ambiguous; do not assume that old PCM has not replayed.
- MP3 file data and the user-space FIFO path can also be involved. These patches do **not** establish that the player's decoder or JTMFS is always correct.

## Implemented

1. Track LPIB and the DMA position-buffer activity independently. If the preferred position buffer freezes >120ms and LPIB moved within the last 60ms, fall back to LPIB and rebase without creating fake progress. Re-promote only after repeated position-buffer movement.
2. Evaluate a position delta against elapsed time at the actual 192 bytes/ms stream rate with 4096 bytes of slack; drop implausible readings without rejecting legitimate >half-ring advances during scheduling delays.
3. Stop the hardware stream if its software service has been absent for an entire DMA-ring revolution; ordinary service can restart from the queued FIFO when available.
4. Extend `mp3 --trace` diagnostic output (serial/kernel debug log) with backend, compressed bytes consumed, decoded frames, source FIFO, active hardware bytes, audio submitted, underruns, and decode time.
5. Add host-testable progress policy plus regression cases for wraps, long delay, backward clock glitches, and source-freeze detection.

## Build and validation

- `make -C kernel32 -f generated.mak drivers/hda/hda.o`: PASS (JTMOS native 32-bit compile; kernel not linked).
- `make -C libc/apps -f mp3.mak mp3.bin`: PASS; i386 statically linked.
- `gcc ... -fsanitize=address,undefined tests/hda_progress/test_hda_progress.c`: PASS, 13/13.
- `sh tools/check_hda_v7157.sh`: PASS, 23 HDA parser/resampler cases.
- New application package and `tools/check_release_media.py`: PASS; kernel image inherited.
- Full kernel link / QEMU audio capture / ThinkPad T400 test: NOT RUN. A new kernel is required for the DMA fix to take effect.

## On-device diagnosis

1. Boot a JTMOS kernel rebuilt from these v72.189 sources. Replacing `mp3.bin` alone does **not** update the HDA DMA driver.
2. Run `mp3.bin --cli --trace path/to/track.mp3` (or use GUI with `--trace`) and keep the serial log.
3. At the onset of a repeat, check the built-in `audio status` command for `source-switches`, `posbuf-fallbacks`, `ignored glitches`, `stalls`, and DMA errors. `sound.bin status` reports generic audio queue/backend state.
4. Compare `file-read`/`decoded-frames` (forward motion in decoder) with `fifo`/`dma` and `underruns`. If the decoder advances normally but DMA does not, investigate HDA. If file progress stops or repeats but DMA advances, investigate JTMFS/`fread`.
5. Compare HDA with SB backend in QEMU if available; also compare the same MP3 on a FAT-formatted drive and JTMFS to isolate the filesystem.

## Remaining risk

Stopping and restarting hardware after an unserviced ring can cause an audible dropout, but prevents uncontrolled stale-buffer replay and provides an explicit diagnostic signal. The test harness only validates position-state mathematics, code compilation, and codec paths; it does not simulate DMA memory coherency or prove audible playback quality.
