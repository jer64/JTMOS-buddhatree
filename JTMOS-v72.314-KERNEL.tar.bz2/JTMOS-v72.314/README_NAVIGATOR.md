See `libc/apps/navigator/README_NAVIGATOR.md` for architecture, build, testing, and compatibility limits.
