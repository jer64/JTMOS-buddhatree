# JTMOS v72.184 – turvallinen lähdepuun ja julkaisupaketin siivous

Lähtötilanne: v72.183:n auditoinnissa löytyi 21 puuttuvaa symbolista linkkiä, 750 sisällöltään identtistä tiedostoryhmää ja useita virheellisesti ZIPiin päätyneitä väliaikaistiedostoja. CRC-testi oli kunnossa, mutta SHA256-manifesti ei kattanut kaikkea sisältöä.

## Toteutus

1. Kaikki 21 odotettua aliaspolkua palautettiin **Unix-symbolisina linkkeinä**. Linkkien kohteet on tarkistettu; kanonisia lähdehakemistoja ei siirretty eikä korvattu.
2. Uuteen v72.184-puuhun ajettiin varovainen, toistettava `tools/clean_full_source_release.py`. Se poistaa käännöksen `.o/.d/.map/.sym`-tuotteet, generoidut paketointihakemistot ja vanhat versionumerolliset pakettikopiot. Aiempi v72.183-puu ja ZIP jätettiin koskematta.
3. Pysyvät käynnistystiedostot `utilities.iso`, `utils.iso`, `kernel32/utilities.iso`, `boot32pm/dosboot/utils.iso`, `root1440.img`, `rootdisk.img` ja tarvittavat NZIP-kopiot säilytettiin. Ne ovat tarkoituksella saman sisällön erillisiä asennuspolkuja.
4. `tools/package_full_release.py` edellyttää nyt 21 oikeaa linkkiä ennen pakkausta ja suodattaa myös generoituja `tools/*_payload`-hakemistoja.
5. `tools/check_full_release_manifest.py` varmistaa jokaisen vaaditun linkin tyypin, nimen ja suhteellisen kohteen ZIPissä. Tarkistussummaluettelo kattaa jokaisen pakatun tavallisen tiedoston eikä yhtään puuttuvaa tai ylimääräistä tiedostoa.
6. `release/qa/v72.184/media-check.json` kertoo todellisten, muuttumattomien asennusbinäärien SHA256-tiivisteet.

## Rajaukset

- Pelkkää sisällön identtisyyttä **ei** käytetä poistoperusteena: lähdekoodin sekä binäärin tarkoitus, hakupolku ja rakennusriippuvuudet ratkaisevat.
- Tämä on `FULL-SOURCE-UNBUILT`-julkaisu: mikään kernelin, GraOSin tai Navigatorin uusi binääri ei synny siivouksessa.
- Hylätyt historialliset GraOS SQA -paketit löytyvät aikaisemmista julkaisuista.

## Toteutunut tulos (28.10.2026)

| Mittari | v72.183 | v72.184 |
|---|---:|---:|
| ZIPin koko (tavua) | 174 765 839 | 113 528 816* |
| Symbolisia linkkejä ZIPissä | 0 | 21 |
| Identtisten fyysisten tiedostojen ryhmiä lähdepuussa | 750 | 716 |
| Fyysisiä tiedostoja duplikaattiryhmissä | 1 895 | 1 815 |
| Duplikaattien laskennallista ylimääräistä raakadataa (tavua) | 67 145 495 | 53 139 502 |

*ZIPin koko on mitattu ennen raportin viimeistä täydennystä, joten lopullinen arkistokoko voi poiketa muutamilla kilotavuilla. Varsinainen vähennys on noin 35 prosenttia. Julkaisussa jää tarkoituksella edelleen identtisiä tiedostoja eri käynnistys- ja asennuspolkuihin sekä alkuperäisiin lähdepuuhun kuuluviin esimerkkeihin.*

**Kriittiset tarkistukset:** `check_duplicate_layout.sh`: PASS, `test_release_cleanup.py`: PASS, `gen_pkg_installers.py --check`: PASS, `check_release_media.py`: PASS, `check_full_release_manifest.py`: PASS. Jo ennen lopullista ZIPiä tarkistettu täydellinen manifesti kattaa 10 829 tavallista tiedostoa ja lisäksi 21 symbolista linkkiä.
