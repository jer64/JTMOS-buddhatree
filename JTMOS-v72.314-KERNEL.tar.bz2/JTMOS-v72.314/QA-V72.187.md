# Unique 2.2 QA — JTMOS v72.187

- Host Unique 2.2 tests: 21 subprocess checks plus file-content assertions PASS.
- Legacy Unique 2.1 regression (`tools/check_unique.sh`): PASS.
- JTMOS/i686 `unique.bin` compile/link: PASS.
- Hardware verification on ThinkPad T400: **NOT PERFORMED**.
- JTMFS existing-file rename and crash consistency: **NOT VERIFIED**.
- No new kernel build, no new kernel features.

## Package/media validation

- `tools/build_install_image.sh`: PASS, 115 application binaries.
- `tools/publish_utilities_iso.sh`: PASS, refreshed `utilities.iso` and aliases.
- `tools/check_release_media.py`: PASS (inherits unchanged kernel/GraOS).
- Extracted `core.sqa.nz` from the release payload and verified its
  `unique.bin` member matches freshly linked i686 `libc/apps/unique.bin` byte-for-byte: PASS.
- Extracted `interpreters.sqa.nz` and verified `unique-system22.uni`: PASS.
- Full-source ZIP is generated using `--allow-inherited-kernel`; old kernel
  is **not** claimed to have been rebuilt.
