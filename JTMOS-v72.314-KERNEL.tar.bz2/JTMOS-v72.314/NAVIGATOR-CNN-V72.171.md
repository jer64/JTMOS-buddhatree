# Navigator v72.171 — CNN CSS/HTML

28.10.2026. User-supplied `edition.cnn.com` homepage snapshot was 7.05 MiB
with ~2.67 MiB of internal CSS. Unlike RKO, its design relies on hundreds
of CSS `--custom-property` declarations, nested `var()` calls, width-range
`@media` queries, `aspect-ratio`, and complex selectors.

## Source changes

1. `nav_css.c`, `nav_css.h`: dynamic declaration-list parsing from the
   declaration block instead of a fixed 96-element stack array, bounded
   at 768 entries. CSS token identifiers expanded from 64 to 128 bytes.
2. `nav_style.c`, `nav_style.h`, `nav_position_layout.inc`:
   reference-counted immutable CSS variable chains; deferred out-of-flow
   layout retains the head rather than deep-cloning 1,024 tokens.
3. `nav_style.c`, `nav_layout.c`: `aspect-ratio: number / number`
   for basic card/image intrinsic height behavior.
4. `nav_css.c`, `nav_style.c`, `nav_layout.c`: bounded selector match cache
   for large pages, valid for one layout pass, keyed by DOM node and
   stylesheet viewport. Cached indices are matched; style resolution still
   recomputes with the current parent, width and CSS variables.
5. `nav_style.c`: larger CSS-key candidate list reduces full sheet scans.

## Measured tests

- ASan/UBSan Lexbor host parse: 10,342 nodes, 16,934 CSS rules,
  CSS `truncated=0`.
- 1,024 px desktop viewport: 7,656 draw operations, `partial=0`.
- `v72171_cnn_css.c`: 180 variables, long property identifiers,
  media width ranges, computed aspect ratio, 600px responsive reflow.
- Original v72.168 CSS/HTML5, positioning, align, DIV and page lifecycle
  regression suite passed using the shipping Lexbor parser.

## Known limits

This release does not claim pixel-perfect CNN or interactive JavaScript
compatibility. Existing QuickJS integration is unchanged. Offline saved
HTML tests do not verify remote stylesheet, image, webfont, CDN, TLS or
network fetches on a JTMOS machine. CSS features like `@container`,
subgrid and complex animations need further work. The 7MB CNN user-supplied
snapshot is intentionally *not* redistributed inside the release.
