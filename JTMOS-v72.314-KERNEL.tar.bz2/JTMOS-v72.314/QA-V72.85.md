# JTMOS v72.85 QA — Navigator CSS/DOM compatibility increment

## Built

- `make -C libc/apps -f navigator.mak -j2 navigator.bin` — PASS.
- `libc/apps/navigator.bin` — rebuilt i386 ELF executable, statically linked.
- Browser source contains DOM/CSS QuickJS additions and linked successfully.
- `VERSION` — 72.85.

## Regression checks

- `tests/v7285_navigator_div_css.sh` — PASS: class selectors, bounded :has()
  child/descendant cases, CSS computed style, inline CSS replacement/removal,
  custom properties, !important, malformed declaration rejection.
- `tests/v7278_dosboot_prompt_parity.py` — PASS (DOS startup source unchanged).
- `tests/v7277_interaction_regression.py` — PASS (GraOS UI mouse/scroll source unchanged).
- v72.83/v72.84 legacy Ethernet source tests contain a hardcoded version
  equality (`72.83`/`72.84`) and therefore deliberately do not form the
  v72.85 acceptance gate; Ethernet C sources were not changed.

## Not performed

- Full kernel/DOSBOOT rebuild: NASM missing in this runtime. Old boot
  binaries remain present from v72.84 and **must not** be labelled v72.85.
- In-system GraOS runtime testing on real or virtual JTMOS hardware.
- Network/CNN/Google visual and dynamic compatibility testing.
- Dedicated QuickJS runtime DOM integration test (only native 32-bit
  compilation and static linking performed).

The included offline HTML file is useful for the next hardware verification.
