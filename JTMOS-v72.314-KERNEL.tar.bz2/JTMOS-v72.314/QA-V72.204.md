# QA — JTMOS / Navigator v72.204

Date: 2026-10-30. Native targets are 32-bit i686 ELF applications for GraOS.

## New TLS1.3 / RSA profile

- 86 named core checks plus 12 Navigator HTTP/TLS integration checks and one
  entropy-consumption check: **99 PASS**.
- Independent host signatures verified with own C RSA for 2048, 2049, 3072
  and 4096-bit moduli, both PKCS1-SHA256 and PSS-SHA256; bit flips rejected.
- X509 leaf/intermediate/configured-root and transmitted-root cases; PSS-signed
  certificate; DNS/IPv4 SAN, case/trailing-dot and wildcard checks; wrong name,
  absent/expired time, missing/reordered/forged chain, non-CA, inappropriate EKU,
  unsupported critical extensions, name constraints and must-staple: PASS.
- Real Python ssl/OpenSSL TLS1.3 server against the C core: authenticated
  handshake, HTTP request/response, tickets ignored and reciprocal close_notify.
  One-byte TCP reads and three-byte writes exercise fragmented I/O.
- Independent Python cryptography scripted peer: transcript/key-schedule/Finished
  agreement, multi-message and fragmented-record handshake, cookie-only HRR,
  KeyUpdate request/reply, clean vs truncated close; bad suite/CCS/ALPN,
  missing certificate, early application data, forged CertificateVerify,
  Finished and GCM tag are rejected; failed context refuses application writes.
- ASan/UBSan replays all 12 scripted cases, every truncated DER prefix,
  1200 certificate mutations and 256 TLS wire mutations: PASS.
- Actual Navigator HTTP -> shared JTMOS socket adapter -> own TLS code ->
  loopback OpenSSL: plain body, gzip+chunked body and close-delimited body PASS.
  Truncation, bad hostname/expiry/EKU, empty anchors, unknown clock, TLS1.2-only
  peer, stalled handshake and HTTPS->HTTP redirect fail as expected. No HTTP
  request is sent to unverified peers or the downgrade destination.
- Real seed adapter (host test disables hardware RNG): consumes/erases 20 fresh
  64-byte records for ten attempted connections. New 96-byte initialization is
  split at the existing OS entropy API's 64-byte limit. No seed/CA bypass.
- New crypto/record/RSA/X509/client compiled with -m32 -march=i686,
  -ffreestanding -fno-builtin -nostdinc against JTMOS headers, then combined
  with ld -r. **nm -u is empty**: no libc/compiler-runtime/crypto-library imports.
- Original known-answer suite: 25/25 PASS. Independent randomized comparisons:
  100 AES-GCM and 100 X25519 cases PASS; logs are included.

## Compatibility

- Existing BearSSL TLS1.2/entropy ASan/UBSan suite: PASS. Includes RSA+ECDSA,
  CA/hostname/time rejection, SNI, gzip/chunked and multi-record bodies,
  authenticated/truncated EOF, CBC-SHA256 policy, one-use seeds/locks/fsync,
  concurrent clients, upgrade and downgrade policy.
- That historical harness now links nav_download_safe.c, expects the current
  HTTP truncation wording, and explicitly disables HTTPS-first only in its
  host executable to exercise an actual HTTP->HTTPS redirect. Native policy
  remains HTTPS-first. A checked Vary field copy uses its validated size,
  removing a host GCC false-positive format-truncation build failure.
- Existing HTTP host regression: 17/17 PASS (legacy async-cookie gate skipped).
  Streaming fixtures: 72/72 PASS. Cache integration: 8 scenarios / 14 requests
  PASS. Logs are in release/qa/v72.204/; none claims hardware execution.

## Binaries and release

- Canonical default Navigator (both TLS backends) rebuilt with -Werror: PASS.
- NAV_WITH_BEARSSL=0 NAV_WITH_TLS13=1 Navigator rebuilt with -Werror: PASS.
  Link/symbol inspection confirms the second binary contains the new TLS client
  and no br_ssl_client_init_full/BearSSL implementation. Other browser libraries
  remain; this is not a complete dependency-free browser migration.
- Both ELF32 binaries use entry 0x80004000 and prefer a 524288 KiB process
  window; actual kernel identity/layout/size/clamp/truncation preflight runs
  in the host harness. No scheduler or native code execution is simulated.
- Full-source release tooling verifies CRC, rooted paths, manifest hashes,
  inherited media consistency and the original 21 symlinks.
- Kernel32, GraOS, DOSBOOT, floppy/CD/install media are inherited; the full
  archive is intentionally UNBUILT. Install the supplied browser binary or
  rebuild the complete media.
- No QEMU, physical eMachines/ThinkPad, VESA/GOP or public-site acceptance test.
- LeakSanitizer is disabled because this environment cannot enumerate /proc
  tasks. ASan and UBSan remain active. The TLS core itself never allocates.
- No independent cryptographic/side-channel audit, revocation testing or full
  Web PKI algorithm/constraint compatibility is claimed. Supported/unsupported
  profiles are enumerated in NAVIGATOR-TLS13-V72.204.md.

## Reproduce

```sh
sh tests/run-v72204-tls13.sh /tmp/nav-tls13
NAV_TEST_LEAKS=0 python3 tests/v71104_tls.py
sh tests/run-v72203-http-stream.sh /tmp/nav-stream
NAV_HOST_HTTP_ONLY=1 python3 tests/v7181_network_host.py
python3 libc/apps/navigator/tests/test_http_cache_v72196.py
make -C libc/apps -f navigator.mak -j2 NAV_WITH_BEARSSL=0 NAV_WITH_TLS13=1 navigator.bin
make -C libc/apps -f navigator.mak -j2 navigator.bin
python3 tests/v7196_navigator_launch.py libc/apps/navigator.bin
```

Host crypto comparisons use Python cryptography >=42 and the host ssl module;
these are test dependencies only. Test keys, seed pools and replay secrets are
created outside the source tree and are excluded from the delivered packages.
