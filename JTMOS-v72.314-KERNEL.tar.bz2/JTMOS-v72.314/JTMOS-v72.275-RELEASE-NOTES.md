# JTMOS v72.275 — pthread_create / Ring3 Thread ABI Prototype

Base: v72.274 full source.

## Implemented in source

- New experimental syscall `SYS_threadctl` (#181) with VERSION / FEATURES
  negotiation and explicitly unsupported CREATE/JOIN/EXIT/SELF handlers.
- Fixed-size i686 `jtmos_thread_create_v1` create descriptor in synchronized
  kernel/libc headers. Required feature flags ensure a future kernel must
  provide shared VM, stack ownership, exit/join, shared FDs, fork safety,
  thread-local errno and reentrant libc before enabling create.
- New libc `pthread_create_proto.c`: validates attributes, reserves aligned
  16KiB–16MiB stacks, creates a descriptor, gates child start until publication,
  cleans up failed creation, handles joinable result/cleanup and delegates
  supported exits to kernel; existing pthread API forwards to prototype.
- Existing APIs do NOT use fork as a pthread substitute.
- Current kernel returns FEATURE=0, therefore pthread_create still returns
  ENOSYS until a real, safe shared-address-space Ring3 clone/exit/join exists.
  `pthread_detach` and cancellation are not implemented.
- `tools/audit_syscall_irq_policy.py` updated to reflect new syscall 181.
- Included architecture notes and i686 link smoke test.

## Verification in build environment

- `make -C libc/libc check`: PASS, both i686 application and kernel libraries,
  ELF32 application linkage and header tests.
- `make -f generated.mak core/int/scs.o`: PASS, i686 kernel syscall unit.
- `python3 tools/audit_syscall_irq_policy.py --root .`: PASS.
- `python3 tests/v72275_pthread_prototype.py`: PASS, static ABI + host regressions.
- `make -C libc/libc app SRC=tests/pthread_create_proto_link_smoke.c
   OUT=build/application/pthread_create_proto_smoke.bin`: PASS.
- Full kernel boot/image, real Ring3 clone runtime, detached threads and
  concurrent Navigator workloads were NOT tested here.

## Binaries caution

The prebuilt kernel image and boot media have been inherited from v72.274
because this environment does not have NASM. Building the new kernel is
necessary to obtain the new version/feature syscall response; however even
then the feature bits intentionally remain zero and no real pthread is created.
