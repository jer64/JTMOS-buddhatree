# JTMOS V72.103 QA – ThinkPad T400 GraOS display stabilization

Date: 2026-10-24. Based on V72.102 full source.

## User-reported symptom
A photo taken from a Lenovo ThinkPad T400 shows an apparent horizontal
line and a vertical light-green wall on the squirrel wallpaper, with the
busy/hourglass implementation suspected of corrupting the GUI. The wallpaper
source itself draws both the wall (old `raw_hill` geometry) and the screen-wide
line (an unconditional `raw_line`). This explains these particular visual
features; other possible framebuffer faults cannot be ruled out from a still.

## Changes
- `libc/apps/gui/graos.h`: `GRAOS_CURSOR_HARDWARE_SAFE=1` by default.
- `guiArrow.c`: busy state is preserved but hourglass visuals and their
  periodic animation updates are disabled on the default T400-safe path.
- `guiArrow.c` and `guiUpdate.c`: cursor-only drawing submits a single union
  damage rectangle. The v72.92 split two-rectangle mode is removed.
- `guiDesktopDraw.c`: hills converge to ground at both endpoints; removed
  the line drawn across foreground hills.
- Existing legacy/new busy IPC methods, per-window tokens and diagnostics
  remain unchanged. No kernel, terminal/VESA or PCI/DMA driver code changes.

## Verification actually performed
- `make -C libc/apps/gui -f graos.mak default`: PASS (static ELF32 graos.bin)
- `readelf` architecture/entry: ELF32 i386, 0x80004000 PASS
- `tests/v72103_graos_cursor_safe.py`: PASS (real production sprite/tick/
  draw/move/update functions compiled in a mock framebuffer; 5,000 successive
  moves; pixels restored, a single region per move, full fallback on failure)
- `tests/v7070_graos_hourglass_cursor.py`: PASS (API remains)
- `tests/v7032_graos_theme_linefix.py`: PASS
- `tests/v72102_boot32pm_version.py`: PASS
- `MAKE=make sh tools/build_install_image.sh`: PASS (112 application binaries;
  utility and GraOS package generation)
- `tools/sqarc --has-member tools/install_payload/graos.sqa graos.bin`: PASS
- identical copies of `utilities.iso`, `utils.iso`, `kernel32/utilities.iso`,
  `boot32pm/dosboot/utils.iso`: PASS
- SQA and utility media contain current GraOS code and resources; other
  inherited application/boot binaries are not rebuilt for this graphics fix.

## Limits and known warnings
- No physical ThinkPad T400 screenshot-after-fix is available. The visual
  result and GPU/driver combination remain to be confirmed on hardware.
- `make packages` tries to rebuild kernel and fails here because NASM is
  unavailable. Direct `tools/build_install_image.sh` PASSED; fresh package
  media were propagated to all release aliases.
- `boot32/nonsysdisk.bin` is missing in the inherited source; installer
  packaging emits a warning and fills its safe area with zeroes.
- The kernel and DOSBOOT binaries remain inherited and are NOT a fresh build.
- v72.92's old animated-hourglass runtime test is intentionally superseded
  by v72.103's safe mode acceptance test. Reenable graphics only after
  testing on the T400, using `GRAOS_CURSOR_HARDWARE_SAFE=0` when compiling.

## Suggested T400 hardware test
1. Install NEW `graos.bin` from `libc/apps/gui/` or updated `graos.sqa`.
2. Reboot/restart GraOS and inspect wallpaper, Start menu, and mouse cursor.
3. Move cursor rapidly diagonally for 30 s; then open/close Filer and
   Navigator while dragging windows.
4. Use `graosctl busy status` / `graosctl busy list` to confirm busy operation
   accounting still runs. Check that rendering remains stable even if a job
   takes longer than 20 seconds.
5. If artifacts persist, capture `serial` diagnostics and another photograph;
   then inspect framebuffer pitch/partial row copy in the VESA syscall.
