# QA — JTMOS / Navigator v72.205

## Uudet testit
| Testi | Tulos |
|---|---|
| `tests/v72205_crypto.py` — SHA-384/512 (909 pituutta), ECDSA P-256/P-384 (120 allekirjoitusta, 1200 väärennöstä/reunatapausta), RSA PKCS1/PSS SHA-256/384/512 2048–4096, 8 Web PKI -ketjuprofiilia, 9 OpenSSL TLS 1.3 -kättelyä | 135 PASS |
| `tests/v72205_real_roots.py` — oikeiden Mozilla-juurien jäsennys + itseallekirjoitus omalla koodilla | 113/117 vahvistettu; 3 SHA-1 + 1 P-521 hylätään hallitusti (ei tuettu) |
| `tests/run-v72204-tls13.sh` (vanha TLS1.3-sarja muutosten päällä) | 99 PASS, i686 `nm -u` tyhjä |
| `tests/run-v72205-navigator-web.sh` — escapet, calc, line-clamp, minmax, flex-minimi, sisäkkäinen flex, syvyys, otsikko | 27/27 bitmap, vector, i686 -O2 |
| Yle-tallenne, 256 KiB pino, ASan/UBSan, 16 reflowta | PASS |
| MTV-tallenne + Tailwind v4 -testityyli, ASan/UBSan, 16 reflowta | PASS |
| Oikea JTMOS QEMUssa, Yle (`release/qa/v72.205/qemu-yle*`) | 4/4 PASS; pikselitiivisteet = host |
| Oikea JTMOS QEMUssa, MTV | ajo kesken 180 s:n aikarajalla (TCG-emulointi ilman KVM:ää); 12/16 reflowta valmiina, ei poikkeusta |
| Regressiot: v72167 DIV 45, v72168 CSS 69+69, v72177 taulukot 18, v72190 3150, v72202 UTF-8 18, v72203 layout 45, HTTP stream 72 | PASS |
| v72168: kaksi grid align-content -testiä | Olivat rikki jo v72.204:ssä; korjattu (auto-rivi 999fr) |
| `run-v72191-navigator-memory.sh` budget 240 MiB | FAIL jo v72.204:ssä (512 MiB ikkuna), ei tämän julkaisun muutos |

## Rajaukset
- Live-yhteyttä yle.fi:hin tai mtvuutiset.fi:hin ei testattu: ympäristön verkko ei päästä niihin.
  Niiden varmenneketjujen tyyppiä (RSA/ECDSA) ei siksi ole todennettu; molemmat profiilit on testattu.
- Liitteet olivat pelkkiä HTML-tallenteita. Ylen ulkoista CSS:ää ei ollut; MTV:n testityyli on
  Tailwind v4:llä tuotettu arvio, ei sivuston oikea CSS.
- Ei fyysistä T400/eMachines-ajoa. Kernel, GraOS ja asennusmediat perittyjä.
- Omaa kryptokoodia ei ole riippumattomasti auditoitu; ECDSA-vahvistus ei ole vakioaikainen (vain julkisia syötteitä).
