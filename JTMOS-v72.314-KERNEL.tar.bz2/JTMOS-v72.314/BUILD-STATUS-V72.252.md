# JTMOS v72.252 – SMSH Interactive Shell Enhancement

Source base: JTMOS v72.251 (retains experimental scattered application memory).

## Implemented

- VT3 SMSH history remains bounded to 32 recent lines; Up/Down and Ctrl+P/N browse it and restore an unfinished draft.
- New editing core supports cursor insertion/deletion; Left/Right, Home/End, Delete, Ctrl+A/E/B/F/U/K/W and Ctrl+D at a nonempty command line.
- Horizontal input viewport keeps editing within the prompt line (no destructive backspacing over wrapped rows).
- `Ctrl+R` reverse-search and Tab file completion retained and integrated into the new editor.
- `history [N|-c]`, `alias NAME=value`, `unalias NAME|-a`, `export NAME[=VALUE]`, `unset NAME`, and `type NAME` SMSH builtins.
- Quote-aware `;`, `&&`, and `||` command sequencing at the VT3 prompt. Variable expansion occurs per command.
- Foreground external process exit status collected via waitable CP processes and `LinuxWaitPid`; pipelines return their last stage's exit status.
- GraOS SMSH consoles gain an independent bounded 32-command history, basic editing shortcuts, and path Tab-completion; independent VT3 shell state is not shared.
- Updated SMSH help and documentation.

## Tests

- Three compiled Linux-host tests for the editor model, builtins/history/aliases and shell sequence/quote handling.
- Native kernel object compile `kernel32/sh/sh.o`, `kernel32/sh/helpapp.o` with i686/m32 JTMOS flags.
- Existing shell Tab/history source smoke test.
- `make release-check-source`, including existing JTMFS 69 crash, 90 atomic-move and 224 atomic-replace cases.

## Important limitations

- This is **not** GNU Bash. No full shell functions, command substitution, programmable completion, heredocs or complete job control.
- The new `;`/`&&`/`||` evaluation and aliases are **VT3 interactive SMSH only**. GraOS SMSH consoles use the older guarded command dispatch; SQSH is separate.
- History and aliases are not persisted to disk or shared with other kernel-console processes.
- No full kernel link or boot-media rebuild (NASM unavailable); included inherited media/binaries are not v72.252 boot images.
- No actual QEMU or ThinkPad T400 keyboard/foreground-job test was possible in this environment.

## Build

```
make release-check-source
make -j2
```

Try in VT3 after full build:

```
history
alias ll='ls -l'
ll
export GREETING=hello
history 10
```

Key tests: type a command, press Up then Down; edit a recalled command with Left, Right and Ctrl+A/E before Enter.
