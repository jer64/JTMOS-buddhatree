# JTMOS v72.228 – Safe Repeat SQA Extraction / JTMFS Error Diagnostics

Base: JTMOS v72.227 FULL SOURCE. Includes prior Navigator, FTP and HTML work.

## Confirmed root cause in uploaded logs

The second `sqa utils.iso` invocation failed with error 23 because
`(kernel32/sh|libc/apps)/sqa.c::sqa_expand_compressed_package()` explicitly
returned 23 when `boot.sqa`, etc. already existed. The destination was not
full (`enospc=0` in supplied diskspace log). The original open_output_file()
also deleted existing files before checking the full replacement contents.

## Changes

- Kernel SQA (`kernel32/sh/sqa.c`) and user SQA (`libc/apps/sqa.c`):
  - Stage every archive member in an exclusive, same-directory `_sqwNN.tmp`.
  - Check the incoming SQA checksum, close and read back the staged file,
    then publish it by namespace rename.
  - Keep a uniquely named `_sqbNN.tmp` backup of any previous file until the
    new file is installed, with best-effort rollback on rename failures.
  - Refuse directory/device targets and retain older content on errors.
  - Expand nested `*.sqa.nz` members into temporary names, then safely replace
    pre-existing `*.sqa` packages (old SQA error 23 eliminated).
  - Keep the compressed source on NZIP/rename failure for debugging.
  - Log more informative SQA errors with path and return/error codes.
- JTMFS: `kernel32/fs/jtmfs/fsadd.c` and `jtmfsAccess.c` now emit
  `ReportMessage` with filename/device/directory block/error code for
  directory entry commit or replacement-create failures.
- Version markers bumped to v72.228, and `libc/apps/sqa.bin` rebuilt.
- New host integration test `tests/v72228_sqa_repeat_replace_host.sh`.

## Important safety limitation

Replacing an existing target requires two JTMFS rename calls (target ->
backup, stage -> target); this is **recoverable**, but not an atomic filesystem
exchange across power loss. An interruption between the two renames may leave
a `_sqbNN.tmp` backup that must be recovered manually. The code explicitly
preserves it on rollback failure. It is not an fsck/journal redesign.

## Verification completed here

- Host `tests/v72228_sqa_repeat_replace_host.sh`: PASS (three repeated
  extracts, stage/backup name collisions, bad SQA checksum, bad embedded NZIP,
  directory destination refusal).
- Host `tools/check_v7176_sqa_nzip.sh`: PASS.
- JTMOS i686 `libc/apps/sqa.bin`: compiles, links as ELF32.
- Kernel `sh/sqa.o`, `fs/jtmfs/fsadd.o`, `fs/jtmfs/jtmfsAccess.o`: compile.
- Full kernel/image linking and QEMU/ThinkPad tests: NOT PERFORMED.

## On-system acceptance test

1. Back up the target file system before testing on real hardware.
2. Execute `sqa utils.iso -o hda1:/tmp` three times, with `boot.sqa` already
   present for repetitions two and three; it must not print error 23.
3. Run archive checksums / `cmp` between produced and expected members.
4. Check `/var/log/kern.log` for `JTMFS: direntry commit failed` or
   `JTMFS: create directory entry failed` messages.
5. If a crash occurs during replacement, inspect `_sqbNN.tmp` (backup) and
   `_sqwNN.tmp` (stage) before deleting either file.
