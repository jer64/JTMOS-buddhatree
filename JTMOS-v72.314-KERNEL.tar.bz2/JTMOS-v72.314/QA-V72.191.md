# QA — JTMOS v72.191 / Navigator 256 MiB

Pohja: koko v72.190-julkaisu. Kernel, libc, Navigator, memwin, BIOS-käynnistyskuva, DOSBOOT ja sovellusmedia on rakennettu uudelleen. Muut sovellusbinäärit ovat aiemman julkaisun yhteensopivia binäärejä.

| Tarkistus | Tulos |
| --- | --- |
| Navigatorin todellinen ELF-muistipyyntö ja kernelin ennakkotarkistus | 262144 KiB pyydetty, 262144 KiB myönnetty, prosessi-ikkuna 262144 KiB: ACCEPT |
| Kernelin oikeasta mmap.c:stä ajettu 256 MiB:n sivutaulukkotesti | PASS: aliasyhtenäisyys, nollaus, PID-rajat, uuden yläpuoliskon PTE:t, asennus/palautus, vapautus ja virhepolkujen peruminen |
| Oikea libc:n brk/sbrk-toteutus 256 MiB:n myönnöllä | PASS: kasvu yli vanhan 128 MiB:n rajan, guard/pino-raja ja epäonnistuneiden muutosten sivuvaikutuksettomuus |
| Muistibudjetti, headroom ja pienemmät myönnöt | 24 tarkistusta PASS ASan/UBSan-ajossa |
| Muistiprofiili ja diagnostiikka | 10033 tarkistusta PASS ASan/UBSan-ajossa |
| DOM-paineen ja aggregate-varausrajojen testit | PASS ASan/UBSan-ajossa |
| DIV/table/CSS-regressiot | 43 + 18 + 45 tarkistusta PASS |
| CSS/layout, fuzz ja sivuelinkaaret | 30 layout-tarkistusta, 120 sivuelinkaarta, 160 virheellistä syötettä ja 3150 elinkaaritarkistusta PASS |
| Kernelin C/NASM-käännös ja linkitys | PASS, image-budget.json täyttää 64 KiB:n minimiliikkumavaran |
| Aliasalueen kolme kanonista esitystä | C, NASM ja linker samat arvot; legacy-alias ja user space rajattu ulos; PASS |

## QEMU, oikea JTMOS-kernel, 2 GiB RAM

`tests/v72191_qemu_memory.py` käynnisti nykyisen VESA/GraOS-profiilin kernelin BIOS-kuvalta ja ajoi oikeita ELF32-ohjelmia. Seuraavat tarkistukset läpäisivät:

- Prosessin todellinen myöntö oli **256 MiB**.
- **240 MiB:n keko** kirjoitettiin ja luettiin sivu kerrallaan; virheellisiä sivuja oli nolla.
- Fork-lapsi tarkisti saman 240 MiB:n datan ja kirjoitti yläalueen COW-sivuille. Vanhemman data säilyi muuttumattomana.
- **Neljä samanaikaista 256 MiB:n työntekijää** käynnistyi; pipe-IPC, waitpid ja vanhemman COW-eristys läpäisivät.
- Historiallisen ensisijaisen ikkunan testi käytti 12 MiB:n varausta, 8 MiB:n kekoa ja 2 MiB:n mmap-aluetta. Fork/COW ja vapautus läpäisivät.
- Ohjelmat palautuivat komentotulkkiin ilman odottamatonta CPU-poikkeusta.

Testi paljasti valmistelussa, että aikaisempi 768 MiB:n kernelaliasalue ei riittänyt suurempien työntekijöiden COW-aliaksiin. Nykyinen 1776 MiB:n alue säilyttää myös legacy-osoitealiaksen. Väliversiot eivät ole toimitettavassa julkaisussa.

Näyttö ja tarkat binääritunnisteet: `release/qa/v72.191/qemu-memory.json`, `qemu-serial.log`, `qemu-console.txt`, `alias-layout.json` ja `image-budget.json`.

## Rajaukset

32-bittiset host-testit ajettiin i386-käyttäjätilan emuloinnissa, koska suoritusympäristö ei käynnistä ELF32/Linux-ohjelmia suoraan. Niiden jälkeen ajettiin yllä kuvattu kokonainen JTMOS-vieraskernel QEMUssa. ASan/UBSan-testit ajettiin natiivissa host-prosessissa; LeakSanitizer on pois käytöstä ympäristön rajoitusten vuoksi.

Vanha `tools/check_release_layout.sh` pysähtyy vanhentuneeseen `^linkit: image`-Makefile-muotovaatimukseen, joka ei täyty myöskään pohjana olevassa v72.190:ssa. Sen onnistumista ei väitetä. Muistiasettelun kanoniset arvot, kuvan linkitysrajat, käynnistys ja prosessien muistitoiminta on tarkistettu yllä erikseen.

Fyysistä ThinkPad T400 -ajoa tai käyttäjän aiemmin kaatuneiden verkkosivujen toistoa ei ole tehty tässä ympäristössä. Muutos ja QEMU-näyttö varmistavat suuremman muistivarauksen; ne eivät osoita kaikkien mahdollisten sivukohtaisten selainvikojen poistuneen.
