# JTMOS V72.264 full release

The canonical `make -j2 full-build` completed successfully. The full source tree,
kernel, CLI/GUI applications, boot/root images, installation ISO and full DOSBOOT
package are included.

Changes: TCP download throughput (uIP out-of-order reassembly and overlap
trimming, 32-frame RX budget, SOCKCTL_WAIT kernel socket wait, direct libc
recv() reads, 16 KiB Navigator body reads) and the publish_utilities_iso.sh
symlink fix that made V72.263 `make full-build` fail after a clean extract.

QEMU 8.2.2: boot smoke PASS; network suite v72.145 10/10 PASS; download
1989 KiB/s lossless (V72.263: 50 KiB/s), 163-317 KiB/s with 2 % loss and
reordering (V72.263: 17 KiB/s). Physical T400/EL1352 testing was not performed.

See QA-V72.264.md, RELEASE-V72.264.txt and FULL-RELEASE-SHA256.txt.
