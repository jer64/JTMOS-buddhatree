# JTMOS v71.96 — Navigatorin käynnistyksen tarkistus

`tests/v7196_navigator_launch.py` kääntää host-testiksi kernelin nykyisen
`exeidentificationmodule.c`-tunnistimen, ELF-osoitealueen tarkistimen ja
`LaunchAppELF32Ex()`-funktion alkuosan ensimmäiseen allokointiin asti.
Se lukee sivukoon ja prosessi-ikkunan rajat suoraan nykyisestä `mm.h`:sta.
Testissä käytetään 32-bittisiä kernelin tietotyyppejä myös 64-bittisellä hostilla.

Tarkistukset: todellisen binäärin tunnisteet ja muistipyyntö; 8 MiB ja 16 MiB
hyväksytään osoitealueen tarkistuksessa; 16 MiB + 1 KiB, 32 MiB ja 64 MiB
hylätään; katkaistu ELF ja rikottu numeerinen ABI-tunniste hylätään.
Vanhojen v71.94/v71.95-binäärien odotettu hylkäys on toistettavissa valinnalla
`--expect-reject`. Uuden binäärin oletustarkistus vaatii hyväksynnän.

Toteutuneet ajot ja v71.95:n regressiot on tallennettu julkaisun `validation`-
hakemistoon. Host-testien läpäisy ei todista fyysisen eMachines/GraOS-koneen
käynnistystä eikä raskaan sivun mahtumista 16 MiB prosessi-ikkunaan.
