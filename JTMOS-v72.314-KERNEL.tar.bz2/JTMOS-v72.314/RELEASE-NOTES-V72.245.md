# JTMOS v72.245 – Filesystem Reliability & Diagnostics

Source base: full v72.244 package. Version: v72.245.

## Implemented (in production C source)

1. **DIRDB fail-closed guard** (`kernel32/fs/jtmfs/diskcache/dirdb_writeDir.c`):
   An invalid RAM directory header may never be written when its uncached
   on-disk header cannot be read completely. The function returns error **313**
   without issuing writes. Existing legacy-header compatibility is preserved
   only when the full header read succeeds and does not contain a modern header.
   Existing healthy disk headers remain protected (error 311).

2. **Bounded-rate queued commit diagnostics** (`kernel32/fs/jtmfs/jtmfsDb.c`):
   The `JtmfsDbWaitQueued()` worker wait now logs at 5 s and every 30 s
   thereafter, showing DNR, waiting PID, worker PID, phase, pending dirents,
   queue state and failure bit. `JtmfsDbStats()` reports warning count and
   maximum observed wait time. The observer NEVER forces a mutex unlock,
   releases a redo record, or prematurely resumes write mutations. If a
   worker is irrecoverably stuck, the waiting thread still waits; this is
   intentional until a safe cancellation/recovery protocol exists.

3. **Commit phase race eliminated**: `db_commit_phase=IDLE` is now assigned
   after acquiring the volume mutation mutex. A second commit waiter can
   no longer overwrite the phase displayed for the running commit.

## New host tests (real production C functions, injected test backends)

- `tests/v72245_dirdb_failclosed_host.py`: failed/short read protects the
  media, healthy header refused and legacy read compatibility retained.
- `tests/v72245_jtmfs_watchdog_host.py`: tests threshold, rate limiting,
  maximum wait statistic and absence of forced releases.
- `tests/v72245_jtmfs_commit_fault_host.py`: compiles the actual kernel
  `JtmfsDbGroupCommit()` with a fake durability backend; injects seven
  errors (data flush, journal enqueue, redo flush, journal verify, FAT flush,
  DIR flush, mirrored super write) and asserts the staged state remains
  intact and writes are frozen. Also tests a successful commit.

## Verified here

- JTMFS v72.245 host tests above: PASS.
- Original v72.241 DIRDB writeback regression (792 variants): PASS.
- Fresh-format JTMFS structural health regression: PASS.
- Both modified kernel translation units compiled to 32-bit i686 objects
  with the project's GCC flags (`-m32 -std=gnu89 -nostdinc`).

## IMPORTANT limitations

- The v72.245 fault-injection host test tests errors at transaction phases,
  not actual sudden power loss, media reordering, nor reboot/replay. The full
  crash/reboot simulator is a separate future stage.
- Kernel startup, real disk I/O and QEMU/T400 integration tests have NOT been
  run in this environment. No on-disk journal layout was changed.
- Boot media inherited from v72.244 (and potentially v72.243/242) are NOT
  regenerated; NASM is not available here. This is a **full source archive**
  with locally recompiled modified kernel objects, not a fully rebuilt bootable
  system. Rebuild the boot media in the developer's own NASM-enabled setup.
- A truly unreadable on-disk legacy directory now correctly blocks a write.
  Investigate the disk error rather than bypassing the guard.

## Commands

    python3 tests/v72245_dirdb_failclosed_host.py
    python3 tests/v72245_jtmfs_watchdog_host.py
    python3 tests/v72245_jtmfs_commit_fault_host.py
    python3 tests/v72241_dirdb_writeback_host.py
    python3 tests/jtmfs_fresh_format_health_regression.py
    make   # on your NASM-enabled development machine
