# JTMOS v72.87 – Stage 2 calendar QA

## Verified in source/build environment

- `calendar.bin`: compiled and linked as JTMOS ELF32 i386 at 0x80004000 – PASS.
- `gui/graos.bin`: compiled and linked as JTMOS ELF32 i386 at 0x80004000 – PASS.
- Native panel-clock click path to `/bin/calendar.bin` with existing-window reuse – source-integrated, syntax-checked; runtime requires T400 testing.
- Separate calendar creates one ordinary GraOS calendar window and an optional editor; never creates a `GRAOS_WINDOW_TASKBAR` window – PASS (source invariant).
- v72.86 dual-slot calendar persistence (edit/delete/recovery/CRC/legacy/dates) – PASS (host tests).
- DOSBOOT v72.78 prompt parity – PASS.
- VESA/autostart/mouse regression – PASS.
- v70.27 GraOS client audit – PASS.
- v72.87 calendar launcher/build/package integration checks – PASS.
- `tools/check_graos_win98_ui.sh`: FAIL on *pre-existing* expected literal caption baseline (`w->y+6`) absent from both v72.86 and v72.87 (newer dynamic caption centering in guiChrome.c); not changed by calendar patch.

## Not verified

- T400 hardware, actual GUI rendering/interaction, simultaneous launches from separate shell processes, root-storage power-fail behavior.
- No full kernel or DOSBOOT rebuild; preserved prior boot/kernel files, not labeled v72.87.
- Existing `utilities.iso` in source tree is OLD and does not automatically include the new app. To use the release, deploy BOTH `libc/apps/calendar.bin` and `libc/apps/gui/graos.bin` to the active boot/install media (`/bin/calendar.bin` and `/bin/graos.bin`) or rebuild full GraOS utilities packages on your development machine.

## Compatibility and safety

- Existing calendar slots `/calendar.a`, `/calendar.b` and legacy `/calendar.txt` untouched by build.
- Old `taskbar.bin` retained for compatibility; running it creates an extra taskbar and could compete for calendar writes. Keep it stopped when using integrated desktop clock.
- GraOS clock launcher avoids a duplicate only when one `JTMOS Calendar` window already exists; it is not an interprocess singleton lock.

## Optional updated native GraOS SQA
- `graos-v72.87.sqa` is a separately assembled GraOS clients package; new `calendar.bin` and `graos.bin` included and verified with sqarc member checks.
- It does not replace the stale `utilities.iso`, which would require a complete boot/image rebuild (NASM unavailable here).
