# Navigator v71.86 — testitulokset ja hyväksymisraportti

## Testattu tässä julkaisuympäristössä

- `make -C libc/apps -f navigator.mak navigator.bin`: PASS,
  i486 ELF32, staattinen JTMOS libc ja Lexbor 3.0.0.
- `tests/v7186_render_memory.c`: PASS, 41 tarkistusta ASan+UBSan;
  vieritys, reunat, muistisuojat, paint-list-culling.
- `tests/v7186_page_lifecycle.c`: PASS, 3 150 tarkistusta ASan+UBSan;
  300 WordPress-tyyppistä sivun elinkaarta ja 150 rikkinäistä dokumenttia,
  CSS:n koonmuutoslaskenta ja Reader-tilan reflow.
- CSS/Layout-regressio: PASS, 30 tarkistusta ja 120 elinkaarta.
- DOM-bridge: PASS, 528 tarkistusta.
- Network 2.0 localhost HTTP: PASS, 13 tarkistusta; async worker PASS.

Uusi elinkaaritesti laskee DOM-areenan, CSS-sääntötaulukon,
piirtolistakapasiteetin ja kuva/välimuistibudjetin summaksi enintään
noin 14,93 MiB testatulla artikkelilla. Tämä ei sisällä prosessin muuta
muistia, GraOSin omaa ikkunan kopiointipintaa, latauspuskuria tai muuta
kirjastomuistia; **se ei todista 16–32 MiB kokonaismuistitavoitetta**.

## Ei testattu / ei täytä vaatimusta

- TLS HTTPS: ei toimivaa natiivia backendia -> FAIL / EI KÄYTÖSSÄ.
- QuickJS: ei moottoria binäärissä -> EI KÄYTÖSSÄ.
- WebP: natiivi dekooderi puuttuu -> EI KÄYTÖSSÄ.
- TrueType/Unicode-fonttirenderöinti -> EI KÄYTÖSSÄ.
- Fyysinen JTMOS/GraOS-laitteisto; resize, kuvahäiriöt ja uptime -> EI TESTATTU.
- Oikeat WordPress-sivustot HTTPS:llä -> EI TESTATTU.
- Selaimen / GraOS:n / kernelin eristäminen mielivaltaisia verkko- ja
  JavaScript-syötteitä vastaan -> EI OSOITETTU.

## Ennen tuotantoa tarvittavat toimet

1. Rakenna ja testaa kryptografinen satunnaislähde sekä BearSSL/Mbed TLS
   TLS 1.2/1.3, SNI, hostname+CA+voimassaolo ja varmennevirheiden hylkäys.
2. Lisää natiivi WebP ja Unicode/TrueType-kirjasto turvallisella fonttipolulla.
3. Käännä QuickJS alkuperäislähteestä ja rajaa JS:n suoritusta omalla
   OS-tason eristysmekanismilla; DOM/WebAPI-toteutusta on laajennettava.
4. Suorita pitkät muistimittaukset, WordPress-sivujen yhteensopivuusmittaukset,
   hakulomake- ja accessibility-testit oikealla koneella.
5. Lisää GraOSin piirtoalijärjestelmään damage-alueen siirtoprotokolla.
