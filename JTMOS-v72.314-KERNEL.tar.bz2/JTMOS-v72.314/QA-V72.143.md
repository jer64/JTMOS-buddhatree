# JTMOS v72.143 – Navigator/GraOS QA

Päiväys 25.10.2026. Pohjana on kokonainen v72.142-lähdepaketti. Tämä julkaisu sisältää lähteet, natiivibinäärit, käynnistysmediat ja täydellisen DOSBOOT-hakemiston.

## Lopputulos

| Tarkistus | Tulos ja todellinen kattavuus |
|---|---|
| Natiivi koonti | PASS. ELF32/i686, Lexbor, WebP, BearSSL ja QuickJS mukana. |
| Kernel / lataaja | PASS. Raakakuva 956 668 tavua; 1 MiB:n ikkunassa 91 908 tavua vapaana. ELF, raakakuva, bootstrap ja BSS-erottelu tarkistettu. |
| Sovelluksen käynnistys | PASS. SYSMEMREQ 102 400 KiB, myönnetty 102 400 KiB, ikkuna 131 072 KiB; oikean kernelin lataajan preflight hyväksyy Navigatorin. |
| Median identiteetti | PASS. utilities.iso:n purettu Navigator vastaa nykyistä binääriä; GUI-, kernel-, boot-image-, NZIP- ja DOSBOOT-kopiot vastaavat kanonisia tiedostoja. |
| Uudet UI-testit, ASan/UBSan | PASS. Historia, virhe/Stop/204, vierityspalautus, fragmentit, CSS, Find-sukupolvet, historiarengas ja resize-erän yhdistely. |
| URL-testit | PASS. 49 sijainti/siirto-URL-paria sekä vaarallisten ja ylipitkien syötteiden hylkäykset. |
| Aika / reap | PASS. 35 s ja 2 s, nollasta alkava aika, 32-bittinen ylivuoto, joutilaan selaimen siivous ja kertaluonteinen SIGKILL. |
| Oikea QuickJS F9-polussa | PASS. Oikea käynnistyksen muistisuunnitelma, DOM-muutos, click-kuuntelija, vanhan JS:n säilyminen virheessä, muistibudjetin epääminen, loputtoman skriptin keskeytys ja 30 VM-elinkaarta. |
| Näppäindekooderi | PASS. Alt+vasen/oikea, tavalliset nuolet, suomalainen AltGr, Alt+Tab/F4 ja Ctrl-kirjaimet. Aiemmat SMSH/SQSH-hakutestit läpi. |
| Tiedostolataus, paikallinen HTTP | PASS. Oikeat lapsiprosessit, rinnakkainen paikallinen sivu, peruutus, myöhäinen tulos, ei ylikirjoitusta, redirect, chunked, 404 ja katkennut vastaus. |
| Säilyvät muisti-/render-testit | PASS. 10 033 profilointitarkistusta, 650 virheellistä HTML-fixturea, 3 150 lifecycle-tarkistusta sekä 1 800 DOM- ja damage-kierrosta. |
| Natiivi QEMU PS/2 | PASS, 10 hyväksyntäkohtaa lopullisella medialla. |
| Natiivi QEMU USB OHCI | PASS, samat 10 kohtaa; USB-näppäimistö ja hiiri tunnistettu ja aktiivinen USB-hiiripolku vahvistettu. |

LeakSanitizer ei ole tässä ympäristössä käytössä. ASan ja UBSan keskeyttävät virheeseen. Testit eivät ole lupaus täydellisestä muistivuodottomuudesta tai modernien verkkosivujen yhteensopivuudesta.

## Natiivin selaimen hyväksyntä

Molemmissa QEMU-ajoissa asennettiin oikeat core-, graos- ja network-paketit lopulliselta utilities.iso:lta, avattiin GraOS ja käynnistettiin paketin Navigator. Todellinen 1024 × 716 asiakasalue varmistettiin ikkunan maksimoinnissa ja paluu 840 × 594 alueeseen testattiin. Sivua vieritettiin ja zoomattiin; hidas HTTP-tiedostolataus peruttiin ja käynnistettiin onnistuneesti uudelleen.

Uudella paikallisella testisivulla F9 muutti tekstin oikealla natiivilla QuickJS:llä. Saman dokumentin #uutinen-hyppy ei aloittanut uutta verkkotyötä. Toisen sivun jälkeen Alt+vasen palautti pikselivertailussa täsmälleen saman artikkelin sisältöalueen. Puuttuvan tiedoston yritys säilytti sen saman sisältöalueen. Navigator suljettiin puhtaasti.

PS/2-ajossa maksimointi tehtiin Windows+nuoli-yhdistelmällä. USB-ajossa käytettiin aidon USB-hiiren otsakepainikkeita; Windows+nuoli-syötteen ajoitus ei ollut USB-automaatiossa luotettava, joten sen toimivuutta ei päätellä tästä ajosta. Alt+vasen kulki molemmissa ajoissa oikean syöteketjun läpi, ja sarjaloki sisältää uuden koodin 39680 (0x9b00).

QEMU käyttää 512 MiB RAM-muistia ja NE2000-verkkoa. USB-ajo käyttää OHCI-ohjainta. Fyysistä ThinkPad T400:aa, eMachines EL1352:ta tai ASUS R558U:ta ei testattu. Tämä ei ole Intel 82567LM -ajurin, ulkoisen HTTPS-palvelun, Google-kirjautumisen tai pitkäaikaisen laitevakauden hyväksyntä.

## Julkaisun toistaminen ja käyttö

```sh
make BOOT_DISPLAY=vesa BOOT_NOGUI=0
python3 tools/check_release_media.py
python3 tests/v72143_navigation_host.py --quickjs
python3 tests/v72143_alt_navigation.py
python3 tests/v72111_download_host.py
NAV_TEST_LEAKS=0 sh tests/run-v7274-navigator-sanitizers.sh
python3 tests/v72111_qemu_navigator.py ../qemu143-ps2 --navigator-only --navigator143
python3 tests/v72111_qemu_navigator.py ../qemu143-usb --navigator-only --usb --navigator143
```

Isäntätestin Lexbor/QuickJS-arkistot rakennetaan tarvittaessa testiajurin ilmoittamilla mukana olevilla työkaluilla. Koonti vaatii GCC/binutilsin, NASMin, maken ja Perlin; QEMU-testi lisäksi QEMUn ja Pillow'n. QEMU-testin VESA-terminaalin luku käyttää oikeista i386-otsakkeista johdettua muistirakennetta. Ajo ei lisää testipoikkeuksia tuotantobinääriin.

Asenna julkaisun paketit ja avaa paikallinen testi:

```text
navigator.bin file:///bin/navgraos143.html
```

Käytä saman julkaisun kernel-, ISO- ja DOSBOOT-tiedostoja yhdessä. Raakakernelin, pakattujen pakettien ja lähteiden tarkistussummat löytyvät alla olevasta evidenssihakemistosta sekä ZIPin MANIFEST-SHA256.txt:stä. ZIPin ulkoinen SHA256SUMS-tiedosto tarkistaa itse julkaisuarkiston.

## Evidenssi

`release/qa/v72.143/media-check.json`, `provenance.json`, `qemu-ps2-result.json` ja `qemu-usb-result.json` sitovat tulokset binääreihin. Samassa hakemistossa ovat lopulliset koonti-, sanitizer-, näppäimistö-, lataus- ja sarjalokit. Sisäisiä QEMU-kuvakaappauksia ei sisällytetä uutena toimituksena.

Vertailussa 793 kernelin C/otsake/assembler-lähdetiedostosta muuttuivat vain julkaisubanneri sekä näppäimistön scanasc.c ja scanasc.h. Intel-, USB-massamuisti- ja FAT32-ajurien lähteet säilyvät v72.142:n mukaisina.

ZIP tarkistetaan erikseen `tools/check_full_release_manifest.py`-työkalulla: yksi versionmukainen juurihakemisto, ei duplikaatti- tai traversal-polkuja, koko tiedostomanifesti, turvalliset linkit, täyden lähdepaketin vaatimat osat sekä medioiden ja testitulosten identiteetti.
