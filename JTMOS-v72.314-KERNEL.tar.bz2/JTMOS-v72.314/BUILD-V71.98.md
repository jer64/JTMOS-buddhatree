# Full release - build and run

Zipin kansio JTMOS-v71.98/ on projektin juurihakemisto.
Build a full JTMOS system on an appropriately provisioned Linux machine:

  cd JTMOS-v71.98
  make

For Navigator 0.2 alone, with the JTMOS libc already prepared:

  make -C libc/apps -f navigator.mak navigator.bin
  make -C libc/apps -f navipctest.mak navipctest.bin

The full root Makefile lists its image outputs as jtm32.img, root1440.img,
utilities.iso and DOSBOOT. Prerequisites (including NASM and ISO/image
utilities) were not available in the release packaging environment, so
there are no prebuilt bootable media in this ZIP.

Do not apply the supplied v71.97-to-v71.98 patch to these v71.98 sources:
those modifications are already integrated.
