# Google login compatibility v71.137

Security hardening in nav_network.c: reject malformed Domain attributes and enforce __Http- and __Host-Http- cookie prefix requirements.

This does not establish Google sign-in compatibility. Required next: working QuickJS, browser DOM/Web APIs, TLS verification, SameSite request context, and real-device tests.
