# JTMOS v72.93 — GraOS busy/hourglass stage 3

## Purpose
Integrate the existing window-scoped `GraOS_BusyBegin`/`GraOS_BusyEnd` API
into real GraOS clients. Stage 1 ownership and stage 2 animation are retained.
VESA-mode EGA text console remains free of any hourglass overlay.

## Implemented

- **Navigator (`libc/apps/navigator.c`)**: a single window-owned token covers
  active HTML, stylesheet and image worker jobs. The event loop reconciles
  token lifecycle after polling; cancellation, navigation replacement, HTTP
  worker errors and cleanup release the token. No blocking wait is introduced
  into the asynchronous network transport. Note that synchronous binary-file
  downloading and lengthy single-threaded DOM/JavaScript work do not animate
  continuously while the application's event loop is blocked.
- **Filer (`libc/apps/filer.c`)**: directory scans, delete operations and file
  copies use independent window-owned tokens. Nested directory refreshes do
  not prematurely release an outer operation's busy state. On an older GraOS
  server lacking the new API, file I/O continues without a token.
- **Calendar (`libc/apps/calendar.c`)**: .ics import/export operations use a
  token owned by the existing calendar window; the token ends before any
  calendar window recreation. This is synchronous feedback, not an async
  operation, so animation during a blocked import is not yet guaranteed.
- **MP3/MPEG-1 media browsers (`libc/apps/media_browser.h`)**: folder scans use
  their own browser window instead of marking the entire desktop busy.
- **GraOS launch manager (`guiStart.c`, `guiArrow.c`, `guiLoop.c`, `graos.h`)**:
  a background GUI application launch triggers a temporary compositor-owned
  global hourglass. It is released as soon as the child's first window is
  registered, or at 5 seconds, whichever comes first. Existing client-owned
  busy operations remain active. This is visual feedback, not a watchdog;
  the launching process is not terminated by the timeout. At most one launch
  is tracked at a time; later launches replace the pending launch indicator.

## Packaging

- Rebuilt ELF32 binaries: `libc/apps/gui/graos.bin`, `libc/apps/navigator.bin`,
  `libc/apps/filer.bin`, `libc/apps/calendar.bin`, `libc/apps/mp3.bin`,
  `libc/apps/mpeg1.bin`.
- Rebuilt `graos.sqa` and `tools/install_payload/graos.sqa` (GraOS/Filer/Calendar
  included). Navigator and media player binaries are present in the full
  release source tree as ELF32 executables, but were not added to `graos.sqa`
  because they belong to their own application categories.
- The existing `utilities.iso` and boot/kernel images were NOT rebuilt.
  The DOSBOOT/boot kernel in the archive is from older releases; use the new
  GraOS/application ELF32 binaries or the updated `graos.sqa` to test this
  change. NASM is unavailable in the build environment.
- Existing calendar store files are neither converted nor overwritten by
  these changes. GraOS taskbar and cursor graphics remain in stage-2 state.

## Known limits

- No real ThinkPad T400 hardware run yet.
- GUI cursor animation depends on the GraOS compositor loop running. A
  synchronous client call that blocks the process's loop may prevent animation
  from progressing visibly.
- Navigator's long synchronous binary downloads are not yet async.
- Launch feedback is bounded at five seconds; it does not distinguish a child
  that has launched without opening a window from a stalled GUI client.
- V72.94 (planned) should add diagnostics, longer stress tests and on-device
  verification, without relying on fake "passed" hardware assertions.
