# JTMOS V72.267 – lokianalyysi (navigator.log + kern*.log, 5.11.2026)

Aineisto: `navigator.log` (9139 riviä, neljä Navigator-istuntoa 13:40–16:39),
`kern.log`, `kern-1…kern-22.log`, `diskspace.log`. `crash.log` ja `www.log`
olivat tyhjiä. Navigator raportoi itsestään versioksi v72.263 (sen oma
VERSION-tiedosto oli jäänyt jälkeen; nyt 72.267).

## 1. Sivun siirto työprosessilta käyttöliittymälle kesti 83 s (korjattu)

edition.cnn.com, 6,9 MiB HTML: verkkohaku kesti 2,7 s (`total_ms=2660`), mutta
siirto forkatulta työprosessilta GraOS-ikkunalle putken kautta kesti noin 80 s
(`net_ipc` kasvoi noin 110 KiB/s, `fetch_ms=83301`).
Syyt: kernelin putki oli 4 KiB ja kopioi tavu kerrallaan, ja Navigator luki
korkeintaan 64 KiB käyttöliittymän kierrosta kohden 2 KiB:n paloina.

Korjaus: kernelin putki on nyt 64 KiB ja kopioi memcpy:llä (PIPE_BUF pysyy
4096:ssa). Navigator siirtää kierroksessa enintään 2 MiB 64 KiB:n paloina,
ja kun putki tyhjenee, se antaa työprosessille vuoron (sched_yield) 10 ms:n
aikarajan sisällä. Kuvadekooderin kuvadata kulkee samaa reittiä.
Mittaus (QEMU): 8 MiB putken läpi V72.266-kernelillä 997 KiB/s,
V72.267:llä 16125 KiB/s.

## 2. Työprosessin fork epäonnistui 425 kertaa (errno=12) (korjattu)

Kernel: `fork: PID20 COW backing clone failed (524288 KiB); kernel VA free
450832 KiB, largest run 305684 KiB`. Jokainen fork tarvitsee kernelin
osoiteikkunasta (noin 1,7 GiB) yhtenäisen alueen, joka on yhtä suuri kuin koko
prosessi-ikkuna. 512 MiB:n Navigatorille mahtui vain yksi lapsiprosessi
kerrallaan. Kun kuvadekooderi (forkattu lapsi) oli käynnissä, verkkotyöprosessin
fork epäonnistui (`active=0`), ja Navigator siirtyi eksponentiaaliseen odotukseen
aina 4 sekuntiin asti. Kuvat latautuivat siksi hitaasti (`img=18/74`).
Kahden yhtäaikaisen 512 MiB:n Navigatorin jälkeen kolmas sai vain 128 MiB.

Korjaus: Navigator pyytää 384 MiB (budjetti 352 MiB; CNN käytti alle 50 MiB).
Silloin selain, dekooderi ja verkkotyöprosessi mahtuvat samaan aikaan. Jos fork
silti epäonnistuu dekooderin ollessa käynnissä, uusi yritys tehdään 100 ms:n
päästä ilman eksponentiaalista odotusta eikä hakua pakoteta selaimen
pääprosessiin. Mittaus (QEMU, 2,5 GiB): 512 MiB:n prosessin toinen
samanaikainen fork `refused (errno=12)`, 384 MiB:n `ok`.

## 3. Lokikirjoitus jumitti käyttöliittymää (korjattu)

Kernel-lokeissa on yli 400 Navigatorin odotusta JTMFS-mutaatiolukossa
(`jtmfs_mutation_lock_mode`). Lukon pitäjinä olivat KJTMFSC, KLOGGER ja
Navigatorin muut prosessit. Odotuksen mediaani oli 256 ms ja pisin 8 s.
navigator.log raportoi joutokäynnillä 120–170 ms:n `slow_ui_tick`-tikkejä.
Jokainen lokirivi oli oma tiedostoon liittävä kirjoitus.

Korjaus: DEBUG-rivit kootaan muistiin ja kirjoitetaan enintään kerran
sekunnissa tai 12 KiB:n välein. REPORT/WARN-rivit kirjoitetaan heti, ja niiden
mukana menevät myös aiemmat puskuroidut rivit. Lapsiprosessit kirjoittavat
puskurinsa ennen `_exit()`-kutsua, eikä forkattu lapsi kirjoita isän puskuria
uudelleen.

## 4. JavaScript-virheet puuttuvista globaaleista (osin korjattu)

Virheiden määrät: `'self' is not defined` 65, `performance` 4,
`HTMLElement` 2, `CustomEvent` 1 ja `IntersectionObserver` 1. Nyt määritellään
`self`/`top`/`parent`/`frames`, `performance` (now, mark, measure…),
`Event`/`CustomEvent`, `Node`/`Element`/`HTMLElement` (instanceof),
`customElements` ja `IntersectionObserver` (raportoi kohteen kerran
näkyväksi). Kaikki määritellään vain, jos nimeä ei vielä ole.

Ei korjattu: Reactin suoratoistoskriptien `$RX`/`$RC` (26 kertaa: "cannot set
property 'data' of undefined") vaatii DOM:iin kommenttisolmut ja
`previousSibling`-ominaisuuden. Se on isompi DOM-muutos.

## 5. Muut havainnot (ei muutoksia)

- edition.cnn.com: alkuasettelu kesti 24 s (`initial layout total_ms=24186`),
  ja käyttöliittymä oli sen ajan jumissa. Klo 15:34 käyttäjä avasi
  ilmeisesti uuden Navigatorin, kun edellinen ei vastannut. Asettelun
  nopeuttaminen vaatii profilointia.
- presstv.ir: `certificate expired/not yet valid`. Kello oli oikein (muut
  TLS-yhteydet onnistuivat), joten vika on todennäköisesti palvelimen
  varmenteessa.
- `TCP send failed fd=1024 errno=32` (EPIPE) 44 kertaa: palvelin sulki
  keep-alive-yhteyden. Haku yritettiin uudelleen ja onnistui.
