# JTMOS Navigator v72.203: oma muistinhallinta, asettelu ja pikselipiirto

## Uuden listan vaihe 1: muistinhallinnan C-pohja

`libc/apps/navigator/nav_memory.h` on itsenäinen C99-toteutus. Se ei kutsu
mallocia, freetä, memcpyä, memsetiä, järjestelmäkutsuja eikä ulkopuolisia
kirjastoja. Se tarvitsee vain freestanding-C:n tyyppiotsakkeet stddef.h ja
stdint.h. Kutsuja antaa valmiiksi kartoitetun, kirjoitettavan muistialueen.
Ydin ei itse kartoita fyysisiä sivuja tai kasvata prosessin osoiteavaruutta.

| Osa | Käyttö | Vapautus ja kustannus |
| --- | --- | --- |
| NavArena | DOM-solmut ja yhden käsittelyvaiheen väliaikaiset objektit | Varaus O(1), reset O(1), koko elinkaari kerralla |
| NavMemory | Eri aikaan vapautettavat skripti- ja muut objektit | First-fit-vapautuslista, jakaminen ja viereisten vapaiden lohkojen yhdistäminen |
| NavArenaMark | Tilapäinen varausvaihe | Paluu tallennettuun varauskohtaan; reset mitätöi vanhat merkit |

Keko kohdistaa palautetut osoitteet 16 tavuun. Areenassa kohdistus annetaan
varauskohtaisesti, ja sen on oltava kahden potenssi. Toteutus tarkistaa
kokolaskennan ylivuodot, alueen rajat ja keon rakenteen. Virheellinen tai
kahdesti vapautettu osoite hylätään: vapaata lohkoa ei etsitä lukemalla
mielivaltaista otsaketta käyttäjän antaman osoittimen edestä.

`nav_mem_check()` käy läpi fyysiset lohkot ja vertaa niitä osoitejärjestyksessä
olevaan vapautuslistaan. Tarkistus ei seuraa tarkistamatonta listan osoitinta.
Varaus ja vapautus käyttävät tätä tarkistusta, joten tämän ensimmäisen keon
operaatiot ovat O(lohkot). DOM:n nopeat solmuvaraukset käyttävät erillisiä
areenoita. Tämä on selkeä lähtöpohja; luokkakohtaiset vapautuslistat voi lisätä
myöhemmin mittausten perusteella.

Keko tukee `alloc`, `calloc`, `realloc` ja `free` -operaatioita.
Uudelleenvarauksen epäonnistuessa alkuperäinen varaus säilyy. Tilastot
`live_bytes`, `peak_bytes` ja `allocations` mahdollistavat elinkaaren
tarkistuksen. calloc nollaa alueen; tavallinen varaus tai vapautus ei pyyhi
vanhaa sisältöä. Nollan tavun varaus palauttaa NULLin. free(NULL) onnistuu.

### Elinkaari ja omistus

Pidä NavMemory-konteksti samassa osoitteessa ja taustamuisti saatavilla koko
keon elinkaaren ajan. Älä kopioi elävää kekoa toiseen osoitteeseen. Jokainen
yksittäinen varaus on vapautettava, tai sen koko omistettu muistialue on
poistettava käytöstä hallitusti. Tämä ei ole roskienkerääjä.

Areenan reset/rewind mitätöi poistettujen varausten osoitteet. Merkkejä
käytetään pinomaisesti: vanhaa merkkiä ei saa käyttää sen alueen uudelleen-
käytön jälkeen. Reset lisää sukupolven ja hylkää sitä edeltäneet merkit.
Kummassakaan varaajassa ei ole lukkoja tai globaalia tilaa; käytä yhtä
omistajaa tai lisää JTMOSin oma lukitus yhteiskäyttöä varten.

### Ensimmäinen esimerkki

`libc/apps/navigator/examples/memory_core.c` näyttää keon, DOM-areenan,
nollatun skriptivarauksen, reallocin ja kaikki vapautukset. Julkaisun vieressä
toimitetaan samassa hakemistossa toimivat `nav_memory.h` ja `memory_core.c`.

```sh
cc -std=c99 -O2 memory_core.c -o memory_core
./memory_core
```

Tavallinen host-komento käyttää koneen normaalia käynnistyskoodia.
Muistinhallinnan oma riippumattomuus testataan erikseen i686-objektista
`-ffreestanding -fno-builtin -fno-pie -fno-pic -nostdinc` -lipuilla:
`nm -u` palauttaa tyhjän tuloksen. Muistiytimessä ei ole ulkoisia symboleita.

### Kytkentä Navigatorin DOM:iin

DOM:n nykyiset osoitevakaat muistipalikat käyttävät nyt NavArena-varaajaa.
Valinnainen `nav_dom_create_in(url, &heap)` ottaa käyttöön NavMemory-keon
kaikille DOM-kontekstin ja muistipalikoiden taustavarauksille. DOM:n
tuhoaminen palauttaa nämä varaukset samalle keolle. Testi luo 400 DIV-solmua
teksteineen omalta alueelta ja vahvistaa, että lopussa live_bytes ja
allocations ovat nollassa.

Normaali `nav_dom_create()` käyttää edelleen JTMOSin nykyistä kekoa
taustapalikoiden hankintaan. Muu Navigator käyttää vielä JTMOSin omaa
libc:tä sekä aiempia Lexbor-, QuickJS-, BearSSL- ja WebP-riippuvuuksia.
Koko selainta ei tässä julkaisussa muuteta kirjastottomaksi. Uuden listan
TLS 1.3-, oma VM- ja muut myöhemmät vaiheet eivät kuulu tähän päivitykseen.

## Aiemmin pyydetty kohta 5: asettelu ja reflow

`nav_box.h` erottaa käytettyjen lohkomittojen laskennan DOM-kierrosta:
content-box/border-box, padding, border, margin:auto, min/max-mitat ja
automaattikorkeuden aspect-ratio. CSS:n prosentit, calc ja periytyminen
ratkaistaan nykyisessä tyylimoottorissa ennen tätä vaihetta. Asettelumoottori
käyttää tätä yhteistä laskentaa, ei erillistä esimerkkialgoritmia.

`NavBoxGeometry` antaa margin-, border-, padding- ja sisältöalueen
suorakulmiot sivun pikseleinä. Nykyiset lohko-, taulukko-, flex- ja
grid-asettelut sekä niiden mittausvaiheet säilyvät. Tämä julkaisu ei väitä
täydellistä modernin CSS:n standarditukea.

Overflow-rajaus tallennetaan piirtoelementtiin omana suorakulmionaan.
Lapsen alkuperäistä leveyttä tai korkeutta ei muuteta rajauksen takia.
Sisäkkäiset rajaukset leikkaavat toisiaan ja liikkuvat mukana asemoinnissa,
muunnoksissa, riviasettelussa ja zoomauksessa. Piiloon jäävä ylivuoto ei
kasvata sivun vierityskorkeutta. Viitteet:
[CSS-laatikkomalli](https://www.w3.org/TR/CSS2/box.html) ja
[overflow/rajaus](https://www.w3.org/TR/CSS2/visufx.html#overflow).

## Aiemmin pyydetty kohta 7: framebuffer ja maalaus

`nav_canvas_init()` kytkee 32-bittisen RGB/BGR-pikselialueen ja tarkistaa
todellisen puskurikoon, mitat ja rivivälin. Riviväli annetaan pikseleinä.
`nav_paint_layout()` voi maalata valmiin piirtojonon suoraan tähän puskuriin.

Navigatorin GraOS-ikkuna käyttää nyt samaa maalaria teksteille, kuville,
reunuksille, liukuväreille ja muille piirtoelementeille. Nykyinen GraOSin
rekisteröity pintapuskuri ja osittaiset päivitykset toimittavat tuloksen
näyttöajurille. Uutta VESA- tai UEFI GOP -ajuria ei lisätä tähän selaimeen.

Kaikki neljä overflow-reunaa rajaavat myös kuvia ja osittain näkyviä
glyyfejä. Kuvan näytteistys ja liukuvärin koordinaatit säilyvät alkuperäisen
laatikon mukaisina. Sekä TrueType- että EGA-tekstin opacity sekoitetaan
todelliseen taustapikseliin. Suurikontrastinen tila, valintakorostukset ja
kuvataustat kulkevat saman rajauksen kautta. Rajaus huomioidaan myös
osumatestissä; opacity-muutos käynnistää uuden piirtokierroksen.

Nykyinen opacity on per-piirtoelementti ja sisäkkäisten arvojen tulo.
Täydellinen eristetyn CSS-ryhmän offscreen-kompositointi jää myöhemmäksi.

## Myös valmistunut vaihe 2: HTTP/HTTPS-datavirta

`nav_http_get_stream()` ja `nav_http_post_stream()` välittävät lopullisen
vastauksen otsakkeet ja enintään 4096 tavun datapalasia callbackille.
Content-Length-, chunked- ja yhteyden sulkeutumiseen perustuvat vastaukset
käyttävät yhtä lineaarista, rajattua lukijaa. Chunked-kehystä ei enää
jäsennetä uudelleen jokaisen verkkoluvun jälkeen eikä siitä tehdä toista
kokonaista kopiota.

`nav_http_get_utf8()` yhdistää tämän ensimmäisen julkaisun UTF-8-dekooderiin
ja välittää skalaarit kutsujalle. Dekooderin tila säilyy verkkopalojen ja
HTTP-chunkien yli. EOF-korvaus tehdään vasta kokonaisen HTTP-vastauksen
valmistuttua; katkennut verkkovastaus palauttaa virheen.

Uusi suoratoistorajapinta pyytää identity-koodausta ja ohittaa kokonaisia
vastauksia tallentavan välimuistin. Jos palvelin lähettää silti pakattua
sisältöä, rajapinta palauttaa virheen ennen callbackeja. Nykyinen puskuroitu
GET/POST säilyttää gzip/deflate-tuen ja välimuistin. UTF-8-rajapinta hyväksyy
UTF-8/utf8-merkistöilmoituksen, hylkää muun ilmoitetun merkistön ja olettaa
ilmoittamattoman tekstin UTF-8:ksi. Se ei ole merkistön automaattitunnistin.

Vastaanotettu sisältö on alustavaa, kunnes koko kutsu onnistuu. Virheen tai
peruutuksen jälkeen osittainen sisältö pitää hylätä. Kutsut ovat synkronisia
ja kuuluvat nykyiseen verkkotyöntekijään; GraOSin tapahtumasilmukka käyttää
edelleen nav_async-rajapintaa. Peruutus tarkistetaan IO-kutsujen välillä.
TLS käyttää nykyistä varmennettua backendia; HTTPS:stä HTTP:hen tapahtuva
uudelleenohjaus estetään edelleen. Tämä ei lisää omaa TLS 1.3 -pinoa.

## Julkaisun käyttö

Asenna `navigator-v72.203.bin` nykyisen `/bin/navigator.bin`-tiedoston
tilalle selaimen ollessa suljettuna. Muistipyyntö on edelleen 512 MiB:n
virtuaali-ikkuna, jonka ydin voi rajata tuettuun kokoon.

Koko lähde-ZIP sisältää pohjan v72.202 ja tämän päivityksen. Navigator on
uudelleen käännetty. Kernel, GraOS, DOSBOOT ja asennusmediat ovat perittyjä,
joten ZIP on FULL-SOURCE-UNBUILT. Vanha utilities.iso ei asenna tätä uutta
Navigatoria. QEMU- tai fyysisen laitteen ajotestiä ei tehty.
