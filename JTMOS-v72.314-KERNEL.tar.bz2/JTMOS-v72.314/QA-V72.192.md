# QA — JTMOS v72.192 / Navigator Yle.fi

Pohja on täydellinen v72.191. Navigator, kernel, A:-käynnistyskuva, B:-juurikuva, DOSBOOT ja sovellusmedia on rakennettu. Muut yhteensopivat sovellusbinäärit ovat aiemmasta julkaisusta.

## Toistettu alkuperäinen vika

V72.191:n oikeilla Navigator-moduuleilla linkitetty ELF32-testiohjelma sai 262144 KiB:n varauksen. Käyttäjän 417157 tavun Yle-HTML jäsentyi, mutta ensimmäinen asettelu laukaisi pinon suojasivulla page faultin: `CR2=0x8ffbfe9c`, `EIP=0x800100f1`, `nav_css_matching_rules`. Ulkoista CSS:ää ja JavaScriptiä ei tarvittu kaatumiseen. Vastaava host-ajo epäonnistui ASan-pinoylivuotoon 256 KiB:n pinolla ja onnistui hostin suurella oletuspinolla.

Todisteet: `release/qa/v72.192/baseline-crash.json` ja `baseline-serial.log`.

## Korjauksen tarkistukset

| Tarkistus | Tulos |
| --- | --- |
| Yle HTML + toimitettu CSS, 256 KiB:n host-pino, ASan/UBSan | 19 tapausta PASS |
| Sama native ELF32-testi oikeassa JTMOSissa, QEMU 2 GiB RAM | 19 tapausta PASS; prosessille todella 256 MiB |
| 16 sisäkkäistä DIViä, sisältö, taulukko ja lomakekenttä | PASS; koko sisältö piirtyy |
| Sama rakenne yli 2048 CSS-säännön välimuistilla | PASS; piirtojälki sama |
| 80 sisäkkäistä DIViä | PASS; hallittu osittainen sivu, ei CPU-poikkeusta |
| Ylen toistuva reflow ja guarded framebuffer, bitmap/vector, 360/560/760/960 px | 16 ajoa PASS; ei asettelun katkaisua |
| Hostin ja JTMOSin layout-arvot sekä framebuffer-tiivisteet | Kaikki 16 täsmäävät |
| Julkaisun oikea Navigator GraOSissa, tallennetun Yle-sivun avaus | PASS |
| Oikean Navigatorin vieritys, zoom, uudelleenlataus ja sulkeminen | PASS; cleanup result=0, ei CPU-poikkeusta |
| DIV/table/CSS-regressiot | 43 + 18 + 45 tarkistusta PASS |
| CSS-valitsimet, cascade ja responsive layout | PASS |
| Layout / sivuelinkaaret / virheelliset syötteet | 30 + 120 + 160 + 3150 tarkistusta PASS |
| Kernelin ELF/raw/bootstrap/BSS ja kokorajat | PASS; 945728 tavua, 102848 tavua vapaana |
| Sovellusmedia ja kernel/Navigator-byte-identiteetti | PASS |

`tests/v72192_yle_page.c` käyttää oikeita jäsennys-, CSS-, asettelu- ja piirtomoduuleita. `tests/run-v72192-navigator-yle.sh` rajoittaa host-pinon 256 KiB:uun. `tests/build-v72192-layout-probe.py` linkittää saman testin native-moduuleihin. `tests/v72192_qemu_yle.py` asentaa pakatut ohjelmat, ajaa testin ja haluttaessa oikean GraOS/Navigator-käyttöliittymän. HTML ja CSS annetaan testien parametreina.

Julkaisu-QEMU-ajon seitsemän hyväksyttyä tarkistusta ja testattujen binäärien SHA256-tunnisteet ovat tiedostossa `release/qa/v72.192/qemu-yle.json`. Kuvakaappaus tarkistettiin sisäisesti; sitä ei jaeta. Piirtotesti ja käyttöliittymätesti läpäisivät v72.192:n kernelillä ja julkaisumedialta asennetulla Navigatorilla.

## Rajaukset

Ylen tallenne ja käyttäjän CSS eivät muodosta täydellistä live-sivupakettia: HTML viittaa myös puuttuviin resursseihin ja eri nimiseen ulkoiseen CSS-tiedostoon. Piirtotesti lisää toimitetun CSS:n erikseen. GraOS-testi avaa alkuperäisen HTML:n paikallisena tiedostona ja varmistaa käyttöliittymän toiminnan; puuttuvat resurssit vaikuttavat sivun ulkoasuun.

Live-HTTPS-yhteyttä yle.fi:hin, koko JavaScript-sovellusta, videoita ja fyysistä ThinkPad T400:aa ei testattu. JavaScript on Navigatorin oletuksen mukaisesti pois käyttöliittymätestissä. Kaatuminen toistui ja korjaantui jo ilman JavaScriptiä. 256 MiB:n muistivaraus ja v72.191:n suurempi prosessi-ikkuna säilyvät.

ASan/UBSan ajettu; LeakSanitizer ei ole käytössä ympäristön rajoitusten vuoksi. Historiallisen `tools/check_release_layout.sh`-tarkistimen vanhentuneen Makefile-muotovaatimuksen onnistumista ei väitetä; kernelin kuvarajat ja mediat tarkistettiin omilla ajantasaisilla tarkistimillaan. Käyttäjän Yle-HTML/CSS/JS-tiedostoja ei sisällytetä lähdepakettiin.
