# Navigator v72.192 — Yle.fi-kaatumisen korjaus

Lähetetyllä Ylen HTML-tallenteella löytyi ja toistui **suorituspinon ylivuoto**. V72.191:n asettelu kaatui oikeassa JTMOS-vieraskoneessa CSS-sääntöjen käsittelyyn ennen ulkoisen CSS:n tai JavaScriptin suorittamista. Muistimyöntö oli jo 256 MiB. Vikapaikka osui pinon alla olevaan suojasivuun (`CR2=0x8ffbfe9c`).

256 MiB:n prosessivaraus ja 256 KiB:n suorituspino ovat eri rajoja. Suurempi keko ei korjaa liian suuria paikallisia työpuskureita rekursiivisessa asettelussa.

## Korjaus

- Taulukon, lomakekentän, lohkokuvan ja rivitaustan suuret työpuskurit on eristetty funktioihin, joita kääntäjä ei saa liittää jokaiseen sisäkkäiseen DIV-kutsuun.
- Rekursiivisten elementtien väliaikaiset tyylit ja CSS-ehdokkaat käyttävät kekoa. Tyylimuuttujien omistus ja vapautus säilyvät.
- CSS-sääntövälimuistin ehdokas- ja osumapuskurit kuuluvat nyt välimuistin omaan varaukseen.
- Asettelun rekursion pinonkulutus on rajattu 128 KiB:uun suhteessa asettelun aloitukseen. Poikkeuksellisen syvä rakenne tuottaa osittaisen sivun ennen suojasivulle päätymistä.

Native i386 / GCC -O2 -mittaus:

| Funktio | Ennen, tavua | Nyt, tavua |
| --- | ---: | ---: |
| node | 7136 | 656 |
| block | 11088 | 1456 |
| children | 1104 | 176 |
| compute | 17888 | 4576 |
| nav_css_matching_rules | 18512 | 80 |

Taulukko kertoo yksittäisen kutsun pinokehyksen, ei koko sivun muistinkulutusta. Suuret kehykset kasautuivat aikaisemmin sisäkkäisten DIV-elementtien mukana.

**256 MiB:n varaus ja 240 MiB:n työmuistibudjetti säilyvät.** DIV/table/CSS-parannukset ja Lexbor-, QuickJS-, WebP- ja BearSSL-tuki säilyvät.

## Käyttöönotto ja testaus

Korvaamalla Navigatorin v72.192-binäärillä saa selainkorjauksen käyttöön. Aiemman v72.191:n kernel tukee edelleen 256 MiB:n varausta. Täysi v72.192-paketti sisältää myös uudelleen rakennetut kernel- ja asennusmediat.

Ylen tallenne läpäisee jäsennyksen, asettelun, toistuvan uudelleenasettelun ja piirtämisen 360/560/760/960 pikselin leveyksillä sekä bittikartta- että vektorifonteilla. Host-ajon pino on rajattu 256 KiB:uun, ASan/UBSan käytössä. Sama testi läpäisee oikeassa JTMOSissa QEMUssa 256 MiB:n myönnöllä. Ylen sivua ei katkaista näissä testeissä. Erillinen 80 sisäkkäisen DIVin testi varmistaa hallitun osittaisen sivun.

Tarkat tulokset: `QA-V72.192.md` ja `release/qa/v72.192/`.

Testisyöte on käyttäjän HTML-tallenne ja mukana toimitettu CSS-tiedosto. HTML viittaa myös puuttuviin resursseihin ja eri nimiseen ulkoiseen tyylitiedostoon. Tämä korjaus varmistaa toistetun asettelukaatumisen poistumisen; se ei vahvista Ylen kaikkien live-resurssien, videon tai JavaScript-sovelluksen toimivuutta. Fyysistä T400-ajoa ei ole tehty. Käyttäjän HTML-, CSS- ja JavaScript-tiedostoja ei jaeta julkaisupaketissa.
