# Navigator v72.191 — 256 MiB muistia

Navigatorin käynnistysvaraus on nostettu **256 MiB:uun** eli 262144 KiB:uun. Mukana on uudelleen käännetty kernel ja libc:n muutos, jotta koko varaus voidaan myös myöntää ja käyttää.

| Raja | Aiempi | v72.191 |
| --- | ---: | ---: |
| Navigatorin SYSMEMREQ | 100 MiB | 256 MiB |
| Kernelin prosessi-ikkuna | 128 MiB | 256 MiB |
| Selaimen hallittu työmuistibudjetti | 100 MiB | 240 MiB |
| DOM-areenan enimmäiskoko | 20 MiB | 40 MiB |
| CSS-allokaatiot | 36 MiB | 64 MiB |
| CSS + layout -profiiliraja | 38 MiB | 80 MiB |
| QuickJS-keon enimmäiskoko | 24 MiB | 48 MiB |
| JavaScript, skriptipuskurit ja muut VM-kulut yhteensä | 32 MiB | 64 MiB |

Prosessin 256 MiB sisältää myös ohjelmakoodin, pinon ja muita natiivivarauksia. Siksi sivuille ja profiloiduille komponenteille jätetään 240 MiB ja 16 MiB pidetään niiden ulkopuolisena liikkumavarana. Komponenttirajoja valvotaan edelleen.

Sivutus kattaa osoitteet `0x80000000–0x8fffffff`. Ensimmäisen 16 MiB:n kiinteä taulukkopaikka säilyy. Laajennus käyttää tarvittaessa 60 lisäsivutaulukkosivua eli 240 KiB prosessia kohti. Varsinaiset datasivut otetaan RAM-muistista ensimmäisellä käytöllä; käynnistys ei täytä koko 256 MiB:ua fyysisillä sivuilla.

Selaimen `fork()`-työntekijät tarvitsevat omat kernelosoitealiaksensa, vaikka fyysiset sivut jaetaan COW-menetelmällä. Kernelin aliasalue on siksi laajennettu 1776 MiB:n virtuaaliseksi alueeksi `0x11000000–0x7fffffff`. Se päättyy ennen käyttäjäaluetta. Tämäkään ei varaa vastaavaa määrää fyysistä muistia.

## Käyttöönotto

Ota käyttöön täydestä julkaisupaketista **sekä uusi kernel että Navigator**. Paketin A:-käynnistyskuva, DOSBOOTin kernel32.nz ja utilities.iso sisältävät vastaavat uudet versiot. Julkaisumedia on rakennettu VESA/GraOS-profiililla.

Vanhalla kernelillä käynnistyminen on edelleen mahdollista, mutta sen aikaisempi prosessiraja pienentää myönnetyn varauksen. Käynnistyksen muistiraportin `granted`-arvon tulee uudella kernelillä olla **256 MiB** ja tavallisen runsaan RAM-muistin tapauksessa `budget`-arvon **240 MiB**.

Jos kernel joutuu rajaamaan varausta esimerkiksi osoitekartan tai vapaan RAM-muistin vuoksi, budjetti johdetaan todellisesta myönnöstä. Vanhan 16 MiB:n ikkunan kohdalla selain ei enää ilmoita sitä suurempaa 32 MiB:n budjettia.

Valinnainen kehittäjätesti on tests-paketin `memwin.bin`: se pyytää 256 MiB, kirjoittaa ja tarkistaa 240 MiB:n keon, tekee fork-kopion ja varmistaa vanhemman datan säilymisen lapsen COW-kirjoitusten jälkeen. Täysi käynnistysvaraus omistaa koko prosessi-ikkunan, joten erillinen sen jälkeinen mmap-alue ei mahdu siihen; pienempi mmap-testitapaus ajetaan erikseen.

## Varmistus

Tarkat tulokset ja suoritetut rajaukset ovat tiedostossa `QA-V72.191.md`. Lähdekoodissa ovat myös 256 MiB:n sivutaulukkotesti, todellista libc:n brk/sbrk-toteutusta ajava testi, muistibudjettitestit ja QEMU-testi. Tämän päivityksen fyysinen ThinkPad T400 -testi jää käyttäjän tehtäväksi.
