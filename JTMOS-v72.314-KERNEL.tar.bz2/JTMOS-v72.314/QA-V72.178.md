# JTMOS V72.178 – network throughput QA

## Passed

- 32-bit i686 freestanding compilation: `kernel32/drivers/tcpip/uip.c`, `jt_http_client.c`, `jt_usersock.c` and `kernel32/sh/networkapp.c`.
- `python3 tests/v72178_tcp_window.py`: PASS (MSS, bounded advertised RX windows, zero-window stop, fallback, MSS initialization, link-budget model).
- `sh tools/check_uip_tcp_payload.sh`: PASS.
- `python3 tests/v72164_nutget_progress.py`: PASS.
- `python3 tests/v72166_nutget_files.py <test-output-path>`: PASS.
- `python3 tools/gen_pkg_installers.py --check`: PASS.

## Not tested / blocked

- End-to-end TCP throughput on physical ThinkPad T400 or eMachines hardware.
- Full kernel link and boot image regeneration. NASM is not available in the current environment; embedded kernel binary/media are inherited and do not include v72.178 kernel changes.
- Ethernet DMA driver performance or packet loss under sustained load. No driver register changes were made without counter evidence.
- Actual HTTPS throughput under KTLS and filesystem overhead.

Treat this archive as **FULL-SOURCE-UNBUILT** until kernel is rebuilt on a NASM-equipped machine. See `NETWORK-THROUGHPUT-V72.178.md` for findings and commands.
