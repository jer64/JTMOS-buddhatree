# JTMOS v72.107 — GraOS input and startup QA

Date: 24 October 2026. Base: complete v72.106 source archive.

The root failure was a mixed-layout `graos.bin`: its desktop and window handlers
read different offsets in `VMODE` than its startup/loop/cursor modules. This
release rebuilds the complete program and makes a mismatch observable at build
and startup. The new tests use the actual private headers and the actual final
ELF, rather than relying exclusively on substitute test structures.

| Improvement | Implementation | Validation |
|---|---|---|
| 1. Consistent build | `-MMD -MP`, included dependency files, VERSION/build-rule/linker-script dependencies, complete rebuild | Every one of 36 GUI objects must rebuild after a private-header change; final ELF/object layout comparison |
| 2. Layout/startup protection | Immutable per-object layout records and pre-display runtime guard; single-sample pointer initialization; real-release arming | Matching TUs accepted; deliberately mixed TU rejected; held startup buttons do not produce a click |
| 3. Reliable button edges | 64-record kernel history, 16-event batches, independent reader cursors, PS/2/USB publication, atomic USB update | 10,000 click pairs; 10,000 held polls; backlog ordering; independent readers; source handover; overflow; serial wrap; old-kernel fallback |
| 4. Shell/capture recovery | One Start action; context dismissal; capture ownership/generation; bounded resize hit tests; responsive external-taskbar fallback | Complete-module test: 100,000 held ticks, 10,000 captured clicks, invalid/destroyed/reused owners, popup-intercepted release, both diagonal cursors |
| 5. Integrated release QA | Complete kernel/apps/boot/DOSBOOT build, final binary check, disposable full-system QEMU tests | See QEMU results and fingerprints in `release/qa/v72.107/` |

Additional corrections found during integrated testing:

- The first generated wallpaper was created in the background cache but was not
  copied to the first scene. The initial full presentation now paints it, so
  old boot/hourglass pixels do not remain on an otherwise live desktop.
- `graos --no-animation` retains a static busy cursor for comparison on hardware;
  the default remains animated. Busy state never captures input.
- `graosctl input` / `graosctl mouse queue` reports layout revision, queue mode,
  cursor, overflow/resync counters, gesture owner, resize state, menu state,
  effective/held-inhibited buttons and backend. Its reply is 20 i686 words and
  uses the existing 432-byte GUICMD transport without resizing it.

Full build: `make` with GCC 13/binutils and NASM 2.16.01 completed, including
all 112 application targets, GraOS/native clients, `kernel32.bin`, compressed
kernel, `jtm32.img`, `root1440.img`, utilities ISO and DOSBOOT. The raw kernel is
1,039,356 bytes, leaving 9,220 bytes within its existing 1 MiB initialized-image
budget. Linker memory-layout assertions passed.

The inherited optional `boot32/nonsysdisk.bin` is absent; the archive builder
warns and zero-fills its reserved safe area. The maintained boot32pm/DOSBOOT
path is built and tested. The deprecated raw boot32 recovery loader is not
claimed to boot this approximately 1 MiB kernel.

Host/runtime checks:

- `tests/v72107_pointer_runtime.py`: PASS, real i686 kernel queue, libc wrappers
  and GUI pointer consumer with production headers; OS/widget callbacks stubbed.
- `tests/v72107_capture_runtime.py`: PASS, entire production `windowMoving.c`
  against real `VMODE`/`WINDOW`; OS/window callbacks stubbed.
- `tests/v72107_layout_guard_runtime.py`: PASS, actual startup guard accepts
  matching translation units and rejects a deliberately incompatible unit.
- `tests/v72107_build_layout.py`: PASS, 36 final linked layout records, all 36
  objects rebuilt by a private-header change; a record-less object is rejected.
- `tests/v72104_graos_mouse_diag.py`: PASS, original diagnostic wire compatibility
  retained, dispatch telemetry follows its new pointer-module location.
- `tests/v72106_cursor_overlay_runtime.py`: PASS, cursor scene preservation,
  all four animation frames, clipping, low memory and display failures.
- `tests/v7294_busy_watchdog_stress.py`: PASS, 100,000 operations, watchdog,
  overflow, wrap and owner cleanup. Run with `ASAN_OPTIONS=detect_leaks=0`
  because LeakSanitizer cannot inspect process threads in this host container;
  the test's address/undefined-behavior instrumentation remains enabled.

The older v72.105 capture test now invokes the real-header, whole-module
regressions instead of maintaining a second VMODE definition.

## Full-system results

Both runs booted the freshly rebuilt kernel, installed core/GraOS from the
actual utilities ISO and ran the final `graos.bin`:

- PS/2 with animated cursor: PASS.
- USB OHCI mouse/keyboard with `--no-animation`: PASS.

Each run verified a painted initial desktop without an unsolicited context
menu, queued input enabled, mouse Start, Windows key, Ctrl+Esc, right-button
context menu, Start closing that context, a held press/release, a new terminal
and subsequent Windows-key input. Screenshots were inspected locally.
Physical TrackPoint/touchpad and T400 display timing remain untested.

The root `graos.sqa` and versioned direct-install copy are now explicitly
mirrored from the same package used by the ISO. Previously the root copy could
remain stale even after a successful canonical ISO rebuild. A package-member
byte comparison is now part of that packaging step.

The full ZIP retains the actual DOSBOOT `kernel32.nz` and `utils.iso` copies
inside their expected directory, rather than omitting them as duplicate bytes.
Their contents must match the canonical kernel/ISO before packaging.
The full-release gate checks canonical `make` outputs; it no longer requires a
manually named standalone Navigator snapshot that the complete build never
creates. Navigator is still built and included in the canonical network package.

## Installation and hardware acceptance

Update both the kernel and GraOS from this complete release. For FreeDOS,
the running kernel is normally the compressed `kernel32.nz` beside DOSBOOT;
copying an unrelated `kernel32.bin` alone will not update that boot path.
Install the current `graos.sqa` / utilities ISO after replacing the boot files.

On the T400: boot without touching the pointing devices, click Start, test
Windows/Ctrl+Esc, desktop/icon context menus, outside click/Escape, window drag
and all resize edges. Release over a menu and verify no capture remains. Test
a held TrackPoint button and USB handover. Compare normal cursor animation with
`graos --no-animation`; record `graosctl input` and `mouseinfo gui` if a problem
persists. A real T400 run has not been performed in this environment.

PS/2 hardware attach/reset policy was retained. The emulator fixture explicitly
runs the existing `mouseinfo reinit` command because QEMU's virtual PS/2 device
starts with reporting disabled under the BIOS-preserve policy. This fixture
step is not a claim that T400 hardware needs the same command.

Historical QA notes and inherited versioned archives in the source tree describe
older releases; this file and the current VERSION describe v72.107.
