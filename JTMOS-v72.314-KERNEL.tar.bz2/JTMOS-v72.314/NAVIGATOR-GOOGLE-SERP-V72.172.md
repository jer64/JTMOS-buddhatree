# Navigator v72.172 — Google search result CSS fallback compatibility

28 October 2026. A user-provided 2.37 MB saved Google search-results HTML
snapshot for `q=jtmos` exposed a real standards-compatibility mismatch in
Navigator's partial-JavaScript mode.

## Root cause

The saved page contains `<noscript><style>table,div,span,p{display:none}</style></noscript>`.
`nav_stylesheets_build()` previously included this style even when the HTML
view had already been rendered by JavaScript in the upstream browser. Its
low-specificity `div{display:none}` suppressed the entire results container.
This is a **generic**, not site-specific issue: any noscript stylesheet can
hide normal page content in a partial scripting browser.

## Fix

In the best-effort static HTML rendering mode, CSS stylesheets and stylesheet
links nested beneath `<noscript>` are not applied/queued. `<template>` remains
inert. This is an intentional compatibility tradeoff: strict no-JavaScript
browser behavior would apply noscript CSS, but Google then hides an otherwise
readable server-rendered results tree. Other CSS declarations remain in source
order and have normal specificity.

## Validation (sanitizer-backed host and saved user HTML)

- Synthetic regression: head CSS remains active; the hidden-results noscript
  stylesheet and noscript link are ignored. A scripting-state reflow remains
  stable and the results remain visible.
- Saved Google HTML (2,373,006 bytes): 4,864 DOM nodes, 11,404 CSS rules,
  4,560 paint operations, 2,461 inside `#rso`; `partial=0`.
- Loading the two user-supplied external CSS resources: 11,509 CSS rules,
  4,560 paint operations, 2,461 inside `#rso`; `partial=0`.
- 1,393 clickable paint operations and a JTMOS result URL present.
- Tests consume snapshots *only at the command line*: private user snapshots,
  tracking query parameters, cookies and account identifiers are NOT bundled.

## Limits

Host parsing is not proof of interactive live Google compatibility. Google
may return a different document, consent flow or JavaScript challenge depending
on cookies, user agent, geo, and traffic. The URL presented by the user exceeds
Navigator's 512-byte address limit; use the semantically equivalent short URL:
`https://www.google.com/search?q=jtmos&num=10`.
JavaScript, Google account sign-in, AI panels, videos, SVG effects, and exact
visual matching are NOT implemented or claimed in this change. Kernel/boot
artifacts remain inherited from the previous complete release.

## Re-run

Build `tests/v72172_google_serp.c` against Navigator host objects and Lexbor;
run it with zero args (self-contained), or with path to saved search HTML and
paths to the two CSS files. Do not commit snapshots into the source tree.
