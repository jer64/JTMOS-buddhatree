# DHCP T400:lla: analyysi ja korjaus V72.150

**Aineisto:** T400:n `tcpdump` V72.149:llä (`release/qa/v72.150/t400-tcpdump-v72.149.txt`).

## Mitä kaappaus näyttää

- T400 lähettää DHCP DISCOVERin, ja **se menee johtoon**: palvelin 10.42.0.1 reagoi siihen heti.
- Palvelin on NetworkManagerin jaettu yhteys (10.42.0.0/24), eli dnsmasq. Ennen OFFERia dnsmasq varmistaa, ettei tarjottava osoite ole käytössä. Kaappauksessa tämä näkyy kolmena ARP-kyselynä "who has 10.42.0.28 tell 10.42.0.1", ja varmistus kestää noin 3 sekuntia.
- T400 vastaanottaa ARP-kyselyt, joten **RX toimii**.
- Seuraava DISCOVER lähti 30 s myöhemmin uudella xid:llä. Tämä on JTMOSin ylläpitosilmukan uusintaväli DHCP:n epäonnistuttua.

Johtopäätös: T400:n verkkoraudassa ei tämän perusteella ole vikaa. JTMOSin DHCP-asiakas odotti OFFERia liian lyhyesti: 1,2 s, 2,4 s ja 3,6 s. Jokaisessa yrityksessä oli lisäksi uusi xid, ja ylläpitosilmukka teki vain yhden 1,2 sekunnin yrityksen 30 sekunnin välein. dnsmasqin myöhässä tullut OFFER oli siksi aina vanhalle xid:lle tai tuli odotuksen jälkeen, ja se hylättiin.

## Toisto QEMUssa ennen korjausta

`tests/v72150_qemu_dnsmasq_dhcp.py` rakentaa QEMUlle raa'an Ethernet-segmentin (`-netdev socket,udp`). Pythonilla toteutettu palvelin toimii kuten dnsmasq: se vastaanottaa DISCOVERin, lähettää kolme ARP-kyselyä osoitteelle 10.42.0.28 ja vasta sitten OFFERin, ja vastaa REQUESTiin ACKilla ja pingiin vastauksella.

V72.149:llä, kun palvelimen tarkistus kesti 4 s, palvelin vastasi jokaiseen DISCOVERiin, mutta JTMOS ei saanut osoitetta 80 sekunnissa. Tämä on sama oire kuin T400:lla.

## Korjaus

- DHCP:n uudelleenlähetys noudattaa RFC 2131:tä: ensimmäinen odotus on noin 4 s, ja se kaksinkertaistuu (4, 8, 16 s) satunnaisen lisän kanssa.
- Koko DORA-kierros käyttää samaa xid:tä, joten myöhässä tuleva OFFER aiempaan DISCOVERiin kelpaa.
- REQUEST lähetetään tarvittaessa uudelleen (4 s, sitten 8 s).
- Ylläpitosilmukka tekee kaksi yritystä, 4 ja 8 s, aiemman yhden 1,2 sekunnin yrityksen sijaan. Uusinnan odotusaika on 4 s.

## Tulokset V72.150:llä

| Palvelimen tarkistusviive | Tulos |
|---|---|
| 3 s (dnsmasqin tyypillinen) | Osoite 10.42.0.28 saatiin 4,4 s:ssa, ping 10.42.0.1 toimii |
| 4 s (v72.149:llä epäonnistui) | Osoite saatiin 5,2 s:ssa, ping toimii |
| 6 s | Osoite saatiin 7,2 s:ssa (OFFER tuli toiseen DISCOVERiin samalla xid:llä), ping toimii |

QEMU:n tavallinen verkkotesti meni läpi 10/10, ja DHCP-koodekin sekä DHCP:n palautustestit menivät läpi.

## T400-ajo

```
ver                    (pitää näyttää 72.150)
inet restart
tcpdump -vv -S -c 12 udp port 67     (DISCOVER, OFFER, REQUEST, ACK)
inet status
ping -c 3 10.42.0.1
```
