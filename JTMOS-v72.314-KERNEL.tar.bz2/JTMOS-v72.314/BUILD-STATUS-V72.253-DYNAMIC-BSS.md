# JTMOS v72.253 – Dynamic BSS Allocation Fix

This source-only corrective release addresses `ld: JTMOS kernel BSS overlaps early stack`
without moving the early boot stack, IDT, paging structures, or removing any linker ASSERT.
The on-disk JTMFS layout is unchanged.

## Changed allocations

| Component | Previous static storage | New storage | Initialization / failure handling |
| --- | ---: | --- | --- |
| FD owner matrix | 62,500 bytes | 8,000-byte *dynamic bitmap* (250×32) | `init_filedes()`; fatal if allocation fails before use |
| FD I/O mutexes | 12,000 bytes | Dynamically allocated and initialized once | `init_filedes()`; fatal if allocation fails before use |
| SMSH shell language state | 18,700 bytes | Lazily allocated and zero-initialized | First shell/bootstrap command; returns error on allocation failure |
| SMSH pipe worker pool | 16,768 bytes | Lazily allocated and zero-initialized | First builtin pipeline; returns error on allocation failure |
| SMSH guarded worker pool | 4,224 bytes | Lazily allocated and zero-initialized | First guarded builtin; returns error on allocation failure |
| SMSH aliases | 7,008 bytes | Lazily allocated and zero-initialized | First alias definition; returns error on allocation failure |

Total fixed .bss decrease: **121,200 bytes (~118.4 KiB)**, before linker alignment.

The FD bitmap uses one bit for each PID/FD ownership relationship. Changes remain
inside the same IRQ-save critical sections used by the original byte matrix.
Dynamic shell pools are allocated with interrupts enabled; only pointer publication
uses an IRQ-save section. Pools persist to avoid releasing memory referenced by
concurrent workers. Boot-critical BSS and JTMFS transaction buffers have not been
converted without proving their initialization and recovery ordering.

## Verification

* `gcc -m32` compilation of all 334 C objects: PASS.
* `python3 tests/v72253_dynamic_bss_host.py`: PASS (native sanitizer-backed checks).
* `make release-check-source`: PASS (includes JTMFS reboot/recovery regressions).
* C-object-only GNU ld script check, with unresolved assembly references ignored:
  `_boot_up=0x00100000`, `_sbss=0x00200000`, `_ebss=0x002AF4AC`,
  `JTMOS_KERNEL_EARLY_STACK_BOTTOM=0x002E0000`; ~194.8 KiB headroom.

**Important:** the C-only link is a **partial validation**, NOT the full kernel link.
NASM is unavailable in the build environment, so bootability was not verified.
Do not treat inherited kernel binaries or boot media as newly built v72.253 artifacts.

## Full build on your Ubuntu JTMOS development host

```sh
make -C kernel32 clean
make -j2
```

Test in QEMU with a disposable disk image before booting a real T400 disk.
If a full link still reports `.bss` overlap, preserve the map file and run
`nm -S --size-sort kernel32/*.o` (or inspect the `.bss.*` sections with `size -A`)
to identify the remaining large boot-time static arrays. Never remove the
`_ebss <= JTMOS_KERNEL_EARLY_STACK_BOTTOM` assertion to make the link pass.
