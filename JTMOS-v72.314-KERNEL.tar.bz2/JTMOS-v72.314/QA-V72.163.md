# JTMOS v72.163 – QA

Päiväys 27.10.2026. Pohjana on kokonainen v72.162-lähdepaketti.
Todisteet: `release/qa/v72.163/`.

| Tarkistus | Tulos |
|---|---|
| Natiivi koonti ja media (`make full-build`) | PASS |
| Ytimen kokoraja (vaatimus 65536 vapaata) | PASS: 936860 tavua, 111716 vapaata |
| QEMU: Angbandin näppäimistö (Press any key, -more-, nuolet, Esc, kirjaimet) | PASS 8/8 |
| QEMU: FHS-asennusskriptit (8 skriptiä, 35 polkua, /usr/bin, DESTDIR, `sqa -u`, KTLS /usr/lib/modules) | PASS 15/15 |
| QEMU: V72.161:n asennusskriptit, #!-skriptit, puupaketit, www | PASS 16/16 |
| QEMU: verkkoregressio | PASS 10/10 |
| QEMU: leikepöytä /tmp/clipboard.txt + SQSH Ctrl+V | PASS 2/2 |
| QEMU: mp3 + plasma-kuorma, ei hiirtä (HDA-kaappaus, 40 s 440 Hz) | v72.162: 1051 katkoa / 22,8 s; v72.163: 0 katkoa |
| SQA-puu-, Angband-port- ja Angband-isäntätestit, `gen_pkg_installers --check` | PASS |

## mp3-mittauksen vaiheet

| Ajo | Katkot | Hiljaisuus |
|---|---|---|
| v72.162, kuorma | 1051 | 22,8 s |
| vuoron luovutus + ytimen äänitehostus, kuorma | 973 | 24,9 s |
| sama ilman kuormaa | 123 | 4,2 s |
| + GraOS-kyselyt 40 ms:n välein ja tilarivit kerran sekunnissa, kuorma | **0** | **0 s** |

Jäljitys (`mp3.bin --trace`) näytti, että purku vei vain noin 13 % ajasta,
mutta silmukka eteni 36 kehystä/s (tarve 38,3). Jokainen kehys odotti
synkronista GraOS-palvelinkierrosta. Korjauksen jälkeen purku etenee noin
kaksinkertaisella reaaliaikanopeudella ja jono pysyy täynnä.

## Rajoitukset

- QEMU:ssa juurilaite on ram:, joten leikepöytätesti ei toista tilannetta,
  jossa ram: puuttuu. '/' osoittaa ytimessä aina juurilaitteeseen
  (`getRootDNR()`), joten polku on sama kaikille ohjelmille.
- V72.162:n QA:ssa havaittiin, että raskaan rinnakkaiskuorman alla `sqa`
  voi palauttaa virheen 11 lopullisen `sync()`-kutsun takia. Asennusskriptit
  pysähtyvät silloin (`|| exit 1`); skriptin voi ajaa uudelleen.
- Ytimen äänitehostus ei yksinään poistanut katkoja QEMU:ssa; varsinainen
  korjaus on mp3.bin:n kyselytahti. Tehostus on rajattu (päättyy, kun jono
  ylittää 0,75 s) ja tarkoitettu varmistukseksi kuormassa myös mp4- ja
  mpeg1-soittimille; niitä ei mitattu erikseen.
- QEMU ajettiin ilman KVM:ää (TCG). ThinkPad T400:lla ei testattu.
