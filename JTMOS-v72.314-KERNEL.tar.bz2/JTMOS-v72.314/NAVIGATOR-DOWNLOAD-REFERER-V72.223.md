# JTMOS v72.223 Navigator download Referer fix

- Navigator now passes its current document URL to downloadmgr.bin as a second argument.
- Download Manager passes the referrer to its forked download worker.
- HTTP downloads send Referer under a strict-origin-when-cross-origin approximation: full source URL on same-origin requests, origin on cross-origin requests, no Referer on HTTPS-to-HTTP downgrade.
- Redirect handling remains bounded to eight hops.
- Legacy download APIs remain available.

Limitations: HTML Referrer-Policy parsing and browser session cookies are not integrated; this is a focused Referer fix. Full JTMOS target build and runtime tests have not been verified in this environment.
