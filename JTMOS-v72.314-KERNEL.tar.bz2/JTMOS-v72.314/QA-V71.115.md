# QA – JTMOS V71.115 (jtmos.com site, Navigator fixes)

| Check | Result | Evidence |
|---|---|---|
| Full `make` | OK, kernel32.bin 1,014,972 B (< 1 MiB) | — |
| `tools/check_jt_httpd_site.sh` (incl. new shots/JPEG/Apache checks) | PASS | `release/qa/v71.115/check-jt-httpd-site.log` |
| `tests/run-v71113-https-front-ci.sh` (+ `/shots/` via Apache, :443 and :80 no-cert) | PASS | `ci-v71113-https-front.log` |
| `tests/run-v71112-navigator-ci.sh` | PASS | `ci-v71112-navigator.log` |
| `tests/run-v71114-ktls-ci.sh` | PASS | `ci-v71114-ktls.log` |
| Navigator in QEMU, https://jtmos.com, 840 px window, whole page | Renders correctly: header, FI/GB, hero, gallery, products, spec, server, contacts, banner, footer | `qemu/navigator-jtmos-com-*.png` |
| nutget -k https://jtmos.com/ + `cat /proc/tls` in GraOS terminal | TLS 1.2 ECDHE-ECDSA-AES256-GCM-SHA384, 15,024 B | `qemu/terminal-nutget-https-proc-tls.png` |
| Chromium 1280 px | OK | `chromium/desktop-1280-*.png` |
| Chromium 390 px (mobile) | OK, scrollWidth 390 (no horizontal scroll) | `chromium/mobile-390-full.png` |

## Screenshot environment (disclosed)

No internet in the sandbox. Guest `hda:/etc/hosts` mapped jtmos.com to the
QEMU host (`qemu/guest-etc-hosts`), where `qemu/vhost_https.py` served this
release's `www/` over HTTPS with a certificate from a local test CA. The
Navigator binary used for the screenshots was the release source plus that
test CA appended to its trust anchors; it is **not** shipped. The QEMU image
was the V71.114-based GUI build; the Navigator and site are V71.115.

## Not tested

- Real https://jtmos.com with the Let's Encrypt certificate.
- The physical eMachines EL1352.
