# Navigator v71.90 – QA and release acceptance

- JTMOS i486 ELF32 link: verify by build and readelf.
- Host memory-pressure / maintenance sanitizer test: see v71.90 CI log.
- Host previous regressions: see tests/run-v7190-navigator-ci.sh.
- Verify SQA via sqarc + host extractor + cmp in package.sh.
- Verify distribution checksums via sha256sum -c.
- HTTPS certificate chain: SKIP (TLS unavailable).
- QuickJS interactive WordPress: SKIP (native engine unavailable).
- Native WebP/TrueType: SKIP (native decoders/renderers unavailable).
- Real WordPress pages and 24h physical eMachines boot: NOT RUN.

Resource policy: <8 MiB OS free -> decoded-image LRU trim to 2 MiB; <4 MiB
or known allocations >configured limit -> clear image pixels and stop only an
idle HTTP worker. This is recovery, NOT a memory-safety or OS stability proof.
