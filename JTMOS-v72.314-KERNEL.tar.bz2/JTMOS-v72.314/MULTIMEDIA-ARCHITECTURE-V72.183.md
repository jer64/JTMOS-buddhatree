# JTMOS v72.183 – multimedia QoS, timing and platform assessment

This is an incremental, source-level multimedia improvement based on v72.182; it is **not** a claim of full real-time, GPU-accelerated, or hardware-validated video support.

## Implemented in v72.183

1. Replaced per-byte streaming ring-buffer copy with two bounded `memcpy` segments for wraparound in `libc/apps/media_stream_buffer.h`. Space is checked before copying; no overwrite. Explicit `received_total` and `delivered_total` counters were added for diagnostics.
2. Added `jt_media_backpressure_sleep_ms()` to make MP3 decoder throttling respond to actual hardware-buffer fill rather than always sleeping 8 ms, bounded to a short 2–16 ms interval when queue exceeds target.
3. Added `jt_media_skip_nonreference()` presentation deadline helper. It explicitly prevents dropping reference frames due to lateness. This helper is tested but has NOT been wired into all codecs.
4. Added `tests/media/v72183_media_qos.c` regression tests for ring wrap, fullness, watermarks, bytes accounting, adaptive sleep and frame drop policy. Existing v72.182 tests still pass.
5. Rebuilt native 32-bit i686 `libc/apps/mp3.bin` successfully.

## Ten capabilities: honest status

| User requirement | Existing base | v72.183 change | Remaining work |
| --- | --- | --- | --- |
| 1. Real-time streams | Audio queue and MP4 audio-clock based sync | Adaptive sleep | Deadline-aware kernel scheduler; hardware profiling |
| 2. CPU/GPU resources | General scheduler, GraOS rendering | Reduced per-byte copying | CPU budget reservation and GPU command API |
| 3. Hardware acceleration | Graphics framebuffer and HDA audio mixer | None | Device-specific Intel GMA / ATI GPU interfaces, secure DMA/IOMMU model |
| 4. AV sync | `jt_media_audio_head_ms` based on queued hardware audio | Drop policy helper | Test PTS/DTS seeking and clock drift on hardware |
| 5. Streaming buffer | Producer/consumer queue and adaptive audio target | Faster bounded ring and diagnostics | Wire to HTTP media producer with backpressure and jitter control |
| 6. Codecs | MP3, MP4/H.264/AAC and other existing app decoders | None | Format matrix, licensing and fuzzing |
| 7. I/O latency | Thread yielding/audio FIFO | Adaptive throttle | DMA completion tracing and disk/network profiling |
| 8. Priority scheduling | General JTMOS scheduler | None | Bounded realtime scheduling with starvation protections |
| 9. Memory | Existing managed buffers | No allocations in ring operations | Large-file streaming, pinned DMA pages and memory budget telemetry |
| 10. Devices | HDA/SB and existing drivers | None | Microphone capture, USB camera, graphics device probing |

## GraOS UI direction (not delivered in this release)

Recommended follow-up: unified media status panel anchored to the existing Volume Mixer with playback state, buffer fill, underruns, selected audio device, mute status and measured AV skew. Do not claim functional device controls without probing hardware. UI should retain current theme and use a compact meter rather than unconditional animations.

## QA and limitations

Run:
```
gcc -O2 -std=c99 tests/media/v72182_media_timing.c -o /tmp/v182 && /tmp/v182
gcc -O2 -std=c99 tests/media/v72183_media_qos.c -o /tmp/v183 && /tmp/v183
cd libc/apps && make -f mp3.mak default
```

These host checks do not establish hard realtime deadlines or verify the device-specific kernel implementation. A new kernel image was not built; existing boot media is inherited and may not include previously unlinked kernel changes. The updated MP3 binary is available in `libc/apps/mp3.bin`, but install-media rebuild has not been performed.
