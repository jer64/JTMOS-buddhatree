# JTMOS v72.178 – uIP/JNET/nutget throughput investigation

## Root cause: TCP receive window, not proven NIC failure

* `UIP_TCP_MSS` was **536 bytes**, despite `UIP_BUFSIZE=1600` and an Ethernet MTU of 1500.
* The uIP TCP encoder in `uip.c` advertised a window of exactly **one MSS** to every peer.
* A one-segment window caps throughput near `MSS/RTT`: at 100 ms, 536/0.1 ≈ 5.36 kB/s (~5.2 KiB/s), matching the observed 3–7.8 KiB/s range.
* The plain HTTP `nutget` path uses **uIP + jt_http_client.c**, not the UDP-oriented `jnet.c` socket facade. HTTPS uses KTLS and `jt_usersock.c`.
* NIC speed (100 Mbit/s) describes the physical link, not the effective TCP window/RTT data rate.

## Changes

1. Increase uIP MSS from 536 to **1460** (1500 MTU minus 20-byte IPv4 and 20-byte TCP headers; the 1600-byte frame buffer remains unchanged).
2. Advertise up to **8 MSS** (11,680 bytes) for the 32-KiB plain-HTTP ring, dynamically limited by free capacity.
3. Increase the heap-allocated user TCP stream RX ring from **4 KiB to 16 KiB** so HTTPS/KTLS downloads can also advertise a window of up to **8 MSS**. This adds about 288 KiB to the persistent 24-slot socket table compared with v72.177.
4. Initialize `uip_conn->mss` on every active or passive open (previously a peer omitting the MSS option could inherit stale/zero connection-slot state).
5. Leave other uIP services at a one-MSS window; `uip_stop()` still forces a zero window and resumes after the reader drains the queue.
6. Do not change ICH9E/82567LM DMA registers or rings without evidence: the current driver already has diagnostic counters for RX drops, CRC errors, missed packets and buffer exhaustion.

## Diagnosis on ThinkPad T400 / eMachines

Run `uip status`, `inet stats reset`, then download a several-MiB **HTTP** test file using `nutget -o test.bin http://HOST/PATH`, and run `inet stats` afterwards. Repeat with HTTPS and compare. If `uip status` indicates SLOW, run `uip fast` for a performance comparison. The source defaults to FAST. On T400 also inspect `inet hw` diagnostics and `rx_drop`, `rx_bad_desc`, `MPC`, `RNBC` counters. Compare RX packets/bytes against the actual file size, and watch for TCP retransmissions.

* With 11,680-byte window at 100 ms RTT the **window-only ceiling** increases to about 114 KiB/s (not a guarantee).
* 100 Mbit/s line rate is **12.5 MB/s before overhead**. uIP remains a simple, mostly single-threaded TCP stack without TCP window scaling, out-of-order reassembly or a modern congestion-control implementation. Expect less than link rate.
* Results from actual hardware and HTTPS depend on latency, server, KTLS encryption cost, Ethernet counter behaviour, filesystem flushes, and scheduler load. Do not infer an Ethernet driver fault from download speed alone.
* The kernel has not been fully linked, booted or benchmarked in this build environment unless explicitly stated otherwise.
