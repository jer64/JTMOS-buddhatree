# JTMOS v72.94 — GraOS Busy/Hourglass Stage 4

## Source basis
Full-source JTMOS v72.93, incremented sequentially to v72.94. Includes all earlier GraOS busy stages, Navigator/Filer/Calendar/media integrations, and the absence of the VESA/EGA console hourglass.

## Implemented

1. **Warning-only long-operation watchdog** (`guiArrow.c`, `guiLoop.c`): each window-scoped busy token older than 20,000 ms is logged **once** with PID, window, token, duration, and bounded description. Operations are not forcibly ended; stalled clients remain visible while alive. Periodic scan is throttled to approximately 250 ms. Closing a window or reaping a dead client still releases tokens.
2. **Read-only IPC diagnostics** (`graosprotocol.h`, `guiServer.c`, modern and legacy GraOS client interfaces): protocol commands 60 and 61 fetch a snapshot of one of the 32 busy slots and a 16-word aggregate statistics snapshot. All replies are copied into the bounded `GUICMD` response. A reused slot may change between queries; there is no globally locked consistent multi-entry snapshot.
3. **graosctl diagnostics**: `graosctl busy status` (or `graosctl busy`), `graosctl busy list`, `graosctl busy stats`, and `graosctl busy test`. The test uses a 3-second legacy busy request and releases it while its process is still alive. Older GraOS servers do not support the new list/stats IPC commands.
4. **Compositor counters** (`guiUpdate.c`, `guiArrow.c`): successful full/region presents, fallback attempts, attempted cursor fast moves, animation phase changes, observed maximum interval between phases and approximate successfully submitted pixel count. Counters are 32-bit unsigned and can wrap on long uptimes; they are observability counters, not an external profiling/latency benchmark. A compositor loop stalled completely cannot execute its own watchdog or animations.
5. **Legacy GraOS client header compatibility:** aligned an older `addFrameBuffer()` function parameter declaration with its definition, allowing its standalone syntax check to succeed.
6. **Preserved functionality**: window-scoped owner validation, launch feedback with bounded five-second duration, four precomputed animation frames, arrow+hourglass for window-scoped busy, global hourglass for legacy or launch busy, cursor split-damage rendering, and Navigator/Filer/Calendar/media application integrations from v72.93.

## Diagnostics

```
graosctl busy status
graosctl busy list
graosctl busy stats
graosctl busy test
```

`busy list` shows window-scoped operations; the number of legacy global owners is included as an aggregate. The warning threshold does **not** terminate the client process or clear its work. `busy test` uses the compatibility global hourglass, not a specific application window.

## Validation

- `python3 tests/v7294_busy_watchdog_stress.py`: 100,000 sequential begin/end cycles under ASan/UBSan, token wrap, 32 concurrent tokens, owner isolation, warning exactly once and recovery. PASS.
- `python3 tests/v7292_hourglass_runtime.py`: 36 assertions plus 5,000 cursor-only moves with region presents; no unexpected full-frame fallback during successful cursor movement. PASS.
- `tests/v7291_busy_host_test.py`, `v7291_busy_integration.py`, `v7293_busy_application_runtime.py`, `v7290_vesa_ega_no_hourglass.py`, and `v7070_graos_hourglass_cursor.py`: PASS.
- New `graos.bin` and `graosctl.bin`: 32-bit ELF i386 entry 0x80004000, rebuilt with current libc. PASS.
- New `graos.sqa` includes byte-for-byte identical new `graos.bin` and `graosctl.bin`, along with older Filer/Calendar binaries from the v72.93 SQA package. PASS.

## Known limitations and important build status

**The JTMOS kernel, DOSBOOT, and utilities.iso have not been rebuilt.** The full source archive may still include earlier binary copies. To use these features, install the new `graos.bin` and `graosctl.bin`, or the v72.94 `graos.sqa` package; `utilities.iso` is not an updated install source.

No real ThinkPad T400 video/USB/TouchPad rendering test has been run in this build environment. A complete multi-hour on-device endurance test and failure-injection under JTMFS are outstanding; host-side tests are not substitutes for those tests.

The 20-second busy warning is diagnostic, not a hang detector that can distinguish a legitimate lengthy copy from a malfunction. Event-loop-wide deadlocks prevent the watchdog from running. `graosctl busy list` polls one slot per IPC; it is not an atomic snapshot under concurrency.

The VESA/EGA text console hourglass previously removed in v72.90 has **not** been reintroduced.

## Suggested on-device acceptance procedure

1. Install `graos.bin` and `graosctl.bin` from v72.94 or the included updated `graos.sqa`. Confirm these binaries actually load rather than earlier `utilities.iso` copies.
2. Open two GraOS windows, start independent long-running operations and run `graosctl busy list`. Switching the pointer between windows should show only the corresponding arrow+hourglass.
3. Use `graosctl busy test`. It should show the legacy global hourglass for approximately three seconds, then return to normal.
4. Run `graosctl busy stats` before and after moving the mouse rapidly and launching/closing applications. Check that presents and animation counters advance without display corruption.
5. Leave a long operation active past 20 s; confirm a single warning but no automatic cancellation. End/close the operation; ensure `busy list` no longer shows the token.
6. Repeat the test with USB mouse and TouchPad; verify the VESA/EGA terminal never draws a glass overlay.
