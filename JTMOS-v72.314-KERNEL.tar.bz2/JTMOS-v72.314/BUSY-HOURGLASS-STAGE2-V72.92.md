# JTMOS v72.92 – GraOS busy/hourglass stage 2

## Implemented (GUI process, not kernel/VESA text console)

- GraOS creates all four 32×32 RGBA large-hourglass frames once in `guiLoadCursor`.
- GraOS creates four additional arrow+small-hourglass frames once at initialization.
- The existing 150 ms busy visibility debounce is preserved; animation runs at
  four 220 ms phases using `(elapsed - 150)/220 % 4`, avoiding scheduling drift.
- The old **global** `JtmosGraOSSetBusy()` compatibility path displays the larger
  centered hourglass (same intent as v72.91).
- The v72.91 **window-specific** `GraOS_BusyBegin()` path displays an animated
  arrow+small-hourglass with the regular arrow hot spot `(0,0)` only when the
  pointer is over the owning busy window.
- Pointer backing-store restoration remains active. With no scene changes
  pending, the old and new pointer rectangles are submitted independently
  when their 32-pixel tile-aligned bounds do not overlap. Overlapping regions
  are merged; a region-present failure retries using a complete frame.
- Existing hand/resize cursors remain available in nonbusy windows.
- `kernel32/init/vesa.c` is **unchanged**; the removed VESA/EGA terminal
  hourglass is *not* reinstated.
- The v72.91 per-window busy token, ownership, cleanup and IPC code is unchanged.

## Files changed

- `libc/apps/gui/graos.h`: cached RGBA animation frames and cursor-only damage metadata.
- `libc/apps/gui/guiArrow.c`: precomputed hourglass and arrow+hourglass sprites,
  explicit time-derived animation phase, selection based on global vs window
  busy mode, cursor-only two-region tracking.
- `libc/apps/gui/guiUpdate.c`: dual cursor-only regions with screen-edge clipping
  and 32-pixel tile alignment, full-frame fallback, metadata reset.
- `libc/apps/gui/guiLoop.c`: explanatory comment for dual-region fast path.
- `tests/v7292_hourglass_runtime.py`: compile and execute actual production
  rendering/time/damage functions against host buffers with ASan/UBSan.

## Verification

- `make -C libc/apps/gui -f graos.mak graos.bin` built a static ELF32 i386 app.
- `tests/v7292_hourglass_runtime.py` passed 33 runtime assertions.
- `tests/v7291_busy_host_test.py` passed 27 prior stage 1 assertions.
- `tests/v7291_busy_integration.py` passed.
- `tests/v7070_graos_hourglass_cursor.py` passed.
- `tests/v7281_t400_mouse_resume.py` passed relevant source checks.
- `tools/sqarc --compare-member graos.sqa graos.bin libc/apps/gui/graos.bin`
  verified the executable matches the distributable app package.
- `graos.sqa` and `tools/install_payload/graos.sqa` include `calendar.bin` and
  `calremind.bin` as before.

**Not verified**: actual ThinkPad T400 on-device rendering and high-rate mouse
movement. The standalone build of the JTMOS kernel/DOSBOOT was NOT executed:
NASM is not installed. The `utilities.iso` retained inside the full source tree
was not regenerated, so it may embed older GraOS application binaries.
Install the rebuilt `graos.bin` or matching `graos.sqa` to test stage 2.

## Next planned phases

- v72.93: application integration (Navigator, Filer, calendar, GraOS launch).
- v72.94: diagnostics, prolonged stress/real-device validation.
