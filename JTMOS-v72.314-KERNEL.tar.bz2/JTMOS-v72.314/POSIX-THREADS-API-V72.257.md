# JTMOS v72.257: threads.h → POSIX/libc compatibility map

This document maps **every class of items** in `kernel32/core/int/threads.h`.
A wrapper means a compatible *public user-mode operation*, not copying the
kernel header into Ring3. In particular, a thread PID and a POSIX `pthread_t`
are not interchangeable handles once multiple userspace threads exist.

## Available POSIX entry points (already present or extended)

| Kernel concept | POSIX libc interface | Status / important distinction |
|---|---|---|
| `pid_t`, `GetCurrentThread()`, `getpid()` | `pid_t`, `getpid()` | Available; never define `pid_t` as a preprocessor macro. |
| Parent/child creation, process exit | `fork()`, `execve()` / `execv()`, `_exit()`, `exit()` | Existing process APIs; fork uses a separate address space. |
| `WaitProcessTermination*()` | `waitpid()`, `wait()` | Existing, for collectable **child processes** only; not arbitrary kernel threads. `WNOHANG` etc. |
| `KillThread()`, `KillThreadEx()`, `ExitThread()` | `kill(pid, SIGTERM/SIGKILL)`, `raise()`, `_exit()` | Existing; no support for kernel-only `KT_NO_THREAD_SWITCH` in user mode. |
| `SwitchToThread()` | `sched_yield()` | Existing syscall-backed cooperative yield. |
| `SwitchToThreadEx(pid)` | none | Explicitly targeting another runnable kernel task is not POSIX. |
| `GetTickCount()`, `GetTickCount2()` | `clock_gettime(CLOCK_MONOTONIC)`, `clock_getres()` | Added; monotonic base currently wraps at 2^32 milliseconds. |
| System date/time | `clock_gettime(CLOCK_REALTIME)`, `gettimeofday()`, `nanosleep()` | Added/previously existing; 1ms nominal resolution. |
| `sleep()` | `sleep()`, `usleep()`, `nanosleep()` | Existing. |
| `GetThreadPriority()`, `SetThreadPriority()`, `set_prio()` | `getpriority()`, `setpriority()`, `nice()` | Existing nice mapping; distinct from kernel priority bytes. |
| Scheduler policy/parameters | `sched_getscheduler()`, `sched_getparam()`, `sched_setparam()`, `sched_setscheduler()` | Added `SCHED_OTHER`, priority 0 only. `SCHED_FIFO` and `SCHED_RR` are NOT implemented. |
| Current directory (DNR/DB and path cache) | `getcwd()`, `chdir()`, `fchdir()` | Path wrappers already present; `fchdir()` returns ENOSYS. Raw DNR/DB/cache not public. |
| Kernel terminal IDs | `isatty()`, `ttyname()`, `tcgetpgrp()`, `tcsetpgrp()` | Existing terminal compatibility layer, with JTMOS limitations. |
| Thread names, memory, CPU time, terminal, count | `jtmos_thread_info()`, `jtmos_thread_count()` | New read-only **JTMOS extension**, not POSIX. Returned PID may be reused. |
| `CreateThreadA`, `create_thread`, `create_app_thread`, `_createAppThread`, `new_thread`, `set_thread` | `pthread_create()` | Declared, but **returns ENOSYS** until a safe Ring3 shared-address-space clone syscall exists. Do not call CPL0 `create_thread()` from applications. |
| Join/detach thread | `pthread_join()`, `pthread_detach()` | ENOSYS pending Ring3 threading/cleanup ABI. |
| Thread self / equality | `pthread_self()`, `pthread_equal()` | Existing PID-based provisional identity; cannot guarantee lifetime-unique IDs. |
| `ThreadCreateStack`, `SetThreadStack`, `ThreadDestroyStack`, `RenderThreadStack` | `pthread_attr_setstacksize()` etc. | Attribute configuration works; actual user thread stack allocation pending Ring3 clone. |
| Mutex/critical sections | `pthread_mutex_*()`, `pthread_mutexattr_*()` | Added userspace private normal/errorcheck/recursive atomics; shared cross-process unsupported. |
| Once initialization | `pthread_once()` | Added atomic once initialization. |
| Thread condition/wakeup | `pthread_cond_*()` | Types/entrypoints present. `pthread_cond_wait`, signal, broadcast return ENOSYS, not fake success. |
| `ThreadTimeOut()`, `TrackThread()`, `ThreadReapQuarantined()` | none | Kernel-only lifecycle/IRQ maintenance; no portable POSIX counterpart. |
| `IdentifyThread`, `_IdentifyThread`, `GetThreadPID` | thread name extensions | Read-only name via `jtmos_thread_info()`, no kernel name mutation from POSIX. |
| `ThreadGiveMagic`, `GetThreadUniquePID`, `valid_pid`, `unif` | `pthread_equal`/process APIs | Deprecated unique-PID helper is identity, not a generation-safe handle. No `LOOPING_PIDS`/`USE_UNIQUE_PIDS` exposure. |

## Structures and arrays: intentionally NOT exported

The following are **internal scheduling and security state**, not POSIX
structures. They must remain behind kernel ABI checks:

- `THREAD`, `APPLICATION`, `FPUREGS`, `TSSEG`, task selectors, TSS saves;
- `thread_scall_active`, `thread_magic`, `threadtmp`, `thread_type`,
  `thread_codedescs`, `thread_datadescs`, `thread_states`, `thread_esps`,
  `thread_name`, `thread_tick`, `thread_ss`, `thread_fpuregs`, `thread_envdb`;
- `thread_ds`, `thread_es`, `thread_fs`, `thread_gs`, `thread_selector`,
  `thread_ml`, `thread_base`, `thread_banks`, `thread_memkb`;
- `thread_terminal`, `thread_special`, `thread_cmdline`, `thread_idling`,
  `thread_dnr`, `thread_db`, `thread_CPUspending`, `thread_eip`,
  `thread_msgbox`, `thread_shell_pointer`;
- `nr_curthread`, `nr_threads`, `force_switch_thread_nr`, `Multitasking`,
  scheduler/IRQ assembly helpers (`copysregs*`, `asmtestapp`, `asmlaunchapp`,
  `RenderThreadStack`, `GetThreadTSS`), and process object pointers.

`FREEZE()/UNFREEZE()` directly manipulate interrupt flags and MUST remain
kernel-private. A pthread mutex does not disable interrupts.  `Immortal()`,
`ThreadQuarantineFromIRQ/Exception()`, `ThreadReapQuarantined()`, `init_threads()`
are also kernel-only. POSIX user-space applications cannot change them.

## Usage

```c
#include <pthread.h>
#include <sched.h>
#include <sys/wait.h>
#include <jtmos/thread_posix.h>

void inspect(void) {
    struct jtmos_thread_info info;
    if (jtmos_thread_info(getpid(), &info) == 0) {
        /* info.name, info.priority, info.memory_bytes */
    }
    (void)sched_yield();
}
```

## Semantics / limitations

- `pthread_*` functions return `0` or an **error number**; process and clock
  APIs return `-1` and set `errno` on error.
- Cross-process `PTHREAD_PROCESS_SHARED` mutexes are not implemented.
- Condition variables do not silently succeed without an OS wait/wake ABI.
- `pthread_exit()` currently terminates the only userspace thread's process.
- `pthread_t` is currently a PID-based compatibility token; PID reuse means it
  is **not** a stable lifetime-unique thread reference.
- JTMOS `pthread_create()` remains unavailable: implementing it correctly
  requires Ring3 shared VM, independent TLS/stacks, safe COW accounting, signal
  delivery, FD lifetime integration and join/reap state.
- `jtmos_thread_info()` makes several syscalls, so it is **not an atomic snapshot**.
- `SCHED_OTHER` is the only admitted POSIX policy; `sched_get_priority_min/max`
  report 0 for this policy. Nice values are handled by `getpriority`.
- The unchanged JTMOS kernel-private `threads.h` remains the authority for
  CPL0 scheduler structures; never compile it directly into a Ring3 port.

## Test commands

```sh
python3 tests/v72257_posix_threads_host.py
python3 tests/v72257_posix_clock_host.py
make -C libc/libc check -j4
```

Host clock regression uses mocked syscalls; full kernel/user ABI and QEMU/T400
runtime integration still need validation. On 64-bit Linux the mocked 32-bit
JTMOS syscall pointers cannot be safely dereferenced: the host test deliberately
checks real-time error propagation and monotonic arithmetic, while the JTMOS
32-bit libc build validates native calling convention.
