# QA – JTMOS V71.112 (Navigator 0.4)

Date: 2026-10-19. Host: Ubuntu 24.04, GCC 13.3, Python 3.13 + Pillow 12,
QEMU 8.2 (`qemu-system-i386`), Chromium headless shell (reference renders only).

## 1. Host regression suites

| Command | Result |
|---|---|
| `sh tests/run-v71112-navigator-ci.sh` (NAV_TEST_LEAKS=1) | PASS – new suite + full v71.89–v71.95 Navigator chain |
| `sh tests/run-v71111-ci.sh` | PASS – v71.104–v71.111 HTTPS/RNG/kernel chain (43 PASS lines) |
| `sh tests/run-v71107-navigator-ci.sh` | PASS after the release string bump (kernel32/include/jtmos_release.h) |

New checks in `tests/v71112_vector_text.c` (ASan/UBSan, LeakSanitizer): 1611
assertions – all 10 built-in faces, glyph coverage (ä, Ö, €, →, Ж, Ω, —, ”),
metrics, descenders, glyph cache budget, 300 truncated/corrupted fonts,
clipping in `jt_ttf_blit`, font-family classification, rem, text-transform,
letter-spacing, color-mix(), hsl(), named colours, ::before/::after text and
boxes (and `:hover` staying inert), grid auto tracks, inline-block, floats,
margin collapsing, flex centering, form controls and the bitmap fallback.

`tests/v71112_jpeg_fit.c` against Pillow BOX downscaling:

| Image | Output | Mean abs error | Peak growth |
|---|---|---|---|
| 1536×1024 baseline 4:4:4 | 220 / 700 px | 1.27 / 1.25 | 324 KiB / 2.3 MiB |
| 2400×1600 baseline 4:2:0 (was unsupported) | 220 / 700 px | 1.30 / 1.19 | 348 KiB / 2.3 MiB |
| 1200×800 progressive 4:2:0 | 220 / 700 px | 1.44 / 1.21 | 3.7 MiB |
| 1800×1200 greyscale | 220 / 700 px | 1.34 / 1.18 | 240 KiB / 1.6 MiB |

The previous full-size path needed ~16 MiB for the 1536×1024 Vunet photo.
All 77 JPEGs in the Vunet/MV fixtures decode with the fit API.

## 2. Native build

```
make -C libc/apps -f navigator.mak navigator.bin      # -Werror, gnu17, i686
python3 tests/v7196_navigator_launch.py libc/apps/navigator.bin
```
ELF32 i386, entry 0x80004000, 1 606 680 bytes, startup 8192 KiB / window
16384 KiB: preflight ACCEPT. Full system `make` and `make image-gui`: PASS.

## 3. Rendering fidelity (saved pages, host harness vs Chromium)

`tests/v7195_saved_pages.c` snapshots (EGA font before, vector font now)
were compared with Chromium headless (JS off and on) at 1280/810/390 px.
Vunet front page height at 1280 px: 81 293 px (Chromium 82 339 px; v71.111
gave 37 545 px). Structure, fonts, badges, colours, panels and photos match;
known differences are listed in RELEASE-V71.112.txt §7.

## 4. Performance (host, -O2, same 1280 px layout)

| Page | v71.111 reflow | v71.112 reflow | CSS memory |
|---|---|---|---|
| Vunet front | 0.226 s | 0.100 s | 2.10 → 1.68 MiB |
| Vunet article | – | 0.040 s | 1.36 MiB |
| MV-lehti front | 0.611 s | 0.312 s | 2.55 → 2.14 MiB |

## 5. Runtime test in JTMOS (QEMU)

Procedure (scripted through the QEMU monitor):
1. `make && make image-gui`, blank `hd_jtmos.img`, boot jtm32.img +
   root1440.img + utilities.iso with std VGA, ne2k_isa, USB HID.
2. In SMSH: `sqa cdrom`, `sqa core.sqa`, `sqa graos.sqa`, `sqa network.sqa`, `gui`.
3. GraOS → Applications → Run:
   `navigator.bin http://10.0.2.2:8000/vunet.net.html` (host `python3 -m http.server`).
4. Ctrl-L to the article (`art.html`) and the MV-lehti front page (`mv.html`).

Second run, after releasing the glyph cache before each parse and lowering
the image budget to 6 MiB: vunet → article → MV → article → vunet, all pages
rendered (the first run showed "HTML document exceeded DOM parser limits" on
the second page: Lexbor ran out of memory in the 16 MiB window).
Scripts: `release/qa/v71.112/qemu/`. The guest ran navigator.bin from the
full-system `make` of the same sources (ELF differs by 160 bytes of code
layout from the package.sh build in release/bin; same source and flags set).

Observed: HTTP fetch, all stylesheets, vector text, pseudo-elements, round
badges, two-column responsive grid, and the hero photos ("Image loaded –
media 381 KB"). Before the streaming JPEG decoder the same photos failed in
JTMOS with "Image unavailable or format unsupported" (out of memory in the
16 MiB window) although host tests passed. Screenshots: `release/qa/v71.112/`.

Not tested: physical eMachines EL1352, live HTTPS sites from inside JTMOS
(the sandbox had no outbound access from the guest), long-running stability.
