# QA – v72.183

- Previous `v72182_media_timing.c`: PASS (31 checks)
- New `v72183_media_qos.c`: PASS (wraparound, queue full, rebuffer, counters, sleeps, deadline helper)
- Native i686 `mp3.bin` application: build/link PASS
- Hardware playback on T400: NOT RUN
- Whole kernel build: NOT RUN
- Complete package image rebuild: NOT RUN
- GPU hardware decode: NOT IMPLEMENTED
