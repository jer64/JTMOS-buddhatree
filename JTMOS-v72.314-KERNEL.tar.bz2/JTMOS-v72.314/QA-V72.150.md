# JTMOS v72.150 – QA

Päiväys 26.10.2026. Pohjana on kokonainen v72.149-lähdepaketti (SHA-256 `cc95c930…2bce84`).

| Tarkistus | Tulos |
|---|---|
| Natiivi koonti, media, mediavahti, Navigatorin preflight | PASS |
| dnsmasq-kaltainen LAN, v72.149, 4 s:n tarkistus | FAIL (perustaso; sama oire kuin T400:lla) |
| dnsmasq-kaltainen LAN, v72.150, 3/4/6 s:n tarkistus | PASS: osoite 10.42.0.28 saatiin 4,4/5,2/7,2 s:ssa, ja ping 10.42.0.1 toimii |
| QEMU-verkkoregressio (slirp) | PASS 10/10 |
| DHCP-koodekki, DHCP-palautus ja rakennetestit | PASS |

Rajaus: T400:lla ei ole vielä ajettu V72.150:tä. Kaappaus kuitenkin osoitti, että DISCOVER lähtee johtoon ja vastaanotto toimii.
