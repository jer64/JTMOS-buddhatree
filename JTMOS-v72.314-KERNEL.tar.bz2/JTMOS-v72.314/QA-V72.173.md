# JTMOS v72.173 QA — package installer fix

| Check | Result |
| --- | --- |
| `python3 tools/gen_pkg_installers.py --check` | PASS |
| `make package-installers` | PASS |
| Deliberate stale generated header was detected | PASS |
| Direct `tools/build_install_image.sh` regenerated stale header | PASS |
| `tools/build_install_image.sh` built complete SQA payload | PASS |
| `tools/publish_utilities_iso.sh` published utility media | PASS |
| `buildroot root1440.img` and `buildroot rootdisk.img` | PASS |
| `tools/check_release_media.py` | PASS |
| Rooted ZIP checker (source-relative symlink count) | PASS |
| Full release manifest and ZIP CRC | PASS |
| Kernel image public-version check | NOT RUN SUCCESSFULLY; kernel inherited from prior release, kernel not rebuilt |
| Fresh full `make` on a native JTMOS development machine | NOT VERIFIED |
| GraOS hardware/QEMU boot test | NOT VERIFIED |

Source of boot32/nonsysdisk.bin warning is nonfatal. See RELEASE-V72.173.txt.
