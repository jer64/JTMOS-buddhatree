# Navigator v72.167 – varmennus

28.10.2026. Selainpäivitys JTMOS v72.166:n täydestä lähdepaketista.

| Tarkistus | Tulos |
|---|---|
| Uudet DIV/CSS-käyttäytymistestit, Lexbor HTML5, ASan + UBSan | PASS 45/45 |
| Samat testit kevyellä HTML-varajäsentimellä, ASan + UBSan | PASS 45/45 |
| Muuttamaton v72.166, samat testit ja Lexbor | 15/45 läpäisi; 30 epäonnistui |
| Muuttamaton v72.166, samat testit ja varajäsennin | 14/45 läpäisi; 31 epäonnistui |
| Aiemmat valitsin/cascade/grid/pituus/URL-testit v71.95 | PASS |
| Aiempi CSS/layout-testi v71.83 | PASS 30 tarkistusta ja 120 sivun elinkaarta |
| Aiempi virheellisen CSS/HTML-syötteen testi | PASS 160 tapausta |
| Aiempi sivujen elinkaaritesti v71.86 | PASS 3150 tarkistusta |
| Testisivun koko jäsennys–CSS–asettelu–piirto, 390 ja 800 px | PASS, kuvat tarkastettu |
| Native i386/ELF32, Lexbor + QuickJS + WebP + BearSSL | PASS, staattinen linkitys |
| Oikean ytimen ELF-tunnistus ja latausasettelun ennakkotarkistus | PASS, ei käyttöjärjestelmän käynnistysajo |

Uudet testit kattavat kiinteät ja nollakokoiset divit, min/max-koot,
content-box/border-box-reunat, prosentti/calc-korkeudet, näkyvän ja leikatun
ylivuodon, pystysuuntaisen vieritysalueen, inline-block-koon, allekkain olevien
sisarusten positiiviset/negatiiviset marginaalit, auto-marginaalit,
`display:contents`, sisäkkäiset divit ja yhdistetyt luokat, HTML:n `<div/>`,
CSS:n lisäyksen, uudelleenasettelun, perityt reunavälit/box-sizing-ominaisuuden,
loogiset koot ja reunavälit sekä flexin pystyakselin keskityksen.

Todisteet: `release/qa/v72.167/`. `baseline-*.log` sisältävät muuttamattoman
pohjan tulokset; `final-*.log` lopulliset 45 tarkistusta. Koonti- ja
ELF-ennakkotarkistuslokit eivät ole todiste selaimen ajamisesta GraOSissa.

LeakSanitizer on pois käytöstä tämän ympäristön prosessi-/säierajoituksen
vuoksi; AddressSanitizer ja UndefinedBehaviorSanitizer ovat käytössä.
GraOS-/QEMU-ajoa tai ThinkPad T400 -laitetestiä ei tehty; QEMU ei ole
käytettävissä tässä ympäristössä. Julkisten sivustojen yhteensopivuutta tai
täydellistä CSS/HTML-standardien toteutusta ei väitetä.

Loogisten ominaisuuksien kartoitus kattaa vaakasuuntaisen LTR-asettelun.
RTL-/pystykirjoitustiloja, täydellistä flex/grid-mallia tai kaikkia
vanhempi/lapsi/tyhjälohkomarginaalien yhdistymistapauksia ei toteutettu tässä
päivityksessä. Kuvien osittainen overflow-leikkaus, elementtikohtaiset
vierityspalkit ja vaakavieritys ovat aiemman moottorin rajoittamia.
Selainpäivitys ei muuta ytimen tai asennusmedioiden v72.166-binaareja.
