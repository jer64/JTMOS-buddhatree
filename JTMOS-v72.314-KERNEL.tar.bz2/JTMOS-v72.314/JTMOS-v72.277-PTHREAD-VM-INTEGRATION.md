# JTMOS v72.277 — Kernel shared-VM integration for future Ring3 pthreads

## Status / safety boundary

This is an incremental kernel integration, **not** functional POSIX thread
creation. `SYS_threadctl(181, FEATURES)` remains **0**;
`pthread_create()` continues to return **ENOSYS**. No Ring3 clone is
published runnable, and Navigator must continue using its existing workers.
The prebuilt boot image is inherited from v72.276; rebuilding a new kernel
requires a complete NASM-enabled toolchain.

## What changed

1. `mm/thread_vm_group.c` now exposes a generation-checked shared-VM **owner**
   resolver, group reference counts and a two-phase root-exit gate. A newly
   attached, **unpublished** child is assigned the same `thread_base` and
   memory size as its owner, without allocating a COW alias. The future
   caller is responsible for the process-VM and lifecycle locks.
2. `mm/mmap.c`: primary and extended user PTE tables, installed PDEs, user
   memory limits, and mapped/VMA-backed mmap operations resolve to the VM
   owner when a group member has been explicitly attached. Page-fault
   resolution follows the owner for user COW/lazy/demand pages. This is an
   architectural path, not one exercised by currently enabled pthreads.
3. `threads.c` defers a group leader's teardown while group members remain.
   A member does not free the leader's mapping metadata or primary backing;
   the member detaches before its PID generation is cleared. Ordinary
   process teardown remains unchanged when no shared-VM group exists.
4. `fork.c` rejects a live multi-member shared-VM process with `EAGAIN` rather
   than attempting an unsafe COW snapshot while siblings can modify the VM.
   Ordinary `fork()` uses its existing separate-process COW behavior.
5. `SYS_threadctl`: read-only `OP_VM_OWNER=7` / `OP_VM_REFS=8` diagnostic calls
   for the caller only. Ordinary processes should report owner=self, refs=1.
6. `thread_start.h`: a pure, testable plan for a Ring3 cdecl start frame
   (`EIP`, `ESP=stack_top-8`, fake return IP, arg, `EFLAGS=0x202`). The existing
   `OP_VALIDATE=6` now checks the two writable frame DWORDs as well as all
   stack mappings. **No frame is written and no TSS is scheduled.**
7. libc's `pthreadprobe.bin` reports the VM owner/refcount diagnostic values.

## Critical missing pieces before enabling CREATE

- **Atomic task publication**: build/validate a new Ring3 TSS, protected
  kernel stack, FPU context, cdecl user frame and group member binding inside
  one rollback-safe transaction; never publish runnable priority until done.
- **Shared process resources**: fd/socket table ownership/refcount, cwd,
  environment, signals, heap accounting, allocator locks and fork barriers.
- **Correct thread-exit and join**: detached/exit state, return values,
  generation-safe handles, waiting without freeing a live ss0 or user stack,
  process-exit semantics when the leader exits before its members.
- **TLS and libc reentrancy**: per-thread `errno`, library globals, locks,
  cancellation, malloc and I/O safety; add real stack guard pages.
- **Full in-guest tests**: QEMU, VirtualBox, T400; concurrency/mmap/fork,
  error-injection and forced-exit stress cases.

## Tested here

- Kernel C objects (`mmap`, VM group, `threads`, `scs`, `fork`) build as i686.
- libc both application and kernel variants build/link (make check).
- ELF32 `pthreadprobe.bin` builds, headers share the same ABI.
- VM group model: 17 old plus 18 new cases; validator: 6; start frame: 9.
- AddressSanitizer + UndefinedBehaviorSanitizer for all four host tests.
- pthread ABI static regressions, syscall IRQ-policy audit.
- No actual Ring3 thread execution or full kernel/boot image validation.

## Developer test

After building **the new kernel** with NASM, run `pthreadprobe` in JTMOS.
Expect `features=0`, `vm_owner=<current PID>`, `refs=1`, `create=ENOSYS`,
`OP_VALIDATE=0` for the sample resident stack. If root or refs differ in a
single-thread program, investigate a stale VM generation before proceeding.
