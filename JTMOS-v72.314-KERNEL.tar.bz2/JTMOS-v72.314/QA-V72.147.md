# JTMOS v72.147 – QA

Päiväys 26.10.2026. Pohjana on kokonainen v72.146-lähdepaketti (SHA-256 `7aaa2760…52fc06`).

| Tarkistus | Tulos |
|---|---|
| Natiivi koonti, media, mediavahti, Navigatorin preflight | PASS |
| ICH9E-ajurimalli, ASan/UBSan | PASS: rengas täynnä 31/32:lla, TDT≠TDH jonon ollessa ei-tyhjä, sekä kaikki aiemmat V72.108–V72.146-tarkistukset |
| Mutaatiot | 5/5 hylätään (täysi rengas, vanha RXDCTL, vanha GCR, COLD=64, ei R2-korjausta) |
| QEMU-verkko, NE2000 | PASS 10/10 |

Rajaus: T400-rautaa ei ole ajettu V72.147:llä. Ohje on tiedostossa `T400-ICH9E-PROBE-V72.147.md`.
