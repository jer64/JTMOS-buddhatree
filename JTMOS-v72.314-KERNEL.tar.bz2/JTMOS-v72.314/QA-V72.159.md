# JTMOS v72.159 – QA

Päiväys 27.10.2026. Pohjana on kokonainen v72.158-lähdepaketti (SHA-256 `079e3f8d…b5c9fd`).

| Tarkistus | Tulos |
|---|---|
| Natiivi koonti ja media | PASS |
| nutget: Content-Length, palvelin pitää yhteyden auki (HTTPS / HTTP) | v72.158 FAIL (jumittui 60 s / -110); v72.159 PASS, tallennettu 4,4 s / 4,7 s |
| nutget: clean, close_notify + RST, RST ilman close_notifyä | PASS |
| QEMU-verkkoregressio | PASS 10/10 |
| SQSH:n Ctrl+C | PASS |
