# JTMOS V72.264 – tarkistukset

## Tulos

Koko julkaisun käännös (`make -j2 full-build`) onnistui puhtaasta purusta
V72.263-paketeista, kun `publish_utilities_iso.sh` oli korjattu. Kaikki alla
luetellut QEMU- ja host-testit läpäistiin. Fyysisellä T400:lla ja EL1352:lla ei
testattu.

| Tarkistus | Tulos |
| --- | --- |
| `make -j2 full-build` (GCC 13.3.0, NASM 2.16.01) | PASS |
| Kernelin kuvabudjetti: 975392 tavua, 73184 vapaana (raja 65536) | PASS |
| `tools/check_public_version.sh` → V72.264 | PASS |
| QEMU-käynnistys: BIOS/NZIP, kernel, SMSH, RAM mkdir/cd, help | PASS |
| QEMU-verkko v72.145 (10 testiä: refused, nonblocking, 4 rinnakkaista, FIN/EOF, 1 MiB echo, nonblocking connect ×2, UDP ×2, listen/accept) | 10/10 PASS |
| QEMU-lataus, häviötön user-net, 8 MiB | PASS, 1989 KiB/s |
| QEMU-lataus, 2 % pudotus + uudelleenjärjestys, 4 MiB, siemen 264 | PASS, 198 KiB/s |
| QEMU-lataus, 2 % pudotus + uudelleenjärjestys, 4 MiB, siemen 1 | PASS, 317 KiB/s |
| QEMU-lataus, 5 % pudotus + uudelleenjärjestys, 2 MiB | PASS, 48 KiB/s |
| Navigator: navigointibudjetti ASan/UBSan + 27 muistisuunnitelmatarkistusta | PASS |
| Navigator: kaksi rinnakkaista >1 MiB IPC-siirtoa, kuvajono | PASS |
| Navigator: 12 HTTP-integraatioskenaariota, 8 HTTP-välimuistiskenaariota | PASS |
| T400 (82567LM) / EL1352 (nForce) | Ei ajettu |

Kaikissa latausajoissa vastaanotettu data tarkistettiin tavu tavulta.

## Vertailu V72.263:een (sama nettest, sama QEMU)

| Mittaus | V72.263 | V72.264 |
| --- | --- | --- |
| Lataus 8 MiB, häviötön | 50 KiB/s (162,7 s) | 1957–1989 KiB/s (4,1 s) |
| Lataus 4 MiB, 2 % häviö, siemen 264 | 17 KiB/s (233,9 s) | 163–198 KiB/s |
| Datasegmenttejä releen läpi (4 MiB, 2 %) | 4083 | 3030–3056 |
| 1 MiB TCP-echo (lähetysrajoitteinen) | 506 KiB/s | 1168–1236 KiB/s |

Myös "häviötön" QEMU-ajo menettää paketteja: QEMUn NE2000 pudottaa kehyksen, kun
sen noin yhdeksän kehyksen vastaanottorengas on täynnä. V72.263:n uIP hylkäsi
jokaisen epäjärjestyksessä tulleen segmentin, joten yksi pudotus maksoi koko
ikkunan uudelleenlähetyksen. Oikealla raudalla rengas on isompi (ICH9 64, nForce
128), mutta sama mekanismi laukeaa jokaisesta Internet-häviöstä.

Häviöllisen linkin nopeutta rajoittaa nyt pääosin vastapää: QEMUn slirp-TCP
korjaa ilman SACKia yhden aukon kierrosaikaa kohden.

## Testiympäristön huomio

Ensimmäinen 2 %:n häviöajo (siemen 264) jumittui noin 280 kt:n kohdalla. Releen
laskurit pysähtyivät molempiin suuntiin, eikä slirp lähettänyt enää edes
uudelleenlähetyksiä. Vieraan TCP-pino ei voi pysäyttää niitä, joten testireleen
säie kaatui (siinä ei ollut virheenkäsittelyä). Releeseen lisättiin
`OSError`-käsittely. Sama ajo meni sen jälkeen läpi, samoin kaksi lisäajoa eri
siemenellä ja 5 %:n häviöllä.

## Toisto

```sh
make -j2 full-build
python3 tests/v72109_qemu_boot.py "$PWD/jtm32.img" /tmp/boot
python3 tests/v72145_qemu_network.py /tmp/net
python3 tests/v72264_qemu_download.py . /tmp/dl direct 8
python3 tests/v72264_qemu_download.py . /tmp/dl2 lossy:2 4        # RELAY_SEED=264
RELAY_SEED=1 python3 tests/v72264_qemu_download.py . /tmp/dl3 lossy:2 4
python3 tests/run-v72263-navigation-budget.py /tmp/navhost
sh tests/run-v72257-navigator-performance.sh
```

Lossy-tilassa toinen, CPU:ton QEMU (`-machine none`) tarjoaa slirpin
hub-liitoksella (user ↔ dgram). Python-rele välittää Ethernet-kehykset sen ja
vieraan NE2000:n välillä.

Lokit ja tulokset: `validation-v72.264/` (vertailuajot:
`validation-v72.264/baseline-v72.263/`).

## Provenienssi

- Pohja: `JTMOS-v72.263-KERNEL-BOOT.tar.bz2` + `JTMOS-v72.263-LIBC-APPS.tar.bz2`
  (FULL-RELEASE-SHA256.txt V72.263 täsmäsi purun jälkeen).
- Kernel: 975392 tavua. Hashit: `FULL-RELEASE-SHA256.txt`.
- Boot-, verkko- ja lataustestit ajettiin tasan tämän julkaisun `jtm32.img`- ja
  `utilities.iso`-tiedostoilla.
- Navigatorin host-testit ajettiin samalla lähdekoodilla ennen versionumeron
  nostoa (VERSION/jtmos_release.h). Koodiin ei tehty muita muutoksia sen jälkeen.
- Seuraava vapaa lähdeversio: V72.265.
