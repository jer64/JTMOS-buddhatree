v71.126: Pointer-stable chunked DOM allocations with 64 KiB growth and a 12 MiB aggregate budget. This is a partial implementation of stage 2; image budgeting and comprehensive timeout integration remain pending. No target runtime validation performed.
Full source snapshot retained from v71.125; prebuilt Navigator package remains v71.124 and must be rebuilt.
