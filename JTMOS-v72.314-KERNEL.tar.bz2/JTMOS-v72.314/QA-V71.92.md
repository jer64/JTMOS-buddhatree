# QA JTMOS Navigator v71.92 – testisuunnitelma ja todennetut rajat

## Suoritetut

- `make -C libc/apps -f navigator.mak -j2 navigator.bin`: ELF32/i386.
- `sh tests/run-v7192-navigator-ci.sh`: SHA-256, kiinnitetty manifesti,
  manipulaatiot, LTS-ajastus, välimuistin siivous, vanhat regressiot.
- Puhdas jakelubuild ja SQA:n binäärivertailu: `package.sh`.

## Ei voitu hyväksyä

- Riippumaton sandbox-/kernel-suojausarviointi.
- Luotettava TLS/CA/CSPRNG, vanhentuneiden varmenteiden testit.
- Full-process RSS 16–32 MiB ilman JS:ää ja 32–64 MiB JS:n kanssa.
- Fyysinen GraOS-laite ja oikeat HTTPS-WordPress-sivustot.

`CERTIFICATION_LTS.md` määrittelee kaikki estoedellytykset.
