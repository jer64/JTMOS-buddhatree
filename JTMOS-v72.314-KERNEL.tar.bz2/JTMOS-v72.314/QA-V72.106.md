# JTMOS v72.106 — QA and implementation notes

## Scope
The GraOS cursor pipeline now composes the software cursor only while a frame
is being presented. A clean scene (`VMODE.buf`) is preserved throughout GUI
redraws and cursor moves. `VMODE.present_buf` is an optional 3 MiB overlay
frame, allocated before the optional window underlay cache. In low memory,
the bounded 32×32 transient overlay is always rolled back after `scall`,
including display failures and the full-screen retry.

## Cursor policy
- Arrow, hand and four resize cursors remain.
- Legacy global busy shows the large animated hourglass.
- Window-bound busy shows the arrow with a small hourglass only over the busy
  window, following the existing owner/generation busy protocol.
- Busy starts displaying after 150 ms and animates every 220 ms.
- One union damaged rectangle is used; the unsafe split-present path stays off.
- Busy is never an input grab and cannot itself block mouse buttons.

## Verification
- ELF32 `graos.bin` rebuilt with `make -f graos.mak default` — PASS.
- `python3 tests/v72106_cursor_overlay_runtime.py` — PASS (18,055 checks):
  5,000 ordinary cursor moves and 1,500 low-memory moves; full redraw under
  cursor, edge clipping, all four busy frames, region failure and both display
  failure/success rollbacks. Real `guiArrow.c`/`guiUpdate.c` production code
  was compiled into a Linux mock-VESA harness.
- `python3 tests/v72105_mouse_capture_host.py` — PASS.
- `python3 tests/v72104_graos_mouse_diag.py` — PASS; updated old safe-profile
  assertion to the new isolated-overlay mode.
- `python3 tests/v7294_busy_watchdog_stress.py` — PASS.
- `python3 tests/v7293_busy_application_runtime.py` — PASS.
- `sh tools/build_install_image.sh` — PASS; produced new GraOS SQA and ISO.
- `boot32/nonsysdisk.bin` missing — safe zero-fill packaging warning.
- Full kernel/DOSBOOT build — NOT RUN (NASM unavailable here).
- ThinkPad T400 graphics regression/hardware testing — NOT RUN.

## Recommended on-machine test
1. Back up the current working `graos.bin` and SQA package.
2. Update to V72.106 `graos.bin` or `graos.sqa`. The GUI only changed in
   user-space, so kernel replacement is not needed for this compositor change.
3. Open the Start/context menus and drag/resize overlapping windows.
4. Run `graosctl busy test` to view the 4-frame large hourglass. Trigger a
   Filer or Navigator long operation to inspect the window-bound busy arrow.
5. Exercise screen corners, rapid mouse movement and switching between
   menus, terminal windows and file copies. Record any freeze with
   `graosctl mouse stats` and `mouseinfo gui` (requires V72.104+ kernel).

Keep old working GraOS binary available for reverting if T400 hardware shows
unexpected tearing or a frozen pointer. Simulated success is not T400 proof.
