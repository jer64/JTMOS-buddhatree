# JTMOS v72.296 — Experimental pthread and socket hardening

## Scope

Based on v72.295. This is a **source-and-targeted-application release**, not a
boot-tested full-system release. It does **not** enable ordinary Navigator
pthread network workers or advertise a production POSIX pthread ABI.
Navigator continues to use the working navnetd process-based network pool.

## Changes

- `libc/libc/modern/pthread.c`: `pthread_once` uses acquire/release state
  publication. Mutex owner state now uses atomic access on the relevant paths.
- `libc/libc/modern/js_socket_slot.h` (new): atomic socket slot state machine:
  FREE -> RESERVED -> LIVE -> CLOSING -> FREE.
- `libc/libc/modern/bsd_socket.c`: sockets reserve a slot before initializing
  it, and closing transitions through CLOSING before making the slot reusable.
- `inet_ntop(AF_INET)` writes into a caller-owned buffer instead of calling
  `inet_ntoa`, whose static buffer cannot be shared safely.
- `libc/apps/pthreadonce.c` + `.mak` (new): 8 workers x 1,024 calls of
  pthread_once plus recursive mutex operations, isolated Ring3 test.
- Test registered under utilities-only applications and in the tests.sqa
  staging/contents checks of tools/build_install_image.sh.
- Navigator and navnetd binaries relinked with the updated libc.
- Version bumped to 72.296.

## Important limitations

- **Concurrent close and recv/send of the same socket is NOT made safe** by
  slot reservation; a further per-descriptor reference/closing protocol is
  needed before shared socket API use can be enabled for general threads.
- `gethostbyname` and other legacy resolver static buffers are still shared;
  full thread-safe resolver, allocator, FILE, TLS, and FD lifetime are pending.
- Normal POSIX `pthread_create` remains blocked without safe kernel feature
  advertisements. Experimental raw Ring3 tests require KERNEL_RING3_TEST=1.
- No QEMU or T400 execution of v72.296 was performed in this environment.

## Actual validation

- `make clean`: PASS (removed old objects and generated SQA/NZ payloads).
- `make -C libc/libc application -j2`: PASS (clean rebuild).
- `make -C libc/apps -f pthreadonce.mak default`: PASS, ELF32/i386.
- `make -C libc/apps -f navigator.mak default`: PASS.
- `make -C libc/apps -f navnetd.mak default`: PASS.
- Host concurrency test of exact `js_socket_slot.h`: 32 native threads,
  320,000 total reservations, no duplicate live slots: PASS.
- Targeted Ring3 test binaries built successfully; **not executed** on JTMOS.
- Partial large application `makeapps` build stopped at execution time limit
  after >100 programs built. Full system `make KERNEL_RING3_TEST=1 -j2`
  stopped because NASM is missing; no bootable new full install media built.
- `release/v72.296/tests.sqa` and `navigator-update.sqa`: tested SQA members
  with `sqarc --compare-member`; `.sqa.nz` roundtrip bit-identical: PASS.

## Building and testing on development machine

Extract KERNEL32, LIBC and APPS archives to the same directory and run:

    cd JTMOS-v72.296
    make clean
    make KERNEL_RING3_TEST=1 -j$(nproc)

Run from a test environment after installing the rebuilt test package:

    pthreadonce.bin
    pthreadrace.bin
    pthreadposixgate.bin
    pthreadchurn.bin
    pthreadlifecycle.bin
    pthreadreap.bin

`pthreadonce.bin` must print PASS before enabling any additional concurrency.
Avoid reusing production filesystems when testing experimental Ring3 changes.
