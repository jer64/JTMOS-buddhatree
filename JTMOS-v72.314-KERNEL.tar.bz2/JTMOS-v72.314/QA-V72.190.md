# QA — JTMOS v72.190 / Navigator DIV ja TABLE

Pohja: JTMOS-v72.189-FULL-SOURCE-UNBUILT.zip. Julkaisun lähdekoodi ja Navigator ovat v72.190; kernelbinääri ja A:-käynnistyskuva ovat perittyjä.

| Tarkistus | Tulos |
| --- | --- |
| Uudet DIV/table/CSS-tapaukset, Lexbor 3.0.0 + ASan/UBSan | 43/43 PASS |
| Samat uudet tapaukset, rajattu varajäsennin + ASan/UBSan | 43/43 PASS |
| Aiemmat v72.177-taulukkotestit, molemmat jäsentimet | 18/18 PASS kummallakin |
| Aiemmat v72.167-DIV-testit, molemmat jäsentimet | 45/45 PASS kummallakin |
| Tasaus, bitmap ja vector, Lexbor | 69/69 PASS kummallakin |
| Asemointi, Lexbor | 48/48 PASS |
| CSS/layout- ja elinkaarisarjat, molemmat jäsentimet | 30 layout-tarkistusta, 120 sivuelinkaarta ja 3150 elinkaaritarkistusta PASS |
| Virheellinen CSS/HTML, molemmat jäsentimet | 160 tapausta PASS |
| Selector/cascade/responsive regression, molemmat jäsentimet | PASS |
| Native Navigator, ELF32/i686, Lexbor/QuickJS/WebP/BearSSL | Compile/link PASS |
| Kernelin ELF-käynnistyksen ennakkotarkistukset | ACCEPT, startup/granted 102400 KiB; rajat, identiteetti ja katkaistut ELF-tiedostot PASS |
| Testisivun oma piirtäjä 800 px ja 360 px | PASS, kuvat tarkistettu visuaalisesti |
| Sovelluspakettien ohjelmainventaario | 126 binääriä, jokainen yhdessä ohjelmapaketissa, PASS |
| Pakettirakenne ja utilities-median sisällöt | PASS; median navigator.bin vastaa uutta binääriä ja navtable190.html testilähdettä |
| Kernelin ja A:-kuvan periytyminen sekä aiemman mp3.bin:n säilyminen | Vertailtu v72.189-ZIPin tavuihin, PASS |
| Julkinen versionumero ja seuraava versio | 72.190 / 72.191, PASS |

ASan/UBSan-ajot pysähtyvät havaitessaan virheen. LeakSanitizer ei toimi tämän suoritusympäristön prosessirajauksessa; vuototarkistusta sillä ei väitetä suoritetuksi. Elinkaaritestien oma muistibudjetin tarkistus läpäisi (pahin tapaus 30,26 MiB).

Ensimmäinen median pakkausyritys pysähtyi väliaikaisen hakemiston irrallisten kopioiden tarkistukseen. Kopiot poistettiin vain kun täydet tavut vastasivat valmista pakettia. Pakkausskripti tekee tämän saman tarkistuksen myös välittömästi lopullisen pakettirakenne-ehdon edellä. Lopullinen ajo tavallisella build_install_image.sh-skriptillä sekä median julkaisu ja riippumaton sisältötarkistus läpäisivät.

Lokeja ja piirtäjän kuvia: `release/qa/v72.190/`. Testiskripti: `tests/run-v72190-navigator-div-table.sh`.

Ei ajettu: koko kernelin linkitys, JTMOSin käynnistys QEMUssa, ThinkPad T400 tai muut fyysiset koneet. Paketti on siksi FULL-SOURCE-UNBUILT; uusi Navigator ja sovellusmedia ovat silti käännettyjä ja tarkistettuja.
