# QA – JTMOS v72.91

| Verification | Result |
|--|--|
| GraOS 32-bit compilation and static ELF link | PASS |
| graosctl 32-bit compilation and static ELF link | PASS |
| JTMOS application libc rebuilt, public busy API exported | PASS |
| 27 real busy-manager state assertions in compiled host harness | PASS |
| Busy command/headers/server IPC authorization wiring | PASS |
| v70.70 hourglass source regression | PASS |
| v71.122 VESA takeover regression | PASS |
| v72.81 T400 mouse resume regression | PASS |
| SQA member comparison (graos.bin/graosctl.bin) | PASS |
| SQA retains calendar and calremind | PASS |
| Kernel32 and DOSBOOT rebuild | NOT DONE – NASM unavailable |
| GraOS GUI on ThinkPad T400 | NOT DONE |

The v72.90 VESA regression is version-locked to **72.90**, so it reports
`FAIL: release increments sequentially` when run on the correctly incremented
v72.91 tree. All its substantive checks printed PASS; the version guard is
unrelated to the v72.91 changes. Do not misreport the whole regression as PASS.

The host unit test compiles real busy-state C functions copied verbatim from
`guiArrow.c` against lightweight host structures, without a real compositor.
This exercises ownership, event cleanup, token allocation and cursor-state
resolution but is NOT a live hardware graphical test.
