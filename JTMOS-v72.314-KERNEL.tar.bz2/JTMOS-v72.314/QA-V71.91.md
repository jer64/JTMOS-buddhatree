# QA JTMOS v71.91 — hyväksymismatriisi

| Ehto | Tulos / rajaus |
|---|---|
| ELF32/i486 käännös | PASS Ubuntu cross-build |
| HW-hookin ohjelmistovaratila | PASS host-mock ja framebuffer-testit |
| Todellinen GPU-blit/fast fill | NOT RUN, ei ajuria |
| HTTP-välimuistin LRU, TTL ja budjettirajat | PASS host-testit |
| Kuvien purkuvälimuisti LRU | Aiemman v71.90-mallin regressiot |
| Renderöinti, DOM, CSS, media, lisäosat | PASS v71.90 CI |
| HTTP/1.1, työntekijä | PASS v71.90 CI |
| HTTPS sertifikaattiketju | SKIP, TLS ei käytettävissä |
| QuickJS, WebP, TrueType natiivissa | Ei käytössä |
| Fyysinen eMachines / GraOS | NOT RUN |

Muistibudjetti: HTTP-objektivälimuistissa rajana 2 MiB (worker); kuva-
cache enintään 10 MiB (UI). Koko prosessin RSS ei ole tällä mitattu.
`nav_hw_set_backend` hyväksyy vain luotetun sisäisen callback-ajurin;
ei tue kolmannen osapuolen suoritettavia lisäosia.
