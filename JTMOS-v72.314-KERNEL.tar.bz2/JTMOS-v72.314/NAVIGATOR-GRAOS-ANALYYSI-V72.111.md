# GraOS–Navigator: syväanalyysi ja toteutettu suunnitelma V72.111

25.10.2026. Koko V72.110-julkaisun päälle tehty V72.111 sisältää sekä nämä muutokset että erillisen Intel 82567LM -korjauksen (`docs/ICH9E-V72.111.md`).

## Tärkeimmät havainnot

Navigatorin ja GraOS:n välinen raja on prosessien välinen komentorajapinta. Selain ylläpitää omaa pikselipintaa, GraOS hallitsee ikkunan kokonaismittoja ja otsakepalkkia, ja verkko-/resurssityöt voivat valmistua käyttöliittymän käsittelemien tapahtumien välissä. Virheet syntyivät näiden elinkaarien yhteensovituksesta: väärä asiakasalueen korkeus, tapahtumajonon nälkiinnyttämä maalaus, synkroninen tiedostolataus, keskeytyvän sivun puskurin elinikä ja epäonnistuneen piirtokomennon kuittaaminen valmiiksi.

Aiemmat V72.108:n hiiren suhteellinen liike, perinteinen hiirellä avattava Start ja näppäimistön fullscreen overview sekä V72.110:n GraOS-muistirajojen korjaukset säilyvät. Tässä ei oteta käyttöön toista GUI-kehystä tai toista selainmoottoria.

## Viisiosainen toteutus

| Osa | Todettu ongelma | Toteutettu käyttäytyminen |
|---|---|---|
| 1. Ikkunasopimus | Selain vähensi resize-mitasta kiinteän otsakekorkeuden; fonttikoko voi muuttaa otsaketta | Uusi julkinen GETCLIENTSIZE=64 kertoo todellisen asiakasalueen ikkunan omistajalle. Selain kysyy sen avauksessa ja resize-tapahtumassa. |
| 2. Tapahtumien ja työn jako | Rajaton tapahtumien purku voi estää latausten ja piirtämisen etenemisen | Enintään 16 tapahtumaa ja yhteistoiminnallinen 4 ms:n budjetti kierroksella. Exit lopettaa ennen seuraavaa työ-/piirtovaihetta. |
| 3. Latausten elinkaari | Tiedoston siirto voi tukkia UI:n, Stop ei kattanut kaikkia töitä, myöhäinen tulos voi julkaista perutun tiedoston | Erillinen streamaava file worker; UI omistaa tilapäistiedoston ja julkaisee sen vasta hyväksytyn valmistumisen jälkeen. Stop kattaa HTML/CSS/kuvat/tiedoston ja keskeyttää uuden laiskan resurssityön. |
| 4. Sivun vaihdon atomisuus | Uuden sivun työn puskuri oli myös näkyvän vanhan sivun lähde | Erillinen staging-puskuri säilyttää vanhan lähteen valmistumiseen asti. Cancel, virhe ja 204 säilyttävät näkyvän sivun. Lisämuisti varataan profiilin budjetista. |
| 5. Piirto ja osoiterivi | Epäonnistunut refresh kadotti dirty-tilan; sama otsikko vaurioitti työpöytää; overlayn alle tehty partial-piirto rikkoi ulkoasun; vanha lataus korvasi uuden osoite-editin | Dirty säilyy IPC-virheessä, muuttumaton caption välimuistitetaan, popup/selection/valikko käyttää koko pinnan maalausta, ja editgeneration suojaa myöhemmin aloitettua osoitteen kirjoittamista. |

## Ikkunamitat ja ABI

`JtmosGraOSGetClientSize` käyttää olemassa olevaa 432 tavun komentokehystä. GraOS tarkistaa lähettäjän ja ikkunan omistajuuden; vastauksena ovat leveys, sisältöalueen korkeus ja otsakkeen korkeus. Navigator ei arvioi palvelimen fonttia. Vanha 22 pikselin yhteensopivuuspolku sallitaan vain vanhan palvelimen ilmoittaessa komennon puuttuvaksi (-3), ei aidon IPC-virheen peittämiseen. Sisäisen GUI-layoutin ABI pysyy 110:ssä ja hiiren jonon ABI 2:ssa.

Uuden framebufferin luonti ja rekisteröinti tehdään ennen vanhan vapautusta, ja epäonnistuminen säilyttää käyttökelpoisen pinnan. Mitat tarkistetaan ennen kertolaskua ja varauksia. Natiiveissa i386-testeissä on mukana 19, 22 ja 33 pikselin otsakkeet sekä väärä omistaja.

## Asynkroninen tiedostolataus

Uusi `nav_download_job.c` käyttää Navigatorin omia verkko-, URL-, TLS-, redirect- ja tallennussääntöjä. UI avaa yksilöllisen väliaikaistiedoston ennen forkia. Lapsi saa avatun tiedostodeskriptorin ja streamaa siihen; pipe kuljettaa vain pienen valmistumisviestin. UI ei odota blokkaavasti. Lapsi ei nimeä tiedostoa lopulliseksi eikä voi ohittaa myöhäistä Stop-käskyä.

UI saa kerrallaan yhden file jobin. Aikakatkaisu on 120 sekuntia. Peruttu lapsi päätyy rajattuun reap-jonoon; ensin SIGTERM ja tarvittaessa kahden sekunnin jälkeen SIGKILL, waitpid nonblocking. Vanhoja .part- tai lopullisia tiedostoja ei poisteta eikä korvata. Oma stage poistetaan epäonnistumisessa tai peruutuksessa. Uusi worker käyttää samoja 512 MiB:n tiedostorajaa, kahdeksan redirectin rajaa, HTTPS-downgrade-kieltoa ja HTTP-framingin tarkistuksia kuin muu latauskoodi.

Busy-token vapautetaan Stopissa ja lazy CSS/image -scheduler pysyy pausella seuraavaan navigointiin. Jo avoimen dokumentin HTML-lähde pysyy elossa cancel/204-tilanteessa. HTTP-komponentin osabudjetti on 24 MiB: näkyvä 8 MiB, uusi 8 MiB ja CSS/kuvat yhteensä 8 MiB. Selaimen 100 MiB:n kokonaisbudjetti säilyy ja staging voidaan evätä siististi.

## Piirtopolku ja syötteen oikeellisuus

Caption-komento lähetetään vain tekstin muuttuessa ja onnistunut teksti muistetaan. Epäonnistunut full/region refresh säilyttää piirtotarpeen, ja region-virhe voi palata koko pinnan päivitykseen. Load-valmistumista ei kuitata ennen onnistunutta esitystä. Popup, valikko, diagnostiikka, find, valinta ja accessibility-focus estävät turvattoman osittaismaalauksen niiden alta. Tavallisessa sisältöalueessa aiempi osittaispiirto ja scroll-pinnan käyttö säilyvät.

Ctrl+L valitsee koko osoitteen. Kirjoitus korvaa valitun tekstin, Ctrl+A toimii kentässä, Home/End/Delete ja caret-näkymä toimivat myös pitkällä osoitteella. Vanhemman sivulatauksen valmistuminen ei korvaa uudemman edit-sukupolven tekstiä. Enterillä aktivoitu tiedostolinkki kulkee samaa `nav_open_link`-polkua kuin hiiren klikkaus.

4 ms on kierroksen tapahtumabudjetti, ei esipakottava määräaika koko selaimelle. Yksittäinen suuri layout tai synkroninen OS-kutsu voi silti kestää sitä pidempään. Tässä ei väitetä yleistä 60 fps -suorituskykytakuuta eikä modernien verkkosivujen täydellistä yhteensopivuutta.

## Testaus

- `v72111_ui_host.py` käyttää todellista Navigatorin main loopia, Lexbor-parseria, layoutia ja maalausta; vain OS/IPC ja työn valmistuminen on mallinnettu. Mukana ovat vaiheittainen sivulataus/cancel/204, muistibudjetin epääminen, kaikkien töiden Stop, lazy pause, caption-cache, epäonnistunut refresh ja uudelleenyritys, overlay-piirto, resize-rollback, osoitevalinta ja näppäimet sekä 40 tapahtuman tulva, jonka aikana maalaus ja työn pollaus etenevät.
- `v72111_download_host.py` suorittaa tuotannon lapsiprosessin, pipen ja HTTP-streamauksen paikallista fixture-palvelinta vasten ASan/UBSanilla. Se testaa hitauden, rinnakkaisen paikallisen sivun, valmistuneen mutta vielä julkaisemattoman lapsen perumisen, olemassa olevien tiedostojen suojan, chunked/redirect/truncated/404-polut ja 20 peruutusta.
- `v72111_geometry_runtime.py` ja `v72111_resources_runtime.py` suorittavat oikeat i386 GUI-moduulit ja modernin asiakkaan: otsakekoot, omistajuus, viestirajat, row/full-bufferin suojat, bitmapit, close/minimize/capture ja resize-järjestys. Vanhan muistivirheen palauttava mutaatio hylätään.
- Säilyvät pointer/shell-testit käyvät läpi 30 000 traversal-liikettä, neljä reunaa ja useat resoluutiot, 2500 Start/overview-vaihtoa sekä 10 000 saman rivin liikettä ilman turhaa scene damagea.
- Navigatorin laajat sanitizer-testit, malformed HTML, render/lifecycle/damage- ja muistipainetestit sekä 600 cookie-workerin elinkaaritesti suoritettiin. LeakSanitizer ei ole tämän ympäristön prosessimallissa käytettävissä; ASan ja UBSan ovat käytössä ja muistitrendi mitataan erikseen.
- `v72111_qemu_navigator.py` on lopulliseen mediaan sidottu natiivi integraatiotesti. PS/2-ajossa hyväksyttiin paikallinen sivu, scroll, zoom, todellinen 1024 × 716 asiakasalue, hitaan tiedostotyön aikainen syöte, Stop, uudelleenlatauksen JTMFS-julkaisu ja sulkeminen. Tiedostotestin yksityinen HTML-fixture tuodaan erillisellä tilapäisellä SQA-medialla; tuotannon HTTPS-first pysyy käytössä. Tarkat tarkistukset ja rajat ovat julkaisu-QA:ssa; siinä käytetty NE2000 ei varmista T400:n Intel-ajuria.

`tools/check_release_media.py` purkaa oikean utilities.iso:n paketit ja vertaa myös verkon navigator.bin-tiedoston nykyiseen koontiin. Se tarkistaa boot-image/NZIP-kernel/GUI- ja DOSBOOT-ketjun. `v72111_media_guard.py` palauttaa vanhentuneen Navigatorin, GraOS:n, boot-imagen ja ISO-aliasin yksi kerrallaan ja vaatii hylkäystä. ZIP-audit tarkistaa manifestin, symbolisten linkkien kohteet, casefold-törmäykset ja duplikaatit.

## Käyttö ja lähdekoodin tarkastaminen

Käytä saman V72.111-paketin kernel-, utilities.iso- ja DOSBOOT-tiedostoja yhdessä. Asenna verkko-/Navigator-paketti `network.sqa` ja GraOS `graos.sqa` samalla julkaisun asennustavalla kuin muut sovellukset. Paikallinen offline-sivu avautuu:

```
navigator file:///bin/navgraos111.html
```

Fixture on tarkoitettu paikalliseen syötteen, scrollauksen, zoomin ja sivunvaihdon tutkimiseen. Uudet NAVDBG-merkinnät sisältävät mittoja ja työn elinkaaria, eivät URL-osoitteita tai sivun yksityistä sisältöä.

Keskeiset muutostiedostot: `libc/apps/navigator.c`, `libc/apps/navigator/nav_download_job.c/h`, `nav_network.c/h`, `nav_profile.c`, `libc/apps/gui/guiServer.c`, `libc/libc/modern/graos_compat.c` ja julkiset `jtmos/graos*.h`-otsakkeet. Ajurin erillinen analyysi, hyväksyntämenettely ja lähdeviitteet ovat `docs/ICH9E-V72.111.md`:ssä.

Lopullinen USB OHCI -ajo läpäisi lisäksi koko työpöydän: hiiren reunat ja käänteinen liike, hiiren perinteinen Start, Windows/Ctrl+Esc overview, oikean painikkeen valikko, terminaali ja neljä ulkoista widget-asiakasta (myös Control Panelin 32 painiketta). Start-rivin 24 kursoripäivityksen aikana scene-laskuri pysyi arvossa 13 ja menu-cache-builds arvossa 1. USB-ajossa toistuivat myös kaikki edellä mainitut Navigator-tarkistukset. Molemmat tulokset on sidottu kernelin, GraOS:n, Navigatorin ja ISO:n SHA-256-tunnisteisiin.
