JTMOS V71.122 – täysi lähdekoodi- ja asennusjulkaisu
===================================================

Lue ensin RELEASE-V71.122.txt. Auditoinnin havainnot ja kymmenen korjauksen
arvio ovat AUDIT-V71.121-NAVIGATOR.md:ssä; testit QA-V71.122.md:ssä.

Paketti sisältää koko lähdekoodipuun, nykyiset ohjelmabinaarit,
jtm32.img- ja root1440.img-levykuvat, utilities.iso/utils.iso-tiedostot sekä
täyden boot32pm/dosboot-paketin. Navigatorin oma v71.122.sqa on lisäksi
release/packages-hakemistossa. Tämä ei ole overlay-päivitys.

Ubuntu-kehityskoneessa: make
Tarvitaan GCC/binutils (i686/-m32), make, Perl ja NASM. Muut lähteet ovat
mukana. Päätason make rakentaa ohjelmat ja käynnistys-/asennusmediat.
QEMU: ./run_jtmos_qemu.sh
Oletusprofiili on edelleen text + nogui; tämä säilyttää huoltokonsolin.

QEMU/RAM-testissä paketit voi avata huoltokonsolissa seuraavasti:
  mkdir bin
  cd bin
  sqa cdrom
  sqa core.sqa
  sqa graos.sqa
  sqa network.sqa
  graos

GraOSissa Ctrl+Shift+N avaa terminaalin. Siitä: navigator.bin
Osoitteen voi antaa myös komentorivillä, esimerkiksi:
  navigator.bin http://jtmos.com/

Uusi testi: sh tests/run-v71122-navigator-ci.sh
QEMU-smoke: python3 tests/v71122_qemu_smoke.py /absoluuttinen/testihakemisto
QEMU-testi käyttää vain erillistä testilevykuvaa.

MANIFEST-SHA256.txt kattaa toimitettavan puun kaikki tavalliset tiedostot
paitsi manifestin itsensä. SHA256SUMS-V71.122.txt listaa tärkeimmät mediat
ja Navigator-kopiot. ZIPin erillinen SHA256SUMS-tiedosto tulee toimituksen
mukana. Vanha make check sisältää vanhentuneita testiodotuksia; koko ketjua
ei ole merkitty läpäistyksi. Tarkemmat tulokset ja varoitukset ovat QA:ssa.
