# JTMOS v72.100 – Directory tree and rooted archive QA

- Base: v72.99 full-source tree; V72.95–V72.98 Intel NIC code retained.
- The v72.99 archive had a flat top-level; v72.100 ZIP now has one parent `JTMOS-v72.100/`.
- 21 identical nested mirrors were byte-verified and replaced with *relative* symlinks.
- **Not deduplicated**: GraOS host `iview` JPEG decoder differs from native libc's JPEG forwarding wrapper; historical Filer `gui/windowMoving.c` differs from GraOS host and must remain intact.
- Directory alias audit `tools/check_duplicate_layout.sh`: **PASS** on source and extracted ZIP.
- The unrelated historical `tools/check_release_layout.sh` has a **known stale assertion** expecting `linkit: image`, while the current Makefile uses a profile-aware `linkit:` recipe. This older checker was not green and is not claimed as such.
- `tools/check_rooted_full_release.py` verifies root directory, symlinks, required source files, path safety and ZIP CRC.
- `unzip` extraction into an empty test directory confirms a single versioned parent directory.
- Current `kernel32.bin` / DOSBOOT not rebuilt. Hardware boot test not performed.

Verified 2026-10-24:
- Rooted ZIP validation: PASS; 10,399 entries, 21 symlinks.
- Real unzip into clean temporary directory: PASS; exactly one top-level `JTMOS-v72.100/` directory, VERSION matches and 21 symlinks restored.
- The built-in ZIP CRC test: PASS.
- Full kernel rebuild and T400 hardware test: NOT RUN.
