# JTMOS Navigator 72.179 — Google Search web-standards compatibility

Date: 2026-10-28. Baseline: v72.178 FULL-SOURCE-UNBUILT.

## Source basis (public standards)

- WHATWG HTML Living Standard: parsing, scripts, `noscript`, form semantics: https://html.spec.whatwg.org/multipage/parsing.html and https://html.spec.whatwg.org/multipage/scripting.html
- WHATWG DOM Standard: `closest`, `matches`, `getElementsByClassName`, `getElementsByTagName`, element/parent traversal: https://dom.spec.whatwg.org/
- WHATWG HTML session history: https://html.spec.whatwg.org/dev/nav-history-apis.html
- WHATWG URL Standard: https://url.spec.whatwg.org/
- MDN CSS conditional rules: https://developer.mozilla.org/en-US/docs/Web/CSS/Guides/Conditional_rules
- MDN requestAnimationFrame: https://developer.mozilla.org/en-US/docs/Web/API/Window/requestAnimationFrame

These are *standards used by web browsers*, not an official exhaustive list of APIs required by Google Search. Google's shipped front end may differ by user-agent, locale, rollout, cookie state and anti-abuse checks.

## Evidence from user-supplied saved Google Search document

Sample `jtmos - Google-haku.html`, 2,371,551 characters, `q=jtmos`:
- 120 `<script` tags, two `<form` tags, and one `<noscript` tag.
- Observed script tokens: `querySelector` (48), `getElementsByClassName` (6), `getElementsByTagName` (11), `closest(` (7), `matches(` (1), `classList` (19), `dataset` (33), `addEventListener` (31), `history.replaceState` (2), `requestAnimationFrame` (2), `getComputedStyle` (9), `new URL` (7), `matchMedia` (6), `ResizeObserver` (3).
- A token occurrence does NOT prove that API is called on every real visit.
- Some scripts are large/minified; no claim of full compatibility with them.

## Already present in v72.178, deliberately reused

- HTML5 Lexbor parser; bounded DOM; CSS cascade, `:is/:where/:not/:has` subset, `@media`, `@supports`, custom properties, Flex/Grid subsets, selectors, `opacity`/transparency, images and inline styles.
- QuickJS embedded interpreter with bounded heap and execution quotas; narrow `fetch`, cookies, DOM mutation, event listeners, timers, `window.location` navigation and `noscript` CSS fallback logic.
- Google offline static snapshot and JavaScript whiteout recovery regressions.

## Implemented in v72.179

- HTML-element `tagName` returns uppercase ASCII names, e.g. `A`, `MAIN`. This fixes scripts comparing `element.tagName === 'A'`.
- Document/element `getElementsByClassName()` accepts multiple whitespace-separated class names with intersection semantics; `getElementsByTagName()` accepts uppercase names and `*`.
- `Element.matches()` and `Element.closest()`, including comma-separated selector lists. `querySelector(All)` handles comma-separated lists too.
- `parentElement`, `parentNode` (element parent subset), `children`, `firstElementChild`, `lastElementChild`, `getAttributeNames`.
- DOM-backed `dataset` proxy: camelCase ↔ `data-*`, reads, writes, deletes, membership and enumeration. Bounded, ASCII-key subset; not the full DOMStringMap corner-case grammar.
- `history.replaceState()` current-entry same-origin rewrite and state value, *without a network request*. Rejects cross-origin rewrites. No full browsing history stack, cloning or `pushState`.
- `requestAnimationFrame()` and `cancelAnimationFrame()` one-shot callbacks through the bounded UI/timer poll; ~16ms scheduling heuristic without hardware vsync.
- All collection APIs yield capped 512-element snapshots, **not live HTMLCollection objects**. Other limits: class tokens <=16, selector lists <=16 alternatives, bounded DOM depth.

## Verified

- JTMOS 32-bit `navigator.bin` compiled successfully with Lexbor, QuickJS, WebP and BearSSL.
- Real host QuickJS + Navigator UI harness passed under ASan/UBSan (QuickJS's large core compiled separately without sanitizer for build-time practicality): selector lists, tagName, DOM traversal, class searches, dataset, same-origin history navigation, animation callback and cross-origin rejection.
- User-supplied offline Google HTML + both CSS files: 4,864 DOM nodes, 11,509 CSS rules, 4,251 paint operations, 2,149 within the `#rso` result section; no partial render; direct JTMOS search link present.
- JavaScript whiteout fallback test passed (3,960 glyphs retained), as did late-CSS whiteout prevention and normal DOM mutation.

## Remaining high-priority gaps

1. HTML script scheduling: real parser-blocking scripts, external async/defer ordering, ES module import graph and import maps.
2. CSSOM `getComputedStyle` backed by computed layout; viewport size APIs, proper `matchMedia` listeners, container queries, full flex/grid algorithms and font fallback.
3. DOM events: capture/bubble phases, once/passive options, focus, submit/input/change/keyboard; mutation observers and layout observation (`ResizeObserver`).
4. JS Web APIs: standards-conformant URL/URLSearchParams, complete History/Location, Fetch (CORS/credentials policy, headers, redirects), Web Crypto, streams/storage.
5. Security model and resource loading: CSP, strict same-origin policy, subresource isolation, cookie constraints, back/forward navigation, cross-process scripts. Some APIs should remain unavailable until security boundaries are implemented.
6. Live request validation: HTTPS handshake/cookies/consent/HTTP redirects, Google response variants and T400/GraOS paint are not verified by offline tests.

## Release status

`FULL-SOURCE-UNBUILT`: kernel and GraOS images are inherited from v72.178. Only Navigator is rebuilt. A complete bootable kernel test is not claimed. The user's saved HTML includes personal/session details and is intentionally NOT embedded in the release archive.
