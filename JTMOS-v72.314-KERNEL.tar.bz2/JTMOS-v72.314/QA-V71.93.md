# QA – Navigator 0.2, JTMOS v71.93, 2026-10-17

## Host-hyväksytyt

- i486/ELF32 ristiinkäännös: PASS.
- v71.93 nav_accessibility/nav_ui_ux: 1 027 tarkistusta, ASan+UBSan PASS.
- v71.93 HTML/DOM/CSS 100/200 % reflow, Reader ja vapautus: 911 tarkistusta, ASan+UBSan PASS.
- v71.92 SHA256, LTS ja lisäosat: 1 026 PASS.
- v71.91 LRU ja piirtorajapinta: 1 237 PASS.
- v71.90 muistihuolto: 36 PASS.
- Profilointi: 10 032 PASS (+ 4 profilointi pois käytöstä).
- GraOS display-list -algoritmi hostilla: 41 PASS.
- Virheellinen HTML: 650 satunnaista syötettä PASS.
- Sivujen elinkaari: 3 150 PASS.
- HTTP/1.1 host: 17 PASS; asynkroninen työntekijä PASS.
- Lisäosien 67 regressiotarkistusta ja 1 200 virheellistä määritystä PASS.
- Paketin SQA/ELF-binäärivertailu: suoritetaan package.sh-jakeluvaiheessa.

## Ei hyväksytty / ei varmennettu

- Täysi hiirettömyys: HTML-lomakkeiden syöttöä ei ole toteutettu; linkit ja selaimen UI ovat ohjattavissa.
- A11y: ruudunlukijan rajapinta, kaikki Unicode-glyfit, WCAG 2.x täydellinen kontrasti- ja navigointiauditointi puuttuvat.
- TrueType-fonteilla tapahtuva suurennus: ei; bittikarttatyylin 100/200 % zoom toteutettu.
- HTTPS/TLS-varmenneketjut: natiivikirjasto puuttuu, HTTPS turvallisesti estetty.
- QuickJS, WebP natiivijulkaisussa: ei käytössä.
- Oikea GraOS/eMachines-laite ja verkon todelliset WordPress HTTPS -sivut: testaamatta.
- Täysi RSS-kokonaismuisti: ei mitattu; vain tunnetut varaukset.
- Lopullinen tuotantosertifiointi: **EI MYÖNNETTY**.

## Toistettavuus

`sh tests/run-v7193-navigator-ci.sh` sekä `sh libc/apps/navigator/package.sh` Ubuntu-ympäristössä. Testitulokset riippuvat käytetystä lähdekoodista ja host-ympäristöstä; fyysinen JTMOS/GraOS on oma hyväksymisvaiheensa.
