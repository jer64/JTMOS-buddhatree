# Navigator Google sign-in readiness (v71.136)

This is NOT a claim of working Google sign-in.

Changes: cookie jar capacity 96 -> 192, per-cookie value 512 -> 1024 bytes. Authentication requests now fail closed when the outgoing Cookie header does not fit, instead of silently dropping cookies. No credentials are stored or logged by this change.

Remaining blockers: fully working QuickJS runtime and DOM, secure TLS certificate verification and reliable entropy, modern form/navigation/redirect semantics, correct SameSite context enforcement, OAuth web APIs, cookie/storage persistence and Google compatibility testing. Google may reject unsupported browsers. Never disable TLS validation to work around this.

Validation: static checks only. No i486 target build, hardware run, or real Google login test performed.
