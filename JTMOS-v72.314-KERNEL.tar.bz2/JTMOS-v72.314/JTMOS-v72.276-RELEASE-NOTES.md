# JTMOS v72.276 — Ring3 pthread/clone preparatory milestone

Base: v72.275 complete source release.

- New `SYS_threadctl OP_VALIDATE` validates a future `CREATE` context without
  creating a thread or changing VM. Preflight checks are snapshots, not locks.
- New generation-aware shared-VM group ownership/reference-counting model and
  kernel adapter, **inactive for execution** until page sharing and teardown
  support land.
- libc future pthread stack allocation is 4 KiB aligned and prefaulted.
- New host unit tests and a linkable ELF32 `pthreadprobe` application.
- **No working `pthread_create` yet.** `FEATURES=0`; `CREATE` returns `ENOSYS`.
- The previous prebuilt kernel/boot image is carried forward. To use the new
  syscall operation, rebuild the kernel with NASM and the JTMOS toolchain.
- Source compilation and safety tests pass; real QEMU/T400 runtime is untested.

See `JTMOS-v72.276-PTHREAD-NEXT-STEPS.md` for exact limitations and next work.
