# JTMOS v72.144 – Navigator/GraOS QA

Päiväys 26.10.2026. Pohjana on kokonainen v72.143 FULL SOURCE RELEASE -paketti (SHA-256 `64a80e59…6f66fa`). Tämä julkaisu sisältää lähteet, natiivibinäärit, käynnistysmediat ja täydellisen DOSBOOT-hakemiston.

## Lopputulos

| Tarkistus | Tulos ja todellinen kattavuus |
|---|---|
| Natiivi koonti | PASS. `make BOOT_DISPLAY=vesa BOOT_NOGUI=0`, ELF32/i686, Lexbor, WebP, BearSSL ja QuickJS mukana, `-Werror`. |
| Sovelluksen käynnistys | PASS. SYSMEMREQ 102 400 KiB, myönnetty 102 400 KiB, ikkuna 131 072 KiB; lataajan preflight hyväksyy Navigatorin. |
| Median identiteetti | PASS. `check_release_media.py` ja v72.110-mediavahti: Navigator, GraOS, kernel, ISO, NZIP- ja DOSBOOT-kopiot ovat yhtenäiset. |
| Indeksi vs. lineaarinen haku, ASan/UBSan | PASS, 68 147 tarkistusta. 60 synteettistä listaa ja 7 200 kyselyä: piirto, aluekysely ja osumaiteraattori täsmälleen samat kuin v72.143:ssa, myös negatiivisilla ja nollakorkeuksilla, yli 4 096 kaistan riveillä, vanhentuneella indeksillä ja virheellisillä parametreilla. |
| Stacking-lajittelu | PASS. 200 satunnaista listaa, 1–65 536 eri avainta; tulos tavu tavulta sama kuin vanhalla algoritmilla. |
| Oikeat layoutit | PASS. 40, 600 ja 2 400 kappaleen sivut sekä 200 %:n zoom: indeksi rakennetaan uudelleen jokaisessa reflow'ssa, ja jokainen vieritysasento vastaa lineaarista hakua. |
| UI, ASan/UBSan | PASS. Tuotannon `navigator.c`: jokaisen glyfin ylin osuma vastaa vanhaa silmukkaa; linkki- ja kontekstivalikkokohde täsmäävät; kaukainen kuva jää ajastamatta ja näkyvä alkaa; osittaisen sivun merkki, Reader-napsautus, poistuminen kokonaisella sivulla ja Find-tila. |
| Säilyvät testit | PASS. v72.143:n navigointi-, ankkuri-, CSS-, Find-, historia-, resize-, URL-, kello- ja oikea QuickJS F9 -sarja; v72.74:n 10 033 profilointitarkistusta, 650 virheellistä HTML-fixturea, 3 150 lifecycle-tarkistusta ja 1 800 DOM/damage-kierrosta; Alt-navigoinnin näppäindekooderi; tiedostolataukset. |
| Natiivi QEMU PS/2 | PASS, 14 hyväksyntäkohtaa lopullisella medialla. |
| Natiivi QEMU USB OHCI | PASS, samat 14 kohtaa; Reader avattiin osittaisen sivun merkkiä napsauttamalla USB-hiirellä. |

LeakSanitizer ei ole tässä ympäristössä käytössä. ASan ja UBSan keskeyttävät virheeseen.

## Natiivin selaimen hyväksyntä

Molemmissa QEMU-ajoissa asennettiin core-, graos- ja network-paketit lopulliselta `utilities.iso`:lta, avattiin GraOS ja ajettiin v72.111:n sekä v72.143:n hyväksyntäkohdat ennallaan: paikallinen sivu, vieritys, zoom, maksimointi 1024 × 716 -alueeseen, tiedostolatauksen peruutus ja uudelleenkäynnistys, F9 QuickJS, saman dokumentin ankkuri ilman uutta workeria, Alt+vasen vierityskohdan palautuksella ja epäonnistuneen sivun säilytys.

Uudet v72.144-kohdat: `navgraos144.html` (206 316 tavua) tuotti natiivisti tasan 100 000 piirtokohdetta ja lokirivin `UI partial page flags=1 items=100000 reader=1`. Tilarivin merkki `Partial page: layout limit | F8 Reader` havaittiin kuvakaappauksesta. End ja kuusi Page Up -painallusta vaihtoivat sisältöalueen, ja merkki säilyi. PS/2-ajossa Reader avattiin F8:lla, USB-ajossa merkin napsautuksella (`UI partial badge click reader=1`). Alt+vasen palautti kokonaiseen v72.143-artikkeliin, ja merkki poistui. Navigator suljettiin puhtaasti.

Ensimmäisessä PS/2-yrityksessä yksi Tab-painallus katosi v72.111:n latausvaiheessa. Toisessa yrityksessä 28 merkin osoitteesta vastaanotettiin 17, kun merkit lähetettiin 0,08 s välein 100 000 kohteen Reader-sivulla. Testin viimeinen siirtymä tehdään nyt Alt+vasemmalla. Havainto on kirjattu analyysiin jatkotyöksi; se ei ole tämän julkaisun hyväksyntäkohta. Kolmas PS/2-ajo ja ainoa USB-ajo menivät läpi muuttamattomalla binäärillä.

QEMU käyttää 512 MiB RAM-muistia ja NE2000-verkkoa. Fyysistä ThinkPad T400:aa, eMachines EL1352:ta tai ASUS R558U:ta ei testattu. Isäntäajat ovat Ubuntu-mittauksia listan läpikäynnistä, eivät laitteiston nopeuslupauksia.

## Julkaisun toistaminen ja käyttö

```sh
make BOOT_DISPLAY=vesa BOOT_NOGUI=0
python3 tools/check_release_media.py
python3 tests/v7196_navigator_launch.py libc/apps/navigator.bin
NAV_TEST_LEAKS=0 sh tests/run-v72144-paint-index.sh
python3 tests/v72144_ui_host.py
python3 tests/v72143_navigation_host.py --quickjs
NAV_TEST_LEAKS=0 sh tests/run-v7274-navigator-sanitizers.sh
python3 tests/v72143_alt_navigation.py
python3 tests/v72111_download_host.py
python3 tests/v72111_qemu_navigator.py ../qemu144-ps2 --navigator-only --navigator143 --navigator144
python3 tests/v72111_qemu_navigator.py ../qemu144-usb --navigator-only --usb --navigator143 --navigator144
```

Asenna julkaisun paketit ja avaa paikallinen testi:

```text
navigator.bin file:///bin/navgraos144.html
```

## Evidenssi

`release/qa/v72.144/`: `media-check.json`, `provenance.json`, `qemu-ps2-result.json` ja `qemu-usb-result.json` sitovat tulokset binääreihin. Samassa hakemistossa ovat koonti-, sanitizer-, indeksi-, UI-, näppäimistö-, lataus- ja sarjalokit.

Kernelin 798 C-, otsake- ja assembler-lähdetiedostosta muuttui vain julkaisubanneri `kernel32/include/jtmos_release.h`. Navigatorin muutokset rajoittuvat tiedostoihin `navigator.c`, `nav_layout.c/h`, `nav_render.c/h` ja `nav_profile.c` sekä uuteen esimerkkisivuun. ZIP tarkistetaan `tools/check_full_release_manifest.py`-työkalulla.
