# v71.104 validation

Validation performed on Linux; no JTMOS boot or physical-machine run claimed.

| Check | Result |
|---|---|
| Native BearSSL build, freestanding `-m32 -march=i486 -nostdinc` | PASS |
| Navigator ELF32 static link, JTMOS headers, application `-Werror` | PASS |
| Kernel's actual ELF identity/startup/layout preflight | PASS; startup 8192 KiB in 16384 KiB window |
| TLS on/off native recompilation, no stale backend | PASS |
| Native archive ELF32 purity / final executable unresolved symbols | PASS |
| Actual BearSSL to independent Python/OpenSSL server, RSA and ECDSA | PASS |
| SNI, Host header, CA chain, hostname, validity time | PASS |
| Expired/future/wrong-host/untrusted/weak-RSA certificates rejected before HTTP | PASS |
| Empty CA store and unusable RTC blocked before entropy use/network | PASS |
| Multi-record 40 KB response, gzip+chunked response, clean TLS EOF | PASS |
| Truncated TLS TCP EOF, unsupported TLS 1.3-only/CBC-only peer, stalled handshake | PASS: bounded failure |
| HTTP-to-HTTPS redirect / HTTPS-to-HTTP downgrade block | PASS |
| One-use entropy bytes, zero-and-fsync-before-output, exhaustion, malformed/missing pool | PASS |
| Entropy lock, concurrent fresh processes, failed fsync produces no output/retains lock | PASS |
| Upstream X.509 certificate and name-extraction tests | PASS |
| Upstream SHA-2/HMAC/HMAC_DRBG/AES-ct/ChaCha20/Poly1305/GHASH/GCM/RSA/EC/ECDSA tests | PASS |
| v71.103 DNS RCODE helper regression | PASS, 7 cases; retained mappings |
| v71.97 64 KB worker IPC + URL normalization | PASS |
| v71.95 saved news-page HTML/CSS/JPEG + v71.94-and-earlier regressions | PASS |
| General SQA package extraction matches source executable | PASS |
| Re-extracted source ZIP offline build | PASS; binary byte-identical to final executable |
| Real JTMOS filesystem pool concurrency/power-loss tests | PENDING target machine |
| eMachines Navigator HTTPS / CPU RNG / public sites | PENDING target machine |

## Commands

```sh
sh tools/build_bearssl_jtmos.sh
make -C libc/apps -f navigator.mak -j2 navigator.bin
python3 tests/v71104_native_build.py
NAV_TEST_LEAKS=0 python3 tests/v71104_tls.py
python3 tests/v71103_dns_rcode.py
sh tests/run-v7197-navigator-ci.sh
NAV_TEST_LEAKS=0 sh tests/run-v7195-navigator-ci.sh
make -C third_party/bearssl CONF=HostPortable -j2 lib tools tests
(cd third_party/bearssl && ./build-host/testx509)
third_party/bearssl/build-host/testcrypto SHA256 SHA384 SHA512 HMAC HMAC_DRBG \
 AES_ct ChaCha20_ct Poly1305_ctmul32 GHASH_ctmul32 GCM EC_prime_i31 \
 EC_c25519_i31 ECDSA_i31 RSA_i31
sh libc/apps/navigator/package.sh
```

The new integration uses AddressSanitizer and UBSan. LeakSanitizer was disabled
only because this environment denies `/proc/<pid>/task` inspection and its
default run aborts in LeakSanitizer itself. Full leak detection remains pending;
this is not a claim of leak freedom. Earlier regression suites intentionally
compile their historical TLS-disabled fixtures and print TLS skip messages;
the new v71.104 suite supplies the actual TLS/certificate tests.

The bundled upstream host X.509 test driver emits GCC's historical
`-Wstringop-overflow` warnings in its configuration-file reader; its tests pass.
The native BearSSL library and modified Navigator units compiled without
warnings. The upstream crypto tests use the same selected portable backends,
but execute as host code; target filesystem, timing and CPU-instruction behavior
still require the machine run.

Direct public probes of `vunet.net` and `jtmos.com` could not resolve DNS in this
environment. No public-server success, QEMU boot or eMachines success is claimed.
Logs are provided under `release/qa/v71.104/` in the source package.

Final navigator.bin: 1,222,568 bytes; SHA-256
`8edab0adfc380c992af9b57c20534f488836a23315010abf3154d6a3d41499de`.

The final prebuilt libc archive was refreshed from the complete clean-source
build. Its Navigator output is byte-identical to the separately extracted source
rebuild with this toolchain, avoiding dependence on an older cached libc archive.
