# JTMOS v71.66-r2 fsck hardening (2026-10-16)

Modified: `kernel32/fs/jtmfs/jtmfsIntegrity.c`.

* Preflight all reclaimable orphan FAT entries against the live allocator before writing any of them. This avoids predictable partial repairs when a mismatch is detected late in the scan. It does not make writes transactional, nor guarantee resilience against I/O errors or power loss.
* Reject impossible physical-media allocation geometries, invalid FAT table spans, insufficient FAT capacity and clustered layouts running off the device.
* Do not start orphan repair if traversal or FAT scan already failed.
* Do not report a successful repair if proven orphan count differs from reclaimed count.

Checks: `make -C kernel32 syntax` PASS; `tools/check_v694_jtmfs_atomic_jtmfsck.sh` PASS.
Full `make c-syntax-check` fails in the pre-existing `check_v68175_idle_graos.sh` (HLT burst assertion) before reaching the rest of the suite.
No boot, real-disk corruption-injection or on-device repair test was run. Do not run `fsck -r` on irreplaceable data without a verified backup.
