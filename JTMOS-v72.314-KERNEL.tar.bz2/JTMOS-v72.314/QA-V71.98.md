# JTMOS v71.98 — QA-tila 17.10.2026

PASS: Navigator 0.2:n natiivi i486/ELF32-käännös.
PASS: navipctest.bin natiivi i486/ELF32-käännös.
PASS: kummankin ELF-binäärin käynnistysrakenteen preflight-tarkistus.
PASS: 64 KiB host-IPC + URL-normalisointi (HTTP ja eksplisiittinen HTTPS).
PASS: kernel32/core/int/scs.c obj-käännös (diagnostiikkareititys).
PASS: v71.97 -> v71.98 patch-testin yhtäpitävyys muutettujen tiedostojen kanssa.
PENDING: eMachines-laitetesti, serial-lokien analyysi.
PENDING: kokonaisen JTMOS:n boot image / root image / utils ISO:n rakentaminen.
PENDING: BearSSL:n turvallinen HTTPS-konfiguraatio.

Nämä PASS-merkinnät perustuvat pakettiin sisällytettyihin lokitiedostoihin;
niissä kuvattuja testejä ei tule sekoittaa laitetestaukseen.
