# Navigator v72.167 – div- ja CSS-korjaukset

28.10.2026. Pohja: JTMOS v72.166 FULL SOURCE RELEASE.

Päivitys korjaa div-laatikoiden mitoitusta, ylivuotoa, sisarusten marginaaleja
ja flex-keskitystä. Kiinteä korkeus säilyy sisällön ylivuodosta huolimatta;
`max-height` toimii myös ilman leikkaamista ja `min-height` on ensisijainen.
Prosentti- ja `calc()`-korkeudet käyttävät vanhemman sisältökorkeutta.
Tyhjät ja nollakokoiset divit eivät lisää keinotekoista pikseliä.

CSS-tukeen lisättiin `inline-size`, `block-size`, niiden min/max-muodot sekä
`margin`- ja `padding`-ominaisuuksien `inline-start`, `inline-end`,
`block-start` ja `block-end` -pitkämuodot. Ne käyttävät samoja cascade-paikkoja
kuin fyysiset ominaisuudet, joten järjestys, tarkkuus ja `!important` toimivat
yhdessä. Kartoitus koskee vaakasuuntaista vasemmalta oikealle -asettelua.
`box-sizing:inherit` sekä `margin:inherit` ja `padding:inherit` toimivat.
Varajäsentimen `<div/>` jatkaa nyt divin sisällön jäsentämistä divin sisään.

## Käyttö

Asenna erillinen `navigator-v72.167.sqa` tavalliseen tapaan `/bin`-hakemistoon
tai korvaa siellä oleva `navigator.bin` uudella binäärillä. Paketin testisivu
aukeaa komennolla `navigator.bin file:///bin/navdiv167.html`.

Tämä on selainpäivitys. `libc/apps/navigator/VERSION` on 72.167, mutta
käyttöjärjestelmän `VERSION`, ydin, GraOS ja asennus-/käynnistysmediat ovat
edelleen 72.166. Täysi lähdepaketti sisältää koko pohjapuun, uuden
`libc/apps/navigator.bin`-tiedoston ja erillisen selainpaketin. Vanhojen
ISO/SQA-asennusmedioiden Navigator päivittyy vasta erillisellä asennuksella.
Paketin rngctl/tlsseedctl-apuohjelmat kuuluvat käyttöjärjestelmäpohjaan.

## Kääntäminen ja testaus

```sh
make -C libc/apps -f navigator.mak -j2 navigator.bin
python3 tools/build_navigator_lexbor_host.py /tmp/nav167-lexbor
LEXBOR_HOST_ARCHIVE=/tmp/nav167-lexbor/liblexbor_static.a \
  sh tests/run-v72167-navigator-div.sh /tmp/nav167-lexbor-test
sh tests/run-v72167-navigator-div.sh /tmp/nav167-subset-test
NAV_HAVE_QUICKJS=1 DIST_DIR=/tmp/navigator-v72.167 \
  sh libc/apps/navigator/package.sh
```

Testit käyttävät samoja C-lähteitä kuin julkaistava selain. Isäntäajossa ovat
käytössä AddressSanitizer ja UndefinedBehaviorSanitizer. Tulokset ja rajat:
`QA-V72.167.md`, `release/qa/v72.167/`.
