# JTMOS v71.97 / Navigator 0.2 — Address bar and HTTP IPC repair

Changes relative to the user-tested v71.96:

1. `nav_address_url()` is only applied to text entered into GraOS's location bar
   or a Navigator command-line start URL. Bare `jtmos.com`, `jtmos.com/path`,
   `192.168.0.1` and `localhost:8080/` receive `http://` automatically.
   Explicit `https://` and `file:///` remain explicit. HTML relative links
   still use `nav_resolve_url()`; their interpretation has not changed.
2. The forked Navigator HTTP worker now transfers requests/responses using
   bounded 2048-byte pipe read/write syscalls instead of passing large
   response sizes to the kernel in one call. This may work around a kernel
   range-check problem causing `Worker IPC read failure` on real HTTP pages.
   The suspected kernel interaction remains UNCONFIRMED without hardware tests.
3. IPC failures now include `errno` and whether the read failed in the header
   or body phase. The GraOS UI will never fall back to blocking `read()` if
   O_NONBLOCK cannot be installed.
4. `navipctest.bin` is a standalone native JTMOS smoke test: fork, pipe,
   F_GETFL/F_SETFL, 64 KiB nonblocking read/write. No network is needed.

## Testing on Ubuntu / build machine

    make -C libc/apps -f navigator.mak -j2 navigator.bin
    make -C libc/apps -f navipctest.mak navipctest.bin
    sh tests/run-v7197-navigator-ci.sh

Verified on Ubuntu: i486 ELF32 link succeeded; native launch preflight
accepted both executables; host-based 64 KiB IPC and URL input tests passed.
The broader v71.95 HTML/CSS regression run was started and reached saved
page/JPEG cases, but the run timed out before the full suite completed.
JTMOS/eMachines hardware has NOT been tested.

## On actual JTMOS (recommended test order)

1. Copy `navipctest.bin` and `navigator.bin` to `hda1:/bin/`.
2. Run `hda1:/bin/navipctest.bin` in SQSH. It should print `PASS ... 65536 bytes`.
   If it fails, copy the exact `errno`, byte count and error message.
3. Open Navigator, enter `jtmos.com` (without `http://`) and separately
   `http://example.org/`. Report the exact status/error text. Some HTTP
   websites redirect to HTTPS, which will remain unavailable in this build.
4. To isolate IPC from networking, navigate to an existing local file such
   as `file:///hda1:/path/to/document.html` (JTMOS path conventions apply).

## Security and limitations

HTTPS IS NOT ENABLED. The original BearSSL code cannot yet be enabled
safely without a verified cryptographic random source, trusted CA anchors,
valid RTC/time and runtime certificate+hostname validation. Never disable
verification or silently downgrade an explicitly requested HTTPS site to HTTP.
Bare hostname requests default to HTTP ONLY while Navigator is in its
HTTP-only stage; the final URL displays this. Do not enter credentials into
an HTTP page. Websites that redirect from HTTP to HTTPS will still fail
with a TLS-unavailable message. A future HTTPS-first default requires a
verified TLS backend, not an insecure workaround.
