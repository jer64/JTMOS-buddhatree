# JTMOS v72.89 – GraOS Calendar Stage 4

## Added

- **Daily, weekly, monthly and yearly recurrence** (0 = no repeat, 1 = daily, 2 = weekly, 3 = monthly, 4 = yearly). The first occurrence is the event's stored date. There is no end date / COUNT in this first implementation. Monthly 29/30/31 events are skipped in shorter months; Feb 29 yearly events occur only in leap years.
- **Reminder lead time** from 0 through 1440 minutes, or `9999` for disabled. Reminder windows are shown by a separate GraOS process, `calremind.bin`, started by `graos.bin` after the desktop window server has initialized. This process monitors the current local clock every five seconds, evaluates reminders once per minute, and may show a popup while the calendar editor is closed.
- **ICS import/export:** calendar's `ICS Import` reads `/calendar-import.ics`, `ICS Export` writes `/calendar-export.ics`. These paths are inside the JTMOS root filesystem. Use these exact filenames for the initial GUI implementation.
- The import implements an intentionally limited RFC 5545 subset: floating **local** DTSTART/DTEND timestamps `YYYYMMDDTHHMMSS`, escaped SUMMARY, simple `RRULE:FREQ=DAILY|WEEKLY|MONTHLY|YEARLY` (optionally `INTERVAL=1`), and display VALARM `TRIGGER:-PT<number>M` or hours. It rejects unsupported rules rather than silently changing their meaning. Time zones, UTC (`Z`), `TZID`, `UNTIL`, `COUNT`, `BYDAY`, `BYMONTHDAY`, `EXDATE`, `RDATE`, detached instances, and exceptions are **not supported**. Re-importing a calendar can duplicate events: backup and review files before importing. Maximum 128 events, event title <=95 bytes and ICS source <=128 KiB.

## Persistence and data safety

- The new CRC32-protected two-generation format `JTCAL4` is stored in `/calendar4.a` and `/calendar4.b` and includes recurrence and reminder fields.
- When no v4 data is present, the calendar reads the v72.88 `JTCAL3` store (which itself can import v2 and legacy text) but does **not overwrite** the old formats. Imported v3 events default to non-recurring and reminder disabled.
- A corrupt latest generation falls back to the previous generation; corruption without a valid alternate makes the store read-only. Save depends on JTMFS `fflush/fsync` reliability. Root-backed RAM storage is not persistent.
- The ICS importer validates **all** events before committing them as one generation. It rejects malformed or unsupported recurrence rules. The export file itself is not an atomic replace: interrupted writes can leave a partial `.ics` file but never modify the calendar database.
- As previously, the GUI relies on a single writer. Do not start two instances of calendar.bin manually, because there is no cross-process lock. The reminder service reads only, never writes.

## Interface

- GraOS taskbar clock opens `calendar.bin`; the built-in taskbar remains the only taskbar.
- Editing a recurring event changes the **whole series**, anchored at the original date, not only the selected occurrence. Deleting it removes the entire series; per-occurrence exceptions are not implemented.
- `0` / `9999` are explicit UI defaults for no recurrence / no reminder. Reminder `0` means alert when the event starts.
- The reminder popup has an OK button; it dismisses automatically after at most three minutes. Multiple simultaneous reminders can be delayed or missed while a popup is open. Agent is best-effort and requires GraOS to be running, working RTC/local time, and readable persistent storage.
- If calremind.bin is not installed at `/bin/calremind.bin`, GraOS still starts but reminders do not appear.

## Deployment

- Install **all three** `/bin/calendar.bin`, `/bin/calremind.bin`, `/bin/graos.bin`; the new `graos-v72.89.sqa` and `graos.sqa` include them.
- Older GraOS clients may coexist, but the old standalone `taskbar.bin` is not needed and should not run as a second panel.
- A full kernel or DOSBOOT was **not** rebuilt in this release. They are copied from v72.88. Run the full kernel/boot media build on a fully provisioned development machine (NASM is missing here).

## Build and tests

```
make -C libc/apps -f calendar.mak calendar.bin
make -C libc/apps -f calremind.mak calremind.bin
make -C libc/apps/gui -f graos.mak graos.bin
./tests/calendar/run_v7289_store_test.sh
./tests/calendar/run_v7288_store_test.sh
./tests/calendar/run_v7286_store_test.sh
python3 tests/v7278_dosboot_prompt_parity.py
```

## Limitations

- No real ThinkPad T400 or QEMU GraOS runtime verification in this release. The host tests exercise the persistence, recurrence, reminder due-time logic, and ICS parser, not actual mouse clicks or reminder popup delivery.
- No alarms when JTMOS or GraOS is shut down. DST changes and timezone math are not modeled; reminders use local, floating clock minutes.
- The ICS format is a **subset**, not universal interoperability. Do not treat successful `.ics` export as evidence that every calendar program will interpret all edge cases identically.
