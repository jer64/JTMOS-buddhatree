# JTMOS v72.200 — Navigator cache index, GraOS task ordering and MP3 audio liveness

## Changes

### Navigator persistent disk cache
- `libc/apps/navigator/nav_cache.c`: URL-indexed, per-host object naming; e.g. `~/.cache/navigator/vai/nvc-cnn.com-100.bin` and `nvc-cnn.com-101.bin`.
- `nvc-index.bin`: bounded 256-object index, dual URL hash, expiry, object size checks and rebuild from cached objects if missing/corrupted.
- Sensitive or credential-bearing URLs are rejected. The complete URL is checked in the object itself before use. Existing hashed-slot cache objects are not blindly interpreted as host-indexed objects.

### GraOS taskbar
- `libc/apps/gui/guiDesktopDraw.c`: task buttons ordered oldest-to-newest by immutable window generation, independent of activation/z-order. The Activities overview retains z-order.
- Only the GraOS server owns task buttons; external `taskbar.bin` supplies menu, clock and calendar controls, not the task-button collector.

### MP3 / kernel audio
- `kernel32/drivers/hda/hda.c/h`: `hda_poll()` performs one synchronous driver service step. `hda_kick()`'s no-PIT fallback is bounded (~8 ms or 100000 spins), rather than potentially busy-waiting for an entire stalled audio stream. Successful restart clears the stale error.
- `kernel32/drivers/audio/audio.c`: both audio position and audio info now service HDA once before returning their counters. This addresses a deadlock where `mp3.bin` throttles on a fixed full FIFO while the PIT DMA callback has stopped.
- `libc/apps/media_timing.h` and `mp3/mp3.c`: 3500 ms forward-progress watchdog, measured from played/queued/active counts; on a frozen stream stop DMA and return an explicit error instead of indefinitely looping the last buffer. Also guards end-of-track drain. `MP3_TRACE=1` remains available.

## Confirmed host/build checks
- PASS: `make -C kernel32 -f generated.mak drivers/hda/hda.o drivers/audio/audio.o -j2` (32-bit kernel objects).
- PASS: `make -C libc/apps -f mp3.mak mp3.bin` (linked ELF32/i686 player).
- PASS: `make -C libc/apps -f navigator.mak navigator.bin` (linked Navigator).
- PASS: `make -C libc/apps/gui -f graos.mak graos.bin` (linked updated GraOS).
- PASS: `python3 tests/test_audio_liveness_v72200.py` (timeout, counter changes, wrap, bounds).
- PASS: `python3 tests/test_taskbar_creation_order_v72200.py` (focus, minimize, close/reopen, ordering).
- PASS: `python3 libc/apps/navigator/tests/test_cache_index_v72200.py` (on-disk index integrity and restart).

## NOT verified
- No full kernel link; NASM/QEMU unavailable in this build environment.
- No prolonged hardware MP3 playback test (ThinkPad T400, QEMU HDA, NVIDIA MCP61, Sound Blaster and GUS not actually run).
- These safeguards address one demonstrated missing-service deadlock and make other stalls recoverable in the player. They do NOT prove that the hardware-level root cause of the user's repeatedly looping DMA buffer is eliminated. Collect `audio probe`, `audio status` and `MP3_TRACE=1` diagnostics after a recurrence.
- Kernel, bootloader and installation media are inherited; these new HDA/audio functions require a full kernel rebuild and deployment, not only copying `mp3.bin`.
