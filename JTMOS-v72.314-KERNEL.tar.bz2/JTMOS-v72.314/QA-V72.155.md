# JTMOS v72.155 – QA

Päiväys 26.10.2026. Pohjana on kokonainen v72.154-lähdepaketti (SHA-256 `38c8b8e4…af2319c`).

| Tarkistus | Tulos |
|---|---|
| Natiivi koonti ja media | PASS |
| ICH9E-ajurimallit v72.108–v72.154 | PASS |
| Uusi v72.155 txmatrix-malli | PASS: jokainen muunnelma alustaa ja odottaa linkkiä, ja bitti 25, TCTL-vaihto sekä matala puskuri tulevat käyttöön vain omissa muunnelmissaan |
| Mutaatio `enable_at_init` | hylätty |
| QEMU: kiinteä osoite, DHCP ja verkkoregressio | PASS, 10/10 |

Rajaus: koeajo on mittausväline. QEMU:ssa ei ole ICH9-mallia, joten tulos saadaan vasta T400:lta.
