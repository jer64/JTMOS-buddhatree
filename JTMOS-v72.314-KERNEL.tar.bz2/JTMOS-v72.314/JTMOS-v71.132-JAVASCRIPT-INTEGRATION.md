# JTMOS v71.132 – Navigator JavaScript integration hardening

Lynx has no built-in JavaScript interpreter. Navigator uses the existing optional QuickJS adapter.

Changes:
- External scripts now share the page-wide 128 KiB JavaScript script-byte budget with inline scripts.
- External `<script type="module" src="...">` now preserves module evaluation mode.
- QuickJS build script targets i486 instead of i686, matching the intended baseline.
- Build script validates a basic QuickJS header API symbol.

Limitations:
- Official upstream QuickJS source is NOT included in this package; native JS remains disabled by default.
- To enable: provide reviewed upstream QuickJS sources in third_party/quickjs and run tools/build_navigator_quickjs.sh.
- No claim of a successful native JS build, HTML5 compatibility or JTMOS hardware test is made.
- Browser process isolation, redirects, cross-origin requests and modern browser APIs require further work.
