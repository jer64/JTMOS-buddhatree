# JTMOS v72.249 — Reliability and Diagnostics

Base: **v72.248**. This is a **complete source-tree release**, not a verified
bootable release. The existing boot images and most bundled binaries predate
v72.249. Recompile on the developer machine before testing the new kernel.

## Ten requested work areas

1. **JTMFS fail-closed directory writes — retained and regression tested.** The
   v72.245 protection rejects lost `.`/`..` entries when the disk copy is sound
   or cannot be read. Legacy readable headers remain compatible.
2. **Crash-safe `mv` — retained and regression tested.** v72.247/248 V4 atomic
   move/replace WAL and recovery are preserved. Atomicity covers each file,
   not the entire `*.mp3` batch. Interrupted old-chain reclamation can leave
   orphan blocks for offline fsck; persistent orphan reclamation is not yet
   implemented.
3. **Async JTMFS bounded wait — added opt-in safety API and CLI.**
   `JtmfsDbWaitQueuedBounded(dnr, timeout_ms)` returns an explicit failure
   without unlocking any mutation locks. `dirdb wait 5000` calls it safely as
   a non-mutating diagnostic. The existing mutation-lock backpressure path
   intentionally retains indefinite waiting rather than continuing with a
   half-durable transaction; this portion remains pending a broader API change.
4. **Per-descriptor I/O — implemented in source.** `vfs_read_impl`,
   `vfs_write_impl`, `vfs_close_impl` and `lseek` no longer take a shared
   function-local lock across all open files; they use each descriptor's
   mutex. The lock wrapper now supports ownership-checked recursion because
   the syscall layer may already hold it. FD offset and close ordering remain
   serialized per descriptor. Requires live multi-process regression testing.
5. **Virtual address fragmentation — best-fit policy and instrumentation.**
   The process mmap allocator tries the tightest available PTE hole first,
   preserving larger contiguous virtual extents. `memfrag [pid]` reports
   free space, largest hole and hole count. Partial `munmap()` is NOT supported
   yet; this is not a solution to every fragmentation case.
6. **Power-cut tests — preserved.** Previous v72.246/247/248 tests run the
   actual journal/recovery C routines against disposable test images and inject
   failures at I/O boundaries.
7. **Kernel RAM flight recorder — implemented.** A bounded static 64 KiB
   text ring captures kernel console messages, DEBUG and REPORT streams
   independently of disk or serial logging. `flightlog` reads the last 4 KiB;
   the fatal handler prints up to 2 KiB using bounded per-character UART waits.
   Ordinary volatile RAM is erased by loss of power; this is not persistent
   RAM across a cold boot.
8. **AHCI diagnostics — implemented.** Fixed malformed `0xEA0 READ` display.
   `ahcistat` shows operation counts, average/max elapsed milliseconds,
   errors and timeouts separately for READ, WRITE, FLUSH and OTHER.
   Measurements are coarse GetTickCount values, not precise latency histograms.
9. **POSIX zero-byte read/write — implemented.** A valid JTMFS descriptor
   accepts `read(fd, NULL, 0)` / `write(fd, NULL, 0)` instead of rejecting the
   null pointer, while negative counts and invalid FDs remain errors.
10. **Release integrity gate — implemented.**
    `make release-check-source` checks source identities and runs host
    regressions. `python3 tools/release_integrity.py --mode boot` refuses to
    certify inherited boot media. Optional `--archive ZIP --sha-file SHA`
    validates ZIP paths, duplicate entries, CRCs, SHA-256 and embedded versions.

## Developer commands

```sh
make release-check-source
# Must fail with the provided source-only manifest:
python3 tools/release_integrity.py --mode boot
# After local full build / manual provenance validation:
make -j2
```

After booting a **newly rebuilt** v72.249 image, inspect:

```text
flightlog
ahcistat
memfrag
dirdb status
dirdb wait 5000
```

## Verification

- Production kernel C files compiled into i386 relocatable objects with
  `make -C kernel32 -f generated.mak ...`.
- v72.246 crash recovery: **69/69 PASS**.
- v72.247 atomic move recovery: **90/90 PASS**.
- v72.248 atomic replace recovery: **224/224 PASS**.
- DIRDB writeback: **792 PASS**; DIRDB fail-closed: PASS.
- Seven group-commit fault cases and watchdog regression: PASS.
- Host tests compile extracted production C functions for the FD lock,
  flight recorder, and best-fit mmap policy: **3/3 PASS**.
- Host metadata-only `mv` wildcard tests: PASS, including 150 MP3s.
- Strict boot-provenance test: expected **FAIL** (media not rebuilt).

## Unverified and known remaining work

No complete kernel link, NASM-based build, QEMU boot test or ThinkPad T400
stress test occurred here. The per-FD I/O changes, best-fit VMA placement,
flight-log panic path and AHCI statistics have **NOT** yet been validated on
real JTMOS hardware. Verify these carefully on a throwaway test disk first.

The journaled V4 superblock version is **not changed** in this release;
existing v72.248 V4 v3 compatibility rules remain in effect.
