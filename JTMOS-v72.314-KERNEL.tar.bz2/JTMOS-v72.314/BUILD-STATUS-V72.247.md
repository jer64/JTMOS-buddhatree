# JTMOS v72.247 – build and test status

Base: v72.246 full-source ZIP. Changes: JTMFS V4 cross-directory atomic move,
redo replay and compatibility guard, host crash/reboot tests, and modified
v72.246 host regression harness for the new move redo record type.

## Verified on Linux test host

- `kernel32/fs/jtmfs/jtmfsAccess.c` and `jtmfsDb.c`: compiled successfully
  with project i386 kernel flags (`-m32 -march=i686 -std=gnu89`), no warnings;
  resulting objects are ELF 32-bit relocatable Intel 80386.
- `tests/v72247_atomic_move_reboot_host.py`: 90 isolated crash/reboot scenarios;
  each move keeps the file in source or target; no double ownership; replay
  is idempotent; 12 explicit crashes during redo recovery; mirrored-super
  recovery, intact FAT chain, three block-write persistence policies.
- `tests/v72246_crash_recovery_host.py`: 69 old WAL crash/reboot scenarios pass.
- `tests/v72245_dirdb_failclosed_host.py`: PASS.
- `tests/v72245_jtmfs_commit_fault_host.py`: PASS (7 injected failures).
- `tests/v72245_jtmfs_watchdog_host.py`: PASS.
- `tests/v72241_dirdb_writeback_host.py`: PASS (792 cases).
- `tests/v72244_mv_wildcards.py` with locally compiled `mv_host`: PASS
  (150 MP3 files and all wildcard/rename regression cases).

## NOT tested

Full kernel linking, bootable media rebuild (NASM unavailable), system boot
under QEMU or on ThinkPad T400, real AHCI flush semantics and unmodified
production-disk full-path invocation. Tests use isolated synthetic disk images
and production WAL/replay C functions with a simulated block backend.

## On-disk format compatibility – important

`JtmfsDbAtomicMove()` first upgrades BOTH mirrored V4 superblocks from version
1 to version 2, fully verified, before writing the first atomic move WAL.
The atomic move WAL record contains two directory entry images and is not
understood by v72.246 or earlier. Older kernels must NOT write this volume.
Old kernels treat the new superblocks as invalid and freeze writes; do not
attempt to bypass this protection. Backup a volume before testing v72.247.

The V4 journal arena location and 72-byte directory entry ABI are unchanged.
The new single-sector `JMOV` WAL record is 176 bytes. V3 volumes continue to
use the conservative old cross-directory move path, not this atomic guarantee.

## Known limitations

- Atomicity is PER FILE, not one transaction for the entire wildcard batch.
- Existing-target replacement remains refused (no implicit overwrite).
- Destination directory needs an existing free entry slot; it is not expanded
  by this transaction. Error 11 indicates an unavailable free slot.
- Source must be a regular file; directory moves are not covered.
- Cross-volume moves are not supported by this metadata-only routine.
- Old boot media and most inherited binaries in this ZIP are from an earlier
  release and must NOT be described as updated v72.247 media.
