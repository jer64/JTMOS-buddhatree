# JTMOS V72.231: ram:-levy, fork-muistiikkuna ja Navigatorin Google-haku

Päivämäärä 2.11.2026. Pohjana V72.230 FULL-SOURCE. Kernel, käynnistyslevyke ja DOS-paketti
on rakennettu uudelleen ja testattu QEMUssa. Navigatorin Google-haku on kuvattu tiedostossa
`NAVIGATOR-GOOGLE-SEARCH-V72.231.md`.

## 1. ram: ei toiminut hda1:-juuren kanssa

**Oire:** kun JTMOS käynnistyi asennetulta `hda1:`-levyltä, `cd ram:/` antoi virheen
"chdir failed: ram:/" (`jtmfs_chdir: unable to resolve 'ram:/' (rv=5)`). Käyttäjän
`diskspace.log` näyttää saman: `dnr=9 dev=ram fs=raw`.

**Syy:** SMSH alusti ram:-levyn JTMFS:ksi vain varajuuren haarassa
(`smsh_boot_root_policy`). Kun juureksi valittiin hda1: tai hda:, ram: jäi alustamatta.

**Korjaus** (`kernel32/sh/fsadmin.c`): uusi `smsh_prepare_ram_volume()` alustaa ram:-levyn
jokaisella käynnistyksellä ennen juuren valintaa. Siksi hda1: jää nykyiseksi laitteeksi.
Olemassa oleva ram:-JTMFS säilytetään. Alustusvirhe ei estä käynnistystä hda:lta.

## 2. Navigatorin työprosessien fork epäonnistui (errno=12)

**Oire** (`navigator.log`): `worker fork failed errno=12` toistui. Toinen samanaikainen
työprosessi epäonnistui aina (`active=1`), ja usein epäonnistui myös ensimmäinen fork heti
edellisen työprosessin päätyttyä (`active=0`). Jokainen epäonnistuminen pysäytti latauksen
kasvavaksi ajaksi (250–4000 ms).

**Syy, varmistettu QEMUssa** (vanha kernel, testiohjelma `forkcap`, 20/24 forkia
epäonnistui, `COW: no alias for 524288 KiB`):
- 512 MiB:n prosessin fork varaa lapselle kokonaisen 512 MiB:n kernelin virtuaalialueen
  (COW-alias). Kernelin karttaikkuna on 0x11000000–0x80000000, eli 1,75 GiB.
- Päättyneen lapsen alias vapautettiin vasta, kun CPU_IDLE ehti ajaa
  (`ThreadReapQuarantined`). Kiireinen Navigator ei anna CPU_IDLE:lle vuoroa, joten
  `waitpid()` palasi mutta alias oli yhä varattuna.
- `pg_find_empty_area_locked()` aloitti haun vihjeestä, nollasi juoksun kääreessä ja lopetti
  vihjeeseen. Vapaa alue, jonka sisällä vihje oli, nähtiin kahtena lyhyenä palana, ja
  mahtuva pyyntö raportoitiin muistin loppumisena.

**Korjaukset:**
- `kernel32/core/cp/fork.c`: fork korjaa karanteenissa olevat päättyneet prosessit ennen
  aliaksen varaamista. Jos varaus epäonnistuu, fork odottaa enintään 4 × 10 ms ja yrittää
  uudelleen ennen ENOMEM-virhettä.
- `kernel32/mm/paging.c`: jos vihjehaku epäonnistuu, tehdään yksi lineaarinen first-fit-haku
  koko ikkunan yli.
- `libc/apps/navigator/nav_async.c`: jos fork palauttaa ENOMEM- tai EAGAIN-virheen, kun
  työprosesseja on käynnissä, samanaikaisten työprosessien raja lasketaan siihen, mikä
  mahtuu, ja odotetaan käynnissä olevaa työprosessia ilman viivettä. Yksi lisäpaikka
  kokeillaan uudelleen 30 sekunnin välein. Tämä korjaa samalla vanhan host-käännösvirheen
  (`unused parameter 'err'`).

## Testit

- **QEMU, ram: + hda1:** asennus `partition hda auto`, `mkfs hda1`,
  `rootinstall hda jtm32.img`, minkä jälkeen käynnistys kiintolevyltä. Juuri on hda1:, ja
  `cd ram:/`, `mkdir` ja `sqa cdrom` toimivat ram:-levyllä. V72.230: "chdir failed".
- **QEMU, ram: varajuurena (levyke):** `sqa cdrom`, `sqa core.sqa` (83 tiedostoa) ja
  sovellusten ajo toimivat.
- **QEMU, fork** (`libc/apps/forkcap.c`, 512 MiB SYSMEMREQ, haettu `nutget`-komennolla NE2000-
  ja slirp-verkon yli):
  - V72.230: vaiheessa A 20/24 forkia epäonnistui, ja vaiheen B toinen samanaikainen fork
    hylättiin.
  - V72.231: vaiheessa A 0/24 epäonnistui, ja vaihe B onnistui.
- **Host, ASan/UBSan:** `tests/v72231_fork_capacity.c` (fork käärittynä ENOMEM-rajalla):
  V72.230:n nav_async 2 FAIL, V72.231 PASS. Lisäksi Google-, lomake- ja URL-testit PASS.
- Kaikki edellä mainitut tulokset on ajettu tämän paketin `jtm32.img`-tiedostolla.

## Paketointi

`forkcap` on rekisteröity kehittäjätestiksi samalla tavalla kuin `memwin`
(`libc/apps/Makefile` UTILITIES_ONLY_APPS, `tools/build_install_image.sh` → tests.sqa).
Ilman tätä `make packages` pysähtyi virheeseen "UNCLASSIFIED TARGET: forkcap" (V70.31 SQA audit).
Tarkistettu: `make -j8 packages` → "V70.31 SQA audit: PASS: 132 release binaries".

## Lokien muut havainnot (ei muutettu)

- `kern*.log` on täynnä DEBUG-rivejä (`_jtmfat_getrootdir was called by …`,
  `jtmfs_ffindfile …`), jotka KLOGGER kirjoittaa hda1:lle. Tämä hidastaa ja kuluttaa levyä.
  SMSH:n `d0` rajaa tulostuksen.
- `AHCI/issue … cmd=0xea0 READ LBA=0 count=0` ovat FLUSH CACHE EXT -komentoja, jotka loki
  nimeää väärin READ:ksi. Ne ovat kosmeettisia.
- `FILE 'navigator.bin' … maxsz = 589824` on latauspuskurin tieto. Puskuri kasvatetaan
  tarvittaessa (`staging buffer grown`).

## Rajoitukset

- `utilities.iso` ja paketit (network.sqa) sisältävät yhä V72.230:n navigator.bin-tiedoston.
  Kopioi `libc/apps/navigator.bin` asennetulle levylle (hda1:/bin). `tools/check_release_media.py`
  odottaa `release/packages/graos-v72.231.sqa`-tiedostoa, jota ei ole rakennettu.
- Testattu vain QEMUssa. ThinkPad T400:aa ja 512 MiB:n Navigatoria GraOS:ssa oikealla
  verkolla ei ole testattu.
- Kahden samanaikaisen 512 MiB:n työprosessin mahtuminen riippuu muista kernelin
  aliaksista. Navigator sopeutuu nyt siihen, mikä mahtuu.
