# QA – JTMOS V71.116 (Navigator + GraOS fixes)

| Check | Result |
|---|---|
| Full `make` | OK, kernel32.bin 1,015,036 B |
| `tests/run-v71116-navigator-render.sh` (new) | PASS |
| `tests/run-v71112-navigator-ci.sh` | PASS |
| `tests/run-v71114-ktls-ci.sh`, `run-v71113-https-front-ci.sh`, `check_jt_httpd_site.sh` | PASS |
| PNG streaming decoder vs Pillow (8 colour types, full size) | identical |
| QEMU GraOS: test pages, tables, gallery PNG over HTTPS, maximize | OK (`release/qa/v71.116/qemu`) |
| Old/new comparison on saved Vunet, MV-lehti, article, jtmos.com | no regressions; article header bug found and fixed |

HTTPS screenshots used a test-CA Navigator build and a local copy of the site
(no internet in the sandbox). Not tested: physical eMachines EL1352.
