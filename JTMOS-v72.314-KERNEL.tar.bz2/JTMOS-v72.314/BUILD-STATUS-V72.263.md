# JTMOS V72.263 full release

The canonical `make -j2 full-build` completed successfully. The full source tree,
kernel, CLI/GUI applications, boot/root images, installation ISO and full DOSBOOT
package are included. The archive is not limited to the Navigator binary.

The embedded-media verifier passed for current Navigator/GraOS binaries, boot
image and kernel, including compression and DOSBOOT/ISO aliases. Navigator host
ASan/UBSan regression tests passed in the preceding implementation phase; its
rebuilt native binary has the same SHA-256.

See QA-V72.263.md, RELEASE-V72.263.txt and FULL-RELEASE-SHA256.txt.

QEMU 8.2.2 TCG boot smoke passed using the exact new jtm32.img: BIOS/NZIP,
kernel startup, scheduler/keyboard routing, SMSH prompt, RAM mkdir/cd and help.
The guest serial log confirms V72.263. Physical T400 testing was not performed.
