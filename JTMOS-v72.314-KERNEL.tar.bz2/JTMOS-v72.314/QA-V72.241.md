# JTMOS V72.241 — validation, 2026-11-03

| Check | Result |
|---|---|
| i686 kernel + BIOS image build and 1 MiB image budget | PASS — 943584 bytes, 104992 bytes free |
| nzip.bin, sqa.bin, unz.bin ELF32 builds | PASS |
| Public version/header/release-note gate | PASS |
| NZIP2 fast codec + independent BIOS/DOS boot contract | PASS |
| SQA repeated replace, corrupt outer/inner input, collision and directory refusal | PASS |
| Real chain I/O: partial/direct/large cluster/short I/O/overflow | PASS |
| Real DIRDB writeback with ASan/UBSan | PASS — 792 boundary/AfterFat/low-memory fallback cases |
| NZIP output failure with RLIMIT_FSIZE + ignored SIGXFSZ | PASS — write failure distinguished, partial output removed |
| SMSH seriallog on/off/status and invalid arguments | PASS — shell remains active |
| DIRDB 32 mkdir in one command, 10000 ms deadline | PASS — 6 queued, 6 completed, 6 backpressure waits |
| DIRDB explicit flush, synchronous mode, re-enable | PASS — physical fsck CLEAN in both modes |
| QEMU IDE, seriallog off, 2 complete SQA extracts | PASS — all 9 packages each time, fsck CLEAN |
| QEMU AHCI, seriallog off, 2 complete SQA extracts | PASS — all 9 packages each time, fsck CLEAN |
| Hard reset after un-synced directory creation | PASS — previously synced directory retained, no invalid entries/chains/crosslinks/size mismatch, final fsck CLEAN |
| Final compressed media, kernel/boot/DOSBOOT identity checks | PASS; JSON in release/qa/v72.241 |

QEMU tests use separate disposable 512 MiB disks (hda1: 510 MiB), 1024 MiB
RAM and the standard text/nogui kernel. Command transcripts and synthetic serial
logs are in `release/qa/v72.241/`. The original V72.240 media reproduced the
network.sqa.nz extraction failure under QEMU AHCI before the fixes.

The serial-off tests were rerun after both directory-boundary fixes. They
performed repeated replacement, not just first-time extraction. No old packages
were silently accepted after an error. The final packaging pass additionally
refreshes unz.bin diagnostics; that binary is not used by the kernel SQA builtin.

Limits: no T400/ASUS physical-hardware run or real power-cut test was available.
The DOSBOOT package was rebuilt and its kernel/media bytes verified, but FreeDOS
boot and the DOS-staged RAM-bank ramextract command were not executed here.
Ramextract compares the copy with the RAM bank; it cannot prove that bytes were
correct before DOSBOOT supplied them. SQA still validates each member checksum.
No filesystem format migration is required. Existing corrupted data are not
repaired merely by installing this kernel. Ordinary DIRDB operations use bounded
background writeback; full queues, cold cache misses, active volume transactions,
sync/fsync and destructive replacement can still wait for I/O.

Unchanged application binaries are preserved from the attached full source
release. LeakSanitizer is disabled in the host boundary harness because this
runtime cannot enumerate /proc task state; address/undefined-behavior checks run.
