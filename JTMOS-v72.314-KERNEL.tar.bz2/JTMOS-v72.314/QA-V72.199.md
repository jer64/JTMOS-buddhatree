# JTMOS v72.199 — Navigator Dynamic Memory 2.0 / QEMU 1 GiB

- Navigator requests up to 512 MiB of *virtual process address space* via APPRAM_524288K. It does not commit that much RAM.
- Kernel MM_USER_PAGES architectural ceiling raised from 256 to 512 MiB (user virtual 0x80000000..0x9fffffff, PDE 512..639). Dynamic extended per-process PTE allocation uses 60 or 124 PTE pages, depending on runtime tier. Earlier 16 MiB primary process window is unchanged. PCI/BAR probe selects a 512 MiB, 256 MiB, or legacy 16 MiB tier so BARs in the new 256..512 MiB extension do not regress older machines.
- Startup memory plan uses the real GetMemorySize() grant and OS sysinfo free RAM, retaining 32 MiB process reservation and 128 MiB system reserve; never force full budget on constrained devices. DOM cap scales with actual budget (on 256 MiB grants, approximately 56 MiB; on full grants, approximately 120 MiB) (128 MiB code ceiling); CSS + layout cap scales with grant to 128 MiB; the parser is limited to 75% of the CSS/layout budget to leave room for layout indexes, CSS parser has separate per-sheet cap.
- Under low free memory, discard decoded image buffers and RAM HTTP cache entries and (on critical pressure) font glyphs; disk cache contents remain intact; network workers only shut down while idle and critical. The browser uses free() to release these objects, but immediate return of every previously committed physical page to the kernel is NOT verified and depends on allocator/munmap behavior.
- All scripts/run_qemu*.sh default to -m 1024 (1 GiB RAM). Other QEMU flags preserved.
- ***This is a source/binary partial build.*** QEMU boot, kernel link and on-device memory safety were not verified; kernel and ISO binaries inherited from v72.198. New kernel VM mapping features require complete rebuild.
- Linux host memory budgets are accounting models, not RSS; 512 MiB VA is not 512 MiB physical memory and is not hardware nested paging.
- **Important hardware caution:** widening the per-PID virtual space may conflict with kernel identity mapped PCI BARs; the kernel runtime probe must succeed. Do not treat a successful source compile as production readiness.

## Validation actually run
- PASS: Navigator v72.199 ELF32/i686 full application link with production flags.
- PASS: kernel32 `mm/mmap.o` and `core/cp/LaunchApp.o` 32-bit compilation using `generated.mak` (not a complete kernel link).
- PASS: 27 host-side adaptive-budget assertions, including 16/64/256/512 MiB grant scenarios.
- PASS: `bash -n` on all seven `scripts/run_qemu*.sh`, and all seven contain `-m 1024`.
- NOT RUN: QEMU boot, kernel link (NASM absent), real T400 test, actual RSS decrease after cache reclamation, PCI BAR compatibility at runtime.
- Note: `free()`-based browser cache eviction releases the data objects; whether sparse committed pages are promptly returned to the kernel requires further instrumentation and runtime verification.
