# JTMOS v72.247 – Atomic Rename & Recovery

## New

JTMFS V4 now performs per-file, same-volume, cross-directory metadata moves
using one checksummed `JMOV` redo record rather than two separately committed
directory updates. The source tombstone and destination entry are applied
under the existing per-volume mutation mutex; the data and FAT chain stay
where they are. On mount, WAL replay re-applies BOTH images before advancing
the mirrored clean superblock. The record is idempotent across interrupted
recovery attempts.

The first atomic move upgrades BOTH mirrored superblocks to version 2 before
any new WAL is written. Older kernels do not support this journal format:
**do not use a v72.246 or earlier kernel for writes after upgrading a volume.**
Back up important files before testing. A downgrade requires a deliberate
migration/reformat, not just swapping the kernel executable.

### Try on a disposable V4 test volume

    mkdir mp3
    mv -v *.mp3 mp3/

Each matching regular file is moved individually, without copying file data.
V3, directory moves, cross-volume moves, full directories, and overwrite of an
existing target retain conservative behavior or return an error.

### Host tests

    python3 tests/v72247_atomic_move_reboot_host.py
    python3 tests/v72246_crash_recovery_host.py

See BUILD-STATUS-V72.247.md for coverage and exact limitations. A whole kernel
or QEMU boot test has not been performed here because NASM is unavailable.
