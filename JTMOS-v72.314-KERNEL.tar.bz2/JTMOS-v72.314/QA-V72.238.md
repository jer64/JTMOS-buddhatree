# V72.238 – varmennus

Lokit ovat hakemistossa `release/qa/v72.238/`.

| Ajo | Tulos |
|---|---|
| `tests/v72237_mkfs_stale_cache.smsh` (`tests/qemu_smsh_script.py`): T400:n tilanne. Ajettiin mkfs, bin/cfg/usr/var, `root -f hda1`, `dirdbtest refuse hda1` (mkdir epäonnistuu ja sync antaa writeback error, kuten T400:lla), `umount -f`, mkfs → `ls` tyhjä, mkdir/sync onnistuvat, jtmfsck CLEAN | 14/14 PASS |
| Sama ajo vanhalla, V72.237:n mukaisella mkfs-koodilla (tilapäinen käännös) | toisti vian: `ls` näytti vanhan juuren, `mkdir hda1:/new` epäonnistui, jtmfsck: "unable to commit dirty metadata" |
| `tests/v72237_qemu_mkfs_640g.py` (T400:n levykoko) | 11/11 PASS |
| V72.234:n tallennustesti (sisältää hda:n `umount -f` + mkfs, kun vanha `/` on vielä käytössä) | 15/15 PASS |
| Sama hda1-osiolla | 14/14 PASS |
| V71.124 päällekirjoitusregressio | PASS |

Ensimmäinen versio korjauksesta keskeytti mkfs:n "busy"-virheeseen, jos jokin
vanhan levyn hakemisto oli vielä käytössä. Tallennustesti löysi tämän
(`bootroot` → `umount -f hda` → `mkfs hda`). Lopullisessa versiossa tällainen
hakemisto irrotetaan levystä.

Navigator ei muuttunut V72.237:stä, joten sen testejä ei ajettu uudelleen
(`release/qa/v72.237/`).

**Ei ajettu:** oikea T400.
