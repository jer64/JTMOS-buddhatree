# JTMOS v72.243 source and application build status

Based on v72.242 full source release, updated 2026-11-03.

## Compiled and tested
- `libc/apps/navigator.bin` is compiled for 32-bit JTMOS with JTMOS_PUBLIC_VERSION=72.243.
- `libc/apps/mp4.bin` is compiled for 32-bit JTMOS.
- `python3 tests/v7151_mp4_player.py`: PASS (including Full-HD Baseline clip and truncated-file termination).
- `sh tests/run-v7197-navigator-ci.sh`: PASS (64 KiB IPC, URL normalization and native ELF preflight).

## Not verified
- Full top-level `make` was attempted but stopped at kernel32/core/asm/aslib.o because NASM is not installed in the build environment (Error 127). No claim of a rebuilt v72.243 kernel or installation media is made.
- The included `jtm32.img`, `root1440.img`, `utilities.iso`, `boot32pm/dosboot/` files are inherited from the v72.242 input release; they do NOT contain these v72.243 application changes.
- Longer Navigator regression script `tests/run-v7195-navigator-ci.sh` did not finish within the test deadline while compiling Lexbor, and is NOT recorded as PASS.
- Real-hardware Lenovo T400 playback, especially non-Baseline H.264, requires testing. The player does not support H.264 High profile/CABAC or HEVC.

## Build / installation
Install NASM (and the rest of the project toolchain), then run `make` in the extracted root to create up-to-date kernel, boot media and utilities ISO containing the new applications. The already compiled Navigator and MP4 binaries are in `libc/apps/` if you prefer to test them separately on an existing JTMOS installation.
See `docs/releases/V72.243-NAVIGATOR-MP4.md` for implementation details.
