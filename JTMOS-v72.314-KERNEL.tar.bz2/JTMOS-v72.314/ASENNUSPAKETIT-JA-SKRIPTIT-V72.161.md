# V72.161: skriptit, hakemistopuupaketit ja asennusskriptit

## Skriptien ajaminen
Ensimmäinen rivi kertoo, mikä ohjelma tiedoston ajaa, kuten Unixissa:

    #!/bin/sqsh       Squirrel Shell (myös *.sh-tiedosto ilman #!-riviä)
    #!/bin/sh         POSIX-tyylinen sh.bin
    #!OHJELMA ARG     OHJELMA ARG TIEDOSTO ARGUMENTIT...

Ytimen ohjelmanlataaja lukee rivin, joten skriptin voi ajaa nimellä SMSH:ssa,
SQSH:ssa ja GraOS:ssa: `angbandinstall.sh --help`.
`sqsh TIEDOSTO ARG...` ajaa tiedoston skriptinä ja poistuu sen tilakoodilla.

SQSH-skripteissä: `$0` (koko polku), `$1`…`$9`, `$#`, `$@`, `$?`,
`${NIMI:-oletus}`, `${NIMI%/*}`, `${NIMI##*/}`, if/then/else/fi,
`test` ja `[ ]`, `shift`, `exit N`. Esimerkki:

    #!/bin/sqsh
    PKG=${0%/*}/angband.sqa
    DESTDIR=${1:-/}
    if [ ! -f "$PKG" ]; then
        echo "ei löydy: $PKG"
        exit 1
    fi
    sqa "$PKG" -o "$DESTDIR" || exit 1

## Hakemistopuut: sqarc -r ja sqa
Uusi muoto SQARC521 tallentaa jäsenet suhteellisilla poluilla
(`usr/share/angband/edit/monster.txt`) ja myös tyhjät hakemistot. sqa luo
hakemistot purkaessaan, joko nykyiseen hakemistoon tai `-o HAKEMISTO`:on.

    sqarc -r hda1:/oma/puu hda1:/oma.sqa      (JTMOS)
    tools/sqarc --tree puu paketti.sqa        (koontikone)
    sqa paketti.sqa                           (purku nykyiseen hakemistoon)

".."-polut, absoluuttiset polut, laitenimet ja yli 31 tavun nimet hylätään.
Vanhat litteät paketit (SQARC520) toimivat ennallaan.

## Asennettavat ohjelmat
Jokaisella on hakemistopuupaketti ja asennusskripti, jotka puretaan /bin:iin
ulomman paketin mukana:

| Skripti | Paketti | Sisältö |
|---|---|---|
| angbandinstall.sh | angband.sqa (demos.sqa) | /usr/bin/angband.bin, /usr/share/angband, /var/games/angband |
| bitchxfullinstall.sh | bitchxfull.sqa (network.sqa) | /usr/bin/bitchxfull.bin, /usr/share/bitchx |
| bitchxinstall.sh | bitchx.sqa (network.sqa) | /usr/bin/bitchx.bin, /usr/share/doc/bitchx |
| irciiinstall.sh | ircii.sqa (network.sqa) | /usr/bin/ircii.bin, /usr/share/ircii |
| fhsinstall.sh | fhs.sqa (core.sqa) | /usr, /var ja /var/www/html/index.html |

Esimerkki Angbandille hda1:llä:

    sqa demos.sqa                (tai pkg install demos hda1:/bin utils.iso)
    angbandinstall.sh hda1:/     tai: kopioi angband.sqa hda1:/:een ja aja siellä  sqa angband.sqa
    angband -n

Skriptit noudattavat GNU-käytäntöjä: `--help`, `--version` ja valinnainen
DESTDIR (oletus `/`, nykyisen laitteen juuri). Ohjelmat menevät /usr/bin:iin
(komentohaku löytää ne), muuttumaton data /usr/share/&lt;paketti&gt;:iin,
dokumentaatio /usr/share/doc/&lt;paketti&gt;:iin ja tallennukset /var:iin.

## WWW-palvelin
`www start` palvelee WWW_ROOT:sta. Jos tiedostoa ei ole siellä, se haetaan
/var/www/html:sta (juurilaite, hda1:, ram:) ennen sisäänrakennettuja sivuja.

## HD Audio
V72.160:n paikkasuodatin saattoi hylätä oikean etenemisen, jos PIT-keskeytykset
myöhästyivät, ja aiheuttaa lyhyen katkon. Nyt ohitetaan vain yli puolen
renkaan hypyt (taaksepäin luettu arvo). QEMU:ssa viisi ajoa, myös kolme
rinnakkain kuormitettuna, ilman yhtään katkoa.
