# Navigator v72.190: DIV, taulukot ja tavalliset CSS-muodot

Pohja on koko JTMOS v72.189. Navigator on käännetty uudelleen ELF32/i686-muotoon Lexbor-, QuickJS-, WebP- ja BearSSL-tuella. Aiemmat lähdekoodimuutokset, mukaan lukien v72.189:n HDA-korjaukset, ovat mukana.

## Toteutetut korjaukset

| Ominaisuus | Uusi toiminta |
| --- | --- |
| `border-spacing: 6px 10px` | Ensimmäinen arvo ohjaa vaakasuuntaa, toinen pystysuuntaa; yhden arvon muoto toimii edelleen. |
| Soluvälien periytyminen | Molemmat arvot periytyvät CSS-puun kautta; `unset` perii ja `initial` asettaa nollan. HTML-taulukon oletusväli on 2 px. |
| CSS-taulukon suorat solut | Peräkkäiset `display:table-cell`-elementit saavat puuttuvan rivin ilman DOM-puun muuttamista. Toimii myös riviryhmän sisällä ja varsinaisten rivien välissä. |
| `table-layout:fixed` | `col` ohittaa ensimmäisen rivin soluleveyden. Ensimmäisen rivin colspan jakaa leveyden määrittelemättömille sarakkeille; myöhempien rivien leveydet eivät muuta sarakkeita. |
| Taulukon vähimmäisleveys | `min-width` kasvattaa myös sarakeruudukon. Kiinteät sarakkeet saavat kasvattaa taulukkoa ilmoitettua leveyttä leveämmäksi. |
| `rowspan` | Nolla ulottaa solun riviryhmän loppuun. Myös tavalliset rowspanit rajataan riviryhmään. Pitkät numerojonot eivät ylivuoda. |
| Reunusten lyhenteet ja pitkät muodot | Leveys, tyyli ja väri osallistuvat itsenäiseen kaskadiin. `border-style:none` säilyy ilman reunaa myös myöhemmän leveysmäärityksen jälkeen. |
| Neljä reunaväriä | `border-color:red green blue black` määrää ylä-, oikean, ala- ja vasemman reunan värin erikseen. |
| CSS-muuttujat | Esimerkiksi `--space:8px 16px; padding:var(--space)` avataan muuttujan korvaamisen jälkeen. Sama koskee margin-, logical pair-, inset-, border- ja gap-lyhenteitä. |
| Kaksiosainen display | Esimerkiksi `display:block flex` ja `display:inline grid` käyttävät vastaavaa flex/grid-asettelua ja säilyttävät inline-ulkoroolin. |
| Virheelliset arvot | Virheelliset display-, border-spacing-, border-width- ja border-style-arvot eivät syrjäytä aiempaa kelvollista määritystä. `@supports` tunnistaa toteutettuja taulukkomuotoja. |

Olemassa oleva tuki prosentti-, px-, em-, rem-, pt- ja vw-mitoille, calc/min/max/clamp-lausekkeille, flex/grid-asettelulle, asemoinnille ja tekstin tasaukselle säilyy. Tämä päivitys ei tarkoita täydellistä CSS-standardin toteutusta.

## Kokeilu JTMOSissa

Asenna päivitetty network-paketti utilities.iso-medialta normaalilla pakettityönkululla tai kopioi uusi binääri `/bin/navigator.bin`-tiedostoksi. Testisivu asentuu network-paketista nimelle `/bin/navtable190.html`:

```text
navigator.bin file:///bin/navtable190.html
```

Testaa leveällä ja kapealla ikkunalla. Sivulla on suoria DIV-taulukkosoluja, HTML-taulukko, kaksi tbody-ryhmää, rowspan=0, colspan, solun sisäinen DIV, eriväriset reunat sekä muuttujista muodostettu padding, border ja gap.

## Tiedostot ja tarkistukset

Muutetut selainmoduulit: `nav_css.c/.h`, `nav_style.c/.h` ja `nav_layout.c`. Pakkausskriptit tuovat testisivun sekä täydelle sovellusmedialle että myöhempiin Navigator-erillispaketteihin.

`tests/v72190_navigator_div_table.c` sisältää 43 kohdennettua tarkistusta. Ajettava testiskripti on `tests/run-v72190-navigator-div-table.sh`. Lexbor-host-arkiston voi tehdä projektin `tools/build_navigator_lexbor_host.py`-työkalulla ja antaa testille `LEXBOR_HOST_ARCHIVE`-ympäristömuuttujana.

## Rajat

Reunusten piirtäjä näyttää näkyvät dotted/dashed/double/3D-tyylit edelleen yhtenäisenä reunana. Täysi collapsed-border-konfliktiratkaisu ja kaikkien puuttuvien taulukkokääreiden muodostaminen eivät ole valmiita; tässä lisättiin puuttuvat rivit solujonoille. Inline-table säilyy aiemman toteutuksen tavoin lohkomaisena. Pystysuuntaiset kirjoitustilat eivät kuulu logical-määritysten tukeen.

Taulukkorajat ovat edelleen enintään 64 saraketta, 512 kerättyä riviä ja 1024 käsiteltyä solua; kyseessä on rajattu selainmoottori.

Julkaisu on nimetty **FULL-SOURCE-UNBUILT**, koska kernel ja A:-käynnistyskuva ovat perittyjä eikä kernelin aiempia lähdemuutoksia ole linkitetty tähän binääriin. Navigator itse ja sovellusmedia on rakennettu uudelleen. T400- tai QEMU-ajosta ei ole näyttöä tästä versiosta.

## Standarditausta

Ratkaisuissa on käytetty [W3C CSS 2:n taulukkomallia](https://www.w3.org/TR/CSS2/tables.html), erityisesti nimettömiä rivejä, kiinteää taulukkoasettelua ja erillisiä soluvälejä. Selain toteuttaa tästä rajatun osajoukon.
