# JTMOS v71.123 – Navigator audit and targeted validation

Baseline: user-supplied `JTMOS-v71.122-FULL-SOURCE-RELEASE(1).zip`.
Date: 2026-10-20.

## Measured baseline limits

- DOM arena: 3 MiB, 24,000 nodes, 128 depth (`nav_dom.h`).
- HTML response: 2 MiB (`navigator_core.h`).
- CSS selectors/rules and paint count significantly below the capacity of large news pages.
- Cookie storage: 16 host-only entries; Domain and Path were not implemented (`nav_network.c`).

## Implementation

See `RELEASE-V71.123.txt` for the 10 categories of changes. The browser
continues to use the real Lexbor HTML5 backend, not a fake HTML parser.
Caps remain finite and are enforced. Cookie processing is a worker-local
in-memory jar; Secure cookies are restricted to TLS and origin matching.

## Test report

- `tests/v71123_dom_limits.c`: parse >26,000 DIV siblings nested >128 levels,
  verify >52,000 total DOM nodes and first base URL (host native parser).
- `tests/v71123_navigator_cookie.c`: host/path/domain restrictions,
  cross-domain isolation, SameSite=None+Secure, Secure and __Host- prefixes,
  cookie deletion, expiry and path precedence (real shipping code).
- `tests/v71122_network.py`: actual localhost HTTP and redirect compatibility.
- `tests/run-v71122-navigator-ci.sh`: existing v71.122 sanitizer regression
  previously passed early stages; full pipeline was not completed in this
  workspace because it exceeded the tool execution limit.

Do not claim end-to-end compliance with google.com, edition.cnn.com, or
foxnews.com. No successful real-site QEMU screenshot/browser rendering test
has been performed, and native default QuickJS support remains disabled.

## Build and integration results

- PASS: `sh tests/run-v71123-navigator-ci.sh` (DOM, cookie, localhost HTTP).
- PASS: 32-bit `navigator.bin` application compilation using JTMOS i686
  toolchain, with Lexbor and BearSSL linked. The shipped default QuickJS
  JavaScript runtime is disabled, as in the original release.
- PASS: complete Navigator `navigator-v71.123.sqa` release package.
- PASS: regeneration of `tools/utilities.sqa`, `utilities.iso`, `utils.iso`,
  and `kernel32/utilities.iso` with the new Navigator binary.
- PASS: extracting `network.sqa.nz` from the updated utilities archive,
  extracting `navigator.bin` from inside that network package and performing
  a byte-for-byte comparison against freshly built Navigator.
- BLOCKED: full operating-system kernel build from source; this environment
  does not include `nasm`. Previously built kernel/boot images are retained.
- NOT TESTED: full graphical site loading in booted GraOS, SSL live-session
  end-to-end checks and CNN/Fox News/Google dynamic JavaScript compatibility.
- LIMITATION: DOM limits are still intentionally finite. Very large or
  malformed HTML can still hit a bound and show the fallback error.
- LIMITATION: cookie Domain verification is not backed by a complete Public
  Suffix List and the complete cross-site SameSite request policy is absent.

Full QA logs: `release/qa/v71.123/`. Do not treat a successfully regenerated
application package as proof that every previous boot image was rebuilt.
