# Navigator TODO

The canonical JavaScript/Web API checklist and implementation plan is maintained in:

`libc/apps/navigator/TODO.md`

Updated in JTMOS v72.278.
