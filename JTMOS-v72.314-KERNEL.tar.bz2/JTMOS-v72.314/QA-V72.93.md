# JTMOS v72.93 QA report

## Build results

| Target | Result |
|---|---|
| graos.bin | PASS, ELF32, 563328 bytes |
| navigator.bin | PASS, ELF32, 2682920 bytes |
| filer.bin | PASS, ELF32, 113536 bytes |
| calendar.bin | PASS, ELF32, 130100 bytes |
| mp3.bin | PASS, ELF32, 126140 bytes |
| mpeg1.bin | PASS, ELF32, 143672 bytes |

## Executed regression tests

| Test | Result | Note |
|---|---|---|
| `v7293_busy_application_runtime.py` | PASS | v7293_busy_application_runtime: PASS; application/launcher integration checks |
| `v7291_busy_host_test.py` | PASS | v7291_busy_host_test: PASS (real production busy core; 27 checks) |
| `v7291_busy_integration.py` | PASS | v7291_busy_integration: PASS |
| `v7292_hourglass_runtime.py` | PASS | v7292_hourglass_runtime: PASS (33 actual frame/tick/damage assertions) |
| `v7290_vesa_ega_no_hourglass.py` | PASS | v7290_vesa_ega_no_hourglass: PASS (static source checks only) |
| `v7070_graos_hourglass_cursor.py` | PASS | v7070_graos_hourglass_cursor: PASS on V72.93 |
| `v7278_dosboot_prompt_parity.py` | PASS | PASS: hd/floppy source words still parsed |

## Packaging

- `graos.sqa`: created with native `tools/sqarc` and 3 rebuilt members verified by `--compare-member`.
- ZIP archive checked with `ZipFile.testzip()`.

## Not tested

- Real T400 mouse/graphics/compositor behaviour.
- End-to-end HTTP/TLS, filesystem speed or interrupted file transfer while in GraOS.
- Kernel and DOSBOOT rebuilt using NASM (NASM unavailable).
- `utilities.iso` rebuilt with updated application binaries.
