# V72.237 – varmennus

Lokit ovat hakemistossa `release/qa/v72.237/`.

| Ajo | Tulos |
|---|---|
| `tests/v72237_qemu_mkfs_640g.py`: T400:n levykoko (1 250 263 728 sektoria). Ajettiin partition hda auto, mkfs hda1 (> 2^30 sektoria), diskspace, root -f hda1, mkfs busy, umount -f, mkfs (T400:n "error 4" -kohta), uudelleenosiointi + mkfs, sqa cdrom ja jtmfsck CLEAN | 11/11 PASS |
| Sama ajo V72.236:n medialla | 11/11 PASS (ehjällä levyllä vika ei toistu; T400:n hda1 oli vaurioitunut) |
| `tests/run-v72237.py`: RFC 4329 -yksikkötesti (tyypit, version-parametri, mime-charset, tunnistusjärjestys, 7 merkistöä, virhetilanteet, purku samaan puskuriin) + javascript:-sisällön haku (%-oktetit, BOM, `#`, koodausvirheet, java\nscript) | PASS |
| Sama ajo: Navigator + oikea QuickJS (ASan/UBSan). Linkit (JS pois/päällä, `#`, ä, koodausvirhe, void, merkkijono korvaa dokumentin), location.href, form action, osoiterivin kielto, inline-tyypit, 8 ulkoista skriptiä (ISO-8859-1, windows-1252, `<script charset>`, UTF-16LE-BOM, laiton UTF-8, shift_jis, version=2, strict-tyyppi) ja skriptidokumentti tekstinä | PASS |
| v72.236:n hakukonegate, v72.233:n host-portti (päivitetyt testien käännöslistat) ja v72.235:n historia | PASS |
| QEMU: V72.234:n tallennustesti, hda1-osio, V71.124 päällekirjoitus | PASS |

**Ei ajettu:** oikea T400 eikä vaurioitunut hda1. T400:n vika päätellään
näin: virheen 4 aiheuttavat vain alustusta edeltävät flush-vaiheet ennen
edistymispalkkia, eikä ruudulla näkynyt laiteajurin flush-virheilmoitusta.
Kaikki nämä polut käsitellään nyt korjatulla tavalla.
