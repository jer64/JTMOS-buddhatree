# JTMOS v72.246 – JTMFS Crash Recovery Engine (phase 1)

Based on v72.245 full-source release. **No on-disk file system format changes.**

## Kernel safety changes

- `kernel32/fs/jtmfs/jtmfsDb.c`: if the disk identifies itself as a V4
  volume but the metadata arena geometry is invalid, **freeze all new JTMFS
  writes** instead of silently falling back to legacy, journal-less writes.
- If both mirrored V4 superblocks fail checks, also freeze new writes. A
  surviving valid mirror can still be used for normal replay.
- `JtmfsDbReadOnly()` now probes on first access so callers cannot bypass the
  freeze before a regular DIRDB path has opened the volume. Normal hot calls
  remain RAM-only after the first probe.
- `JtmfsDbGroupCommit()` returns `-11` on a frozen/invalid V4 probe instead of
  claiming a successful no-op. Prepare/stage/commit helpers similarly return
  errors on frozen volumes. Raw inspection and read access are retained.
- These checks protect existing media against unintended modification; never
  bypass them by reformatting the device if they trigger unexpectedly.

## Crash/reboot test matrix

`tests/v72246_crash_recovery_host.py` extracts and compiles the **actual**
production C definitions of the V4 superblock/redo record and the functions
`db_probe`, `JtmfsDbGroupCommit`, `JtmfsDbRecover`, checksum and WAL helpers.
It substitutes a host-only block layer, FAT allocator and directory layer.

The test creates temporary 64-KiB disk images in a private temp directory.
For each crash boundary it starts a separate host process which executes
`_exit(86)` at an I/O checkpoint. It then starts two *new* processes against
that same persistent image to check recovery and stable replay results.

- Exhaustive 20 checkpoints across data, redo, FAT, directory and mirrored
  superblock I/O, plus a clean path, under **three** block-device models:
  volatile queued writes, eager write-through and early torn 24-byte writes.
- Two new file entries share a single transaction. After recovery they must
  be **both present or both absent**, never cross-linked or partly published.
  A visible file must have a valid, durable FAT chain and unmodified data.
- Damaged/latest superblock fallback to older mirror + successful replay.
- Tampered redo checksum must be rejected before namespace publication.
- Both superblocks invalid, invalid geometry, one good mirror and an older
  V3-format disk marker are handled according to their respective safety rules.
- Repeated recovery must be idempotent (identical clean sequence, generation,
  and visible directory entries on a second process invocation).

`python3 tests/v72246_crash_recovery_host.py`

## Tests executed

- New isolated persistent-image recovery scenarios: **69 PASS**.
- v72.245 group-commit phase fault host test: PASS (7 injected errors).
- v72.245 DIRDB failed-read fail-closed test: PASS.
- v72.245 worker watchdog test: PASS.
- v72.241 DIRDB writeback host regression: PASS (792 cases).
- JTMFS freshly formatted structure regression: PASS.
- Changed `kernel32/fs/jtmfs/jtmfsDb.c` compiled to **ELF32 Intel i386** with
  the project's own GCC flags.

## Limits and safety

These are isolated **host tests** and do not emulate all ATA/AHCI physical
behaviors, cache reorderings, power-fail electronics or the complete
JTMFS mount and `jtmfsck` implementation. A full-volume QEMU power-cycle test
and hardware crash/reboot tests remain future work. Never fault-inject a real
JTMFS volume containing user data. The test does not touch physical devices.

The full ZIP includes the updated source and locally built `jtmfsDb.o`, but
**the complete kernel and boot media are not rebuilt**, as NASM is unavailable
in this environment. Inherited boot images and prebuilt applications may
still contain older code. Rebuild on a NASM-enabled JTMOS development host.

## Verification commands

```sh
python3 tests/v72246_crash_recovery_host.py
python3 tests/v72245_jtmfs_commit_fault_host.py
python3 tests/v72245_dirdb_failclosed_host.py
python3 tests/v72245_jtmfs_watchdog_host.py
python3 tests/v72241_dirdb_writeback_host.py
python3 tests/jtmfs_fresh_format_health_regression.py
make -j2  # Requires NASM and full JTMOS build dependencies
```
