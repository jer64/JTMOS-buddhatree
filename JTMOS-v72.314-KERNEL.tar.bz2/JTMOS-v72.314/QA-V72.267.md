# JTMOS V72.267 – tarkistukset

| Tarkistus | Tulos |
| --- | --- |
| `make -j8 full-build` (GCC 13.3.0) | PASS |
| Kernelin kuvabudjetti: 934656 tavua, 113920 vapaana | PASS |
| `tests/v72267_qemu_pipespeed.py` (QEMU 2,5 GiB, lopullinen media) | PASS: 8 MiB 508 ms = 16125 KiB/s; 384 MiB:n prosessin toinen samanaikainen fork ok |
| Sama pipespeed.bin V72.266-kernelillä | 8216 ms = 997 KiB/s (vertailu) |
| forkcap.bin (512 MiB) V72.267:llä | toinen samanaikainen fork `refused (errno=12)`: vahvistaa 384 MiB:n tarpeen |
| navipctest.bin (QEMU) | PASS: fork, pipe, fcntl, nonblocking 65536 tavua |
| `tests/v72109_qemu_boot.py` | PASS |
| `tests/v72160_qemu_graos_calendar.py` | 3/3 PASS |
| `tests/v72266_qemu_buttondemo.py` | 4/4 PASS |
| `tests/run-v72263-navigation-budget.py` (ASan/UBSan, 384 MiB) | PASS, muistisuunnitelma 28 tarkistusta |
| `tests/v72267_nav_log_batch.c`, `tests/v72240_nav_log.c`, `tests/v72212_logging/run.sh` | PASS |
| `node tests/v72267_nav_webapi_shim.js` | PASS |
| Navigator oikeassa verkossa / T400 | Ei ajettu (QEMU-ympäristössä ei ole internetyhteyttä) |

Valmiiksi rikki olleet testit (sama tulos V72.265/V72.266:lla):
`tests/v71100_pipe_dos_menu.py`, `tools/check_pipes_filebuf.sh` ja
`tests/run-v72240.py`, joka kaatuu jo vaiheessa `run-v72239.py`.

Lokit: `validation-v72.267/`. Lokianalyysi: `LOKIANALYYSI-V72.267.md`.
