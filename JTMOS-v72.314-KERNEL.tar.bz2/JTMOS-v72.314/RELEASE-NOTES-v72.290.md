# JTMOS v72.290 – pthread lifecycle/reap accounting correction

**Base:** complete JTMOS v72.289 source. All release packages use `.tar.bz2`.

The QEMU report from v72.289 showed `FAIL lifecycle collector batch=0 reclaimed=2 (stacks retained)`, while `pthreadposixgate`, `pthreadchurn`, `pthreadrace`, `pthreadscale`, and `pthreadstress` passed. Source inspection found the old lifecycle and reap tests counted only stacks reclaimed by their explicit collector calls, overlooking threads collected opportunistically by the v72.289 `pthread_create`/`pthread_detach`/`pthread_join` paths.

## Implemented

- `libc/apps/pthreadlifecycle.c`: accept EINVAL (detached/pending) or ESRCH (already collected) on immediate stale joins; for each batch, wait until every detached handle returns ESRCH and the worker completion counter matches, rather than summing explicit collect() results. Report the count that was explicitly reclaimed separately.
- `libc/apps/pthreadreap.c`: same change to two batches of 4 detached threads.
- Updated `tools/build_install_image.sh` test descriptions and regenerated `tests.sqa` and `utilities.iso` with the rebuilt ELF32 test programs.
- VERSION 72.290. No changes to the kernel or libc pthread implementation, no change to the feature gate, and no general POSIX compliance claim.

## Validation

- `make -C libc/libc check`: PASS.
- Build `pthreadlifecycle.bin` and `pthreadreap.bin`: PASS, ELF32/i386, entry 0x80004000.
- `sh tools/build_install_image.sh`: PASS.
- `make publish-utilities-iso`: PASS, `cmp utilities.iso utils.iso` PASS.
- `tools/sqarc --has-member` and `--compare-member` against the rebuilt binaries: PASS for lifecycle and reap.
- **QEMU runtime and full kernel rebuild not performed:** QEMU/NASM are unavailable here. Existing kernel/boot binaries are inherited from v72.289, and require rebuilding on your machine for test mode.

## Instructions

    make KERNEL_RING3_TEST=1

Extract `tests.sqa` to JTMOS `/bin` and run:

    pthreadlifecycle.bin
    pthreadreap.bin
    pthreadposixgate.bin
    pthreadchurn.bin
    pthreadrace.bin
    pthreadscale.bin
    pthreadstress.bin

Expected `pthreadlifecycle.bin` batch results: `collected=4 stale=4`; `explicit` may be 0 to 4 depending on whether the earlier calls have already collected some children. A genuine detached-thread cleanup problem should still fail due to a handle remaining pending or an incorrect completed-thread count.

**Safety:** `KERNEL_RING3_TEST=1` remains experimental; normal POSIX pthread use is still gated. Do not use production disks; no full POSIX thread, TLS, cancellation, signal or fork safety guarantees.
