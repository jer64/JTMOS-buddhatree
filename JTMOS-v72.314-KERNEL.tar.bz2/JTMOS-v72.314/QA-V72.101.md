# JTMOS V72.101 QA – fixed-layout kernel-size regression

## Root cause
V72.100 linker _edata at physical 0x0020061B, 1,563 bytes beyond the
fixed 1 MiB raw kernel range. The .bss overlap is a consequence.
No change to kernel load address, BSS/stack/paging layout or boot32pm staging.

## Source changes
- `kernel32/sh/helpapp.c`: shorten resident help strings, preserve all commands.
- `kernel32/autogen.pl`: report actual kernel32.bin size/headroom after link.
- `tests/v72101_kernel_image_budget.py`: compilation and hard limit regression.
- `VERSION`, `kernel32/include/jtmos_release.h`: V72.101.

## Build measurements
- V72.100 `helpapp.o` -Os/i686: .text 1,016; .rodata 6,026; total 7,042 B.
- V72.101 `helpapp.o` -Os/i686: .text 920; .rodata 2,895; total 3,815 B.
- Reduction: **3,227 B**, exceeds reported 1,563 B overflow by 1,664 B.
- Linker layout/loader 1 MiB checks retained.

## Verification
- `perl -c kernel32/autogen.pl`: PASS.
- Native 32-bit `sh/helpapp.o` compilation: PASS.
- Built-in redirection and JTMFS-condense source tests: PASS.
- Compact help size-budget test: PASS.
- Source layout directory aliases: run before packing.
- Rooted ZIP, symlinks and CRC: run after packing.

## Limitations
Cannot build new `kernel32.bin`/DOSBOOT here (NASM absent, most original
kernel objects absent). The size reduction is a measured object-space result;
actual full link and T400 boot are **not verified**. The archive is UNBUILT.
