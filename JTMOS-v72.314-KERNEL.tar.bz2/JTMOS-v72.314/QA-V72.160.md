# JTMOS v72.160 – QA

Päiväys 27.10.2026. Pohjana on kokonainen v72.159-lähdepaketti (SHA-256 `397831a2…847b5aa6`).

| Tarkistus | Tulos |
|---|---|
| Natiivi koonti ja media (`check_release_media.py`) | PASS |
| HDA-yksikkötestit (`check_hda_v7157.sh`, 18 tapausta) | PASS |
| QEMU ich9-intel-hda + hda-duplex: 4 s 440 Hz, ei yli 1 ms:n katkoa | PASS (3,9 s, 439,9 Hz, pisin hiljaisuus 1 näyte) |
| QEMU ich9-intel-hda + hda-micro: sama | PASS (3,9 s, 440,1 Hz, pisin hiljaisuus 1 näyte) |
| Paikka luetaan DMA-paikkapuskurista (`audio status`) | PASS ("position from DMA position buffer") |
| GraOS-komentokehote: tuplaklikkaus valitsee URL:n, Ctrl+Shift+C kopioi, ei SIGINT:iä | PASS |
| GraOS-komentokehote: Ctrl+Shift+V liittää, ei suorita; Enter suorittaa | PASS |
| SQSH: Ctrl+V liittää ensimmäisen rivin, ei suorita | PASS |
| GraOS: kello avaa kalenterin, toinen klikkaus sulkee, X-painike sulkee | PASS |
| QEMU-verkkoregressio | PASS 10/10 |
| SQSH:n Ctrl+C (ping) | PASS |
| Koko paketin manifesti (`check_full_release_manifest.py`) ja ZIP:stä uudelleenkoonti | PASS (kernel32.bin, graos.bin, sqsh.bin, calendar.bin, utilities.iso, levykuvat identtiset) |

Huomio: QEMU:n HDA-malli ei tuota T400:n LPIB-virhettä, joten pätkimisen korjaus
on varmistettava T400:lla: `audio status` -> "position from DMA position buffer",
"ignored glitches" kertoo, montako virheellistä paikkalukemaa ohitettiin.

`tests/v72110_qemu_desktop.py` käyttää kiinteää tekstimuistiosoitetta 0xba000,
joka ei enää vastaa SMSH-terminaalia; testi aikakatkaistaan jo ennen GraOS:ia.
Uudet GraOS-testit etsivät terminaalin `screens`-symbolista.
