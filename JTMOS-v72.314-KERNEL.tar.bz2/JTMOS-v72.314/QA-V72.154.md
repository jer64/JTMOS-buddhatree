# JTMOS v72.154 – QA

Päiväys 26.10.2026. Pohjana on kokonainen v72.153-lähdepaketti (SHA-256 `16be63da…ae062a`).

| Tarkistus | Tulos |
|---|---|
| Natiivi koonti ja media | PASS |
| ICH9E-ajurimallit v72.108–v72.152 ja uusi v72.154 | PASS: EN pois linkin ollessa alhaalla, päälle linkin noustua; TIPG 0x00602008 |
| Mutaatio `enable_at_init` (vanha käytös) | hylätty |
| QEMU: `inet static`, ARP ja uusi Host Unreachable -viesti | PASS |
| QEMU: DHCP ja verkkoregressio | PASS, 10/10 |

Rajaus: QEMU:ssa ei ole ICH9 LAN -mallia. Sitä, korjaako muutos T400:n lähetyksen, ei ole todennettu.
