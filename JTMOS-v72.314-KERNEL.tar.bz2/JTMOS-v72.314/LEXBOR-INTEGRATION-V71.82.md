# Real Lexbor integration — completion checklist

The code contains `nav_lexbor.c` implementing an adapter to the official `lxb_html_document_create()` / `lxb_html_document_parse()` API. The adapter iterates the native Lexbor DOM node/attribute structures and copies nodes into JTMOS' bounded lightweight page arena; once the copy is complete it destroys the Lexbor document. Lexbor C library is licensed Apache-2.0; upstream: https://github.com/lexbor/lexbor

## What is still needed
1. Acquire the **official, version-pinned Lexbor source** and preserve its LICENSE/NOTICE files. Do not download source from untrusted mirrors.
2. Use upstream's `single.pl --port=posix html` with a pinned revision, or CMake to build an appropriate static subset (HTML + DOM + core + tag + ns). Verify which platform hooks and standard functions Lexbor actually requires in this JTMOS libc.
3. Cross-compile for i486 with `-m32 -march=i486 -ffreestanding` and JTMOS headers. Audit `malloc/free`, printf variants, libc locale, atomics, thread-local data, `errno`, and all unresolved symbols.
4. Verify source compatibility of `nav_lexbor.c` with the pinned Lexbor tag. This code has **NOT** been built against official Lexbor in this release.
5. Ensure the combined *Lexbor allocations plus* 3 MiB copied DOM stay inside an explicit process memory budget, or store Lexbor's DOM directly to avoid double allocation. Current `SYSMEMREQ(APPRAM_12288K)` may be insufficient for complex pages.
6. Compile with `NAV_HAVE_LEXBOR=1`, provide `LEXBOR_INCLUDE` and `LEXBOR_ARCHIVE` paths, and inspect `navigator.map` and binary symbols to prove Lexbor is linked.
7. Run HTML5lib/WHATWG tree construction corpus and WordPress page regressions on both Linux host and JTMOS/GraOS.
8. Add page load cycles with COW/brk/mmap accounting and an OOM regression. Verify all Lexbor allocations freed on page change.

Only after steps 1–8 succeed may the release claim a standards-conforming HTML5 parsing backend.
