# JTMOS v72.148 – QA

Päiväys 26.10.2026. Pohjana on kokonainen v72.147-lähdepaketti (SHA-256 `54ca56dd…e2aeb1ab`).

| Tarkistus | Tulos |
|---|---|
| Natiivi koonti | PASS. Kernelin 1 MiB:n ikkunassa vapaana 86 212 tavua (raja 65 536). |
| Media, mediavahti ja Navigatorin preflight | PASS |
| QEMU, oikea julkaisumedia | PASS 4/4. SMSH:n `ver` ja `version` sekä SQSH:n `ver` ja `version` näyttävät version 72.148 ja järjestelmän buildin 72.148. Ristiriitavaroitusta ei tule. |

Ruutukaappaukset tekstinä ja sarjaloki ovat hakemistossa `release/qa/v72.148/`.
