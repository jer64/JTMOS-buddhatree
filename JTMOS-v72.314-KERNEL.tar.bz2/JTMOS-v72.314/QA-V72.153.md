# JTMOS v72.153 – QA

Päiväys 26.10.2026. Pohjana on kokonainen v72.152-lähdepaketti (SHA-256 `2ad8e05e…445600`).

| Tarkistus | Tulos |
|---|---|
| Natiivi koonti ja media | PASS |
| MANC/FWSM-dekoodaus, tuotantokoodi isäntäkoneella käännettynä | PASS: T400:n FWSM 600180C4 → FW valid, iAMT, PHY-reset sallittu |
| QEMU-verkkoregressio | PASS 10/10 |

Muutos koskee vain `inet hw` -tulostetta; ajuriin ei koskettu. Bittiarvot ovat Intelin e1000e:n `defines.h`-tiedostosta.
