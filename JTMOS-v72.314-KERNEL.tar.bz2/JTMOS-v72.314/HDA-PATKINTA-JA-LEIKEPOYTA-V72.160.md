# V72.160: miksi ääni pätki T400:lla ja mitä muutettiin

## Oire
v72.159:llä 2captain.mp3 soi T400:n Conexant CX20561 -koodekin kautta, mutta
ääni katkesi aina DMA-puskurin vaihdon kohdalla.

## Syy
Ajuri seurasi soittokohtaa pelkästään SDnLPIB-rekisteristä (Link Position in
Buffer). Intel ICH -ohjaimilla LPIB voi antaa yksittäisen väärän arvon BDL-
segmentin rajalla. Ajurin laskenta `delta=(lpib+RING-last)%RING` tulkitsi
taaksepäin hypähtäneen arvon lähes koko renkaan (128 KiB ≈ 680 ms) etenemiseksi.
Silloin kirjoituskohta näytti jääneen jälkeen, `hda_fill_from_fifo` merkitsi
alivuodon ja aloitti kirjoittamisen uudesta kohdasta DMA:n edellä: kuuluva
aukko joka segmentinvaihdossa.

Linuxin snd-hda-intel ei luota LPIB:hen Intel-ohjaimilla vaan käyttää DMA-
paikkapuskuria (DPLBASE 0x70 / DPUBASE 0x74): ohjain kirjoittaa jokaisen
virran paikan muistiin (8 tavua virtaa kohti).

## Korjaus
1. DMA-paikkapuskuri sijoitetaan BDL-sivun loppupuolelle (offset 2048) ja
   otetaan käyttöön joka virran käynnistyksessä. Paikka luetaan puskurista,
   kun sen on nähty liikkuvan; muuten LPIB.
2. Uskottavuussuodatin: jos uusi paikka väittää edenneen enemmän kuin 48 kHz
   16-bit stereo (192 tavua/ms) ehtii kuluneessa ajassa (+ väljyys), lukema
   ohitetaan ja lasketaan ("ignored glitches").
3. Suojaväli 2 KiB -> 8 KiB ja alivuodon jälkeinen aloitusmarginaali
   1 KiB -> 4 KiB.

## Leikepöytä
Jaettu leikepöytä on tiedosto `ram:/clipboard.txt` (Navigator, Nutedit,
tekstikentät). GraOS:n komentokehotteessa: hiiren veto valitsee, tuplaklikkaus
valitsee sanan, Ctrl+Shift+C kopioi ja Ctrl+Shift+V liittää – kuten GNOME
Terminalissa. Ctrl+Shift+C ei koskaan muutu Ctrl+C-keskeytykseksi. Liitos
kirjoittaa vain ensimmäisen rivin ilman rivinvaihtoa, joten komento ei
suoriudu itsestään. SQSH:ssa myös pelkkä Ctrl+V liittää.

## Kalenteri
Paneelin kello on nyt vaihtokytkin: klikkaus avaa kalenterin, uusi klikkaus
sulkee sen. Kalenterissa on X-painike, ja Esc sulkee sen edelleen.

## Testaa T400:lla
    audio probe
    audio status        <- "position from DMA position buffer"
    audio test 440 4000 <- tasainen ääni ilman katkoja
    mp3 2captain.mp3
    audio status        <- underruns ja ignored glitches
Jos ääntä ei kuulu, paina ThinkPadin äänenvoimakkuus ylös -näppäintä
(EC voi pitää vahvistimen mykistettynä).
