# JTMOS v72.157 – QA

Päiväys 27.10.2026. Pohjana on kokonainen v72.156-lähdepaketti (SHA-256 `1a98dbce…ce0c1450`).

| Tarkistus | Tulos |
|---|---|
| Natiivi koonti ja media | PASS |
| ICH9E-ajurimallit v72.108–v72.156 | PASS |
| Uusi v72.157-malli | PASS: TCTL 0x3103F0F8 ennen linkkiä ja 0x3103F0FA linkin jälkeen; TARC1 bitti 28 = 0, bitit 24/26/30 = 1; txmatrixin rivi 7 tuottaa vanhan parin |
| Mutaatio `wholesale_tctl` (vanha TCTL-kirjoitus) | hylätty |
| QEMU: kiinteä osoite, DHCP ja verkkoregressio | PASS, 10/10 |

Rajaus: QEMU:ssa ei ole ICH9-mallia. Vaikutus T400:een vahvistetaan txmatrixin riveillä 0 ja 7.
