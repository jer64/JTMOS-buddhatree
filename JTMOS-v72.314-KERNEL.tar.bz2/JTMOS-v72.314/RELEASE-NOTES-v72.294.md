# JTMOS v72.294 — Navigator low-memory asynchronous HTTPS helper

## Summary

Introduced `navnetd.bin`: a separate JTMOS ELF32/i386 process with a 64 MiB
memory request, rather than calling `fork()` on Navigator's 384 MiB process for
certain requests. Existing asynchronous IPC, request cancellation, child
reaping, and 5-second worker reuse are retained.

## Implementation

- `nav_async_begin_post()` attempts `jtmos_spawn_pipes("navnetd.bin", fds)`
  **only** for anonymous `https://` GET requests without `@` in the URL and
  only while Navigator's cookie jar is empty. On spawn failure, it uses the
  existing fork/pipe path. POST, cookies, authenticated pages, plain HTTP and
  `file:///` retain the old fork protocol.
- A new shared `navigator/nav_worker_ipc.h` defines the existing fixed-size
  request/response frame for both the legacy worker and the standalone helper.
  It contains no process-local pointers. Parent retains the original bounded
  response-header/body/cookie-delta validation.
- `navnetd.bin` rejects all POST and non-HTTPS requests; it does not load
  Navigator's cookie jar. It executes HTTP(S) via the existing JTMOS TCP/TLS
  library and can serve consecutive GET requests over the stdin/stdout pipe.
  It sends response cookie deltas to the parent; after the parent's jar changes,
  the isolated worker is not reused.
- `navnetd.bin` is an explicit release application in `libc/apps/Makefile` and
  is staged with `navigator.bin` under `network.sqa` when the full install-image
  build is available. For updating an installed system without rebuilding all
  other applications, use the included standalone `NAVIGATOR-UPDATE.sqa`.

## Validation done in this environment

- `make clean` — passed before any release build.
- `make -C libc/apps -f navigator.mak -j4 navigator.bin` — ELF32 linked.
- `make -C libc/apps -f navnetd.mak navnetd.bin` — ELF32 linked.
- `tools/check_navnetd_v72294.py` — PASS, 64 framed HTTPS GETs against a
  stand-in network implementation in one helper process, clean EOF, POST and
  HTTP rejection; source guard assertions.
- `sh tools/check_navigator_v72293.sh` — PASS, 14 HTTP scenarios and prior
  IPC, CSS, Download Manager and event-loop regressions.
- `sqarc --compare-member` — embedded navigator.bin/navnetd.bin match builds.
- NZIP2 `.sqa.nz` decompresses byte-identically to `.sqa`.
- SHA256 and bzip2 archive checks performed separately.

## Remaining limitations / required JTMOS test

- The whole OS rebuild `make KERNEL_RING3_TEST=1 -j2` could not complete:
  NASM is missing (`nasm -f elf core/asm/aslib.asm`). Neither a bootable kernel
  nor a complete `network.sqa`/`utilities.iso` was regenerated here.
- No QEMU/ThinkPad browser page-load test has been performed. This is a
  source + binary application test release, not a verified system boot release.
- This does not enable general POSIX pthread use for Navigator's network
  stack. It uses an independent process with nonblocking IPC; no CPU-bound
  render-thread parallelism or DOM/JS/Google/YLE fix is claimed.
- For cookie-heavy pages and session activity, Navigator still uses the
  previous larger fork worker; the performance improvement is limited to
  eligible anonymous HTTPS requests and is yet to be measured on JTMOS.
- `navnetd.bin` must be installed together with this `navigator.bin`; failing
  to install it is expected to trigger the legacy fork fallback.

## Test on JTMOS

Extract `NAVIGATOR-UPDATE.sqa` on the test system and place `navigator.bin`
and `navnetd.bin` in `/bin` together. Then run:

```
navigator.bin https://example.org/
navigator.bin https://yle.fi/
navigator.bin https://mtvuutiset.fi/
```

Review `/var/log/navigator.log` for `navnetd spawned pid=` and `worker
reused pid=` (or `navnetd unavailable`), and compare load times / memory
against v72.293 with the same QEMU or T400 configuration.

To build all sources on a development machine with NASM available:

```
make clean
make KERNEL_RING3_TEST=1 -j$(nproc)
```

Three source archives (`KERNEL32`, `LIBC`, `APPS`) should be extracted in one
parent directory, producing a single `JTMOS-v72.294` project tree.
