# GraOS: syväanalyysi, korjaussuunnitelma ja toteutus v72.110

25.10.2026. Lähtöaineisto on keskustelussa toimitettu täysi JTMOS v72.109
-release. ZIPin SHA-256 on
`b0dce424556f80022a8dff8a8c6bee0a8940e3c6944de67d0d775fd7a2429c88`.
Toteutus julkaistaan kokonaisena v72.110-pakettina.

GraOSin merkittävimmät tässä tarkastuksessa vahvistuneet ongelmat olivat
poikkeuspoluissa: vähämuistitilan framebufferin rekisteröinnissä,
epäkelvon asiakasviestin käsittelyssä ja ikkunatunnuksen uudelleenkäytössä.
Tavallinen käynnistys voi näyttää toimivalta näiden vikojen ollessa mukana.
Siksi korjauksissa painotettiin todellisen 32-bittisen koodin ajotestejä ja
virhetilojen tarkoituksellista tuottamista.

**Arkkitehtuuri ja säilytettävät ominaisuudet**

Tarkastelu seurasi polkuja `guiStart`/`guiStartup` -> `guiLoop` ->
`guiPointer`/`windowMoving`/`guiServer` -> ikkunat ja widgetit ->
`windowDraw`/`guiDesktopDraw` -> `guiArrow`/`guiUpdate`. Lisäksi tarkastettiin
aktiivinen `libc/libc/modern/graos_compat.c`-asiakasrajapinta ja GraOSin
rakennus- ja paketointitarkistukset. GraOSin lopullisessa ohjelmassa on 36
yksityisen rakenteen ABI-tunnistetta sisältävää moduulia.

| Osa | Vastuu ja arvio |
|---|---|
| Käynnistys | Ensimmäinen työpöytä piirretään ennen palvelimen rekisteröintiä. Sekarakenteiset objektit estävä ABI-tarkistus on tarpeellinen ja säilytettiin. |
| Syöte | Suhteellinen kernelin liikejono ja erillinen osoittimen rajaus korjaavat vanhan näkymättömän seinän. Kaappauksessa on jo ikkunan sukupolven tarkistus. |
| Shell | Hiiren Start avaa perinteisen valikon; Windows/Ctrl+Esc avaa Overview'n. Valikkopinta on välimuistissa ja saman rivin kursoriliike kulkee kevyen esityspolun kautta. |
| IPC | Kiinteä GUICMD-viesti on 432 tavua. Viestejä käsiteltiin enintään kahdeksan kierroksessa, mutta käsittelyajalle ei ollut budjettia. |
| Ikkunat | Palvelin omistaa rakenteet ja sovellus omistaa oman ikkunansa. Ikkuna- ja tapahtumataulukot ovat rajattuja; tunnukset kierrätetään. |
| Piirto | Taustalla on ikkunoiden välimuisti ja vahinkoalueet; kursori esitetään erillisenä kerroksena. Näitä toimivia polkuja ei kirjoitettu uudelleen. |
| Resurssit | BMP-lataus tarvitsee omat kokorajat ja tiedoston pituuden tarkistuksen. Pelkkä onnistunut malloc ei osoita laskettua kokoa oikeaksi. |

**Vahvistetut viat ja niiden merkitys**

1. **Vakava: rivipuskuria käytettiin kokonaisen framebufferin tallennukseen.**
   `guiServer.c`, `GRAOS_GSID_ADDFRAMEBUFFER`: kun suuren kopion varaus
   epäonnistuu, `fb_direct=1` tarkoittaa vain yhden rivin kokoista puskuria.
   Seuraavan samankokoisen pinnan rekisteröinti vertasi vanhoja leveyttä ja
   korkeutta, mutta ei `fb_direct`-tilaa. Siten koko pinnan kopio saattoi
   kohdistua rivipuskuriin. Esimerkiksi 20x10-pinta tarvitsee 800 tavua,
   rivipuskuri vain 80 tavua. Virhe voi rikkoa GraOSin keon ilman välitöntä
   kaatumista. Uudelleenkäyttö sallitaan nyt vain aidolle täydelle kopiolle.

2. **Vakava: BMP:n kokolaskenta saattoi ylivuotaa ennen varausta.**
   `guiBmp.c`, `guiBmpLoad32`: leveys*4 ja leveys*korkeus*4 laskettiin
   32-bittisessä osoiteavaruudessa ilman ylärajoja. Myös negatiivisen
   korkeuden INT_MIN-tapaus oli ongelmallinen. Nyt etumerkki puretaan
   turvallisesti, mitat rajataan 4096 pikseliin/akseli ja dekoodattu data
   enintään 64 MiB:iin. DIB-otsikon, pikselialun, kertolaskujen, seek-rajan
   ja tiedoston todellisen pituuden on täsmättävä ennen varausta. Tämä on
   lataajan yläraja; se ei lupaa, että 64 MiB:n varaus onnistuu.

3. **Korkea: asiakasrajapinnan koordinaattitarkistus saattoi kiertyä.**
   Label-, textbox- ja bitmap-komennoissa tarkistettiin `x+width` ja
   `y+height`. Suuret positiiviset arvot voivat ylittää etumerkillisen intin
   rajan. Nyt ensin todetaan alkupiste ikkunan sisäiseksi ja sitten verrataan
   kokoa erotukseen `window_width-x`. Painikkeiden loppupisteet tarkistetaan
   ennen koon laskemista. Framebufferin alkupisteet ja asiakasosoitteen
   loppu rajataan myös ennen piirtoa/kopiointia.

4. **Korkea: ikkunan omistajuudessa oli tarpeettoman avoin poikkeus.**
   Sulkeminen, minimointi, palautus, päivitys ja painikkeen luonti sallittiin
   myös, kun `w->pid==0`. Tällöin ulkoinen asiakas saattoi kohdistaa komennon
   työpöydän omistamaan ikkunaan. Nyt näihin komentoihin tarvitaan täsmäävä
   omistaja-PID. Työpöydän sisäiset kutsut toimivat suoraan kuten ennen.
   Tämä rajaa nämä ikkunakomennot; koko IPC-järjestelmää ei muutettu uudeksi
   käyttöoikeusjärjestelmäksi. Esimerkiksi globaalit shell-komennot säilyvät.

5. **Keskitaso: viestikuoren ja merkkijonon raja ei ollut yhtenäinen.**
   Palvelin hyväksyi myös liian suuren ilmoitetun viestipituuden, ja kaikkien
   merkkijonokomentojen edellä ei asetettu päätettä. Resurssihakupolku käyttää
   merkkijonofunktioita, joten pääte kuuluu sisääntulorajalle. Nyt kuori on
   täsmälleen 432 tavua ja str-kentän viimeinen tavu nollataan. PID 0:n
   erityistapaukseksi jää kernelin asynkroninen exception-alert. Aktiivinen
   moderni asiakas tarkistaa myös vastausten ja asynkronisten ilmoitusten
   pituuden ennen niiden tulkintaa. Nykyinen wire-ABI säilyy.

6. **Keskitaso: ikkunan sulkeminen jätti tunnukseen sidottua shell-tilaa.**
   Alt+Tab-valinta ja viimeisen klikkauksen kohde käyttävät ikkunatunnusta.
   Suljetun paikan uusi ikkuna ei saa periä näitä. Sulkeminen peruu nyt
   kyseiseen ikkunaan liittyvän tehtävänvaihtimen ja nollaa kaksoisklikkauksen.
   Minimointi peruu heti kyseisen ikkunan painike-/siirto-/resize-kaappauksen,
   eikä odota seuraavaa hiirinäytettä.

7. **Suorituskyky: IPC:n määräraja ei rajannut käytettyä aikaa.**
   Kahdeksan framebuffer-päivitystä voi viedä huomattavasti enemmän aikaa kuin
   kahdeksan ping-viestiä. `guiLoop` käsittelee IPC:n ennen syötettä. Pollaus
   lopetetaan nyt myös, kun kierroksen 4 ms:n yhteistyöbudjetti täyttyy.
   Jonoon jäävät viestit säilyvät seuraavaa kierrosta varten. Yksittäistä
   komentoa ei keskeytetä, joten tämä ei takaa neljän millisekunnin
   enimmäisviivettä; PIT:n tarkkuuskin vaikuttaa havaittuun aikaan.

8. **Tapahtumien eheys ja tarkistettavuus.** Peräkkäiset resize-tilat
   täyttivät 16 tapahtuman jonon, vaikka asiakas tarvitsee viimeisimmän tilan.
   Nyt vain vierekkäiset resize-tilat yhdistetään. Näppäin-, painike-, focus-
   ja close-tapahtumia ei yhdistetä eikä järjestetä uudelleen. Samassa
   ikkunassa ei myöskään hyväksytä kahta samaa painiketunnusta, koska focus
   ja tapahtuman kohde perustuvat siihen. Lisäksi GraOSin `make syntax`
   viittasi olemattomiin `jt_ttf_gui.c`- ja `jt_fonts_builtin_gui.c`-nimiin;
   se tarkistaa nyt näiden objektien todelliset fonttilähteet.

Lisätesti oikeilla asiakasohjelmilla paljasti vielä Control Panelin kapasiteettivirheen.
Sen 32 asiakaspainiketta ja kolme ikkunapainiketta ylittivät 32 paikan taulukon.
Loppupään painikkeiden luonti epäonnistui. Kapasiteetti nostettiin 40:een;
rajattu taulukko ja sen täyttymisen tarkistus säilyvät. Koska WINDOW-rakenne
muuttui, yksityinen ABI nostettiin 110:een ja kaikki 36 moduulia rakennettiin
uudelleen. ABI-vartijan on yhä hylättävä vanha/sekoitettu objekti. Julkinen
432 tavun viestimuoto ei muuttunut. Ikkunataulukon kiinteä muistinkulutus
kasvoi mitattuna 31 744 tavua (32 ikkunapaikkaa).

Julkaisun lisätarkistuksessa löytyi myös ristiriita: uusi GraOS oli rakennettu
mutta ISOsta purettu paketti ei vastannut sitä. Tarkka ulkoinen syy ei ole
osoitettu, joten sitä ei nimetä nzip- tai make-viaksi pelkän lopputuloksen
perusteella. Rakennusketju varmistaa nyt jokaisen uuden pakatun SQA:n
purkamalla sen ja vertaamalla raakasisältöön. Uusi
`tools/check_release_media.py` seuraa lopullisen ISO:n GraOS- ja boot-paketit
nykyisiin binääreihin, A-kuvaan ja raw-kerneliin sekä tarkistaa DOSBOOT-kopiot.
Se suoritetaan tavallisen täyden maken lopussa, täyden ZIPin paketoinnissa ja
uuden QEMU-testin alussa. Testi tallentaa lähtösummat ja hylkää myös median
muuttumisen ajon aikana. Näin pelkkä onnistunut käännös tai ulompien
pakettinimien tarkistus ei riitä julkaisun hyväksymiseen.

**Toteutettu kuuden kohdan suunnitelma**

| Järjestys | Toteutus | Hyväksymisehto |
|---|---|---|
| 1 | Framebufferin uudelleenkäytön ja pintaosoitteiden suojaus | Rivipolulta täydelle kopiolle siirtyminen onnistuu ilman yli menevää kopiota; varausten suojatavut säilyvät. |
| 2 | IPC-kuori, merkkijonot, geometriat ja omistajuus | Virheelliset syötteet hylätään; tavalliset asiakkaat säilyttävät toimintansa. |
| 3 | BMP-lataajan aritmetiikka ja tiedostorajat | Oikeat kuvat tuottavat oikeat pikselit; vialliset koot eivät johda varaukseen. |
| 4 | IPC-kierroksen aikabudjetti | Määrä- ja aikaraja toteutuvat, viestejä ei häviä ja tick-laskurin kierto toimii. |
| 5 | Ikkunan elinkaaren tilasiivous | Sulkeminen/minimointi ja saman paikan uudelleenkäyttö eivät jätä shell- tai kaappaustilaa. |
| 6 | Resize-jonon yhdistäminen ja regressioiden valvonta | 100 000 resize-tilaa ei syrjäytä aikaisempaa näppäintä; väliin tuleva painiketapahtuma säilyttää järjestyksen. |

Kaikki kuusi kohtaa on toteutettu. Widget-tunnusten ja kapasiteetin tarkistus
sekä rikkoutuneen syntaksitarkistuksen korjaus tukevat kohtia 2 ja 6.

**Testaus ja mitatut tulokset**

Uudet testit käyttävät oikeita GraOS-otsakkeita ja tuotantofunktioita i386
-ohjelmissa. Käyttöjärjestelmäpalvelut ovat hallittuja testikorvikkeita;
testi ei väitä ajavansa näitä poikkeuspolkuja fyysisessä T400:ssa.

- `tests/v72110_server_runtime.py`: rivipuskurista täyteen pintaan siirtyminen,
  100 uudelleenrekisteröintiä, varausrajat ja suojatavut, virhekuoret, pääte,
  geometriat, omistajuus, painiketunnukset, 100 000 resize-tilaa, kaappaus,
  minimointi, sulkeminen, tunnuksen kierrätys sekä pollauksen määrä/aika/tick-
  kierto. **PASS.** Vanha rivipuskurin uudelleenkäyttöehto palautettiin
  erilliseen testiversioon: testi hylkäsi sen odotetusti.
- `tests/v72110_resources_runtime.py`: BMP:n top-down/bottom-up, skaalaus,
  pikselit, alfa, INT_MIN, kiertyvät koot, siirtymät, katkennut tiedosto,
  10 000 virheotsaketta ja varausvirheet. Aktiivisella modernilla asiakkaalla
  kuori, protokolla, lähettäjä, magic ja kahden ikkunan asynkroniset
  ilmoitukset. **PASS.**
- Aiemmat suhteellisen hiiren, kaappauksen, shellin, ABI-vartijan, objektien
  riippuvuuksien ja kursorikerroksen testit: **PASS.** Mukana 30 000 hiiren
  läpivientiä, 10 000 saman valikkorivin liikettä ja 18 063 kursoritarkistusta.
- Busy/watchdog: 100 000 begin/end-kierrosta, tokenin kierto ja siivous,
  AddressSanitizer/UBSan: **PASS.** LeakSanitizerin /proc-tehtäväluennan
  ympäristörajoituksen vuoksi uusinnassa poistettiin vain leak-tarkistus;
  osoite- ja undefined-tarkistukset pysyivät käytössä. Alkuperäinen virhe ja
  uusinnan syy ovat lokissa.
- Julkaisumedian vartija hyväksyy yhtenäisen ketjun ja hylkää tarkoituksella
  vanhennetun GraOSin, boot-kuvan ja DOSBOOT-aliasen. **PASS.**
- Täysi `make`, viimeinen erillinen mediauudelleenpaketointi, GraOSin
  syntaksitarkistus ja 36 moduulin linkitetty ABI:
  **PASS.** Kernelin ELF/raw-, 64 KiB:n reservi-, päällekkäisyys- ja
  pinorajojen testit sekä image-työkalun tarkistukset: **PASS.**
- PS/2 ja USB OHCI todellisella julkaistavalla kernelillä/ISOlla: **PASS.**
  Perinteinen hiiri-Start, Windows/Ctrl+Esc-Overview, kaikki neljä reunaa ja
  välitön paluuliike, kontekstivalikko, pitkä painallus sekä terminaalin
  avaaminen ja näppäimistöreitti toimivat. Erilliset labeldemo-, textboxdemo-,
  bitmapdemo- ja Control Panel -asiakkaat avataan ja suljetaan; kahden
  ensimmäisen näppäimistötoiminto tekee myös IPC-kierroksen takaisin asiakkaan
  label-päivitykseen. Control Panelin kaikki 32 asiakaspainiketta valmistuvat
  ennen sulkemista. Testi odottaa valmistumista havaituista IPC-komennoista,
  sillä kiinteä host-viive voi hitaammalla USB-ajolla sulkea ikkunan kesken
  rakentamisen. Myöhäisen luonnin hylkääminen jo suljettuun ikkunaan on oikein.

| Saman valikkorivin mittaus | PS/2 | USB OHCI |
|---|---:|---:|
| Esitetyt kursoripäivitykset | 24 | 24 |
| Työpöydän uudet kompositiot | 0 | 0 |
| Uudelleen rakennettu valikkopinta | 0 | 0 |

Tämä vahvistaa aiemman kevyen valikkopolun säilymisen näissä testeissä.
Se ei ole T400:n fyysisen piirtonopeuden FPS-mittaus. Kernel on edelleen
955 004 tavua ja sen 1 MiB:n ikkunaan jää 93 572 tavua; muistiosoitteita tai
linkkerin suojauksia ei kasvatettu. Yksityisen GUI-rakenteen ABI on edelleen
110 ja suhteellisen hiirijonon versio 2.

Testatut keskeiset binäärit:

```text
kernel32.bin  1f2c89513a2e41eb64dd999e75fc4dc5e746b6c5d6ff6df7b55bbdc963945775
graos.bin     6b3afca08c9297262fb537ab825b2864a2d88c0a6abe18503c7c9be6205d2c7a
utilities.iso cfa1b065917106e60acfa897ccc494afb8404c4c9a4f70c39bbbd078c6e341f9
```

Lähteet ja ajolokit ovat kokonaisessa paketissa hakemistossa
`release/qa/v72.110/`. ISO -> pakattu SQA -> GraOS/boot-kuva -> NZIP -> raw
-ketju tarkistetaan oikeista tavuista. Lopullisen ZIPin sisäinen manifesti,
symboliset linkit, nimet ja media-aliaset tarkistetaan erikseen.

**Jatkokehityshavainnot ja tämän julkaisun rajat**

Kaikkien tapahtumalajien yhtäaikainen tulva voi yhä täyttää rajallisen jonon.
Resize-yhdistäminen ei ole täydellinen häviötön tapahtumaprotokolla. Nykyinen
jono säilyttää vanhan ylivuotokäytöksen muulle liikenteelle.

Prosessin identiteetti on yhä pääosin PID. Kuolleiden asiakkaiden siivous
pollaa elossaoloa 250 ms:n välein; nopean PID-kierrätyksen täydellinen
erottaminen tarvitsee kernelin prosessisukupolven. Tämän julkaisun
ikkunatunnuksen siivous ei ratkaise sitä. Myöskään synkronisissa julkisissa
pyynnöissä ei ole uutta request-ID:tä: viivästyneen vastauksen erottaminen
seuraavasta pyynnöstä on erillinen protokollan kehityskohde.

Fonttimoottori on TrueType-pohjainen, mutta joissakin widgeteissä on edelleen
8 pikselin tekstiasetteluoletuksia. Muuttuvan fonttikoon täydellinen yhtenäinen
layout ja tekstin saavutettavuus tarvitsevat erilliset käyttöliittymätestit.

T400:n fyysinen Ethernet TX/RX, TrackPoint-tuntuma ja VESA-esityksen ajoitus
ovat edelleen laitehyväksynnän kohteita. V72.108:n ICH9E/PHY/Kumeran-muutokset
ovat mukana, mutta tämän GraOS-tarkastuksen perusteella ei julisteta T400:n
verkkoliikennettä toimivaksi. Muiden vanhojen kernelmoduulien varoitukset
säilyvät; koko historiallisen puun varoituksettomuutta ei luvata.

Käyttöönotto: pura täysi v72.110 uuteen hakemistoon ja aja `make`. Päivitä
käytetty boot32pm/DOSBOOT-kokonaisuus ja utilities.iso samasta releasesta.
Pelkkä GraOS-binäärin tai kernel32.bin:n vaihto ei päivitä kaikkia pakattuja
käynnistys- ja asennuspolkuja.
