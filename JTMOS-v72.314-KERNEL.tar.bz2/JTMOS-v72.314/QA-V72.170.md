# QA v72.170

- Native JTMOS gcc -m32/ld ELF32 Navigator build: PASS.
- Host source build with AddressSanitizer + UndefinedBehaviorSanitizer: PASS.
- Original RKO source (2,646 nodes) through Lexbor HTML5: parsed, 61 CSS
  selector rules, 0 CSS truncation, 5,644 paint items at 1050px: PASS.
- Existing v72.168 alignment, positioning, DIV, HTML/CSS and page lifecycle
  tests with and without Lexbor: PASS.
- v72.170 CSS background URL/position/repeat/paint pixel assertions: 14 PASS.
- Float percentage three-column layout widths (RKO at 1050px): 224/472/228px: PASS.
- Test instructions: `sh tests/run-v72170-rko.sh /tmp/nav170`

Limitations: no runtime acceptance test on real hardware in this environment.
This is not a claim of full CSS2/CSS3, full JS compatibility or pixel-perfect
rendering of Remix.Kwed.Org.
