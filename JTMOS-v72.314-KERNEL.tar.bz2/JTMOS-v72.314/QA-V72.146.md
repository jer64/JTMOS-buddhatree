# JTMOS v72.146 – T400 82567LM: QA

Päiväys 26.10.2026. Pohjana on kokonainen v72.145-lähdepaketti (SHA-256 `633082c8…96e122`).

| Tarkistus | Tulos ja todellinen kattavuus |
|---|---|
| Natiivi koonti | PASS. Kernel 961 180 tavua, 1 MiB:n ikkunassa vapaana 87 396 tavua (raja 65 536). |
| Median identiteetti, mediavahti ja Navigatorin preflight | PASS. |
| ICH9E-ajurimalli, ASan/UBSan | PASS. GCR 0x1234003F → 0xFFFFFFC0, RXDCTL=0x01010000, tilastolaskurit summautuvat. V72.145:n R2/COLD-tarkistukset sekä V72.108- ja V72.111-mallit menevät läpi. |
| Mutaatiot | 4/4 hylätään: vanha RXDCTL, vanha GCR, COLD=64 ja R2-korjauksen poisto. |
| QEMU-verkko, NE2000 | PASS, 10/10 (TCP, UDP, connect, listen/accept). |

## Rajaus

Muutokset tehtiin käyttäjän T400-raportin perusteella. QEMU ei emuloi ICH9 LAN:ia, joten se, korjaako RXDCTL- tai GCR-muutos T400:n RX- tai TX-liikenteen, varmistuu vasta seuraavasta rauta-ajosta. Uusi `inet hw` näyttää MAC:n tilastot ja automaattisen diagnoosin, jotka erottavat PHY/Kumeran-puolen DMA-puolesta. Ohje on tiedostossa `T400-ICH9E-RAPORTTI-V72.146.md`.

## Evidenssi

`release/qa/v72.146/`: alkuperäinen T400-raportti, ajurimallin ja mutaatioiden lokit, QEMU-tulos ja sarjaloki, mediatarkistus, provenance ja koontiloki.
