# JTMOS v72.158 – QA

Päiväys 27.10.2026. Pohjana on kokonainen v72.157-lähdepaketti (SHA-256 `3daf39d4…fe82b7b`).

| Tarkistus | Tulos |
|---|---|
| Natiivi koonti, media ja ktls.kmo | PASS |
| Ctrl+C: ping SMSH:ssa | PASS 0,2 s (v72.157 ja v72.158) |
| Ctrl+C: ping SQSH:ssa (SMSH → sqsh) | v72.157 FAIL; v72.158 PASS 0,2 s, SQSH jatkaa |
| nutget HTTPS: close_notify ja FIN / close_notify ja RST | PASS, 23 400 tavua tallennettu |
| nutget HTTPS: RST ilman close_notifyä | PASS: ei tallennettu, aikakatkaisu 60 s:n jälkeen |
| QEMU-verkko, DHCP ja kiinteä osoite | PASS, 10/10 |
| ICH9E-ajurimallit | PASS |

Rajaus: GraOS-ikkunan Ctrl+C-reitti on testattu koodipolkuna (sama `OutputTerminalKeyboardBuffer` → päätteen lippu → delegoitu odotus), ei QEMU:n GraOS-näytöltä. T400:n RST-ajoitus ei toistu QEMU:n slirpissä.
