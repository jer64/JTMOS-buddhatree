# V72.236 – varmennus

Lokit ovat hakemistossa `release/qa/v72.236/`. Kaikki ajot tehtiin lopullisilla
binääreillä ja lähteillä.

| Ajo | Tulos |
|---|---|
| `tests/run-v72236.py`: hakukoneen yksikkötesti (`tests/v72236_search_engine.c`). DuckDuckGo-oletus, `g`/`d`/`?`, käyttäjän todellinen Google-osoite (`hl=fi&source=hp…&gbv=1`) tunnistetaan tarkistussivuksi ja ohjataan `…?q=jtmos`:iin, ä/ö-koodaus, google.evil.com hylätään, asetustiedosto (google / Mojeek / DDG, http- ja rikkinäiset rivit hylätään) | PASS |
| Sama ajo: Navigatorin UI-integraatio (`v72232_merged_ui`). Osoiterivin haku DuckDuckGolla, Google valittuna → tarkistussivu → DuckDuckGo, ja edellinen sivu säilyy välin, `g`-haku ei odota Googlea, Googlen etusivun hakukenttä + Enter → DuckDuckGo. Lisäksi Google-lomake, URL- ja fork-testit | PASS |
| V72.233:n host-portti (Navigator, Save As, evästeet, GraOS) | PASS |
| V72.235:n osoiterivi- ja historiatestit (ASan/UBSan) | PASS |
| QEMU-tallennustesti V72.236:n medialla (käynnistys, ram:, kaikki paketit) | 15/15 PASS |

Testifixture `tests/v72236_pages/google-botguard.html` on käyttäjän tallentama
sivu, josta tarkistus-skriptit on poistettu.

**Ei ajettu:** oikeaa hakua DuckDuckGoon. Tämän ympäristön verkko ei pääse
duckduckgo.comiin, ja QEMU-testeissä ei ole internetiä. DuckDuckGo voi
joskus näyttää automaattisille asiakkaille oman tarkistuksensa. Jos se
tapahtuu, `/cfg/navigator-search.txt`:hen voi vaihtaa toisen hakukoneen.
