# JTMOS v72.196 QA / pending-request audit

| Check | Result |
|---|---|
| Navigator native ELF32/i686 compile/link | PASS |
| Download Manager native ELF32/i686 compile/link | PASS |
| Real host HTTP GET cache integration (8 policies) | PASS (14 network requests) |
| Multi-process persistence, expiry, checksum corruption, sensitive URLs, clear, root split | PASS |
| Iterative stylesheet collector 6000-node DOM | PASS |
| Navigator key scrolling / Ctrl+J / Download Manager from v72.195 | RETAINED (not rerun on device) |
| HOME/USER root creation, SMSH/SQSH home startup | RETAINED (kernel not rebuilt here) |
| MTV Uutiset static Reader | RETAINED (live website unverified) |
| Yle.fi exception #14 fixed on JTMOS hardware | UNVERIFIED |
| Saved Yle full 256KiB stack host suite | TIMED OUT (no PASS claim) |
| TCP download speed >=600 KiB/s on T400 | UNVERIFIED |
| Full kernel, DOSBOOT, GraOS install media rebuild | NOT PERFORMED |

This is a FULL-SOURCE-UNBUILT release. The new Navigator and Download Manager
binaries have been linked, but the complete kernel/install images are inherited.
The on-disk cache is best-effort. Cache-Control with no-store/private/no-cache,
responses involving cookies, personalized Vary, and non-whitelisted URL
parameters will intentionally trigger re-downloads.

## Open items carried forward

- Yle.fi page fault diagnosis needs /var/log/crash.log with CR2/ERR/EIP and
  real reproducibility test; iterative stylesheet traversal is a safeguard,
  not evidence of a complete fix.
- Full CSS/font/color edge cases and dynamic JavaScript site behavior are
  not fully implemented or certified. MTV playback remains unsupported.
- Firefox shortcut parity is partial; a full key map/gesture audit is pending.
- HTTP conditional requests (ETag, Last-Modified/304), >512 KiB disk entries,
  cache eviction policy beyond bounded hash slots, persistent offline pages,
  download resumability are future improvements.
- T400 real-world 5x network throughput target still needs benchmarks.
