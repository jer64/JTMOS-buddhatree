# JTMOS v72.98 — QA report / Ethernet stage 4

| Test | Status |
|---|---|
| Complete v72.97 source tree preserved | PASS |
| v72.98 version marker | PASS |
| Real JTMOS -m32 GCC build: ich9e.o | PASS |
| Real JTMOS -m32 GCC build: ethdev.o | PASS |
| Real JTMOS -m32 GCC build: networkapp.o | PASS |
| Fake-MMIO link up/down and direct-send gating | PASS |
| Fake-MMIO watchdog: 2s threshold, DD counting, 32-bit tick overflow | PASS |
| 100,000 synthetic TX descriptor submissions/reclamations | PASS |
| 50 forced DMA quiesce failures preserve descriptors | PASS |
| DMA quiesce acknowledgment permits safe ring reset | PASS |
| v72.97 receive/ring/ARP/DHCP fake-MMIO regression | PASS |
| Existing Ethernet carrier/DHCP recovery regression | PASS |
| Existing DHCP/ARP/ICMP, HTTP owner-thread structural regression | PASS |
| DHCP DISCOVER/OFFER/REQUEST/ACK/NAK codec host test | PASS |
| Complete kernel32.bin + DOSBOOT rebuild | **NOT BUILT** (NASM unavailable) |
| Physical ThinkPad T400 test incl. 1,000 pings and 24h soak | **NOT RUN** |
| Completed physical TX/RX DMA and DHCP operation | **UNVERIFIED** |
| Full ZIP integrity and SHA256 | PASS after packaging |

The new tests use compiled C from the production driver and injected fake MMIO; no simulator can claim real PCI DMA operation.
