# JTMOS v72.92 QA report

| Check | Result |
|---|---|
| GraOS full 32-bit compile + static ELF32 link | PASS |
| 33 actual cursor frame/time/damage runtime assertions | PASS |
| ASan and UBSan used for host cursor runtime checks | PASS |
| Prior window-busy 27 host assertions | PASS |
| Prior v72.91 busy IPC / ownership integration | PASS |
| Prior v70.70 hourglass source regression | PASS |
| T400 mouse recovery source regression | PASS |
| SQA graos.bin byte-for-byte member match | PASS |
| SQA preserves calendar and calremind | PASS |
| VESA/EGA terminal hourglass absent | PASS (source unchanged) |
| Kernel32 and DOSBOOT rebuild | NOT PERFORMED (NASM unavailable) |
| On-device live GraOS rendering, T400 | NOT PERFORMED |

The host tests compile source functions against stubs for the GPU/present ABI.
They do not prove correctness on physical hardware.
