# Navigator: vaihe 1 — UTF-8-dekooderi (v72.202)

Tässä julkaisussa toteutetaan pyydetyn kahdeksanvaiheisen selainrungon
ensimmäinen vaihe nykyiseen Navigatoriin. DOM, CSS ja GraOS-piirto säilyvät
käytössä. Niiden käyttämä tekstidekooderi on nyt yhteinen, ja tuleva HTTP-
rajapinta voi käyttää samaa dekooderia myös pienissä verkkopuskureissa.
Vaiheiden 2–8 uudistuksia ei toteuteta tämän päivityksen osana.

## Tiedostot ja kytkentä

- `libc/apps/navigator/nav_utf8.h`: itsenäinen C99-dekooderi; vain stddef.h ja
  stdint.h tarvitaan. Header-only-toteutus ei edellytä DOM-, fontti-, IO- tai
  GraOS-kirjaston linkittämistä. Ei mallocia, rekursiota eikä globaalia tilaa.
- `nav_dom.c`: entinen `nav_utf8_next()` käyttää uutta dekooderia. Näin
  asettelu, SVG-teksti, valinta, lomakkeet ja Navigatorin GraOS-tekstipiirto
  saavat saman virheenkäsittelyn olemassa olevan rajapinnan kautta.
- `navigator_html.c`: myös plain text ja vanha HTML-tekstinäkymä käyttävät
  yhteistä purkua. Aiempi vain C3-alkuisia ääkkösiä käsittelevä haara poistui.
- `nav_html5.c`: varajäsentimen 1024 tavun tekstipalat säilyttävät myös
  script/style-sisällön UTF-8-merkit kokonaisina.
- `libc/apps/navigator/examples/utf8_decode.c`: ensimmäinen ajettava C-esimerkki.

DOM:n merkkijonot säilyvät UTF-8-muodossa. Koko dokumentista ei tehdä neljä
tavua per merkki vievää ylimääräistä kopiota. Tämän vaiheen uusi streaming-
rajapinta on valmis vaiheelle 2; nykyisen HTTP-työntekijän vastaanottopolkua
ei tässä muuteta inkrementaaliseksi HTML-jäsentimeksi.

## Tavujen purkaminen

| Merkki | UTF-8-tavut | Unicode-skalaari |
| --- | --- | --- |
| ä | C3 A4 | U+00E4 |
| ö | C3 B6 | U+00F6 |
| å | C3 A5 | U+00E5 |
| Ä / Ö / Å | C3 84 / C3 96 / C3 85 | U+00C4 / U+00D6 / U+00C5 |
| € | E2 82 AC | U+20AC |
| 😀 | F0 9F 98 80 | U+1F600 |

Aloitustavu määrää, tarvitaanko yksi, kaksi vai kolme jatkotavua. Kukin
jatkotavu lisää kuusi bittiä koodipisteeseen. E0/ED/F0/F4-aloitusten toisen
tavun rajoitukset estävät ylipitkät esitykset, surrogaatit sekä U+10FFFF:n
ylittävät arvot. Nämä virheelliset esitykset eivät koskaan päädy DOM:n tai
fontin käsiteltäviksi kelvollisina merkkeinä.

Algoritmi ja virheellisten jonojen käsittely perustuvat
[WHATWG Encoding Standardin UTF-8-dekooderiin](https://encoding.spec.whatwg.org/#utf-8-decoder).
Esimerkiksi `E2 82 3C` tuottaa `U+FFFD U+003C`: `<` säilyy seuraavaa
jäsennysvaihetta varten. Pelkkä `E2 82` EOF:ssa tuottaa yhden korvausmerkin.

## Rajapinnan käyttö

```c
NavUtf8Decoder decoder;
NavUtf8Result result;
uint32_t cp;
size_t offset = 0;
nav_utf8_init(&decoder);

for (;;) {
    result = nav_utf8_decode(&decoder, bytes, byte_count, &offset, &cp, 1);
    if (result == NAV_UTF8_DONE) break;
    if (result != NAV_UTF8_SCALAR && result != NAV_UTF8_REPLACED) {
        /* virheellinen kutsu; tässä esimerkissä koko syöte on jo saatavilla */
        break;
    }
    /* cp on yksi Unicode-skalaari; välitä se parserille tai fontille. */
}
```

| Paluuarvo | Toiminta |
| --- | --- |
| NAV_UTF8_SCALAR | cp sisältää kelvollisen skalaarin; jatka lukemista. |
| NAV_UTF8_REPLACED | cp = U+FFFD; jatka samasta puskurista. |
| NAV_UTF8_NEED_MORE | Puskuri loppui; säilytä dekooderin tila ja odota lisää. |
| NAV_UTF8_DONE | Lopullinen puskuri ja mahdollinen vajaa merkki on käsitelty. |
| NAV_UTF8_BAD_ARGUMENT | Korjaa kutsun osoittimet tai pituus; tila säilyy. |

Verkkosyötteessä säilytä yksi `NavUtf8Decoder` vastausta kohti. Aseta
`offset=0` kunkin uuden puskurin alussa ja `final=0` niin kauan kuin lisää
tavuja voi tulla. Lopussa käytä `final=1`; myös tyhjä EOF-kutsu on sallittu:
`nav_utf8_decode(&decoder, NULL, 0, &offset, &cp, 1)`, missä offset on 0.
Kutsu toistuvasti SCALAR/REPLACED-paluuarvon jälkeen, myös viimeisen tavun
kuluttamisen jälkeen, jotta EOF:n katkennut merkki tulee käsitellyksi.

Virheellinen jatkotavu jätetään seuraavalle kutsulle. Siksi REPLACED voi
palautua kuluttamatta yhtään tavua tästä puskurista, jos merkin alku tuli
edellisessä puskurissa. Älä kasvata offsetia itse virheen jälkeen. Uuden
dokumentin alussa alusta tila uudelleen; rinnakkaiset vastaukset tarvitsevat
omat tilansa.

Dekooderi säilyttää U+0000:n ja U+FEFF:n. HTML:n NUL-korvaus tehdään
nykyisessä `nav_utf8_next()`-adapterissa; BOM:n käsittely kuuluu dokumentin
syöttökerrokseen. Tämä ei ole charset-automaattitunnistin: Latin-1- ja
Windows-1252-tavuja ei pidä syöttää UTF-8:na. Unicode-normalisointi,
yhdistelmämerkkien asettelu ja emoji-fontit ovat erillisiä ominaisuuksia.
UTF-8:n onnistunut purku ei lupaa, että jokaiselle merkille on fonttiglyyfi.
GraOSin EGA-varatilassa tuetut ääkköset muunnetaan nykyisiin glyyfeihin ja
puuttuvat merkit esitetään kysymysmerkillä; vektoripolku käyttää Unicodea.

## Esimerkin kääntäminen

```sh
cd libc/apps/navigator/examples
cc -std=c99 -Wall -Wextra -Werror utf8_decode.c -o utf8_decode
./utf8_decode
```

Esimerkki tulostaa tekstin `Hyvää yötä, ÅÄÖ åäö € 😀` koodipisteet. Julkaisun
rinnalla toimitettu itsenäinen `utf8_decode.c` ja `nav_utf8.h` toimivat samassa
hakemistossa; käännöskomento on sama. JTMOSin oma Navigator kääntyy komennolla
`make -C libc/apps -f navigator.mak -j2 navigator.bin`.

## Asennus ja testaus

`libc/apps/navigator.bin` on tämän vaiheen muutoksilla uudelleen käännetty
natiivi JTMOS ELF32 -sovellus. Sen erillinen kopio on
`navigator-v72.202.bin`; asenna se nykyisen järjestelmäsi `/bin/navigator.bin`-
tiedoston tilalle sovelluksen ollessa suljettuna. Käynnistä uusi Navigator
asennuksen jälkeen. Pohjan nykyinen 512 MiB:n virtuaalimuistipyyntö säilyy;
ydin rajaa myönnetyn ikkunan koneen tuen mukaan (vanha ydin voi myöntää
256 MiB). Varaus ei tarkoita, että koko määrä varataan heti fyysisestä RAMista.

Koko lähde-ZIP sisältää v72.201-pohjan ja tämän päivityksen. Kernel ja vanhat
käynnistys-/asennusmediat ovat perittyjä, joten arkiston nimi on
FULL-SOURCE-UNBUILT. Vanha utilities.iso ei sisällä tätä uutta Navigatoria.
Koko järjestelmän uusi asennusmedia vaatii normaalin täyden käännöksen.
QEMU- tai fyysisen laitteen ajotestiä ei tehty tässä ympäristössä.

Testikomennot ja todetut tulokset: `QA-V72.202.md`. Testit kattavat myös
ääkkösten ja erikoismerkkien päätymisen samaan pikselimaalaukseen, jota
GraOSin Navigator-ikkuna käyttää.
