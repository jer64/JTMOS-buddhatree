# JTMOS v72.195 QA

| Check | Result |
|---|---|
| Native `navigator.bin` link: ELF32 i686 | PASS |
| Native `downloadmgr.bin` link: ELF32 i686 | PASS |
| Kernel SMSH home path modified source compilation | PASS (2 existing warnings) |
| HTTP/TLS socket and HTTP client source compilation | PASS |
| MTV article and homepage synthetic sanitized tests (256 KiB stack) | PASS |
| MTV malformed/mismatched host URL rejection tests | PASS |
| Yle synthetic layout/painter test | PASS |
| Basic CSS cascade and font tests | PASS |
| Real mtvuutiset.fi HTML fetch from this environment | BLOCKED (no DNS) |
| T400, QEMU navigation and downloads | NOT TESTED |
| Full kernel link, DOSBOOT rebuild and ISO media update | NOT PERFORMED (NASM missing) |
| TCP speedup >=5x | NOT VERIFIED |

This is a FULL-SOURCE-UNBUILT ZIP. It preserves source + inherited boot/kernel
binaries, rather than implying a bootable v72.195 image. The new Navigator and
Download Manager binaries are independently linked, but not yet installed into
inherited utilities media. Read RELEASE-V72.195.txt before using on hardware.
