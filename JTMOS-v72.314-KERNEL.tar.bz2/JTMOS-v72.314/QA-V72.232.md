# V72.232 – yhdistetyn julkaisun varmennus

Lähdevertailu: ei V72.230:stä puuttuvia tiedostoja V72.231:ssä.
V72.231 lisäsi kahdeksan tiedostoa ja muutti 32 tiedostoa. Uudempi kokonaisuus
säilytettiin ja asennusmedia rakennettiin yhdenmukaiseksi.

14 toiminnallista selain-/kernel-moduulia ja seitsemän kernel-/boot-artefaktia
verrattiin tavulleen uudemman lähtöpaketin sisältöön. Sovellus-/kernel-koodia
 ei muutettu yhdistämisessä; vain versiot, dokumentaatio ja host-testi päivittyivät.

## Ajetut tarkistukset

- Natiivi Navigator ja forkcap: i686/ELF32-käännös, Navigator 512 MiB.
- Molempien julkaisujen host-testit ja uusi yhdistetyn käyttöliittymän testi,
  ASan/UBSan. Mukana myös aiempien monirivisten textarea-lomakkeiden regressio.
- Neljän Yle/MTV-sivuaineiston kuusi renderöintitapausta: 24 tapausta,
  ASan/UBSan ja 256 KiB:n pino. Aineisto on 2.11.2026 haettu testikopio,
  ei tässä työssä ajettu uusi verkkoyhteensopivuustesti.
- Fork-kapasiteettitesti läpi sekä pääajossa että kolmessa erillisessä ajossa
  testin host-exit/reap-ajoituskilvan korjauksen jälkeen.
- Asennuspakettien inventaario: 132 ohjelmaa, kukin yhdessä paketissa.
- Selaimen tavut puretusta network.sqa:sta vastaavat uutta binääriä.
- forkcap.bin:n tavut puretusta tests.sqa:sta vastaavat uutta binääriä.
- boot.sqa:n jtm32.img vastaa mukana olevaa V72.231-kuvaa.
- GraOS-paketin kopiot ja kaikki ISO-/NZIP-peilit vastaavat toisiaan.

Tarkat lokit, syötepakettien tarkistussummat ja mediaidentiteetit ovat
hakemistossa `release/qa/v72.232/`. Host-rajat korvaavat verkon ja GraOS-näytön.

Ytimen ja BIOS-/FreeDOS-käynnistimen binäärejä ei rakennettu uudelleen.
Ne ovat V72.231:stä. Ei uutta QEMU-/T400-käynnistystä tai JTMOS TCP/TLS
-päästä päähän -testiä. Paketin purun, manifestin ja symbolisten linkkien
varmennus tehdään valmiista ZIPistä erikseen.
