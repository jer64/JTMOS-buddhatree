# JTMOS v72.248 — JTMFS Atomic Replace & Recovery

## Scope

This release extends the v72.247 checksum-protected, one-sector atomic
cross-directory move journal to replacement of an **existing regular file**.
The operation works for source and target in the **same JTMFS V4 directory**
or in **two directories on one V4 volume**. The journal stores the old source
tombstone, new destination entry, and the displaced destination's original
entry as one checksum-protected `JREP` record. New target data/FAT are
flushed before publication. Both namespace entries are published before the
obsolete target FAT chain may be freed. On power loss during metadata
publication, restart replay applies both entries idempotently.

Calls from `jtmfs_RenameFile()` route an existing regular-file destination
into the new `JtmfsDbAtomicReplace()` path under the volume mutation lock;
nonexistent destinations still take the v72.247 move path. The existing
`jtmfs_atomic_replace()` staging API (used by file-copy, condense and POSIX
write replacement) now also uses the single-sector JREP transaction on V4,
while retaining its historical target timestamp semantics. Inline staging
contents are repacked safely or expanded before the swap.

## On-disk compatibility — IMPORTANT

**BACK UP TEST VOLUMES BEFORE USE.** Before emitting a JREP record, both V4
journal superblocks are durably upgraded from v1/v2 to **v3**, and feature
`JTMFS_DB_FEATURE_ATOMIC_REPLACE` is set. A v72.247 or older kernel cannot
read that format and must not be used to write the volume. Do not bypass
write-frozen/downgrade checks. V3 filesystems do not gain atomic replacement.

`JTMFS_FILE_ENTRY` is still 72 bytes. A JREP record is smaller than a single
512-byte journal sector and does not change geometry. Ordinary redo and
v72.247 JMOV move records remain readable.

## Failure model and limitations

- Atomic namespace replacement is **per file**, not for an entire wildcard
  batch. One file is either unmodified (source + old target) or committed
  (source tombstone + new target) after restart recovery.
- The old target chain is never freed until the namespace journal and super
  are durable. **A crash during subsequent FAT reclamation may leave orphan
  blocks.** The reboot replay never re-frees that chain because its FAT links
  may already have been partly released. Run **offline `jtmfsck` after a
  backup** if orphan blocks are reported. Full resumable FAT reclamation is
  **not implemented**.
- Regular files only; directory replacement, cross-volume rename, hardlinks,
  POSIX open-unlinked inode lifetime and all possible live-FD semantics are
  not implemented. In particular, do not replace a file held open by another
  process until open-handle lifetime handling is strengthened.
- Recovery testing uses simulated isolated images and actual production JTMFS
  journaling C routines; it has not yet been booted on T400/QEMU with a real
  kernel and real AHCI flush behavior.
- Existing bootable images/ISO and most inherited binaries in this ZIP were
  built **before v72.248**. Two kernel C objects were rebuilt for i386 only;
  `nasm` was not available to rebuild the complete kernel/media here.

## Verify

```sh
python3 tests/v72248_atomic_replace_reboot_host.py
python3 tests/v72247_atomic_move_reboot_host.py
python3 tests/v72246_crash_recovery_host.py
python3 tests/v72245_dirdb_failclosed_host.py
python3 tests/v72245_jtmfs_commit_fault_host.py
python3 tests/v72245_jtmfs_watchdog_host.py
python3 tests/v72241_dirdb_writeback_host.py
```

The V4 staging-API integration is compile-checked, but has not yet been
exercised end-to-end on a booted production kernel.

The v72.248 crash harness runs six combinations of same/cross-directory
replacement and 3 disk durability models, with failure at every write/flush
boundary, extra interruptions during journal replay, and mirrored-super
corruption. It verifies namespace alternatives, FAT ownership, replay
idempotence, and the superblock v3 guard. All disk images are temporary.
