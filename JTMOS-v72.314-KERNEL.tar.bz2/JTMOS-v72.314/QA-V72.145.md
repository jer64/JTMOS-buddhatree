# JTMOS v72.145 – T400-verkko, JNet/uIP ja järjestelmäkutsut: QA

Päiväys 26.10.2026. Pohjana on kokonainen v72.144-lähdepaketti (SHA-256 `794ecff0…7f17de`). Julkaisu sisältää lähteet, natiivibinäärit, käynnistysmediat ja DOSBOOT-hakemiston.

## Lopputulos

| Tarkistus | Tulos ja todellinen kattavuus |
|---|---|
| Natiivi koonti | PASS. `make BOOT_DISPLAY=vesa BOOT_NOGUI=0`. Kernel 959 708 tavua, 1 MiB:n ikkunassa vapaana 88 868 tavua (raja 65 536). Ytimen BSS pieneni noin 11 KiB, koska UDP-jonot ovat nyt keossa. |
| Median identiteetti ja käynnistys | PASS. `check_release_media.py`, v72.110-mediavahti ja Navigatorin lataajan preflight. |
| QEMU-verkko, NE2000, v72.145 | PASS, 10/10. Suljetun portin `connect()` palauttaa ECONNREFUSED. Ei-blokkaava connect palauttaa EINPROGRESS, minkä jälkeen `SO_ERROR` on 0 tai 111. UDP-kaiku tulee oikeasta lähdeosoitteesta ja 4 datagrammin purske saapuu järjestyksessä. 1 MiB TCP-kaiku meni läpi ehjänä (noin 850 KiB/s), samoin 4 rinnakkaista virtaa, FIN → 0 ja listen/accept isännältä. |
| Sama testi v72.144:llä | 5/7: `connect()` suljettuun porttiin onnistui virheellisesti ja UDP:stä tuli EOPNOTSUPP. Tulos on evidenssinä. |
| Navigatorin QEMU-regressio, PS/2 | PASS, 14/14. Navigator on linkitetty uudelleen uudella libc:llä, ja HTTP-lataus, F9, ankkurit, historia ja 100 000 kohteen sivu toimivat. |
| ICH9E-ajurimalli, ASan/UBSan | PASS. R2-PHY:llä rekisterit 29/30 kirjoitetaan, R1:llä ei; COLD=63 ja CT=15. Koko V72.111-malli on mukana: 100 000 TX-kuittausta, RX, kaapelin irrotus ja injektoidut virhepolut. |
| Mutaatiot | Molemmat hylätään: ilman R2-kirjoituksia ja COLD=64. |
| Aiemmat verkkotestit | PASS: DHCP/ping/HTTP, DHCP-palautus, BSD-socket-yhteensopivuus, V72.108-ajurimalli, verkkoaliakset, automaattinen uudelleenkäynnistys ja isännän verkkotesti. Vanhoihin versionumeroihin sidotut testit epäonnistuvat samalla tavalla sekä v72.144:llä että v72.145:llä. |
| Navigatorin isäntätestit | PASS: piirtoindeksi (68 147 tarkistusta) ja tiedostolataukset. |

## Rajaus

QEMU:ssa ei ole ICH9 LAN -mallia. Koko verkkopino ajettiin NE2000:lla. Intel 82567LM -ajurin muutokset on testattu vain mallilla, joka suorittaa tuotantokoodin mutta ei todista PCIe-DMA:ta, PHY:n sähköistä linkkiä eikä DHCP:tä T400:lla. Fyysistä ThinkPad T400:aa, eMachines EL1352:ta tai ASUS R558U:ta ei testattu. Rautatestin ohje on tiedostossa `T400-VERKKO-JNET-UIP-V72.145.md`.

## Toistaminen

```sh
make BOOT_DISPLAY=vesa BOOT_NOGUI=0
python3 tools/check_release_media.py
python3 tests/v72145_ich9e_runtime.py
ICH9E145_MUTATION=no_r2_fixup python3 tests/v72145_ich9e_runtime.py   # pitää epäonnistua
python3 tests/v72145_qemu_network.py ../qemu145-net
python3 tests/v72111_qemu_navigator.py ../qemu145-nav --navigator-only --navigator143 --navigator144
```

QEMU-verkkotesti käyttää isännällä paikallisia TCP- ja UDP-kaikupalvelimia sekä `hostfwd`ia. Ulkoverkkoa ei tarvita.

## Evidenssi

`release/qa/v72.145/`: `provenance.json`, `media-check.json`, `qemu-network-result.json`, `qemu-network-baseline-v72.144-result.json`, `qemu-navigator-ps2-result.json`, sarjalokit, ajurimallin ja mutaatioiden lokit, regressiolokit ja koontiloki.
