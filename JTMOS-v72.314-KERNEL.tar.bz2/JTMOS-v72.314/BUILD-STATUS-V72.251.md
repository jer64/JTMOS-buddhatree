# JTMOS v72.251 — Physically Scattered ApplicationModule Experiment

Base: **v72.250 BSS-FIX**. This is a complete **source-only** release.
The inherited `jtm32.img`, ISO images and other boot payloads **are not v72.251 builds**.

## Design

- Virtual addresses are contiguous and page-aligned; data is backed by
  independently reserved **4 KiB physical frames** selected from the E820-aware
  bitmap with `mmClaimFreePageAfter()`. It works if no two free physical frames
  are adjacent. The allocator never requests a multi-page physical run.
- PDEs and PTEs use the existing 32-bit IA-32 page-table architecture. Each
  individual 4 KiB page-table page must be physically contiguous, but different
  page tables and page directories do not require mutual physical adjacency.
- No large contiguous frame-vector allocation is needed in the new experimental
  allocator. The owner registry is a bounded small kernel static table (64
  slots), while PTEs record the frame numbers. Teardown reads PTEs to free
  physical pages before relinquishing the virtual reservation.
- `CEXEC_FLAG_SCATTER_PHYSICAL` opts a `turbo_cexec()` stack and
  `turbo_cexec_image()` program image into this allocator. The stack has an
  *unmapped low guard page*. These CEXEC mappings are eagerly populated at
  4 KiB granularity (safe for page faults while running on the stack).
- An optional `mm_scatter_metadata_alloc()` maps the ELF32 sparse backing's
  **page-vector itself** across separate physical pages. Enable for an
  experimental whole-ELF build with
  `JTMOS_MM_SCATTER_PAGE_VECTOR=1` in `ApplicationModule_scatter.h` or as
  a compile definition. It is **off by default** pending boot/fork testing.
  Existing ELF32 program data/heap/stack are already backed by first-touch
  sparse pages in v72.250. Existing ring-3 COW and demand paging are unchanged.
- Process-exit cleanup calls `mm_app_scatter_release_pid()` to reclaim
  interrupted experimental allocations. Allocation errors roll back all PTEs
  and physical frame claims. A PTE is invalidated before its frame is freed.
- Per-process resident/virtual memory statistics include live scatter CEXEC
  regions. Memory used by unrelated legacy kernel allocations is not changed.

## Runtime smoke test (newly rebuilt kernel only)

```
scattertest
scattertest 4096
```

The command writes and reads one byte in each allocated 4 KiB page, prints
physically nonadjacent page pairs, releases the allocation, and runs a C
function on an independently mapped 64 KiB scatter-backed stack. A zero
nonadjacent-pair count on an unfragmented machine is not failure: the contract
is that no adjacency is **required**, not that adjacency is forbidden.

### Programmatic opt-in

```
CEXEC_REQUEST req = {0};
req.pid = GetCurrentThread();
req.flags = CEXEC_FLAG_SCATTER_PHYSICAL;
req.stack_size = 256 * 1024;
result = turbo_cexec(entry, argc, argv, &req);
```

You may allocate optional scatter-backed module heaps with
`mm_app_scatter_alloc(pid, bytes, 0)` and free them with
`mm_app_scatter_free(pid, pointer)`. CEXEC code remains kernel/supervisor
code; this feature does NOT constitute a new Ring-3 sandbox.

## Host validation

```
sh tests/v72251_scatter/run_host.sh
python3 tests/v72251_scatter/source_check.py
make release-check-source
```

Host test covers: 300 and 513 isolated physical pages, virtual contiguous
mapping, optional guard, separate image, full rollback after injected PTE
mapping failure or bitmap exhaustion, correct owner check, double-free
rejection, process-exit recovery, and physically scattered metadata pages.

## Limits

- IA-32 non-PAE: 4 KiB pages. This design does not enable swap or NUMA.
- Experimental CEXEC mapping max size 64 MiB per region, 64 tracked regions;
  cap is to limit IRQ/latency during early bring-up, not a contiguity limit.
- Only individual frame allocations are needed for experimental application
  backing. The rest of JTMOS still has some legacy contiguous allocations
  (e.g. boot/driver buffers and buddy pool initialization).
- No complete kernel link, NASM boot build, QEMU boot or T400 hardware run was
  possible here. Do NOT run these tests on a disk holding valuable data.
