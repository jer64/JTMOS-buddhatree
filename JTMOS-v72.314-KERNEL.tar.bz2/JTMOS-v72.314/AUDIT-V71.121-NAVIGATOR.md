# JTMOS v71.121:n auditointi ja v71.122:n korjaukset

Auditointipäivä: 20.10.2026. Lähtöaineisto: käyttäjän toimittama
`JTMOS-v71_121-FULL-SOURCE-RELEASE.zip`, SHA-256
`79e2263bca8bc1d7fb0c4291bd39fe0872d53677a10e487e0f72982c15dcb04e`.

V71.121 sisälsi kaksi toistettua muistinhallinnan virhettä Navigatorissa.
Niiden korjaus on v71.122:n tärkein muutos. Uusi julkaisu sisältää kaikki
kymmenen alla arvioitua korjausta ja niille kohdennetun testisarjan.

## Rajaus ja menetelmä

Katselmointi kohdistui viimeisimpiin v71.117–121-muutoksiin, Navigatorin
DOM-, lomake-, kuva-, SVG-, HTTP- ja GraOS-käyttöliittymäkoodiin sekä
GraOSin näyttötilan käyttöönottoon, kernelin USB-syötteeseen, idle-polkuun ja terminaalihistorian kopiointiin.
Kernelin muistinhallinnan, syscallien ja keskeytysten olemassa olevia
tarkistuksia ajettiin erikseen. ZIPin CRC ja sisäinen SHA-256-manifesti
tarkistettiin alkuperäisistä arkistotavuista ennen lähteiden muutoksia.

Host-testit käyttivät toimitettuja lähteitä, aitoa Lexbor-parseria,
AddressSanitizeria ja UndefinedBehaviorSanitizeria sekä paikallista
HTTP-palvelinta. LeakSanitizer poistettiin käytöstä, koska se ei pystynyt
lukemaan prosessitietoja tässä suoritusympäristössä. Näistä ajoista ei siis
päätellä muistivuototestauksen läpäisyä.

## Kymmenen tärkeintä Navigator/GraOS-korjausta

P1 tarkoittaa tässä ensisijaisesti korjattavaa muisti-/vakausvirhettä;
P2 tarkoittaa konkreettista toiminnallista tai yhteensopivuusvirhettä.
Viittaukset koskevat alkuperäistä v71.121-koodia, ellei toisin mainita.

| Sija | Taso | Havainto ja vaikutus | Toteutus v71.122:ssa | Todennus |
|---|---|---|---|---|
| 1 | P1 | `nav_form.c:168–197`: HTML:n `jtmos:value` käsiteltiin sisäisenä puskurina. `val_cap()` luki tavut ennen merkkijonoa kapasiteettina ja setter saattoi kirjoittaa varatun attribuutin ohi DOM-areenaan. | Tyyppinen, selaimen omistama tila DOM-solmussa; kapasiteettia ei lueta merkkijonon edestä. Reset säilyttää uudelleenkäytettävän puskurin. | Alkuperäisellä Lexbor-polulla suojatavu muuttui; korjatussa versiossa 256 suojatavua säilyy ja 500 reset/muokkauskierrosta ei kasvata areenaa. |
| 2 | P1 | `nav_image.c:47–51`: jos trim vapautti edes jotakin, jäljelle jäävää tilaa ei enää tarkistettu. Pysyvät SVG:t estivät riittävän vapautuksen. 6 MiB:n välimuisti kasvoi testissä 8 MiB:iin ja sitten 12 MiB:iin; vähennys meni unsigned-alivuotoon. | Pakollinen jälkitarkistus, turvallinen raja-aritmetiikka ja tarkistus ennen inline-SVG-rasterin varausta. | Osittainen trim + kaksi isoa SVG:tä; ylitys hylätään, tarkalleen 6 MiB hyväksytään, seuraava lisäys hylätään. |
| 3 | P1 | `kernel32/init/vesa.c:1006`: valmistellun LFB:n geometria tulkittiin jo asetetuksi näyttötilaksi. QEMU pysyi 720×400-tekstinäytössä, vaikka GraOS ilmoitti piirtävänsä 1024×768-kuvaa; tuloksena oli musta/raidallinen ruutu. | Valmiin tilan uudelleenkäyttö edellyttää BIOS-grafiikkatilaa tai aktiivista NV6150/BGA-provideria. Muuten oikea mode set suoritetaan. | Alkuperäinen polku toistettiin QEMUssa. Aidon C-funktion host-malli kattaa prepared/active/BIOS/mapping-tapaukset; lopullisessa QEMU-kokeessa todettiin oikea 1024×768 GraOS-työpöytä ja Navigatorin testisivu. |
| 4 | P1 | `navigator.c`: `popup_sel` jäi viittaamaan vanhaan DOMiin navigoinnin ja näkymän uudelleenrakennuksen yli. Myös saman URLin haku-/valintatila saattoi jäädä vanhaan asetteluun. | Yhteinen `page_ui_reset()` ennen jokaista dokumentin vapautusta ja navigoinnin alussa. | Testi kääntää oikean GraOS-asiakkaan cleanup-funktion hostille; lisäksi jokainen vapautuskohta tarkistetaan. Varsinaista koko GraOS-tapahtumasilmukkaa ei emuloida tässä testissä. |
| 5 | P2 | `nav_layout.c:730–755`: kentän piirto käytti 160 tavun puskuria, vaikka muokkaus ja lähetys tukivat 4095 tavua. Pitkän kentän uudet merkit katosivat näkyvistä. | Koko tuettu arvo piirtoon, loppuun vieritys ja kentän sisäinen rajaus. Salasanapeite lasketaan Unicode-merkeistä. | Todellinen DOM/asettelu: 301. merkki Z pysyy näkyvissä aktiivisessa 180 px:n kentässä. |
| 6 | P2 | `nav_form.c:198–222`: Backspace ohitti readonly/disabled-ehdot ja monimerkkinen liittäminen ohitti maxlengthin. | Yhteinen muokkauskielto kaikille näppäinmuutoksille; liitteen rajaus UTF-8-rajoilla ja HTML:n UTF-16-yksiköissä. | Kirjoitus/poisto estettyihin kenttiin; ääkkösliittäminen, emoji ja täysi kenttä. |
| 7 | P2 | `nav_form.c:224–243`: radionappien nimet vertailtiin kirjainkoosta riippumatta, ja lomakkeen ulkopuolisia `form=id`-kenttiä ei ryhmitelty oikein. | Täsmällinen nimi ja sama lomakeomistaja, koko dokumentin läpikäynti. | `choice`/`Choice`, eri lomakkeet ja ulkoinen samaan lomakkeeseen kuuluva radio. |
| 8 | P2 | `nav_form.c:158–166,247–254,303–325`: optgroupin disabled ei estänyt valintaa ja disabled-option voitiin lähettää. | Yhteinen option/optgroup-esto, käytössä olevan oletuksen valinta ja lähetyksen suodatus. | Estetty ryhmä ei ole valittavissa; estetty valinta puuttuu kyselystä. |
| 9 | P2 | `nav_form.c:359`: suhteellinen action ratkaistiin sivun URLia vasten ja `<base href>` ohitettiin. Lomake meni väärään osoitteeseen. | Ei-tyhjä action käyttää DOMin base-URLia; tyhjä action dokumentin URLia. | Eri isäntään/hakemistoon osoittava base ja tyhjä action tarkistetaan erikseen. |
| 10 | P2 | `nav_network.c:386–419`: ensimmäinen 100/103 käsiteltiin lopullisena, ja muu onnistuminen kuin 200 hylättiin. | Rajattu väliotsakkeiden käsittely, 2xx-vastaukset ja 204/205:n dokumentin säilytys. Välimuistiosuman URL-kopion kokotarkistus lisättiin. | Oikea localhost-liikenne: 100+103+200 samassa/split-puskurissa, POST/201, 202, avoin 204/205-yhteys, liian monet väliotsakkeet, 101:n hylkäys, pieni URL-puskuri. |

Muistivirheiden testit osoittivat Navigator-prosessin muistirajojen rikkoutumisen.
Auditoinnissa ei osoitettu kernelin hallinnan kaappausta eikä näitä virheitä
testattu eMachines-laitteella.

## Julkaisuarkiston muut havainnot

ZIPin CRC-tarkistus oli kunnossa: pakkaus ei ollut rikkoutunut. Sen sisäinen
`MANIFEST-SHA256.txt` oli vanhentunut: 10 047 merkinnästä 69 viittasi puuttuvaan
tiedostoon ja 64 tiedoston summa ei vastannut arkistoa. Lisäksi 225 arkiston
tiedostoa puuttui manifestista. Mukana oli esimerkiksi VERSIONin, Makefilen,
USB-syötekoodin ja Navigator-tiedostojen vanhoja summia. Nämä luvut tarkistettiin
suoraan alkuperäisestä ZIPistä, joten auditoinnin käännökset eivät vaikuta niihin.
V71.122:n manifesti luodaan vasta lopullisesta toimitettavasta puusta ja
varmennetaan vielä uuden ZIPin sisältä.

Navigatorin pakettirakentaja oli lukittu versioon 71.112 ja oletusarvoisesti
rakensi WebP:n pois käytöstä. Rakentaja on muutettu seuraamaan VERSIONia ja
nykyistä WebP-oletusta. Alkuperäinen tiedosto säilyy lähtö-ZIPissä. SQA-keräilijä ohittaa nyt
rsyncin `.rsync-tmp`-työhakemiston, joka aiheutti yhdessä uusinta-ajossa
virheellisen duplikaattinimen; oikeiden duplikaattinimien hylkäys säilyi
ja molemmat tapaukset testattiin.

## Kernelin ja koko projektin tarkistukset

Kernelin 343 C-käännösyksikön syntaksitarkistus onnistui. Siinä näkyi kaksi
ennestään olevaa `SchedulerWaitPause`-prototyyppivaroitusta
(`secure_random.c` ja `jt_sntp.c`). Syscall-IRQ-, NMI-, ISR- ja GDT/TSS-
tarkistukset läpäisivät ajot. Tarkastetusta idle-polusta ei saatu todennettua
uutta vikaa. GraOSin näyttötilan käyttöönoton vika löytyi erillisessä
QEMU-kokeessa ja korjattiin yllä kuvatusti.

Koko projektin `make check` ei ollut vihreä: se pysähtyi vanhaan
`check_v68175_idle_graos.sh`-testiin, joka edellyttää jo korvattua HLT64-vakiota
nykyisten FAST=16/SLOW=64-vakioiden sijaan. Erikseen ajetuista testeistä
`v7143_dynamic_app_memory.py` odottaa yhä GraOSilta 512 KiB:n varausta, vaikka
julkaisu pyytää 16 MiB. `v7068_terminal_screen_vga_graos_audit.py` odottaa vanhaa
80×25-toteutusta ja `v6915_idle_hdled_hdbench.py` vanhaa LED-koodin merkkijonoa.

USB:n host-regressiotesti ei kääntynyt: testin MOUSE-stubista puuttuu wheel,
ja uusi repeat-funktio tuottaa LP64-hostilla varoituksia, joita testin -Werror
käsittelee virheenä. Natiivin i686-kernelin koko käännös onnistui. V71.122 ei
väitä koko vanhan `make check` -ketjun läpäisyä; yllä olevat testien
ylläpitovelat on kirjattu erikseen Navigatorin kymmenestä korjauksesta.

## Korjatun julkaisun varmennus

- `tests/run-v71122-navigator-ci.sh`: PASS (ASan/UBSan; LSan pois käytöstä).
- `tests/run-v71120-navigator-ci.sh`: PASS, myös 8000 SVG-muunnosta ja kuva-
  referenssit sekä todellinen POST/303/307-liikenne.
- `tests/run-v71116-navigator-render.sh`: PASS.
- `tests/run-v71112-navigator-ci.sh`: PASS, koko vanha ketju mukaan lukien
  1611 vektorifontti/CSS-tarkistusta ja JPEG-referenssit.
- Täysi päätason `make`: PASS; BIOS-levykuva, root-levykuva, utilities.iso ja
  täysi DOSBOOT syntyivät samasta v71.122-puusta.
- Navigatorin ELF32- ja kernelin käynnistysvalidaattorit: PASS.
- Yksityiskohtaiset lokit ja QEMU-smoken tulos: `QA-V71.122.md` ja
  `release/qa/v71.122/`.
