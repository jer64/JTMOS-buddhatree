# JTMOS v72.149 – QA

Päiväys 26.10.2026. Pohjana on kokonainen v72.148-lähdepaketti (SHA-256 `2a22eb1d…f68849`).

| Tarkistus | Tulos |
|---|---|
| Natiivi koonti | PASS. Kernelin 1 MiB:n ikkunassa vapaana 84 772 tavua (raja 65 536). |
| Media, mediavahti ja Navigatorin preflight | PASS |
| tcpdumpin purkajat, isäntä, ASan/UBSan | PASS, 22 tarkistusta, joista yksi on 2 000 sumutetun kehyksen ajo |
| QEMU, tcpdump eläviä kehyksiä vastaan | PASS 5/5: perustaso (SYN sisään, RST ulos), `-v` + tcp, `-vv` + udp port, `-vvv` heksavedos, neljä peräkkäistä avausta ja sulkua |
| QEMU-verkkoregressio, NE2000 | PASS 10/10 |
| ICH9E-ajurimalli | PASS |

QEMU-ajon tcpdump-tulosteet ovat hakemistossa `release/qa/v72.149/`.
